from sqlalchemy.ext.declarative import declarative_base
SchemaBase = declarative_base()
