from sqlalchemy import Column, Index
from .__base__ import SchemaBase
from sqlalchemy.dialects.postgresql import DOUBLE_PRECISION, TEXT, VARCHAR, INTEGER, BOOLEAN, BIGINT, JSONB, BYTEA


class NlpAttributeDb(SchemaBase):
    __tablename__ = "nlp_attribute_db"
    id = Column(VARCHAR(128), primary_key=True, nullable=False)
    doc_id = Column(TEXT)
    link_id = Column(TEXT)
    link_id_level2 = Column(TEXT)
    link_id_level3 = Column(TEXT)
    link_id_level4 = Column(TEXT)
    link_id_level5 = Column(TEXT)
    link_id_level6 = Column(TEXT)
    link_id_subsection1 = Column(TEXT)
    link_id_subsection2 = Column(TEXT)
    link_id_subsection3 = Column(TEXT)
    hierarchy = Column(VARCHAR(128), primary_key=True, nullable=False)
    iqv_standard_term = Column(TEXT)
    parent_id = Column(TEXT)
    group_type = Column(TEXT)
    process_source = Column(TEXT)
    text = Column(TEXT)
    attribute_class = Column(TEXT)
    attribute_index = Column(TEXT)
    start = Column(INTEGER, nullable=False)


Index('nlp_attribute_db_doc_id', NlpAttributeDb.doc_id)
Index('nlp_attribute_db_doc_id_hierarchy',
      NlpAttributeDb.doc_id, NlpAttributeDb.hierarchy)
Index('nlp_attribute_db_iqv_standard_term', NlpAttributeDb.iqv_standard_term)
Index('nlp_attribute_db_link_id', NlpAttributeDb.link_id)
Index('nlp_attribute_db_link_id_level2', NlpAttributeDb.link_id_level2)
Index('nlp_attribute_db_link_id_level3', NlpAttributeDb.link_id_level3)
Index('nlp_attribute_db_link_id_level4', NlpAttributeDb.link_id_level4)
Index('nlp_attribute_db_link_id_level5', NlpAttributeDb.link_id_level5)
Index('nlp_attribute_db_link_id_level6', NlpAttributeDb.link_id_level6)
Index('nlp_attribute_db_link_id_subsection1',
      NlpAttributeDb.link_id_subsection1)
Index('nlp_attribute_db_link_id_subsection2',
      NlpAttributeDb.link_id_subsection2)
Index('nlp_attribute_db_link_id_subsection3',
      NlpAttributeDb.link_id_subsection3)
Index('nlp_attribute_db_parent_id',
      NlpAttributeDb.parent_id, NlpAttributeDb.group_type)
Index('nlp_attribute_db_parent_id_hierarchy', NlpAttributeDb.parent_id,
      NlpAttributeDb.hierarchy, NlpAttributeDb.group_type)
