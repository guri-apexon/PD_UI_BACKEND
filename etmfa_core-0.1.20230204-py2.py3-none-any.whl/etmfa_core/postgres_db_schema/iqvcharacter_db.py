from sqlalchemy import Column, Index
from .__base__ import SchemaBase
from sqlalchemy.dialects.postgresql import DOUBLE_PRECISION, TEXT, VARCHAR, INTEGER, BOOLEAN, BIGINT, JSONB, BYTEA


class IqvcharacterDb(SchemaBase):
    __tablename__ = "iqvcharacter_db"
    id = Column(VARCHAR(128), primary_key=True, nullable=False)
    doc_id = Column(TEXT)
    link_id = Column(TEXT)
    link_id_level2 = Column(TEXT)
    link_id_level3 = Column(TEXT)
    link_id_level4 = Column(TEXT)
    link_id_level5 = Column(TEXT)
    link_id_level6 = Column(TEXT)
    link_id_subsection1 = Column(TEXT)
    link_id_subsection2 = Column(TEXT)
    link_id_subsection3 = Column(TEXT)
    hierarchy = Column(VARCHAR(128), primary_key=True, nullable=False)
    iqv_standard_term = Column(TEXT)
    parent_id = Column(TEXT)
    group_type = Column(TEXT)
    Bottom = Column(INTEGER, nullable=False)
    Left = Column(INTEGER, nullable=False)
    Right = Column(INTEGER, nullable=False)
    Tag = Column(TEXT)
    Top = Column(INTEGER, nullable=False)
    Value = Column(INTEGER, nullable=False)


Index('iqvcharacter_db_doc_id', IqvcharacterDb.doc_id)
Index('iqvcharacter_db_doc_id_hierarchy',
      IqvcharacterDb.doc_id, IqvcharacterDb.hierarchy)
Index('iqvcharacter_db_iqv_standard_term', IqvcharacterDb.iqv_standard_term)
Index('iqvcharacter_db_link_id', IqvcharacterDb.link_id)
Index('iqvcharacter_db_link_id_level2', IqvcharacterDb.link_id_level2)
Index('iqvcharacter_db_link_id_level3', IqvcharacterDb.link_id_level3)
Index('iqvcharacter_db_link_id_level4', IqvcharacterDb.link_id_level4)
Index('iqvcharacter_db_link_id_level5', IqvcharacterDb.link_id_level5)
Index('iqvcharacter_db_link_id_level6', IqvcharacterDb.link_id_level6)
Index('iqvcharacter_db_link_id_subsection1',
      IqvcharacterDb.link_id_subsection1)
Index('iqvcharacter_db_link_id_subsection2',
      IqvcharacterDb.link_id_subsection2)
Index('iqvcharacter_db_link_id_subsection3',
      IqvcharacterDb.link_id_subsection3)
Index('iqvcharacter_db_parent_id',
      IqvcharacterDb.parent_id, IqvcharacterDb.group_type)
Index('iqvcharacter_db_parent_id_hierarchy', IqvcharacterDb.parent_id,
      IqvcharacterDb.hierarchy, IqvcharacterDb.group_type)
