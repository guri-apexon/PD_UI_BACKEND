from sqlalchemy import Column, Index
from .__base__ import SchemaBase
from sqlalchemy.dialects.postgresql import DOUBLE_PRECISION, TEXT, VARCHAR, INTEGER, BOOLEAN, BIGINT, JSONB, BYTEA


class IqvdocumentfeedbackqcDb(SchemaBase):
    __tablename__ = "iqvdocumentfeedbackqc_db"
    id = Column(VARCHAR(128), primary_key=True, nullable=False)
    doc_id = Column(TEXT)
    link_id = Column(TEXT)
    link_id_level2 = Column(TEXT)
    link_id_level3 = Column(TEXT)
    link_id_level4 = Column(TEXT)
    link_id_level5 = Column(TEXT)
    link_id_level6 = Column(TEXT)
    link_id_subsection1 = Column(TEXT)
    link_id_subsection2 = Column(TEXT)
    link_id_subsection3 = Column(TEXT)
    hierarchy = Column(VARCHAR(128), primary_key=True, nullable=False)
    iqv_standard_term = Column(TEXT)
    parent_id = Column(TEXT)
    group_type = Column(TEXT)
    timeCreated = Column(TEXT)
    timeUpdated = Column(TEXT)
    userId = Column(TEXT)
    source_system = Column(TEXT)
    fileName = Column(TEXT)
    documentFilePath = Column(TEXT)
    bIsActive = Column(BOOLEAN, nullable=False)


Index('iqvdocumentfeedbackqc_db_doc_id', IqvdocumentfeedbackqcDb.doc_id)
Index('iqvdocumentfeedbackqc_db_doc_id_hierarchy',
      IqvdocumentfeedbackqcDb.doc_id, IqvdocumentfeedbackqcDb.hierarchy)
Index('iqvdocumentfeedbackqc_db_iqv_standard_term',
      IqvdocumentfeedbackqcDb.iqv_standard_term)
Index('iqvdocumentfeedbackqc_db_link_id', IqvdocumentfeedbackqcDb.link_id)
Index('iqvdocumentfeedbackqc_db_link_id_level2',
      IqvdocumentfeedbackqcDb.link_id_level2)
Index('iqvdocumentfeedbackqc_db_link_id_level3',
      IqvdocumentfeedbackqcDb.link_id_level3)
Index('iqvdocumentfeedbackqc_db_link_id_level4',
      IqvdocumentfeedbackqcDb.link_id_level4)
Index('iqvdocumentfeedbackqc_db_link_id_level5',
      IqvdocumentfeedbackqcDb.link_id_level5)
Index('iqvdocumentfeedbackqc_db_link_id_level6',
      IqvdocumentfeedbackqcDb.link_id_level6)
Index('iqvdocumentfeedbackqc_db_link_id_subsection1',
      IqvdocumentfeedbackqcDb.link_id_subsection1)
Index('iqvdocumentfeedbackqc_db_link_id_subsection2',
      IqvdocumentfeedbackqcDb.link_id_subsection2)
Index('iqvdocumentfeedbackqc_db_link_id_subsection3',
      IqvdocumentfeedbackqcDb.link_id_subsection3)
Index('iqvdocumentfeedbackqc_db_parent_id',
      IqvdocumentfeedbackqcDb.parent_id, IqvdocumentfeedbackqcDb.group_type)
Index('iqvdocumentfeedbackqc_db_parent_id_hierarchy', IqvdocumentfeedbackqcDb.parent_id,
      IqvdocumentfeedbackqcDb.hierarchy, IqvdocumentfeedbackqcDb.group_type)
