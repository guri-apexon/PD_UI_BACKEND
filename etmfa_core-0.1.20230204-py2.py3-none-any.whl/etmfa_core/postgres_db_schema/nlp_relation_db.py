from sqlalchemy import Column, Index
from .__base__ import SchemaBase
from sqlalchemy.dialects.postgresql import DOUBLE_PRECISION, TEXT, VARCHAR, INTEGER, BOOLEAN, BIGINT, JSONB, BYTEA


class NlpRelationDb(SchemaBase):
    __tablename__ = "nlp_relation_db"
    id = Column(VARCHAR(128), primary_key=True, nullable=False)
    doc_id = Column(TEXT)
    link_id = Column(TEXT)
    link_id_level2 = Column(TEXT)
    link_id_level3 = Column(TEXT)
    link_id_level4 = Column(TEXT)
    link_id_level5 = Column(TEXT)
    link_id_level6 = Column(TEXT)
    link_id_subsection1 = Column(TEXT)
    link_id_subsection2 = Column(TEXT)
    link_id_subsection3 = Column(TEXT)
    hierarchy = Column(VARCHAR(128), primary_key=True, nullable=False)
    iqv_standard_term = Column(TEXT)
    parent_id = Column(TEXT)
    group_type = Column(TEXT)
    confidence = Column(DOUBLE_PRECISION, nullable=False)
    process_source = Column(TEXT)
    relation_type = Column(TEXT)
    relation_name = Column(TEXT)
    is_hierarchical = Column(INTEGER, nullable=False)
    is_bidirectional = Column(INTEGER, nullable=False)
    entities_list = Column(TEXT)


Index('nlp_relation_db_doc_id', NlpRelationDb.doc_id)
Index('nlp_relation_db_doc_id_hierarchy',
      NlpRelationDb.doc_id, NlpRelationDb.hierarchy)
Index('nlp_relation_db_iqv_standard_term', NlpRelationDb.iqv_standard_term)
Index('nlp_relation_db_link_id', NlpRelationDb.link_id)
Index('nlp_relation_db_link_id_level2', NlpRelationDb.link_id_level2)
Index('nlp_relation_db_link_id_level3', NlpRelationDb.link_id_level3)
Index('nlp_relation_db_link_id_level4', NlpRelationDb.link_id_level4)
Index('nlp_relation_db_link_id_level5', NlpRelationDb.link_id_level5)
Index('nlp_relation_db_link_id_level6', NlpRelationDb.link_id_level6)
Index('nlp_relation_db_link_id_subsection1', NlpRelationDb.link_id_subsection1)
Index('nlp_relation_db_link_id_subsection2', NlpRelationDb.link_id_subsection2)
Index('nlp_relation_db_link_id_subsection3', NlpRelationDb.link_id_subsection3)
Index('nlp_relation_db_parent_id',
      NlpRelationDb.parent_id, NlpRelationDb.group_type)
Index('nlp_relation_db_parent_id_hierarchy', NlpRelationDb.parent_id,
      NlpRelationDb.hierarchy, NlpRelationDb.group_type)
