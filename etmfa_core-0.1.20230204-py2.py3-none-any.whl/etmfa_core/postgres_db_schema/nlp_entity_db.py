from sqlalchemy import Column, Index
from .__base__ import SchemaBase
from sqlalchemy.dialects.postgresql import DOUBLE_PRECISION, TEXT, VARCHAR, INTEGER, BOOLEAN, BIGINT, JSONB, BYTEA


class NlpEntityDb(SchemaBase):
    __tablename__ = "nlp_entity_db"
    id = Column(VARCHAR(128), primary_key=True, nullable=False)
    doc_id = Column(TEXT)
    link_id = Column(TEXT)
    link_id_level2 = Column(TEXT)
    link_id_level3 = Column(TEXT)
    link_id_level4 = Column(TEXT)
    link_id_level5 = Column(TEXT)
    link_id_level6 = Column(TEXT)
    link_id_subsection1 = Column(TEXT)
    link_id_subsection2 = Column(TEXT)
    link_id_subsection3 = Column(TEXT)
    hierarchy = Column(VARCHAR(128), primary_key=True, nullable=False)
    iqv_standard_term = Column(TEXT)
    parent_id = Column(TEXT)
    group_type = Column(TEXT)
    process_source = Column(TEXT)
    text = Column(TEXT)
    dts = Column(TEXT)
    user_id = Column(TEXT)
    entity_key = Column(TEXT)
    entity_class = Column(TEXT)
    entity_index = Column(TEXT)
    negated = Column(TEXT)
    ontology = Column(TEXT)
    ontology_version = Column(TEXT)
    ontology_item_code = Column(TEXT)
    standard_entity_name = Column(TEXT)
    confidence = Column(DOUBLE_PRECISION, nullable=False)
    start = Column(INTEGER, nullable=False)
    text_len = Column(INTEGER, nullable=False)


Index('nlp_entity_db_doc_id', NlpEntityDb.doc_id)
Index('nlp_entity_db_doc_id_hierarchy',
      NlpEntityDb.doc_id, NlpEntityDb.hierarchy)
Index('nlp_entity_db_iqv_standard_term', NlpEntityDb.iqv_standard_term)
Index('nlp_entity_db_link_id', NlpEntityDb.link_id)
Index('nlp_entity_db_link_id_level2', NlpEntityDb.link_id_level2)
Index('nlp_entity_db_link_id_level3', NlpEntityDb.link_id_level3)
Index('nlp_entity_db_link_id_level4', NlpEntityDb.link_id_level4)
Index('nlp_entity_db_link_id_level5', NlpEntityDb.link_id_level5)
Index('nlp_entity_db_link_id_level6', NlpEntityDb.link_id_level6)
Index('nlp_entity_db_link_id_subsection1', NlpEntityDb.link_id_subsection1)
Index('nlp_entity_db_link_id_subsection2', NlpEntityDb.link_id_subsection2)
Index('nlp_entity_db_link_id_subsection3', NlpEntityDb.link_id_subsection3)
Index('nlp_entity_db_parent_id', NlpEntityDb.parent_id, NlpEntityDb.group_type)
Index('nlp_entity_db_parent_id_hierarchy', NlpEntityDb.parent_id,
      NlpEntityDb.hierarchy, NlpEntityDb.group_type)
