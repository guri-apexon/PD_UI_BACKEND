from sqlalchemy import Column, Index
from .__base__ import SchemaBase
from sqlalchemy.dialects.postgresql import DOUBLE_PRECISION, TEXT, VARCHAR, INTEGER, BOOLEAN, BIGINT, JSONB, BYTEA


class IqvdocumentprocessDb(SchemaBase):
    __tablename__ = "iqvdocumentprocess_db"
    id = Column(VARCHAR(128), primary_key=True, nullable=False)
    doc_id = Column(TEXT)
    link_id = Column(TEXT)
    link_id_level2 = Column(TEXT)
    link_id_level3 = Column(TEXT)
    link_id_level4 = Column(TEXT)
    link_id_level5 = Column(TEXT)
    link_id_level6 = Column(TEXT)
    link_id_subsection1 = Column(TEXT)
    link_id_subsection2 = Column(TEXT)
    link_id_subsection3 = Column(TEXT)
    hierarchy = Column(VARCHAR(128), nullable=False)
    iqv_standard_term = Column(TEXT)
    parent_id = Column(TEXT)
    group_type = Column(TEXT)
    ProcessName = Column(TEXT)
    ProcessType = Column(TEXT)
    ProcessVersion = Column(TEXT)
    ProcessVersionHash = Column(TEXT)
    bProcessRequired = Column(BOOLEAN, nullable=False)
    ProcessStartTime = Column(TEXT)
    ProcessFinishTime = Column(TEXT)
    ProcessMachineName = Column(TEXT)
    ProcessUserID = Column(TEXT)
    ProcessEnvironment = Column(TEXT)


Index('iqvdocumentprocess_db_doc_id', IqvdocumentprocessDb.doc_id)
Index('iqvdocumentprocess_db_doc_id_hierarchy',
      IqvdocumentprocessDb.doc_id, IqvdocumentprocessDb.hierarchy)
Index('iqvdocumentprocess_db_iqv_standard_term',
      IqvdocumentprocessDb.iqv_standard_term)
Index('iqvdocumentprocess_db_link_id', IqvdocumentprocessDb.link_id)
Index('iqvdocumentprocess_db_link_id_level2',
      IqvdocumentprocessDb.link_id_level2)
Index('iqvdocumentprocess_db_link_id_level3',
      IqvdocumentprocessDb.link_id_level3)
Index('iqvdocumentprocess_db_link_id_level4',
      IqvdocumentprocessDb.link_id_level4)
Index('iqvdocumentprocess_db_link_id_level5',
      IqvdocumentprocessDb.link_id_level5)
Index('iqvdocumentprocess_db_link_id_level6',
      IqvdocumentprocessDb.link_id_level6)
Index('iqvdocumentprocess_db_link_id_subsection1',
      IqvdocumentprocessDb.link_id_subsection1)
Index('iqvdocumentprocess_db_link_id_subsection2',
      IqvdocumentprocessDb.link_id_subsection2)
Index('iqvdocumentprocess_db_link_id_subsection3',
      IqvdocumentprocessDb.link_id_subsection3)
Index('iqvdocumentprocess_db_parent_id',
      IqvdocumentprocessDb.parent_id, IqvdocumentprocessDb.group_type)
Index('iqvdocumentprocess_db_parent_id_hierarchy', IqvdocumentprocessDb.parent_id,
      IqvdocumentprocessDb.hierarchy, IqvdocumentprocessDb.group_type)
