from sqlalchemy import Column, Index
from .__base__ import SchemaBase
from sqlalchemy.dialects.postgresql import DOUBLE_PRECISION, TEXT, VARCHAR, INTEGER, BOOLEAN, BIGINT, JSONB, BYTEA


class IqvsubtextDb(SchemaBase):
    __tablename__ = "iqvsubtext_db"
    id = Column(VARCHAR(128), primary_key=True, nullable=False)
    doc_id = Column(TEXT)
    link_id = Column(TEXT)
    link_id_level2 = Column(TEXT)
    link_id_level3 = Column(TEXT)
    link_id_level4 = Column(TEXT)
    link_id_level5 = Column(TEXT)
    link_id_level6 = Column(TEXT)
    link_id_subsection1 = Column(TEXT)
    link_id_subsection2 = Column(TEXT)
    link_id_subsection3 = Column(TEXT)
    hierarchy = Column(VARCHAR(128), primary_key=True, nullable=False)
    iqv_standard_term = Column(TEXT)
    parent_id = Column(TEXT)
    group_type = Column(TEXT)
    bNoTranslate = Column(BOOLEAN, nullable=False)
    reservedTypeVal = Column(INTEGER, nullable=False)
    parent2LocalName = Column(TEXT)
    Value = Column(TEXT)
    OuterXml = Column(TEXT)
    strText = Column(TEXT)
    strTranslatedText = Column(TEXT)
    runElementName = Column(TEXT)
    DocumentSequenceIndex = Column(INTEGER, nullable=False)
    sequence = Column(INTEGER, nullable=False)
    startCharIndex = Column(INTEGER, nullable=False)


Index('iqvsubtext_db_doc_id', IqvsubtextDb.doc_id)
Index('iqvsubtext_db_doc_id_hierarchy',
      IqvsubtextDb.doc_id, IqvsubtextDb.hierarchy)
Index('iqvsubtext_db_iqv_standard_term', IqvsubtextDb.iqv_standard_term)
Index('iqvsubtext_db_link_id', IqvsubtextDb.link_id)
Index('iqvsubtext_db_link_id_level2', IqvsubtextDb.link_id_level2)
Index('iqvsubtext_db_link_id_level3', IqvsubtextDb.link_id_level3)
Index('iqvsubtext_db_link_id_level4', IqvsubtextDb.link_id_level4)
Index('iqvsubtext_db_link_id_level5', IqvsubtextDb.link_id_level5)
Index('iqvsubtext_db_link_id_level6', IqvsubtextDb.link_id_level6)
Index('iqvsubtext_db_link_id_subsection1', IqvsubtextDb.link_id_subsection1)
Index('iqvsubtext_db_link_id_subsection2', IqvsubtextDb.link_id_subsection2)
Index('iqvsubtext_db_link_id_subsection3', IqvsubtextDb.link_id_subsection3)
Index('iqvsubtext_db_parent_id', IqvsubtextDb.parent_id, IqvsubtextDb.group_type)
Index('iqvsubtext_db_parent_id_hierarchy', IqvsubtextDb.parent_id,
      IqvsubtextDb.hierarchy, IqvsubtextDb.group_type)
