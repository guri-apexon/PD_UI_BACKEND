from sqlalchemy import Column, Index
from .__base__ import SchemaBase
from sqlalchemy.dialects.postgresql import DOUBLE_PRECISION, TEXT, VARCHAR, INTEGER, BOOLEAN, BIGINT, JSONB, BYTEA


class DocumentparagraphsDb(SchemaBase):
    __tablename__ = "documentparagraphs_db"
    id = Column(VARCHAR(128), name='PK_public.documentparagraphs_db',
                primary_key=True, nullable=False)
    __table_args__ = {"postgresql_inherits": "iqvpageroi_db"}
