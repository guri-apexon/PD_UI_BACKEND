from sqlalchemy import Column, Index
from .__base__ import SchemaBase
from sqlalchemy.dialects.postgresql import DOUBLE_PRECISION, TEXT, VARCHAR, INTEGER, BOOLEAN, BIGINT, JSONB, BYTEA


class IqvdocumentlinkDb(SchemaBase):
    __tablename__ = "iqvdocumentlink_db"
    id = Column(VARCHAR(128), primary_key=True, nullable=False)
    doc_id = Column(TEXT)
    link_id = Column(TEXT)
    link_id_level2 = Column(TEXT)
    link_id_level3 = Column(TEXT)
    link_id_level4 = Column(TEXT)
    link_id_level5 = Column(TEXT)
    link_id_level6 = Column(TEXT)
    link_id_subsection1 = Column(TEXT)
    link_id_subsection2 = Column(TEXT)
    link_id_subsection3 = Column(TEXT)
    hierarchy = Column(VARCHAR(128), nullable=False)
    iqv_standard_term = Column(TEXT)
    parent_id = Column(TEXT)
    group_type = Column(TEXT)
    LinkType = Column(TEXT)
    DocumentSequenceIndex = Column(INTEGER, nullable=False)
    LinkPage = Column(INTEGER, nullable=False)
    LinkLevel = Column(INTEGER, nullable=False)
    LinkText = Column(TEXT)
    LinkPrefix = Column(TEXT)


Index('iqvdocumentlink_db_doc_id', IqvdocumentlinkDb.doc_id)
Index('iqvdocumentlink_db_doc_id_hierarchy',
      IqvdocumentlinkDb.doc_id, IqvdocumentlinkDb.hierarchy)
Index('iqvdocumentlink_db_iqv_standard_term',
      IqvdocumentlinkDb.iqv_standard_term)
Index('iqvdocumentlink_db_link_id', IqvdocumentlinkDb.link_id)
Index('iqvdocumentlink_db_link_id_level2', IqvdocumentlinkDb.link_id_level2)
Index('iqvdocumentlink_db_link_id_level3', IqvdocumentlinkDb.link_id_level3)
Index('iqvdocumentlink_db_link_id_level4', IqvdocumentlinkDb.link_id_level4)
Index('iqvdocumentlink_db_link_id_level5', IqvdocumentlinkDb.link_id_level5)
Index('iqvdocumentlink_db_link_id_level6', IqvdocumentlinkDb.link_id_level6)
Index('iqvdocumentlink_db_link_id_subsection1',
      IqvdocumentlinkDb.link_id_subsection1)
Index('iqvdocumentlink_db_link_id_subsection2',
      IqvdocumentlinkDb.link_id_subsection2)
Index('iqvdocumentlink_db_link_id_subsection3',
      IqvdocumentlinkDb.link_id_subsection3)
Index('iqvdocumentlink_db_parent_id',
      IqvdocumentlinkDb.parent_id, IqvdocumentlinkDb.group_type)
Index('iqvdocumentlink_db_parent_id_hierarchy', IqvdocumentlinkDb.parent_id,
      IqvdocumentlinkDb.hierarchy, IqvdocumentlinkDb.group_type)
