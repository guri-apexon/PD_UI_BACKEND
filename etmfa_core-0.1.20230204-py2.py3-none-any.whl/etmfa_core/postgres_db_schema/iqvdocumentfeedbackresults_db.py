from sqlalchemy import Column, Index
from .__base__ import SchemaBase
from sqlalchemy.dialects.postgresql import DOUBLE_PRECISION, TEXT, VARCHAR, INTEGER, BOOLEAN, BIGINT, JSONB, BYTEA


class IqvdocumentfeedbackresultsDb(SchemaBase):
    __tablename__ = "iqvdocumentfeedbackresults_db"
    id = Column(VARCHAR(128), primary_key=True, nullable=False)
    doc_id = Column(TEXT)
    link_id = Column(TEXT)
    link_id_level2 = Column(TEXT)
    link_id_level3 = Column(TEXT)
    link_id_level4 = Column(TEXT)
    link_id_level5 = Column(TEXT)
    link_id_level6 = Column(TEXT)
    link_id_subsection1 = Column(TEXT)
    link_id_subsection2 = Column(TEXT)
    link_id_subsection3 = Column(TEXT)
    hierarchy = Column(VARCHAR(128), nullable=False)
    iqv_standard_term = Column(TEXT)
    parent_id = Column(TEXT)
    group_type = Column(TEXT)
    iqvdata = Column(TEXT)
    date_time_stamp = Column(TEXT)
    user_id = Column(TEXT)
    post_data = Column(TEXT)
    expiry_date = Column(TEXT)
    expiry_date_confidence = Column(DOUBLE_PRECISION, nullable=False)
    document_id = Column(TEXT)
    ref_id = Column(TEXT)
    ref_id_type = Column(TEXT)
    document_composite_confidence = Column(DOUBLE_PRECISION, nullable=False)
    alcoac_check_composite_score = Column(DOUBLE_PRECISION, nullable=False)
    alcoac_check_composite_score_confidence = Column(
        DOUBLE_PRECISION, nullable=False)
    feedback_source = Column(TEXT)
    feedback_source_version = Column(TEXT)
    tmf_environment = Column(TEXT)
    customer = Column(TEXT)
    environment = Column(TEXT)
    source_system = Column(TEXT)
    sponsor = Column(TEXT)
    protocol = Column(TEXT)
    project_id = Column(TEXT)
    amendment_number = Column(TEXT)
    draft_number = Column(TEXT)
    version_number = Column(TEXT)
    document_status = Column(TEXT)
    source_filename = Column(TEXT)
    study_status = Column(TEXT)
    molecule_device = Column(TEXT)
    indication = Column(TEXT)
    country = Column(TEXT)
    site = Column(TEXT)
    document_class = Column(TEXT)
    document_date = Column(TEXT)
    document_date_confidence = Column(DOUBLE_PRECISION, nullable=False)
    document_date_type = Column(TEXT)
    language = Column(TEXT)
    language_confidence = Column(DOUBLE_PRECISION, nullable=False)
    name = Column(TEXT)
    name_confidence = Column(DOUBLE_PRECISION, nullable=False)
    subject = Column(TEXT)
    subject_confidence = Column(DOUBLE_PRECISION, nullable=False)
    document_rejected = Column(TEXT)
    received_date = Column(TEXT)
    tmf_ibr = Column(TEXT)
    priority = Column(TEXT)
    blinded = Column(BOOLEAN, nullable=False)


Index('iqvdocumentfeedbackresults_db_doc_id',
      IqvdocumentfeedbackresultsDb.doc_id)
Index('iqvdocumentfeedbackresults_db_doc_id_hierarchy',
      IqvdocumentfeedbackresultsDb.doc_id, IqvdocumentfeedbackresultsDb.hierarchy)
Index('iqvdocumentfeedbackresults_db_iqv_standard_term',
      IqvdocumentfeedbackresultsDb.iqv_standard_term)
Index('iqvdocumentfeedbackresults_db_link_id',
      IqvdocumentfeedbackresultsDb.link_id)
Index('iqvdocumentfeedbackresults_db_link_id_level2',
      IqvdocumentfeedbackresultsDb.link_id_level2)
Index('iqvdocumentfeedbackresults_db_link_id_level3',
      IqvdocumentfeedbackresultsDb.link_id_level3)
Index('iqvdocumentfeedbackresults_db_link_id_level4',
      IqvdocumentfeedbackresultsDb.link_id_level4)
Index('iqvdocumentfeedbackresults_db_link_id_level5',
      IqvdocumentfeedbackresultsDb.link_id_level5)
Index('iqvdocumentfeedbackresults_db_link_id_level6',
      IqvdocumentfeedbackresultsDb.link_id_level6)
Index('iqvdocumentfeedbackresults_db_link_id_subsection1',
      IqvdocumentfeedbackresultsDb.link_id_subsection1)
Index('iqvdocumentfeedbackresults_db_link_id_subsection2',
      IqvdocumentfeedbackresultsDb.link_id_subsection2)
Index('iqvdocumentfeedbackresults_db_link_id_subsection3',
      IqvdocumentfeedbackresultsDb.link_id_subsection3)
Index('iqvdocumentfeedbackresults_db_parent_id',
      IqvdocumentfeedbackresultsDb.parent_id, IqvdocumentfeedbackresultsDb.group_type)
Index('iqvdocumentfeedbackresults_db_parent_id_hierarchy', IqvdocumentfeedbackresultsDb.parent_id,
      IqvdocumentfeedbackresultsDb.hierarchy, IqvdocumentfeedbackresultsDb.group_type)
