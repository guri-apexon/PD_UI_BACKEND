from sqlalchemy import Column, Index
from .__base__ import SchemaBase
from sqlalchemy.dialects.postgresql import DOUBLE_PRECISION, TEXT, VARCHAR, INTEGER, BOOLEAN, BIGINT, JSONB, BYTEA


class DocumenttablesDb(SchemaBase):
    __tablename__ = "documenttables_db"
    id = Column(VARCHAR(128), name='PK_public.documenttables_db',
                primary_key=True, nullable=False)
    __table_args__ = {"postgresql_inherits": "iqvpageroi_db"}
