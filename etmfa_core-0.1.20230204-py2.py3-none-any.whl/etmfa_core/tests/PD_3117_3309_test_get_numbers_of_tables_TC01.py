import psycopg2
import json
from sqlalchemy import create_engine, inspect
from etmfa_core.tests.utils.get_schema_info import GetSchemaInfo
import pytest


@pytest.mark.parametrize("table_name_path",
                         [(r'./etmfa_core/tests/data/tables_name.txt'),
                          ])
def test_get_numbers_of_tables(table_name_path):
    get_schema_info = GetSchemaInfo()
    tables = get_schema_info.get_numbers_of_tables()

    with open(table_name_path, 'r') as f:
        data = f.read()
        table_name_dict = json.loads(data)
        
    assert len(table_name_dict['tables_name_list']) == len(tables)
