"""Test related to IQVIA document functions."""
import pytest

from etmfa_core.aidoc.IQVDocumentFunctions import (get_document_footer_text, get_document_title_text,
                                                   get_leaves_from_iqv_document)
from etmfa_core.aidoc.models.IQVDocument import (IQVDocument, IQVPageROI,
                                                 Rectangle, IQVWord)
from etmfa_core.aidoc.models.IQVUtilities import Constants


def _get_roi(width: float, height: float,
             left_x: float = 0.0, top_y: float = 0.0,
             text: str = None, page_sequence: int = 1,
             bScannedOCR: bool = False, scannedOCRCode: str = ''
             ) -> IQVPageROI:
    """Return ROI object with populated attributes."""
    rectangle = Rectangle()
    rectangle.Height = Constants.PPI_RESOLUTION * height
    rectangle.Width = Constants.PPI_RESOLUTION * width
    rectangle.X = Constants.PPI_RESOLUTION * left_x
    rectangle.Y = Constants.PPI_RESOLUTION * top_y

    roi = IQVPageROI()
    roi.OriginalROIHeightInches = height
    roi.OriginalROIWidthInches = width
    roi.rectangleGlobalLocationOnPage = rectangle
    roi.PageSequenceIndex = page_sequence
    roi.bScannedOCR = bScannedOCR
    roi.scannedOCRCode = scannedOCRCode

    if text:
        if isinstance(text, str):
            roi.strTexts = [text]
        else:
            for word in text:
                iqv_word = IQVWord()
                iqv_word.Text = word
                roi.QWords.append(iqv_word)

    return roi


def _build_doc_with_text_rois(doc_dict: dict):
    """Create IQVIA doc scaffolding with footer/header/title rois."""
    document = IQVDocument()
    for page in doc_dict['pages']:
        page_roi = _get_roi(**page["roi"])

        for _, child_roi_dict in page['child_rois'].items():
            child_roi = _get_roi(**child_roi_dict)
            page_roi.ChildBoxes.append(child_roi)

        document.DocumentImages.append(page_roi)

    return document


@pytest.mark.parametrize(('document'), [
    (
            # \\quintiles.net\enterprise\Apps\etmfaitest\Data\Takeda BXA25284 (MT203-2004) Re-post - eTransfer 06-27\
            # contents\SPAIN\03 Regulatory\03.01 Trial Approval\03.01.02 Approval\
            # RegUpdAckAmendApprvl-2015-06-22-APP-AoR-spa-TRANFR-000001.pdf
            {
                "pages": [{
                    "roi": {"width": 8.26, "height": 11.69, "page_sequence": 1},
                    "child_rois": {
                        "footer": {"width": 4.74, "height": 0.15, "left_x": 1.18, "top_y": 11.04, "text": "Test footer"}
                    }
                }]
            }
    ),
    (
            # \\morsetmfml01d\Data\(Shipped 07-09) GlaxoSmithKline QRA77758 (HGS1006-C1115)\contents\
            # Countries\SERBIA\00 COUNTRY DOCUMENTS\Patient Materials and Recruitment\Patient Materials\
            # Self Injection Log-Patient Material-2011-10-20-VER-srp-TRANTO-000008.pdf
            {
                "pages": [{
                    "roi": {"width": 11.0, "height": 8.5, "page_sequence": 2},
                    "child_rois": {
                        "footer": {"width": 3.95, "height": 0.11, "left_x": 1.0, "top_y": 7.48, "text": "Test footer"}
                    }
                }]
            }
    ),
    (
            {
                "pages": [{
                    "roi": {"width": 8.26, "height": 11.69, "page_sequence": 1},
                    "child_rois": {
                        "footer": {"width": 4.74, "height": 0.15, "left_x": 1.18, "top_y": 11.04, "text": "Test footer"}
                    }
                }, {
                    "roi": {"width": 11.0, "height": 8.5, "page_sequence": 2},
                    "child_rois": {
                        "footer": {"width": 3.95, "height": 0.11, "left_x": 1.0, "top_y": 7.48, "text": "Test footer"}
                    }
                }]
            }
    ), (
            {
                "pages": []
            }
    )],
                         ids=[
                             "Longer doc (height) than A4 format.",
                             "Landscape format.",
                             "Document with different page formats.",
                             "Empty document."
                         ]
                         )
def test_get_footer_text(document):
    """Test footer text extraction for different document formats."""
    iqvia_doc = _build_doc_with_text_rois(document)
    expected_footer_text = ' '.join([page['child_rois']['footer']['text'] for page in document['pages']])
    assert get_document_footer_text(iqvia_doc) == expected_footer_text


@pytest.mark.parametrize("document", [
    (
            {
                "pages": []
            }
    )
])
def test_get_title_text(document):
    """Test title text extraction."""
    iqvia_doc = _build_doc_with_text_rois(document)
    expected_title_text = ' '.join([page['child_rois']['title']['text'] for page in document['pages']])
    assert get_document_title_text(iqvia_doc) == expected_title_text


def get_document_text(iqvia_doc: IQVDocument, filter_regions) -> str:
    roi_leaves = get_leaves_from_iqv_document(iqvia_doc, filter_regions)

    document_text = []

    for roi in roi_leaves:
        document_text.append(roi.GetLocalText())

    return ' '.join(document_text)


@pytest.mark.parametrize('document, expected_text, expected_text_without_filter', [
    (
            {
                "pages": [{
                    "roi": {"width": 322, "height": 16, "page_sequence": 1, "bScannedOCR": True,
                            'scannedOCRCode': 'eng'},
                    "child_rois": {
                        "roi1": {"width": 390, "height": 22, "left_x": 240, "top_y": 196,
                                 "text": "Certificat de formation - Training Certificate"},
                        "roi2": {"width": 322, "height": 16, "left_x": 274, "top_y": 221,
                                 "text": "Ce document atteste que - this document certifies that"},
                        "ocr1": {"width": 322, "height": 16, "left_x": 274, "top_y": 221,
                                 "text": ['The', 'University', 'of', 'Hong', 'Kong', 'like'],
                                 "bScannedOCR": True, 'scannedOCRCode': 'eng'},

                    }
                }]
            },
            'The University of Hong Kong like',
            'Certificat de formation - Training Certificate Ce document atteste que - this document certifies that The University of Hong Kong like'
    ),
    (
            {
                "pages": [{
                    "roi": {"width": 322, "height": 16, "page_sequence": 1, "bScannedOCR": False},
                    "child_rois": {
                        "roi1": {"width": 390, "height": 22, "left_x": 240, "top_y": 196,
                                 "text": "Certificat de formation - Training Certificate"},
                        "roi2": {"width": 322, "height": 16, "left_x": 274, "top_y": 221,
                                 "text": "Ce document atteste que - this document certifies that"},
                        "ocr1": {"width": 322, "height": 16, "left_x": 274, "top_y": 221,
                                 "text": ['The', 'University', 'of', 'Hong', 'Kong', 'like'],
                                 "bScannedOCR": True, 'scannedOCRCode': 'eng'},

                    }
                }]
            },
            'Certificat de formation - Training Certificate Ce document atteste que - this document certifies that The University of Hong Kong like',
            'Certificat de formation - Training Certificate Ce document atteste que - this document certifies that The University of Hong Kong like'
    ),
    (
            {
                "pages": []
            }, '', ''
    )],
                         )
def test_get_leaves_from_iqv_document(document, expected_text, expected_text_without_filter):
    """Test get leaves from document."""
    iqvia_doc = _build_doc_with_text_rois(document)
    filtered_regions_text = get_document_text(iqvia_doc, False)
    all_regions_text = get_document_text(iqvia_doc, True)

    assert filtered_regions_text == expected_text
    assert all_regions_text == expected_text_without_filter
