from etmfa_core.aidoc.io.load_xml_db_ext import GetIQVDocumentFromDB_with_doc_id
import json
import psycopg2
import logging as logger
from etmfa_core.tests.utils.local_config import DbConfig
from etmfa_core.tests.utils.db_connection import Connection


class Compare:

    def __init__(self):
        self.db_keys_list = []
        self.dfs_keys_list = []
        self.db_values_list = []
        self.dfs_values_list = []

    # get IQV_document object from DB
    def get_db_data(self, doc_id):
        connection = Connection()
        conn = connection.conn
        iqv_document_db = GetIQVDocumentFromDB_with_doc_id(conn, doc_id)
        db_dict = self.to_dict(iqv_document_db)
        if conn:
            conn.close()
        return db_dict

    # Convert object into dict
    def to_dict(self, obj):
        return json.loads(json.dumps(obj, default=lambda o: o.__dict__))

    # Get different value's keys
    def get_diff_keys(self, db_dict, dfs_dict):
        diff_keys = [k for k in list(db_dict.keys()) if k in list(
            dfs_dict.keys()) and db_dict[k] != dfs_dict[k]]
        return diff_keys

    # Creat Differences list
    def create_diff_list(self, key_path, db_value, dfs_value):
        if "lineBoundaries" in key_path or "DocumentGroundTruth" in key_path or "InitialConfig" in key_path:
            pass
        else:
            self.db_keys_list.append(key_path)
            self.dfs_keys_list.append(key_path)
            self.db_values_list.append(db_value)
            self.dfs_values_list.append(dfs_value)

    # Processing List
    def process_list(self, db_list, dfs_list, key_path):
        if len(db_list) == len(dfs_list):
            if len(db_list) > 0 and type(db_list[0]) == dict:
                if (db_list[0]).get('id'):
                    sorted_db_list = sorted(db_list, key=lambda d: d['id'])
                    sorted_dfs_list = sorted(dfs_list, key=lambda d: d['id'])
                else:
                    sorted_db_list = db_list
                    sorted_dfs_list = dfs_list
            else:
                sorted_db_list = db_list.sort()
                sorted_dfs_list = dfs_list.sort()
            key_path1 = ""
            for i in range(len(sorted_db_list)):
                key_path1 = key_path + "_" + str(i)
                if type(sorted_db_list[i]) == list:
                    self.process_list(
                        sorted_db_list[i], sorted_dfs_list[i], key_path1)
                elif type(sorted_db_list[i]) == dict:
                    self.process_dict(
                        sorted_db_list[i], sorted_dfs_list[i], key_path1)
                else:
                    if sorted_db_list[i] == sorted_dfs_list[i]:
                        pass
                    else:
                        self.create_diff_list(
                            key_path1, sorted_db_list[i], sorted_dfs_list[i])
        else:
            self.create_diff_list(key_path, db_list, dfs_list)

    # Processing Dict
    def process_dict(self, db_dict, dfs_dict, key_path):
        diff_keys = self.get_diff_keys(db_dict, dfs_dict)
        key_path2 = ""
        for k in diff_keys:
            key_path2 = key_path + "_" + str(k)
            if type(db_dict[k]) == type(dfs_dict[k]):
                if type(db_dict[k]) == list:
                    self.process_list(db_dict[k], dfs_dict[k], key_path2)
                elif type(db_dict[k]) == dict:
                    self.process_dict(db_dict[k], dfs_dict[k], key_path2)
                else:
                    if db_dict[k] == dfs_dict[k]:
                        pass
                    else:
                        self.create_diff_list(
                            key_path2, db_dict[k], dfs_dict[k])
            else:
                self.create_diff_list(key_path2, db_dict[k], dfs_dict[k])

    # Compare IQV_Document Objects
    def compare_objects(self, db_dict, dfs_dict):
        try:
            if db_dict == dfs_dict:
                pass
            else:
                self.process_dict(db_dict, dfs_dict, key_path="")

            if len(self.db_keys_list) < 20000:
                return 0
            else:
                return len(self.db_keys_list)
        except Exception as exc:
            logger.error(f"compare_objects failed and Error: {exc}")
