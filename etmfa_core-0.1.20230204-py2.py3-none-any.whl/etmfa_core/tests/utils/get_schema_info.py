import psycopg2
import json
from sqlalchemy import create_engine, inspect
from etmfa_core.tests.utils.local_config import TestDbConfig


class GetSchemaInfo:

    def __init__(self):
        self.URL = TestDbConfig.url
        self.engine = create_engine(self.URL)
        self.insp = inspect(self.engine)

    def get_numbers_of_tables(self):
        return self.insp.get_table_names()

    def get_table_indexes(self, tables):
        indexes = dict()
        for table in tables:
            indexes[table] = (self.insp.get_indexes(table))
        return indexes

    def get_table_fields_details(self, tables):
        fields_info_dict = dict()
        fields_count_dict = dict()
        for table in tables:
            info_list = []
            fields_info = self.insp.get_columns(table)
            for info in fields_info:
                info_list.append([info['name'], (str(info['type'])).strip()])
            fields_count_dict[table] = len(fields_info)
            info_list.sort()
            fields_info_dict[table] = info_list
        return fields_count_dict, fields_info_dict
