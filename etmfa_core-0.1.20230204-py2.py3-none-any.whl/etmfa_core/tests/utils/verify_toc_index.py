
import psycopg2
from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker
from etmfa_core.tests.utils.local_config import DbConfig
from etmfa_core.postgres_db_schema.iqvdocumentlink_db import IqvdocumentlinkDb


def verify_toc_index(doc_id):
    """ Here we are Verifying Indexes of Table of Contents
        Input perameter is doc_id
        Output perameters are record_count, link_id_count, missing_link_count and  empty_link_level_count
    """
    URL = DbConfig.url
    engine = create_engine(URL, echo=True)
    Session = sessionmaker(bind=engine)
    session = Session()
    result = session.query(IqvdocumentlinkDb).filter(
        IqvdocumentlinkDb.doc_id == doc_id)
    record_count = 0
    link_id_count = 0
    missing_link_count = 0
    empty_link_level_count = 0
    for row in result:
        record_count = record_count + 1
        if row.link_id != '':
            link_id_count = link_id_count + 1
        if row.LinkLevel == 1:
            if row.link_id == '':
                missing_link_count = missing_link_count + 1
        elif row.LinkLevel == 2:
            if row.link_id == '' or row.link_id_level2 == '':
                missing_link_count = missing_link_count + 1
        elif row.LinkLevel == 3:
            if row.link_id == '' or row.link_id_level2 == '' or row.link_id_level3 == '':
                missing_link_count = missing_link_count + 1
        elif row.LinkLevel == 4:
            if row.link_id == '' or row.link_id_level2 == '' or row.link_id_level3 == '' or row.link_id_level4 == '':
                missing_link_count = missing_link_count + 1
        elif row.LinkLevel == 5:
            if row.link_id == '' or row.link_id_level2 == '' or row.link_id_level3 == '' or row.link_id_level4 == '' or row.link_id_level5 == '':
                missing_link_count = missing_link_count + 1
        elif row.LinkLevel == 6:
            if row.link_id == '' or row.link_id_level2 == '' or row.link_id_level3 == '' or row.link_id_level4 == '' or row.link_id_level5 == '' or row.link_id_level6 == '':
                missing_link_count = missing_link_count + 1
        elif row.LinkLevel == 7:
            if row.link_id == '' or row.link_id_level2 == '' or row.link_id_level3 == '' or row.link_id_level4 == '' or row.link_id_level5 == '' or row.link_id_subsection1 == '':
                missing_link_count = missing_link_count + 1
        elif row.LinkLevel == 8:
            if row.link_id == '' or row.link_id_level2 == '' or row.link_id_level3 == '' or row.link_id_level4 == '' or row.link_id_level5 == '' or row.link_id_subsection1 == '' or row.link_id_subsection2 == '':
                missing_link_count = missing_link_count + 1
        elif row.LinkLevel == 9:
            if row.link_id == '' or row.link_id_level2 == '' or row.link_id_level3 == '' or row.link_id_level4 == '' or row.link_id_level5 == '' or row.link_id_subsection1 == '' or row.link_id_subsection2 == '' or row.link_id_subsection3 == '':
                missing_link_count = missing_link_count + 1
        else:
            empty_link_level_count = empty_link_level_count + 1

    return record_count, link_id_count, missing_link_count, empty_link_level_count
