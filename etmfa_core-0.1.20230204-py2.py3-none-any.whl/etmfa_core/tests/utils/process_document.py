from etmfa_core.aidoc.io.load_xml_db_ext import AddIQVDocumentToDB_with_doc_id, GetIQVDocumentFromDB_with_doc_id
from etmfa_core.aidoc.io import *
import psycopg2
from etmfa_core.tests.utils.local_config import TestDbConfig
from etmfa_core.tests.utils.db_connection import Connection
from sqlalchemy import create_engine, MetaData
from etmfa_core.postgres_db_schema import create_schemas
URL = TestDbConfig.url

connection = Connection()
conn = connection.conn1


def create_schemas_in_test_db():
    """ creating schema in test DB"""
    create_schemas(URL)


def drop_all_tables():
    """" Deleting all tables from test DB """
    engine = create_engine(URL)
    meta = MetaData(engine)
    meta.reflect()
    meta.drop_all()


def process_document(file_path, doc_id, parent_id, table_name, group_type):
    """ Processing document into test DB"""
    iqv_document = read_iqv_xml(file_path)
    drop_all_tables()
    create_schemas_in_test_db()
    result = AddIQVDocumentToDB_with_doc_id(
        iqv_document, doc_id, parent_id, conn, table_name, group_type)
    iqv_document_db = GetIQVDocumentFromDB_with_doc_id(conn, doc_id)
    if conn:
        conn.close()
    if result == True and iqv_document_db != None:
        return True
    else:
        return False
