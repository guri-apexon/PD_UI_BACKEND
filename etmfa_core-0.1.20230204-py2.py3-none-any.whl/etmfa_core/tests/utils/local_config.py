import yaml
import logging
class DbConfig:
    try:
        file_path = "server_config.yaml"
        with open(file_path, 'r') as ymlfile:
            cfg = yaml.load(ymlfile, Loader=yaml.FullLoader)
            user = cfg["user"]
            password = cfg["password"]
            host = cfg["host"]
            port = cfg["port"]
            database = cfg["database"]
            url = "postgresql+psycopg2://" + user + ":" + password + "@" + host + ":" + port + "/" + database
    except Exception as exp:
        logging.error(
            "Loading Defaults due to exception when reading yaml from server_config {0}", exp)

class TestDbConfig:
    try:
        file_path = "server_config.yaml"
        with open(file_path, 'r') as ymlfile:
            cfg = yaml.load(ymlfile, Loader=yaml.FullLoader)
            database = cfg["test_database"]
            user = cfg["test_user"]
            password = cfg["test_password"]
            host = cfg["test_host"]
            port = cfg["test_port"]
            url = "postgresql+psycopg2://" + user + ":" + password + "@" + host + ":" + port + "/" + database
    except Exception as exp:
        logging.error(
            "Loading Defaults due to exception when reading yaml from server_config {0}", exp)
