from etmfa_core.tests.utils.local_config import DbConfig, TestDbConfig
import psycopg2


class Connection:

    def __init__(self):
        self.conn = psycopg2.connect(database=DbConfig.database, user=DbConfig.user, password=DbConfig.password,
                                     host=DbConfig.host, port=DbConfig.port)
        self.conn1 = psycopg2.connect(database=TestDbConfig.database, user=TestDbConfig.user, password=TestDbConfig.password,
                                      host=TestDbConfig.host, port=TestDbConfig.port)
