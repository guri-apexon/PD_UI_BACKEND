from etmfa_core.postgres_db_schema import create_schemas
from local_config import TestDbConfig
URL = TestDbConfig.url
create_schemas(URL)
