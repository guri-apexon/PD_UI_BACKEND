from etmfa_core.tests.utils.compare_objects import Compare
import json
import pytest


@pytest.mark.parametrize("doc_id, dfs_file_path",
                         [('c6617d90-20ee-48f0-a1f4-5e0ab4696bd9',r'./etmfa_core/tests/data/dfs_data.txt'),
                          ])
def test_compare_objects(doc_id, dfs_file_path):
    compare = Compare()
    db_data = compare.get_db_data(doc_id)
    
    with open(dfs_file_path, 'r') as f:
        data = f.read()
        dfs_data = json.loads(data)

    result = compare.compare_objects(db_data, dfs_data)
    assert result == 0
