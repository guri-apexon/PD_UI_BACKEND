import psycopg2
import json
from sqlalchemy import create_engine, inspect
from etmfa_core.tests.utils.get_schema_info import GetSchemaInfo
import pytest


@pytest.mark.parametrize("fields_count_info_path, fields_info_path",
                         [(r'./etmfa_core/tests/data/table_fields_count_info.txt',r'./etmfa_core/tests/data/table_fields_info.txt'),
                          ])
def test_get_table_fields_details(fields_count_info_path, fields_info_path):
    test_get_schema_info = GetSchemaInfo()
    tables = test_get_schema_info.get_numbers_of_tables()
    test_fields_count_info, test_fields_info = test_get_schema_info.get_table_fields_details(
        tables)

    with open(fields_count_info_path, 'r') as f:
        data = f.read()
        dev_fields_count_info = json.loads(data)
    
    with open(fields_info_path, 'r') as f:
        data = f.read()
        dev_fields_info = json.loads(data)

    assert dev_fields_count_info == test_fields_count_info
    assert dev_fields_info == test_fields_info
