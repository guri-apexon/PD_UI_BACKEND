import psycopg2
import json
from sqlalchemy import create_engine, inspect
from etmfa_core.tests.utils.get_schema_info import GetSchemaInfo
import pytest


@pytest.mark.parametrize("index_details_path",
                         [(r'./etmfa_core/tests/data/table_indexes_details.txt'),
                          ])
def test_get_table_indexes(index_details_path):
    test_get_schema_info = GetSchemaInfo()
    tables = test_get_schema_info.get_numbers_of_tables()
    test_index_details = test_get_schema_info.get_table_indexes(tables)

    with open(index_details_path, 'r') as f:
        data = f.read()
        dev_index_details = json.loads(data)
    assert dev_index_details == test_index_details
