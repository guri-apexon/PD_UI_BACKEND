from etmfa_core.tests.utils.verify_toc_index import verify_toc_index
import pytest


@pytest.mark.parametrize("doc_id",
                         [('c6617d90-20ee-48f0-a1f4-5e0ab4696bd9'),
                          ])
def test_verify_toc_index(doc_id):
    record_count, link_id_count, missing_link_count, empty_link_level_count = verify_toc_index(
        doc_id)
    assert record_count == link_id_count
    assert missing_link_count == 0
    assert empty_link_level_count == 0
