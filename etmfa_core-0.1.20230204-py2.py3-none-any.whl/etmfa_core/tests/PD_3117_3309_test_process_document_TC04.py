from etmfa_core.tests.utils.process_document import process_document
import pytest


@pytest.mark.parametrize("file_path, doc_id, parent_id, table_name, group_type",
                         [(r'./etmfa_core/tests/data/OU_D2_D1_NCT03710889.20221202182438.xml.zip', 'c6617d90-20ee-48f0-a1f4-5e0ab4696bd9', '', '', ''),
                          ])
def test_process_document(file_path, doc_id, parent_id, table_name, group_type):
    result = process_document(
        file_path, doc_id, parent_id, table_name, group_type)

    assert result == True
