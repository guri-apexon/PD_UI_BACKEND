import copy
from etmfa_core.aidoc.models.IQVDocument import (
    IQVDocument,
    IQVPageROI,
    Rectangle,
)


def UpdateIQVDocumentSpatialLocations(iqvDocument: IQVDocument):
    """
    Invoke this after all ROI's have been created (after digitizer). Update current PAGE ROI and all children.
    Triage puts ROI Rectangle W/H/X/Y in original scale.
    Triage scales up image by predefined factor (default 4), to improve OCR
    Digitizer uses this scale factor to calculate line/word ROI Rectangle and fonts size
    So all Rectangles in IQVDocument is in it's original scale
    Copy Rectangle location information to RectangleGlobalLocationOnPage, it is used to query data based on location
    """
    for pg in iqvDocument.DocumentImages:
        for roi in pg.ChildBoxes:
            _update_iqv_pageroi_spatiallocations(roi)


def _update_iqv_pageroi_spatiallocations(roi: IQVPageROI):
    roi.rectangleGlobalLocationOnPage = copy.deepcopy(roi.rectangle)

    for child in roi.ChildBoxes:
        _update_iqv_pageroi_spatiallocations(child)
