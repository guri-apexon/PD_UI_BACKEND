import uuid


# Class Definitions


class Point(object):
    """
    Point class represents and manipulates x,y coords.
    """
    x = int
    """
    upper left, typically in pixels
    """
    y = int
    """
    upper left, typically in pixels
    """

    def __init__(self):
        self.x = 0
        self.y = 0


class Rectangle(object):
    """Main data structure for a document resource. Contains
    everything for deconstruction and reconstruction."""
    Height = int
    """
    height (y), typically in pixels
    """
    Width = int
    """
    width (x), typically in pixels
    """
    X = int
    """
    upper left, typically in pixels
    """
    Y = int
    """
    upper left, typically in pixels
    """

    def __init__(self):
        self.Height = 0
        self.Width = 0
        self.X = 0
        self.Y = 0


class LanguageCode(object):
    """
    Versions of language code captured in single class,
    to make transform between 2-char, 3-char, and 4/5-char
    codes
    """

    code = str
    """
    2-character code
    """

    description = str
    """
    Description of language
    """

    eTMFCode = str
    """
    Special code for eTMF if necessary
    """

    fourLetterCode = str
    """
    en-US, es-ES
    """

    id = str
    """

    """

    ReleaseVersionAvailability = int
    """
    Major release version
    """

    tesseractCode = str
    """
    standard code for tesseract, such as 3-char code
    """

    def __init__(self):
        self.code = ''
        self.description = ''
        self.eTMFCode = ''
        self.fourLetterCode = ''
        self.id = ''
        self.ReleaseVersionAvailability = -1
        self.tesseractCode = ''


class IQVDocumentMapping(object):
    """
    Used to track all document classifications and mappings,
    from historical system (e.g., ELVIS) to target system (e.g., Wingspan).
    Includes current document instruction information for metadata as
    the <a href="#IQVDocumentMapping.AdditionalInstructionsList">IQVDocumentMapping.AdditionalInstructionsList</a>.
    Also provides support for the MLGroup mappings that require
    personnel role to determine document classification
    """

    Additional_instructions = str
    """
    Subject line/ Additional instructions   updated instructions
     which may impact the subject field (upcoming config update)
        e.g., 'Enter topic of meeting in subject field if applicable.'
    """

    AdditionalAttributesList = []
    """
    Categorized list of additional attributes for metadata
    extraction.
    Examples for key:value
    value = 1 if required = true
    value = 0 if required = false
    key is attribute display name
    key examples: Meeting Type, Subject, Ref Model Subtype
    """

    AdditionalInstructionsList = []
    """
    Categorized list of additional instructions for metadata
    extraction.
    Examples for key:value
    value = 0 if NOT for subject line
    value = 1 if YES for subject line!
    MeetingTopic:{0 or blank,1}
    IndividualName:{0 or blank,1,2} # Use numeric to specify how many names
    DocumentName:{0 or blank,1,2} # Use numeric to specify how many names
    Version:{0 or blank, 1} # Use original
    AmendmentNumber
    LanguageIdentifier
    """

    CONTENT_TYPE = str
    """
    ELVIS artifact names(source for the machine learning)
       e.g., 'DOC'
    """

    DateGuidance = str
    """
    Date identifier, what type of date to use for the document date,
    such as:
    Signature Date
    File Date
    Version Date
    Meeting Start Date
    """

    DateGuidanceSecondary = str
    """
    This is secondary to <a href="#IQVDocumentMapping.DateGuidance">IQVDocumentMapping.DateGuidance</a>. If the
    preferred date of <a href="#IQVDocumentMapping.DateGuidance">IQVDocumentMapping.DateGuidance</a> is not
     found, then this fallback date is used.
    Date identifier, what type of date to use for the document date,
    such as:
    Signature Date
    File Date
    Version Date
    Meeting Start Date
    """

    DerivedMappings = []
    """
    List of all derived mappings. In other systems,
    there may be classifications specific to that system.
    For example, one model supports 2 master lists, one from each system.
    The 2 master lists are linked here.
    This is appropriate for all 1-1, many-1, and 0-1 mappings.
    1-many mappings are not handled well
    """

    DIA_KEY = str
    """
    ELVIS artifact names(source for the machine learning)
      e.g., '01.05.03'
    """

    DOC_ABBREVIATION = str
    """
    ELVIS artifact names(source for the machine learning)
      e.g., 'PM-SponsMtgMin'
    """

    DOC_ARTIFACT = str
    """
    ELVIS artifact names(source for the machine learning)
      e.g., '03 Project Management- Sponsor Meeting Material'
    """

    DOC_CLASS = str
    """
    ELVIS artifact names(source for the machine learning)
      e.g., 'Core'
    """

    DOC_COUNT = int
    """
    ELVIS historical counts	
    e.g., 75234
    """

    DOC_COUNT_CURRENT = int
    """
    Wingspan current counts	
    e.g., 75234
    """

    DOC_SECTION = str
    """
    ELVIS artifact names(source for the machine learning)
      e.g., '05 General'
    """

    DOC_ZONE = str
    """
    ELVIS artifact names(source for the machine learning)
      e.g., '01 Trial Management'
    """

    Document_Description = str
    """
    Description of document
    """

    ExpirationDateExpected = int
    """
    This is separate from <a href="#IQVDocumentMapping.DateGuidance">IQVDocumentMapping.DateGuidance</a>. If the
    expiration date is expected for this document
     classification, value = 1.
    If no expiration date is expected, value = 0.
    """

    Full_Classification_Historical = str
    """
    ELVIS classification Zone.Section.Artifact.Abbreviation
    as XX.XX.XX.Abbreviation
    artifact names(source for the machine learning)
      e.g., '01.05.03.PM-SponsMtgMin'
    e.g., '05.04.09.AlertLtr_SubmPack'
    """

    Full_Classification_Wingspan = str
    """
    Derived from <a href="#IQVDocumentMapping.Wingspan_Doc_ID">IQVDocumentMapping.Wingspan_Doc_ID</a> PLUS <a href="#IQVDocumentMapping.Subtype">IQVDocumentMapping.Subtype</a>
    Wingspan document ID(which also determines level (study, country, site)
    PLUS Subtype if exists
    Add a period '.' delimiter if the subtype exists
    e.g., '100.58'
    e.g., '105.44.Alert Letter Submission Package'
    """

    id = str
    """
    id
    """

    MLClassificationGroup = str
    """
    In MLGroup matrix, the output of the classifier.
     e.g., 'CV' for all of the following {05.02.04.P-InvCV,
    05.02.05.Sub-InvCV,05.02.06.OtherCV,08.01.07.LabDirCV,01.02.02.ProjTeamCV}
    """

    MLClassificationRole = str
    """
    In MLGroup matrix, the role of the individual.
    e.g., PI,
    SubInv,
    Other,
    HeadOfFacility,
    ProjTeam
    """

    MLConfusionCluster = str
    """
    Confusion cluster/group that this predicted class label belongs to.
    If a document is predicted as this class label, and a
     MLConfusionCluster exists, then we have the option to push the
     document to the specialized ConfusionCluster Model for
    improved classification.
    The MLConfusionCluster should be a uuid, that is linked
    to the specialized ConfusionCluster Model
    """

    Subject = str
    """
    suggested subject line, for specific docs that do not have a subtype.
     This is only applicable for 5 doc types
    """

    Subtype = str
    """
    Wingspan applicable subtype
      e.g., 'Minutes'
    """

    TargetSystemName = str
    """
    Name of target system
    Prevents ambiguity when handle multiple target systems with same model and mapping
    """

    TargetSystemVersion = str
    """
    Version of target system
    Prevents ambiguity when handle multiple target systems with same model and mapping
    """

    Wingspan_DIA = str
    """
    DIA reference number
        e.g., '01.05.03'
    """

    Wingspan_Doc_ID = str
    """
    Wingspan document ID(which also determines level (study, country, site)
        e.g., '100.58'
    """

    Wingspan_doc_type = str
    """
    Document type
     e.g., 'Other Trial Management Meeting Material (Study Level)'
    """

    def __init__(self):
        self.Additional_instructions = ''
        self.AdditionalAttributesList = []
        self.AdditionalInstructionsList = []
        self.CONTENT_TYPE = ''
        self.DateGuidance = ''
        self.DateGuidanceSecondary = ''
        self.DerivedMappings = []
        self.DIA_KEY = ''
        self.DOC_ABBREVIATION = ''
        self.DOC_ARTIFACT = ''
        self.DOC_CLASS = ''
        self.DOC_COUNT = -1
        self.DOC_COUNT_CURRENT = -1
        self.DOC_SECTION = ''
        self.DOC_ZONE = ''
        self.Document_Description = ''
        self.ExpirationDateExpected = -1
        self.Full_Classification_Historical = ''
        self.Full_Classification_Wingspan = ''
        self.id = ''
        self.MLClassificationGroup = ''
        self.MLClassificationRole = ''
        self.MLConfusionCluster = ''
        self.Subject = ''
        self.Subtype = ''
        self.TargetSystemName = ''
        self.TargetSystemVersion = ''
        self.Wingspan_DIA = ''
        self.Wingspan_Doc_ID = ''
        self.Wingspan_doc_type = ''


class IQVDocumentProcess(object):
    """
    Track individual sub-processes, whether they are
    required in the workflow, etc.
    """

    bProcessRequired = bool
    """
    true or false
    """

    doc_id = str
    """
    Element index
    Which document is this element in?
    Top-level id for <a href="#IQVDocument">IQVDocument</a>
    """

    group_type = str
    """
    Element index
    Which item is this element a member of? (name of member = group_type)
    For example, for <a href="#IQVPageROI.Properties">IQVPageROI.Properties</a>, group_type = "Properties"
    Possible parents include but are not limited to
    <a href="#IQVDocument">IQVDocument</a><a href="#IQVPageROI">IQVPageROI</a><a href="#IQVDocumentLink">IQVDocumentLink</a>
    SQL code example 1 for usage of index
    <code>
    WHERE parent_id=parent_id AND group_type=group_type
    </code>
    """

    hierarchy = str
    """
    image,table,paragraph,item,header,footer,roi
    """

    id = str
    """
    GUID/UUID for tracking
    """

    iqv_standard_term = str
    """
    Element index
    If this element is a link or header, what is the standard term?
    There is 0 or 1 iqv_standard_term for each element
    """

    KeyValues = []
    """
    Additional key-value information,
    such as QC filename
    """

    link_id = str
    """
    Element index
    Which [link <a href="#IQVDocumentLink">IQVDocumentLink</a>] section is this element in?
    The id for <a href="#IQVDocumentLink.LinkType">IQVDocumentLink.LinkType</a> == "toc"
    and <a href="#IQVDocumentLink.LinkLevel">IQVDocumentLink.LinkLevel</a> == 1
    """

    link_id_level2 = str
    """
    Element index
    Which [link <a href="#IQVDocumentLink">IQVDocumentLink</a>] section is this element in?
    The id for <a href="#IQVDocumentLink.LinkType">IQVDocumentLink.LinkType</a> == "toc"
    and <a href="#IQVDocumentLink.LinkLevel">IQVDocumentLink.LinkLevel</a> == 2
    """

    link_id_level3 = str
    """
    Element index
    Which [link <a href="#IQVDocumentLink">IQVDocumentLink</a>] section is this element in?
    The id for <a href="#IQVDocumentLink.LinkType">IQVDocumentLink.LinkType</a> == "toc"
    and <a href="#IQVDocumentLink.LinkLevel">IQVDocumentLink.LinkLevel</a> == 3
    """

    link_id_level4 = str
    """
    Element index
    Which [link <a href="#IQVDocumentLink">IQVDocumentLink</a>] section is this element in?
    The id for <a href="#IQVDocumentLink.LinkType">IQVDocumentLink.LinkType</a> == "toc"
    and <a href="#IQVDocumentLink.LinkLevel">IQVDocumentLink.LinkLevel</a> == 4
    """

    link_id_level5 = str
    """
    Element index
    Which [link <a href="#IQVDocumentLink">IQVDocumentLink</a>] section is this element in?
    The id for <a href="#IQVDocumentLink.LinkType">IQVDocumentLink.LinkType</a> == "toc"
    and <a href="#IQVDocumentLink.LinkLevel">IQVDocumentLink.LinkLevel</a> == 5
    """

    link_id_level6 = str
    """
    Element index
    Which [link <a href="#IQVDocumentLink">IQVDocumentLink</a>] section is this element in?
    The id for <a href="#IQVDocumentLink.LinkType">IQVDocumentLink.LinkType</a> == "toc"
    and <a href="#IQVDocumentLink.LinkLevel">IQVDocumentLink.LinkLevel</a> == 6
    """

    link_id_subsection1 = str
    """
    Element index
    Which [link <a href="#IQVDocumentLink">IQVDocumentLink</a>] section is this element in?
    The id for <a href="#IQVDocumentLink.LinkType">IQVDocumentLink.LinkType</a> == "subsection1"
    """

    link_id_subsection2 = str
    """
    Element index
    Which [link <a href="#IQVDocumentLink">IQVDocumentLink</a>] section is this element in?
    The id for <a href="#IQVDocumentLink.LinkType">IQVDocumentLink.LinkType</a> == "subsection2"
    """

    link_id_subsection3 = str
    """
    Element index
    Which [link <a href="#IQVDocumentLink">IQVDocumentLink</a>] section is this element in?
    The id for <a href="#IQVDocumentLink.LinkType">IQVDocumentLink.LinkType</a> == "subsection3"
    """

    parent_id = str
    """
    Element index
    Which item is this element a member of?
    For example, for <a href="#IQVPageROI.Properties">IQVPageROI.Properties</a>, parent_id = <a href="#IQVPageROI.id">IQVPageROI.id</a>
    Possible parents include but are not limited to
    <a href="#IQVDocument">IQVDocument</a><a href="#IQVPageROI">IQVPageROI</a><a href="#IQVDocumentLink">IQVDocumentLink</a>
    SQL code example 1 for usage of index
    <code>
    WHERE parent_id=parent_id AND group_type=group_type
    </code>
    SQL code example 2 for usage of index
    <code>
    WHERE parent_id=parent_id
    </code>
    """

    ProcessEnvironment = str
    """
    dev, test, prod, mobile, etc
    """

    ProcessFinishTime = str
    """
    End time for processing of document datetime string
    """

    ProcessMachineName = str
    """
    name of machine where processing took place
    """

    ProcessName = str
    """
    triage, digitizer, classifier, extractor, finalizer, QC
    """

    ProcessStartTime = str
    """
    Start time for processing of document datetime string
    """

    ProcessType = str
    """
    more detailed info, such as type of QC
    """

    ProcessUserID = str
    """
    name of user process/ user id
    """

    ProcessVersion = str
    """
    Code version, human-readable value, such as 1.0
    """

    ProcessVersionHash = str
    """
    Code version, formal hash value. Object ID for git (source code repo) revision.
    """

    def __init__(self):
        self.bProcessRequired = False
        self.doc_id = ''
        self.group_type = ''
        self.hierarchy = ''
        self.id = ''
        self.iqv_standard_term = ''
        self.KeyValues = []
        self.link_id = ''
        self.link_id_level2 = ''
        self.link_id_level3 = ''
        self.link_id_level4 = ''
        self.link_id_level5 = ''
        self.link_id_level6 = ''
        self.link_id_subsection1 = ''
        self.link_id_subsection2 = ''
        self.link_id_subsection3 = ''
        self.parent_id = ''
        self.ProcessEnvironment = ''
        self.ProcessFinishTime = ''
        self.ProcessMachineName = ''
        self.ProcessName = ''
        self.ProcessStartTime = ''
        self.ProcessType = ''
        self.ProcessUserID = ''
        self.ProcessVersion = ''
        self.ProcessVersionHash = ''
        self.id = str(uuid.uuid1())


class IQVQCUpdateTracking(object):
    """
    Track individual QC item detail
    """

    doc_id = str
    """
    Element index
    Which document is this element in?
    Top-level id for <a href="#IQVDocument">IQVDocument</a>
    """

    dts = str
    """
    YYYYMMDDHHMMSS
    """

    group_type = str
    """
    Element index
    Which item is this element a member of? (name of member = group_type)
    For example, for <a href="#IQVPageROI.Properties">IQVPageROI.Properties</a>, group_type = "Properties"
    Possible parents include but are not limited to
    <a href="#IQVDocument">IQVDocument</a><a href="#IQVPageROI">IQVPageROI</a><a href="#IQVDocumentLink">IQVDocumentLink</a>
    SQL code example 1 for usage of index
    <code>
    WHERE parent_id=parent_id AND group_type=group_type
    </code>
    """

    hierarchy = str
    """
    image,table,paragraph,item,header,footer,roi
    """

    id = str
    """
    GUID/UUID of the <see cref="!:IQVItemQC" /> for tracking
    """

    iqv_standard_term = str
    """
    Element index
    If this element is a link or header, what is the standard term?
    There is 0 or 1 iqv_standard_term for each element
    """

    ItemDataType = str
    """
    data type (IQVPageROI, IQVSubText, etc.)
    """

    link_id = str
    """
    Element index
    Which [link <a href="#IQVDocumentLink">IQVDocumentLink</a>] section is this element in?
    The id for <a href="#IQVDocumentLink.LinkType">IQVDocumentLink.LinkType</a> == "toc"
    and <a href="#IQVDocumentLink.LinkLevel">IQVDocumentLink.LinkLevel</a> == 1
    """

    link_id_level2 = str
    """
    Element index
    Which [link <a href="#IQVDocumentLink">IQVDocumentLink</a>] section is this element in?
    The id for <a href="#IQVDocumentLink.LinkType">IQVDocumentLink.LinkType</a> == "toc"
    and <a href="#IQVDocumentLink.LinkLevel">IQVDocumentLink.LinkLevel</a> == 2
    """

    link_id_level3 = str
    """
    Element index
    Which [link <a href="#IQVDocumentLink">IQVDocumentLink</a>] section is this element in?
    The id for <a href="#IQVDocumentLink.LinkType">IQVDocumentLink.LinkType</a> == "toc"
    and <a href="#IQVDocumentLink.LinkLevel">IQVDocumentLink.LinkLevel</a> == 3
    """

    link_id_level4 = str
    """
    Element index
    Which [link <a href="#IQVDocumentLink">IQVDocumentLink</a>] section is this element in?
    The id for <a href="#IQVDocumentLink.LinkType">IQVDocumentLink.LinkType</a> == "toc"
    and <a href="#IQVDocumentLink.LinkLevel">IQVDocumentLink.LinkLevel</a> == 4
    """

    link_id_level5 = str
    """
    Element index
    Which [link <a href="#IQVDocumentLink">IQVDocumentLink</a>] section is this element in?
    The id for <a href="#IQVDocumentLink.LinkType">IQVDocumentLink.LinkType</a> == "toc"
    and <a href="#IQVDocumentLink.LinkLevel">IQVDocumentLink.LinkLevel</a> == 5
    """

    link_id_level6 = str
    """
    Element index
    Which [link <a href="#IQVDocumentLink">IQVDocumentLink</a>] section is this element in?
    The id for <a href="#IQVDocumentLink.LinkType">IQVDocumentLink.LinkType</a> == "toc"
    and <a href="#IQVDocumentLink.LinkLevel">IQVDocumentLink.LinkLevel</a> == 6
    """

    link_id_subsection1 = str
    """
    Element index
    Which [link <a href="#IQVDocumentLink">IQVDocumentLink</a>] section is this element in?
    The id for <a href="#IQVDocumentLink.LinkType">IQVDocumentLink.LinkType</a> == "subsection1"
    """

    link_id_subsection2 = str
    """
    Element index
    Which [link <a href="#IQVDocumentLink">IQVDocumentLink</a>] section is this element in?
    The id for <a href="#IQVDocumentLink.LinkType">IQVDocumentLink.LinkType</a> == "subsection2"
    """

    link_id_subsection3 = str
    """
    Element index
    Which [link <a href="#IQVDocumentLink">IQVDocumentLink</a>] section is this element in?
    The id for <a href="#IQVDocumentLink.LinkType">IQVDocumentLink.LinkType</a> == "subsection3"
    """

    OriginalText = str
    """
    text
    """

    parent_id = str
    """
    Element index
    Which item is this element a member of?
    For example, for <a href="#IQVPageROI.Properties">IQVPageROI.Properties</a>, parent_id = <a href="#IQVPageROI.id">IQVPageROI.id</a>
    Possible parents include but are not limited to
    <a href="#IQVDocument">IQVDocument</a><a href="#IQVPageROI">IQVPageROI</a><a href="#IQVDocumentLink">IQVDocumentLink</a>
    SQL code example 1 for usage of index
    <code>
    WHERE parent_id=parent_id AND group_type=group_type
    </code>
    SQL code example 2 for usage of index
    <code>
    WHERE parent_id=parent_id
    </code>
    """

    Properties = []
    """
    Additional key-value information
    """

    QC_id = str
    """
    parent process id:
    id of <a href="#IQVDocument.IQVDocumentProcesses">IQVDocument.IQVDocumentProcesses</a> for
    <a href="#IQVDocumentProcess.ProcessType">IQVDocumentProcess.ProcessType</a> == QC
    <a href="#IQVDocumentProcess.id">IQVDocumentProcess.id</a>
    """

    QCType = str
    """
    add/delete/modify
    """

    roi_id = str
    """
    GUID/UUID of the <a href="#IQVPageROI">IQVPageROI</a> that
     has been modified
    """

    seq_num = int
    """
    seq_num in qc change file
    """

    source_system = str
    """
    LM, QC
    """

    UpdatedText = str
    """
    text
    """

    user_id = str
    """
    user id
    """

    def __init__(self):
        self.doc_id = ''
        self.dts = ''
        self.group_type = ''
        self.hierarchy = ''
        self.id = ''
        self.iqv_standard_term = ''
        self.ItemDataType = ''
        self.link_id = ''
        self.link_id_level2 = ''
        self.link_id_level3 = ''
        self.link_id_level4 = ''
        self.link_id_level5 = ''
        self.link_id_level6 = ''
        self.link_id_subsection1 = ''
        self.link_id_subsection2 = ''
        self.link_id_subsection3 = ''
        self.OriginalText = ''
        self.parent_id = ''
        self.Properties = []
        self.QC_id = ''
        self.QCType = ''
        self.roi_id = ''
        self.seq_num = -1
        self.source_system = ''
        self.UpdatedText = ''
        self.user_id = ''
        self.id = str(uuid.uuid1())


class IQVTM_DocClassLite(object):
    """
    Simple doc class for classification
    """

    DocumentCount = int
    """
    Count of docs
    """

    Index = int
    """
    Ti is concatenation of all TEXT in this document class ci
    """

    def __init__(self):
        self.DocumentCount = -1
        self.Index = -1


class IQVTableColumnHeader(object):
    """
    Structure for one of the headers of
     the column in a table
    """

    doc_id = str
    """
    Element index
    Which document is this element in?
    Top-level id for <a href="#IQVDocument">IQVDocument</a>
    """

    group_type = str
    """
    Element index
    Which item is this element a member of? (name of member = group_type)
    For example, for <a href="#IQVPageROI.Properties">IQVPageROI.Properties</a>, group_type = "Properties"
    Possible parents include but are not limited to
    <a href="#IQVDocument">IQVDocument</a><a href="#IQVPageROI">IQVPageROI</a><a href="#IQVDocumentLink">IQVDocumentLink</a>
    SQL code example 1 for usage of index
    <code>
    WHERE parent_id=parent_id AND group_type=group_type
    </code>
    """

    hierarchy = str
    """
    image,table,paragraph,item,header,footer,roi
    """

    id = str
    """

    """

    iqv_standard_term = str
    """
    Element index
    If this element is a link or header, what is the standard term?
    There is 0 or 1 iqv_standard_term for each element
    """

    link_id = str
    """
    Element index
    Which [link <a href="#IQVDocumentLink">IQVDocumentLink</a>] section is this element in?
    The id for <a href="#IQVDocumentLink.LinkType">IQVDocumentLink.LinkType</a> == "toc"
    and <a href="#IQVDocumentLink.LinkLevel">IQVDocumentLink.LinkLevel</a> == 1
    """

    link_id_level2 = str
    """
    Element index
    Which [link <a href="#IQVDocumentLink">IQVDocumentLink</a>] section is this element in?
    The id for <a href="#IQVDocumentLink.LinkType">IQVDocumentLink.LinkType</a> == "toc"
    and <a href="#IQVDocumentLink.LinkLevel">IQVDocumentLink.LinkLevel</a> == 2
    """

    link_id_level3 = str
    """
    Element index
    Which [link <a href="#IQVDocumentLink">IQVDocumentLink</a>] section is this element in?
    The id for <a href="#IQVDocumentLink.LinkType">IQVDocumentLink.LinkType</a> == "toc"
    and <a href="#IQVDocumentLink.LinkLevel">IQVDocumentLink.LinkLevel</a> == 3
    """

    link_id_level4 = str
    """
    Element index
    Which [link <a href="#IQVDocumentLink">IQVDocumentLink</a>] section is this element in?
    The id for <a href="#IQVDocumentLink.LinkType">IQVDocumentLink.LinkType</a> == "toc"
    and <a href="#IQVDocumentLink.LinkLevel">IQVDocumentLink.LinkLevel</a> == 4
    """

    link_id_level5 = str
    """
    Element index
    Which [link <a href="#IQVDocumentLink">IQVDocumentLink</a>] section is this element in?
    The id for <a href="#IQVDocumentLink.LinkType">IQVDocumentLink.LinkType</a> == "toc"
    and <a href="#IQVDocumentLink.LinkLevel">IQVDocumentLink.LinkLevel</a> == 5
    """

    link_id_level6 = str
    """
    Element index
    Which [link <a href="#IQVDocumentLink">IQVDocumentLink</a>] section is this element in?
    The id for <a href="#IQVDocumentLink.LinkType">IQVDocumentLink.LinkType</a> == "toc"
    and <a href="#IQVDocumentLink.LinkLevel">IQVDocumentLink.LinkLevel</a> == 6
    """

    link_id_subsection1 = str
    """
    Element index
    Which [link <a href="#IQVDocumentLink">IQVDocumentLink</a>] section is this element in?
    The id for <a href="#IQVDocumentLink.LinkType">IQVDocumentLink.LinkType</a> == "subsection1"
    """

    link_id_subsection2 = str
    """
    Element index
    Which [link <a href="#IQVDocumentLink">IQVDocumentLink</a>] section is this element in?
    The id for <a href="#IQVDocumentLink.LinkType">IQVDocumentLink.LinkType</a> == "subsection2"
    """

    link_id_subsection3 = str
    """
    Element index
    Which [link <a href="#IQVDocumentLink">IQVDocumentLink</a>] section is this element in?
    The id for <a href="#IQVDocumentLink.LinkType">IQVDocumentLink.LinkType</a> == "subsection3"
    """

    OriginalText = str
    """
    original text from document
    """

    parent_id = str
    """
    Element index
    Which item is this element a member of?
    For example, for <a href="#IQVPageROI.Properties">IQVPageROI.Properties</a>, parent_id = <a href="#IQVPageROI.id">IQVPageROI.id</a>
    Possible parents include but are not limited to
    <a href="#IQVDocument">IQVDocument</a><a href="#IQVPageROI">IQVPageROI</a><a href="#IQVDocumentLink">IQVDocumentLink</a>
    SQL code example 1 for usage of index
    <code>
    WHERE parent_id=parent_id AND group_type=group_type
    </code>
    SQL code example 2 for usage of index
    <code>
    WHERE parent_id=parent_id
    </code>
    """

    Properties = []
    """
    color
    time_unit = {
        Epoch
        Sub-epoch
        Year
        Month
        Week

    Day
        Visit
        Window
    }
    value
    Properties for this IQVTableColumnHeader as <a href="#IQVKeyValueSet">IQVKeyValueSet</a><a href="#IQVKeyValueSet.key">IQVKeyValueSet.key</a> See standardized key listing
    <a href="#IQVKeyValueSet.value">IQVKeyValueSet.value</a> See standardized key listing
    <a href="#IQVKeyValueSet.confidence">IQVKeyValueSet.confidence</a> is 0 to 1 confidence value
    """

    roi_id = str
    """
    pointer to id of <a href="#IQVPageROI">IQVPageROI</a> of header cell,
    the cell in the table
     (childbox of row, which is childbox of table in
    <a href="#IQVDocument.DocumentTables">IQVDocument.DocumentTables</a>
    """

    rowIndex = int
    """
    sequence index row_id ones-based
    """

    rowRef = str
    """
    unique id for this columnheader as in t#r#
    """

    def __init__(self):
        self.doc_id = ''
        self.group_type = ''
        self.hierarchy = ''
        self.id = ''
        self.iqv_standard_term = ''
        self.link_id = ''
        self.link_id_level2 = ''
        self.link_id_level3 = ''
        self.link_id_level4 = ''
        self.link_id_level5 = ''
        self.link_id_level6 = ''
        self.link_id_subsection1 = ''
        self.link_id_subsection2 = ''
        self.link_id_subsection3 = ''
        self.OriginalText = ''
        self.parent_id = ''
        self.Properties = []
        self.roi_id = ''
        self.rowIndex = -1
        self.rowRef = ''
        self.id = str(uuid.uuid1())


class IQVTableColumn(object):
    """
    Structure for one of the headers of
     the column in a table
    """

    doc_id = str
    """
    Element index
    Which document is this element in?
    Top-level id for <a href="#IQVDocument">IQVDocument</a>
    """

    group_type = str
    """
    Element index
    Which item is this element a member of? (name of member = group_type)
    For example, for <a href="#IQVPageROI.Properties">IQVPageROI.Properties</a>, group_type = "Properties"
    Possible parents include but are not limited to
    <a href="#IQVDocument">IQVDocument</a><a href="#IQVPageROI">IQVPageROI</a><a href="#IQVDocumentLink">IQVDocumentLink</a>
    SQL code example 1 for usage of index
    <code>
    WHERE parent_id=parent_id AND group_type=group_type
    </code>
    """

    headers = []
    """

    """

    hierarchy = str
    """
    image,table,paragraph,item,header,footer,roi
    """

    id = str
    """
    unique id
    """

    iqv_standard_term = str
    """
    Element index
    If this element is a link or header, what is the standard term?
    There is 0 or 1 iqv_standard_term for each element
    """

    link_id = str
    """
    Element index
    Which [link <a href="#IQVDocumentLink">IQVDocumentLink</a>] section is this element in?
    The id for <a href="#IQVDocumentLink.LinkType">IQVDocumentLink.LinkType</a> == "toc"
    and <a href="#IQVDocumentLink.LinkLevel">IQVDocumentLink.LinkLevel</a> == 1
    """

    link_id_level2 = str
    """
    Element index
    Which [link <a href="#IQVDocumentLink">IQVDocumentLink</a>] section is this element in?
    The id for <a href="#IQVDocumentLink.LinkType">IQVDocumentLink.LinkType</a> == "toc"
    and <a href="#IQVDocumentLink.LinkLevel">IQVDocumentLink.LinkLevel</a> == 2
    """

    link_id_level3 = str
    """
    Element index
    Which [link <a href="#IQVDocumentLink">IQVDocumentLink</a>] section is this element in?
    The id for <a href="#IQVDocumentLink.LinkType">IQVDocumentLink.LinkType</a> == "toc"
    and <a href="#IQVDocumentLink.LinkLevel">IQVDocumentLink.LinkLevel</a> == 3
    """

    link_id_level4 = str
    """
    Element index
    Which [link <a href="#IQVDocumentLink">IQVDocumentLink</a>] section is this element in?
    The id for <a href="#IQVDocumentLink.LinkType">IQVDocumentLink.LinkType</a> == "toc"
    and <a href="#IQVDocumentLink.LinkLevel">IQVDocumentLink.LinkLevel</a> == 4
    """

    link_id_level5 = str
    """
    Element index
    Which [link <a href="#IQVDocumentLink">IQVDocumentLink</a>] section is this element in?
    The id for <a href="#IQVDocumentLink.LinkType">IQVDocumentLink.LinkType</a> == "toc"
    and <a href="#IQVDocumentLink.LinkLevel">IQVDocumentLink.LinkLevel</a> == 5
    """

    link_id_level6 = str
    """
    Element index
    Which [link <a href="#IQVDocumentLink">IQVDocumentLink</a>] section is this element in?
    The id for <a href="#IQVDocumentLink.LinkType">IQVDocumentLink.LinkType</a> == "toc"
    and <a href="#IQVDocumentLink.LinkLevel">IQVDocumentLink.LinkLevel</a> == 6
    """

    link_id_subsection1 = str
    """
    Element index
    Which [link <a href="#IQVDocumentLink">IQVDocumentLink</a>] section is this element in?
    The id for <a href="#IQVDocumentLink.LinkType">IQVDocumentLink.LinkType</a> == "subsection1"
    """

    link_id_subsection2 = str
    """
    Element index
    Which [link <a href="#IQVDocumentLink">IQVDocumentLink</a>] section is this element in?
    The id for <a href="#IQVDocumentLink.LinkType">IQVDocumentLink.LinkType</a> == "subsection2"
    """

    link_id_subsection3 = str
    """
    Element index
    Which [link <a href="#IQVDocumentLink">IQVDocumentLink</a>] section is this element in?
    The id for <a href="#IQVDocumentLink.LinkType">IQVDocumentLink.LinkType</a> == "subsection3"
    """

    maxX = int
    """
    max x in spatial dimensions
    """

    minX = int
    """
    min x in spatial dimensions
    """

    parent_id = str
    """
    Element index
    Which item is this element a member of?
    For example, for <a href="#IQVPageROI.Properties">IQVPageROI.Properties</a>, parent_id = <a href="#IQVPageROI.id">IQVPageROI.id</a>
    Possible parents include but are not limited to
    <a href="#IQVDocument">IQVDocument</a><a href="#IQVPageROI">IQVPageROI</a><a href="#IQVDocumentLink">IQVDocumentLink</a>
    SQL code example 1 for usage of index
    <code>
    WHERE parent_id=parent_id AND group_type=group_type
    </code>
    SQL code example 2 for usage of index
    <code>
    WHERE parent_id=parent_id
    </code>
    """

    Properties = []
    """
    Properties for this IQVTableColumn as <a href="#IQVKeyValueSet">IQVKeyValueSet</a><a href="#IQVKeyValueSet.key">IQVKeyValueSet.key</a> See standardized key listing
    <a href="#IQVKeyValueSet.value">IQVKeyValueSet.value</a> See standardized key listing
    <a href="#IQVKeyValueSet.confidence">IQVKeyValueSet.confidence</a> is 0 to 1 confidence value
    """

    table_roi_id = str
    """
    unique id for table
    """

    tableColumnIndex = int
    """
    sequence index col_id ones-based
    """

    tableColumnRef = str
    """
    unique id for this columnheader as in t#c#;
    if merged with other columns, list columnheaders as single string
    with space delimiter
    """

    tableIndex = int
    """
    sequence index table_id ones-based
    """

    def __init__(self):
        self.doc_id = ''
        self.group_type = ''
        self.headers = []
        self.hierarchy = ''
        self.id = ''
        self.iqv_standard_term = ''
        self.link_id = ''
        self.link_id_level2 = ''
        self.link_id_level3 = ''
        self.link_id_level4 = ''
        self.link_id_level5 = ''
        self.link_id_level6 = ''
        self.link_id_subsection1 = ''
        self.link_id_subsection2 = ''
        self.link_id_subsection3 = ''
        self.maxX = -1
        self.minX = -1
        self.parent_id = ''
        self.Properties = []
        self.table_roi_id = ''
        self.tableColumnIndex = -1
        self.tableColumnRef = ''
        self.tableIndex = -1
        self.id = str(uuid.uuid1())


class IQVTableRow(object):
    """
    Structure for the column in a table
    """

    doc_id = str
    """
    Element index
    Which document is this element in?
    Top-level id for <a href="#IQVDocument">IQVDocument</a>
    """

    group_type = str
    """
    Element index
    Which item is this element a member of? (name of member = group_type)
    For example, for <a href="#IQVPageROI.Properties">IQVPageROI.Properties</a>, group_type = "Properties"
    Possible parents include but are not limited to
    <a href="#IQVDocument">IQVDocument</a><a href="#IQVPageROI">IQVPageROI</a><a href="#IQVDocumentLink">IQVDocumentLink</a>
    SQL code example 1 for usage of index
    <code>
    WHERE parent_id=parent_id AND group_type=group_type
    </code>
    """

    header = str
    """

    """

    hierarchy = str
    """
    image,table,paragraph,item,header,footer,roi
    """

    id = str
    """

    """

    iqv_standard_term = str
    """
    Element index
    If this element is a link or header, what is the standard term?
    There is 0 or 1 iqv_standard_term for each element
    """

    link_id = str
    """
    Element index
    Which [link <a href="#IQVDocumentLink">IQVDocumentLink</a>] section is this element in?
    The id for <a href="#IQVDocumentLink.LinkType">IQVDocumentLink.LinkType</a> == "toc"
    and <a href="#IQVDocumentLink.LinkLevel">IQVDocumentLink.LinkLevel</a> == 1
    """

    link_id_level2 = str
    """
    Element index
    Which [link <a href="#IQVDocumentLink">IQVDocumentLink</a>] section is this element in?
    The id for <a href="#IQVDocumentLink.LinkType">IQVDocumentLink.LinkType</a> == "toc"
    and <a href="#IQVDocumentLink.LinkLevel">IQVDocumentLink.LinkLevel</a> == 2
    """

    link_id_level3 = str
    """
    Element index
    Which [link <a href="#IQVDocumentLink">IQVDocumentLink</a>] section is this element in?
    The id for <a href="#IQVDocumentLink.LinkType">IQVDocumentLink.LinkType</a> == "toc"
    and <a href="#IQVDocumentLink.LinkLevel">IQVDocumentLink.LinkLevel</a> == 3
    """

    link_id_level4 = str
    """
    Element index
    Which [link <a href="#IQVDocumentLink">IQVDocumentLink</a>] section is this element in?
    The id for <a href="#IQVDocumentLink.LinkType">IQVDocumentLink.LinkType</a> == "toc"
    and <a href="#IQVDocumentLink.LinkLevel">IQVDocumentLink.LinkLevel</a> == 4
    """

    link_id_level5 = str
    """
    Element index
    Which [link <a href="#IQVDocumentLink">IQVDocumentLink</a>] section is this element in?
    The id for <a href="#IQVDocumentLink.LinkType">IQVDocumentLink.LinkType</a> == "toc"
    and <a href="#IQVDocumentLink.LinkLevel">IQVDocumentLink.LinkLevel</a> == 5
    """

    link_id_level6 = str
    """
    Element index
    Which [link <a href="#IQVDocumentLink">IQVDocumentLink</a>] section is this element in?
    The id for <a href="#IQVDocumentLink.LinkType">IQVDocumentLink.LinkType</a> == "toc"
    and <a href="#IQVDocumentLink.LinkLevel">IQVDocumentLink.LinkLevel</a> == 6
    """

    link_id_subsection1 = str
    """
    Element index
    Which [link <a href="#IQVDocumentLink">IQVDocumentLink</a>] section is this element in?
    The id for <a href="#IQVDocumentLink.LinkType">IQVDocumentLink.LinkType</a> == "subsection1"
    """

    link_id_subsection2 = str
    """
    Element index
    Which [link <a href="#IQVDocumentLink">IQVDocumentLink</a>] section is this element in?
    The id for <a href="#IQVDocumentLink.LinkType">IQVDocumentLink.LinkType</a> == "subsection2"
    """

    link_id_subsection3 = str
    """
    Element index
    Which [link <a href="#IQVDocumentLink">IQVDocumentLink</a>] section is this element in?
    The id for <a href="#IQVDocumentLink.LinkType">IQVDocumentLink.LinkType</a> == "subsection3"
    """

    maxY = int
    """
    max x in spatial dimensions
    """

    minY = int
    """
    min x in spatial dimensions
    """

    parent_id = str
    """
    Element index
    Which item is this element a member of?
    For example, for <a href="#IQVPageROI.Properties">IQVPageROI.Properties</a>, parent_id = <a href="#IQVPageROI.id">IQVPageROI.id</a>
    Possible parents include but are not limited to
    <a href="#IQVDocument">IQVDocument</a><a href="#IQVPageROI">IQVPageROI</a><a href="#IQVDocumentLink">IQVDocumentLink</a>
    SQL code example 1 for usage of index
    <code>
    WHERE parent_id=parent_id AND group_type=group_type
    </code>
    SQL code example 2 for usage of index
    <code>
    WHERE parent_id=parent_id
    </code>
    """

    tableIndex = int
    """
    sequence index table_id ones-based
    """

    tableRowIndex = int
    """
    sequence index col_id ones-based
    """

    tableRowRef = str
    """
    unique id for this columnheader as in t#c#;
    if merged with other columns, list columnheaders as single string
    with space delimiter
    """

    def __init__(self):
        self.doc_id = ''
        self.group_type = ''
        self.header = ''
        self.hierarchy = ''
        self.id = ''
        self.iqv_standard_term = ''
        self.link_id = ''
        self.link_id_level2 = ''
        self.link_id_level3 = ''
        self.link_id_level4 = ''
        self.link_id_level5 = ''
        self.link_id_level6 = ''
        self.link_id_subsection1 = ''
        self.link_id_subsection2 = ''
        self.link_id_subsection3 = ''
        self.maxY = -1
        self.minY = -1
        self.parent_id = ''
        self.tableIndex = -1
        self.tableRowIndex = -1
        self.tableRowRef = ''
        self.id = str(uuid.uuid1())


class IQVExternalLink(object):
    """
    link from IQVPageROI
    """

    connection_type = str
    """
    type of link connection
    'internal' or 'external'
    """

    destination_link_id = str
    """
    Destination to where this is pointing to, if destination
    is in the same document

    Assumed that the destination_link already
    exists in the <a href="#IQVDocument.DocumentLinks">IQVDocument.DocumentLinks</a>
    """

    destination_link_prefix = str
    """
    If applicable, the prefix of the destination link

    Destination to where this is pointing to, if destination
    is in the same document

    Assumed that the destination_link already
    exists in the <a href="#IQVDocument.DocumentLinks">IQVDocument.DocumentLinks</a>
    """

    destination_link_text = str
    """
    The header/link text of destination link

    Destination to where this is pointing to, if destination
    is in the same document

    Assumed that the destination_link already
    exists in the <a href="#IQVDocument.DocumentLinks">IQVDocument.DocumentLinks</a>
    """

    destination_url = str
    """
    Destination to where this is pointing to, if destination
    is to a URL (not in the same document)
    """

    doc_id = str
    """
    Element index
    Which document is this element in?
    Top-level id for <a href="#IQVDocument">IQVDocument</a>
    """

    Elements = []
    """
    List of elements segmented from the full link section
    as list of <a href="#IQVExternalLinkElement">IQVExternalLinkElement</a>
    """

    group_type = str
    """
    Element index
    Which item is this element a member of? (name of member = group_type)
    For example, for <a href="#IQVPageROI.Properties">IQVPageROI.Properties</a>, group_type = "Properties"
    Possible parents include but are not limited to
    <a href="#IQVDocument">IQVDocument</a><a href="#IQVPageROI">IQVPageROI</a><a href="#IQVDocumentLink">IQVDocumentLink</a>
    SQL code example 1 for usage of index
    <code>
    WHERE parent_id=parent_id AND group_type=group_type
    </code>
    """

    hierarchy = str
    """
    image,table,paragraph,item,header,footer,roi
    """

    id = str
    """
    Gloablly unique id.
    """

    iqv_standard_term = str
    """
    Element index
    If this element is a link or header, what is the standard term?
    There is 0 or 1 iqv_standard_term for each element
    """

    length = int
    """
    length (num chars) of <a href="#IQVExternalLink.source_text">IQVExternalLink.source_text</a>
    """

    link_id = str
    """
    Element index
    Which [link <a href="#IQVDocumentLink">IQVDocumentLink</a>] section is this element in?
    The id for <a href="#IQVDocumentLink.LinkType">IQVDocumentLink.LinkType</a> == "toc"
    and <a href="#IQVDocumentLink.LinkLevel">IQVDocumentLink.LinkLevel</a> == 1
    """

    link_id_level2 = str
    """
    Element index
    Which [link <a href="#IQVDocumentLink">IQVDocumentLink</a>] section is this element in?
    The id for <a href="#IQVDocumentLink.LinkType">IQVDocumentLink.LinkType</a> == "toc"
    and <a href="#IQVDocumentLink.LinkLevel">IQVDocumentLink.LinkLevel</a> == 2
    """

    link_id_level3 = str
    """
    Element index
    Which [link <a href="#IQVDocumentLink">IQVDocumentLink</a>] section is this element in?
    The id for <a href="#IQVDocumentLink.LinkType">IQVDocumentLink.LinkType</a> == "toc"
    and <a href="#IQVDocumentLink.LinkLevel">IQVDocumentLink.LinkLevel</a> == 3
    """

    link_id_level4 = str
    """
    Element index
    Which [link <a href="#IQVDocumentLink">IQVDocumentLink</a>] section is this element in?
    The id for <a href="#IQVDocumentLink.LinkType">IQVDocumentLink.LinkType</a> == "toc"
    and <a href="#IQVDocumentLink.LinkLevel">IQVDocumentLink.LinkLevel</a> == 4
    """

    link_id_level5 = str
    """
    Element index
    Which [link <a href="#IQVDocumentLink">IQVDocumentLink</a>] section is this element in?
    The id for <a href="#IQVDocumentLink.LinkType">IQVDocumentLink.LinkType</a> == "toc"
    and <a href="#IQVDocumentLink.LinkLevel">IQVDocumentLink.LinkLevel</a> == 5
    """

    link_id_level6 = str
    """
    Element index
    Which [link <a href="#IQVDocumentLink">IQVDocumentLink</a>] section is this element in?
    The id for <a href="#IQVDocumentLink.LinkType">IQVDocumentLink.LinkType</a> == "toc"
    and <a href="#IQVDocumentLink.LinkLevel">IQVDocumentLink.LinkLevel</a> == 6
    """

    link_id_subsection1 = str
    """
    Element index
    Which [link <a href="#IQVDocumentLink">IQVDocumentLink</a>] section is this element in?
    The id for <a href="#IQVDocumentLink.LinkType">IQVDocumentLink.LinkType</a> == "subsection1"
    """

    link_id_subsection2 = str
    """
    Element index
    Which [link <a href="#IQVDocumentLink">IQVDocumentLink</a>] section is this element in?
    The id for <a href="#IQVDocumentLink.LinkType">IQVDocumentLink.LinkType</a> == "subsection2"
    """

    link_id_subsection3 = str
    """
    Element index
    Which [link <a href="#IQVDocumentLink">IQVDocumentLink</a>] section is this element in?
    The id for <a href="#IQVDocumentLink.LinkType">IQVDocumentLink.LinkType</a> == "subsection3"
    """

    link_text = str
    """
    text that is the key to finding this link,
    such as the section prefix number (e.g., "8.1"),
    but *not* the entire text contained in the link
    """

    parent_id = str
    """
    Element index
    Which item is this element a member of?
    For example, for <a href="#IQVPageROI.Properties">IQVPageROI.Properties</a>, parent_id = <a href="#IQVPageROI.id">IQVPageROI.id</a>
    Possible parents include but are not limited to
    <a href="#IQVDocument">IQVDocument</a><a href="#IQVPageROI">IQVPageROI</a><a href="#IQVDocumentLink">IQVDocumentLink</a>
    SQL code example 1 for usage of index
    <code>
    WHERE parent_id=parent_id AND group_type=group_type
    </code>
    SQL code example 2 for usage of index
    <code>
    WHERE parent_id=parent_id
    </code>
    """

    Properties = []
    """
    List of additional properties as <a href="#IQVKeyValueSet">IQVKeyValueSet</a><a href="#IQVKeyValueSet.key">IQVKeyValueSet.key</a> See standardized key listing
    <a href="#IQVKeyValueSet.value">IQVKeyValueSet.value</a> See standardized key listing
    <a href="#IQVKeyValueSet.confidence">IQVKeyValueSet.confidence</a> is 0 to 1 confidence value
    gridspan (for table cell)
    """

    source_text = str
    """
    part (substring) of the parent item text

    text string for the source link
    """

    startIndex = int
    """
    start location of <a href="#IQVExternalLink.source_text">IQVExternalLink.source_text</a> within
    the parent item
    """

    def __init__(self):
        self.connection_type = ''
        self.destination_link_id = ''
        self.destination_link_prefix = ''
        self.destination_link_text = ''
        self.destination_url = ''
        self.doc_id = ''
        self.Elements = []
        self.group_type = ''
        self.hierarchy = ''
        self.id = ''
        self.iqv_standard_term = ''
        self.length = -1
        self.link_id = ''
        self.link_id_level2 = ''
        self.link_id_level3 = ''
        self.link_id_level4 = ''
        self.link_id_level5 = ''
        self.link_id_level6 = ''
        self.link_id_subsection1 = ''
        self.link_id_subsection2 = ''
        self.link_id_subsection3 = ''
        self.link_text = ''
        self.parent_id = ''
        self.Properties = []
        self.source_text = ''
        self.startIndex = -1
        self.id = str(uuid.uuid1())


class IQVExternalLinkElement(object):
    """
    parts of external link
    """

    doc_id = str
    """
    Element index
    Which document is this element in?
    Top-level id for <a href="#IQVDocument">IQVDocument</a>
    """

    group_type = str
    """
    Element index
    Which item is this element a member of? (name of member = group_type)
    For example, for <a href="#IQVPageROI.Properties">IQVPageROI.Properties</a>, group_type = "Properties"
    Possible parents include but are not limited to
    <a href="#IQVDocument">IQVDocument</a><a href="#IQVPageROI">IQVPageROI</a><a href="#IQVDocumentLink">IQVDocumentLink</a>
    SQL code example 1 for usage of index
    <code>
    WHERE parent_id=parent_id AND group_type=group_type
    </code>
    """

    hierarchy = str
    """
    image,table,paragraph,item,header,footer,roi
    """

    id = str
    """
    Gloablly unique id.
    """

    iqv_standard_term = str
    """
    Element index
    If this element is a link or header, what is the standard term?
    There is 0 or 1 iqv_standard_term for each element
    """

    length = int
    """
    length of text string for this element within the link
    """

    link_id = str
    """
    Element index
    Which [link <a href="#IQVDocumentLink">IQVDocumentLink</a>] section is this element in?
    The id for <a href="#IQVDocumentLink.LinkType">IQVDocumentLink.LinkType</a> == "toc"
    and <a href="#IQVDocumentLink.LinkLevel">IQVDocumentLink.LinkLevel</a> == 1
    """

    link_id_level2 = str
    """
    Element index
    Which [link <a href="#IQVDocumentLink">IQVDocumentLink</a>] section is this element in?
    The id for <a href="#IQVDocumentLink.LinkType">IQVDocumentLink.LinkType</a> == "toc"
    and <a href="#IQVDocumentLink.LinkLevel">IQVDocumentLink.LinkLevel</a> == 2
    """

    link_id_level3 = str
    """
    Element index
    Which [link <a href="#IQVDocumentLink">IQVDocumentLink</a>] section is this element in?
    The id for <a href="#IQVDocumentLink.LinkType">IQVDocumentLink.LinkType</a> == "toc"
    and <a href="#IQVDocumentLink.LinkLevel">IQVDocumentLink.LinkLevel</a> == 3
    """

    link_id_level4 = str
    """
    Element index
    Which [link <a href="#IQVDocumentLink">IQVDocumentLink</a>] section is this element in?
    The id for <a href="#IQVDocumentLink.LinkType">IQVDocumentLink.LinkType</a> == "toc"
    and <a href="#IQVDocumentLink.LinkLevel">IQVDocumentLink.LinkLevel</a> == 4
    """

    link_id_level5 = str
    """
    Element index
    Which [link <a href="#IQVDocumentLink">IQVDocumentLink</a>] section is this element in?
    The id for <a href="#IQVDocumentLink.LinkType">IQVDocumentLink.LinkType</a> == "toc"
    and <a href="#IQVDocumentLink.LinkLevel">IQVDocumentLink.LinkLevel</a> == 5
    """

    link_id_level6 = str
    """
    Element index
    Which [link <a href="#IQVDocumentLink">IQVDocumentLink</a>] section is this element in?
    The id for <a href="#IQVDocumentLink.LinkType">IQVDocumentLink.LinkType</a> == "toc"
    and <a href="#IQVDocumentLink.LinkLevel">IQVDocumentLink.LinkLevel</a> == 6
    """

    link_id_subsection1 = str
    """
    Element index
    Which [link <a href="#IQVDocumentLink">IQVDocumentLink</a>] section is this element in?
    The id for <a href="#IQVDocumentLink.LinkType">IQVDocumentLink.LinkType</a> == "subsection1"
    """

    link_id_subsection2 = str
    """
    Element index
    Which [link <a href="#IQVDocumentLink">IQVDocumentLink</a>] section is this element in?
    The id for <a href="#IQVDocumentLink.LinkType">IQVDocumentLink.LinkType</a> == "subsection2"
    """

    link_id_subsection3 = str
    """
    Element index
    Which [link <a href="#IQVDocumentLink">IQVDocumentLink</a>] section is this element in?
    The id for <a href="#IQVDocumentLink.LinkType">IQVDocumentLink.LinkType</a> == "subsection3"
    """

    NLP_Entities = []
    """
    This ROI contains the listed entities
     <a href="#NLP_Entity">NLP_Entity</a>
    """

    parent_id = str
    """
    Element index
    Which item is this element a member of?
    For example, for <a href="#IQVPageROI.Properties">IQVPageROI.Properties</a>, parent_id = <a href="#IQVPageROI.id">IQVPageROI.id</a>
    Possible parents include but are not limited to
    <a href="#IQVDocument">IQVDocument</a><a href="#IQVPageROI">IQVPageROI</a><a href="#IQVDocumentLink">IQVDocumentLink</a>
    SQL code example 1 for usage of index
    <code>
    WHERE parent_id=parent_id AND group_type=group_type
    </code>
    SQL code example 2 for usage of index
    <code>
    WHERE parent_id=parent_id
    </code>
    """

    startIndex = int
    """
    location of text string for this element within the link
    """

    text = str
    """
    text string for this element within the link
    """

    def __init__(self):
        self.doc_id = ''
        self.group_type = ''
        self.hierarchy = ''
        self.id = ''
        self.iqv_standard_term = ''
        self.length = -1
        self.link_id = ''
        self.link_id_level2 = ''
        self.link_id_level3 = ''
        self.link_id_level4 = ''
        self.link_id_level5 = ''
        self.link_id_level6 = ''
        self.link_id_subsection1 = ''
        self.link_id_subsection2 = ''
        self.link_id_subsection3 = ''
        self.NLP_Entities = []
        self.parent_id = ''
        self.startIndex = -1
        self.text = ''
        self.id = str(uuid.uuid1())


class IQVNumberingGroup(object):
    """
    Information about bullets
    """

    abstractNumId = int
    """
    id for formatting of bullet
    """

    countItems = int
    """
    num items with this numbering
    """

    doc_id = str
    """
    Element index
    Which document is this element in?
    Top-level id for <a href="#IQVDocument">IQVDocument</a>
    """

    group_type = str
    """
    Element index
    Which item is this element a member of? (name of member = group_type)
    For example, for <a href="#IQVPageROI.Properties">IQVPageROI.Properties</a>, group_type = "Properties"
    Possible parents include but are not limited to
    <a href="#IQVDocument">IQVDocument</a><a href="#IQVPageROI">IQVPageROI</a><a href="#IQVDocumentLink">IQVDocumentLink</a>
    SQL code example 1 for usage of index
    <code>
    WHERE parent_id=parent_id AND group_type=group_type
    </code>
    """

    hierarchy = str
    """
    image,table,paragraph,item,header,footer,roi
    """

    id = str
    """

    """

    iqv_standard_term = str
    """
    Element index
    If this element is a link or header, what is the standard term?
    There is 0 or 1 iqv_standard_term for each element
    """

    link_id = str
    """
    Element index
    Which [link <a href="#IQVDocumentLink">IQVDocumentLink</a>] section is this element in?
    The id for <a href="#IQVDocumentLink.LinkType">IQVDocumentLink.LinkType</a> == "toc"
    and <a href="#IQVDocumentLink.LinkLevel">IQVDocumentLink.LinkLevel</a> == 1
    """

    link_id_level2 = str
    """
    Element index
    Which [link <a href="#IQVDocumentLink">IQVDocumentLink</a>] section is this element in?
    The id for <a href="#IQVDocumentLink.LinkType">IQVDocumentLink.LinkType</a> == "toc"
    and <a href="#IQVDocumentLink.LinkLevel">IQVDocumentLink.LinkLevel</a> == 2
    """

    link_id_level3 = str
    """
    Element index
    Which [link <a href="#IQVDocumentLink">IQVDocumentLink</a>] section is this element in?
    The id for <a href="#IQVDocumentLink.LinkType">IQVDocumentLink.LinkType</a> == "toc"
    and <a href="#IQVDocumentLink.LinkLevel">IQVDocumentLink.LinkLevel</a> == 3
    """

    link_id_level4 = str
    """
    Element index
    Which [link <a href="#IQVDocumentLink">IQVDocumentLink</a>] section is this element in?
    The id for <a href="#IQVDocumentLink.LinkType">IQVDocumentLink.LinkType</a> == "toc"
    and <a href="#IQVDocumentLink.LinkLevel">IQVDocumentLink.LinkLevel</a> == 4
    """

    link_id_level5 = str
    """
    Element index
    Which [link <a href="#IQVDocumentLink">IQVDocumentLink</a>] section is this element in?
    The id for <a href="#IQVDocumentLink.LinkType">IQVDocumentLink.LinkType</a> == "toc"
    and <a href="#IQVDocumentLink.LinkLevel">IQVDocumentLink.LinkLevel</a> == 5
    """

    link_id_level6 = str
    """
    Element index
    Which [link <a href="#IQVDocumentLink">IQVDocumentLink</a>] section is this element in?
    The id for <a href="#IQVDocumentLink.LinkType">IQVDocumentLink.LinkType</a> == "toc"
    and <a href="#IQVDocumentLink.LinkLevel">IQVDocumentLink.LinkLevel</a> == 6
    """

    link_id_subsection1 = str
    """
    Element index
    Which [link <a href="#IQVDocumentLink">IQVDocumentLink</a>] section is this element in?
    The id for <a href="#IQVDocumentLink.LinkType">IQVDocumentLink.LinkType</a> == "subsection1"
    """

    link_id_subsection2 = str
    """
    Element index
    Which [link <a href="#IQVDocumentLink">IQVDocumentLink</a>] section is this element in?
    The id for <a href="#IQVDocumentLink.LinkType">IQVDocumentLink.LinkType</a> == "subsection2"
    """

    link_id_subsection3 = str
    """
    Element index
    Which [link <a href="#IQVDocumentLink">IQVDocumentLink</a>] section is this element in?
    The id for <a href="#IQVDocumentLink.LinkType">IQVDocumentLink.LinkType</a> == "subsection3"
    """

    numberingLevels = []
    """
    Numbering levels for this group
    """

    numId = int
    """
    all items with same numId are of same group, with same numbering system
    """

    paraEndIndex = int
    """
    Last para index in this numbering group
    """

    paraIds = []
    """
    All ids in this numbering group
    """

    paraIds_list = str
    """

    """

    paraStartIndex = int
    """
    First para index in this numbering group
    """

    parent_id = str
    """
    Element index
    Which item is this element a member of?
    For example, for <a href="#IQVPageROI.Properties">IQVPageROI.Properties</a>, parent_id = <a href="#IQVPageROI.id">IQVPageROI.id</a>
    Possible parents include but are not limited to
    <a href="#IQVDocument">IQVDocument</a><a href="#IQVPageROI">IQVPageROI</a><a href="#IQVDocumentLink">IQVDocumentLink</a>
    SQL code example 1 for usage of index
    <code>
    WHERE parent_id=parent_id AND group_type=group_type
    </code>
    SQL code example 2 for usage of index
    <code>
    WHERE parent_id=parent_id
    </code>
    """

    def __init__(self):
        self.abstractNumId = -1
        self.countItems = -1
        self.doc_id = ''
        self.group_type = ''
        self.hierarchy = ''
        self.id = ''
        self.iqv_standard_term = ''
        self.link_id = ''
        self.link_id_level2 = ''
        self.link_id_level3 = ''
        self.link_id_level4 = ''
        self.link_id_level5 = ''
        self.link_id_level6 = ''
        self.link_id_subsection1 = ''
        self.link_id_subsection2 = ''
        self.link_id_subsection3 = ''
        self.numberingLevels = []
        self.numId = -1
        self.paraEndIndex = -1
        self.paraIds = []
        self.paraIds_list = ''
        self.paraStartIndex = -1
        self.parent_id = ''


class IQVNumberingLevel(object):
    """
    Format for each level, starting with level 0
    """

    doc_id = str
    """
    Element index
    Which document is this element in?
    Top-level id for <a href="#IQVDocument">IQVDocument</a>
    """

    group_type = str
    """
    Element index
    Which item is this element a member of? (name of member = group_type)
    For example, for <a href="#IQVPageROI.Properties">IQVPageROI.Properties</a>, group_type = "Properties"
    Possible parents include but are not limited to
    <a href="#IQVDocument">IQVDocument</a><a href="#IQVPageROI">IQVPageROI</a><a href="#IQVDocumentLink">IQVDocumentLink</a>
    SQL code example 1 for usage of index
    <code>
    WHERE parent_id=parent_id AND group_type=group_type
    </code>
    """

    hierarchy = str
    """
    image,table,paragraph,item,header,footer,roi
    """

    id = str
    """

    """

    ilvl = int
    """
    ilvl index
    """

    iqv_standard_term = str
    """
    Element index
    If this element is a link or header, what is the standard term?
    There is 0 or 1 iqv_standard_term for each element
    """

    link_id = str
    """
    Element index
    Which [link <a href="#IQVDocumentLink">IQVDocumentLink</a>] section is this element in?
    The id for <a href="#IQVDocumentLink.LinkType">IQVDocumentLink.LinkType</a> == "toc"
    and <a href="#IQVDocumentLink.LinkLevel">IQVDocumentLink.LinkLevel</a> == 1
    """

    link_id_level2 = str
    """
    Element index
    Which [link <a href="#IQVDocumentLink">IQVDocumentLink</a>] section is this element in?
    The id for <a href="#IQVDocumentLink.LinkType">IQVDocumentLink.LinkType</a> == "toc"
    and <a href="#IQVDocumentLink.LinkLevel">IQVDocumentLink.LinkLevel</a> == 2
    """

    link_id_level3 = str
    """
    Element index
    Which [link <a href="#IQVDocumentLink">IQVDocumentLink</a>] section is this element in?
    The id for <a href="#IQVDocumentLink.LinkType">IQVDocumentLink.LinkType</a> == "toc"
    and <a href="#IQVDocumentLink.LinkLevel">IQVDocumentLink.LinkLevel</a> == 3
    """

    link_id_level4 = str
    """
    Element index
    Which [link <a href="#IQVDocumentLink">IQVDocumentLink</a>] section is this element in?
    The id for <a href="#IQVDocumentLink.LinkType">IQVDocumentLink.LinkType</a> == "toc"
    and <a href="#IQVDocumentLink.LinkLevel">IQVDocumentLink.LinkLevel</a> == 4
    """

    link_id_level5 = str
    """
    Element index
    Which [link <a href="#IQVDocumentLink">IQVDocumentLink</a>] section is this element in?
    The id for <a href="#IQVDocumentLink.LinkType">IQVDocumentLink.LinkType</a> == "toc"
    and <a href="#IQVDocumentLink.LinkLevel">IQVDocumentLink.LinkLevel</a> == 5
    """

    link_id_level6 = str
    """
    Element index
    Which [link <a href="#IQVDocumentLink">IQVDocumentLink</a>] section is this element in?
    The id for <a href="#IQVDocumentLink.LinkType">IQVDocumentLink.LinkType</a> == "toc"
    and <a href="#IQVDocumentLink.LinkLevel">IQVDocumentLink.LinkLevel</a> == 6
    """

    link_id_subsection1 = str
    """
    Element index
    Which [link <a href="#IQVDocumentLink">IQVDocumentLink</a>] section is this element in?
    The id for <a href="#IQVDocumentLink.LinkType">IQVDocumentLink.LinkType</a> == "subsection1"
    """

    link_id_subsection2 = str
    """
    Element index
    Which [link <a href="#IQVDocumentLink">IQVDocumentLink</a>] section is this element in?
    The id for <a href="#IQVDocumentLink.LinkType">IQVDocumentLink.LinkType</a> == "subsection2"
    """

    link_id_subsection3 = str
    """
    Element index
    Which [link <a href="#IQVDocumentLink">IQVDocumentLink</a>] section is this element in?
    The id for <a href="#IQVDocumentLink.LinkType">IQVDocumentLink.LinkType</a> == "subsection3"
    """

    lvlText = str
    """
    "·"
    "•"
    %2
    %1.
    """

    numFmt = str
    """
    bullet
    lowerLetter
    lowerRoman
    decimal
    upperLetter
    """

    parent_id = str
    """
    Element index
    Which item is this element a member of?
    For example, for <a href="#IQVPageROI.Properties">IQVPageROI.Properties</a>, parent_id = <a href="#IQVPageROI.id">IQVPageROI.id</a>
    Possible parents include but are not limited to
    <a href="#IQVDocument">IQVDocument</a><a href="#IQVPageROI">IQVPageROI</a><a href="#IQVDocumentLink">IQVDocumentLink</a>
    SQL code example 1 for usage of index
    <code>
    WHERE parent_id=parent_id AND group_type=group_type
    </code>
    SQL code example 2 for usage of index
    <code>
    WHERE parent_id=parent_id
    </code>
    """

    start = str
    """
    start text
    """

    def __init__(self):
        self.doc_id = ''
        self.group_type = ''
        self.hierarchy = ''
        self.id = ''
        self.ilvl = -1
        self.iqv_standard_term = ''
        self.link_id = ''
        self.link_id_level2 = ''
        self.link_id_level3 = ''
        self.link_id_level4 = ''
        self.link_id_level5 = ''
        self.link_id_level6 = ''
        self.link_id_subsection1 = ''
        self.link_id_subsection2 = ''
        self.link_id_subsection3 = ''
        self.lvlText = ''
        self.numFmt = ''
        self.parent_id = ''
        self.start = ''


class PredictedItem(object):
    """
    Empirical tracking of a predicted key/value. This one instance is
    the system performance on a set of documents, for a single key, for a single
     file type, for a single classification.
    """

    AttributeKey = str
    """
    What key was being predicted for this set of documents, such as document_date,
    etc. Aligns with <a href="#IQVAttributeCandidate.AttributeKey">IQVAttributeCandidate.AttributeKey</a>
    """

    DocumentType = int
    """
    File type. aligns with ground truth <a href="#IQVDocumentGroundTruth.DocumentType">IQVDocumentGroundTruth.DocumentType</a>
    """

    Full_Classification_Historical = str
    """
    ground truth for this document, or predicted classification for
     this document. Aligns with mapping IQV.XML <a href="#IQVDocumentMapping.Full_Classification_Historical">IQVDocumentMapping.Full_Classification_Historical</a>
    """

    Predicted_TestConfidence = float
    """
    (should be correct/count) <see cref="!:PredictedItem_TestCorrect" /> divided
     by <a href="#PredictedItem.PredictedItem_TestCount">PredictedItem.PredictedItem_TestCount</a>
    """

    Predicted_TestCorrect = int
    """
    Of the total number of document predicted for be this key,
    how many were correct??
    """

    PredictedItem_RawScore = float
    """
    For informational purposes only
    """

    PredictedItem_TestCount = int
    """
    How many documents were predicted for be this key?
    """

    def __init__(self):
        self.AttributeKey = ''
        self.DocumentType = -1
        self.Full_Classification_Historical = ''
        self.Predicted_TestConfidence = 0.0
        self.Predicted_TestCorrect = -1
        self.PredictedItem_RawScore = 0.0
        self.PredictedItem_TestCount = -1
        self.id = str(uuid.uuid1())


class IQVConfidenceTracker(object):
    """
    Empirical tracking of a predicted key/value. This one instance is
    the system performance on a set of documents, for a single key,
    with a list of all file types, all classfications. So there should be
    one instance of this for document_date, one for document_classification, one
    for language, to make up the complete confidence tracker package.
    """

    AttributeKey = str
    """
    What key was being predicted for this set of documents, such as document_date,
    etc. Aligns with <a href="#IQVAttributeCandidate.AttributeKey">IQVAttributeCandidate.AttributeKey</a>
    """

    PredictedItems = []
    """
    All predicted items for this AttributeKey
    """

    def __init__(self):
        self.AttributeKey = ''
        self.PredictedItems = []
        self.id = str(uuid.uuid1())


class IQVLanguageMapping(object):
    """
    Prior information about each language
    based on historical documents, such as
    counts
    """

    HistoricalCount = int
    """
    Count in historical document set
    """

    HistoricalCountWeight = float
    """
    Normalized Count in historical document set,
    with total=1.0
    """

    id = str
    """
    id
    """

    languageCode = LanguageCode
    """
    Language code, specified in <a href="#LanguageCode">LanguageCode</a>
    """

    script_list = str
    """
    Script or writing system for the language
    There may be more than one per language
    """

    scripts = []
    """
    Script or writing system for the language
    There may be more than one per language
    """

    def __init__(self):
        self.HistoricalCount = -1
        self.HistoricalCountWeight = 0.0
        self.id = ''
        self.languageCode = LanguageCode()
        self.script_list = ''
        self.scripts = []


class IQVCountryMapping(object):
    """
    Prior information about each country
    based on historical documents, such as
    language of documents, date format of documents
    """

    Country = str
    """
    Name of the country
    """

    DateFormats = []
    """
    MDY, DMY, YMD
    """

    id = str
    """
    id
    """

    iqvLanguageMappings = []
    """
    Language mappings that make up at least
    0.1% (1 in 1000) documents for this country, as in
    <a href="#IQVLanguageMapping">IQVLanguageMapping</a>
    """

    def __init__(self):
        self.Country = ''
        self.DateFormats = []
        self.id = ''
        self.iqvLanguageMappings = []


class IQVAttributeCandidate(object):
    """
    Possible Attribute found in the document,
    such as document date
    """

    AttributeKey = str
    """
    key, such as document_date
    """

    AttributeValue = str
    """
    value of the attribute, such as date string
    """

    CandidateSelected = int
    """
    is this selected as top candidate?
    """

    doc_id = str
    """
    Element index
    Which document is this element in?
    Top-level id for <a href="#IQVDocument">IQVDocument</a>
    """

    Features = []
    """
    Features for this attribute candidate as list of IQVKeyValueSet
    """

    group_type = str
    """
    Element index
    Which item is this element a member of? (name of member = group_type)
    For example, for <a href="#IQVPageROI.Properties">IQVPageROI.Properties</a>, group_type = "Properties"
    Possible parents include but are not limited to
    <a href="#IQVDocument">IQVDocument</a><a href="#IQVPageROI">IQVPageROI</a><a href="#IQVDocumentLink">IQVDocumentLink</a>
    SQL code example 1 for usage of index
    <code>
    WHERE parent_id=parent_id AND group_type=group_type
    </code>
    """

    hierarchy = str
    """
    image,table,paragraph,item,header,footer,roi
    """

    id = str
    """
    id
    """

    iqv_standard_term = str
    """
    Element index
    If this element is a link or header, what is the standard term?
    There is 0 or 1 iqv_standard_term for each element
    """

    link_id = str
    """
    Element index
    Which [link <a href="#IQVDocumentLink">IQVDocumentLink</a>] section is this element in?
    The id for <a href="#IQVDocumentLink.LinkType">IQVDocumentLink.LinkType</a> == "toc"
    and <a href="#IQVDocumentLink.LinkLevel">IQVDocumentLink.LinkLevel</a> == 1
    """

    link_id_level2 = str
    """
    Element index
    Which [link <a href="#IQVDocumentLink">IQVDocumentLink</a>] section is this element in?
    The id for <a href="#IQVDocumentLink.LinkType">IQVDocumentLink.LinkType</a> == "toc"
    and <a href="#IQVDocumentLink.LinkLevel">IQVDocumentLink.LinkLevel</a> == 2
    """

    link_id_level3 = str
    """
    Element index
    Which [link <a href="#IQVDocumentLink">IQVDocumentLink</a>] section is this element in?
    The id for <a href="#IQVDocumentLink.LinkType">IQVDocumentLink.LinkType</a> == "toc"
    and <a href="#IQVDocumentLink.LinkLevel">IQVDocumentLink.LinkLevel</a> == 3
    """

    link_id_level4 = str
    """
    Element index
    Which [link <a href="#IQVDocumentLink">IQVDocumentLink</a>] section is this element in?
    The id for <a href="#IQVDocumentLink.LinkType">IQVDocumentLink.LinkType</a> == "toc"
    and <a href="#IQVDocumentLink.LinkLevel">IQVDocumentLink.LinkLevel</a> == 4
    """

    link_id_level5 = str
    """
    Element index
    Which [link <a href="#IQVDocumentLink">IQVDocumentLink</a>] section is this element in?
    The id for <a href="#IQVDocumentLink.LinkType">IQVDocumentLink.LinkType</a> == "toc"
    and <a href="#IQVDocumentLink.LinkLevel">IQVDocumentLink.LinkLevel</a> == 5
    """

    link_id_level6 = str
    """
    Element index
    Which [link <a href="#IQVDocumentLink">IQVDocumentLink</a>] section is this element in?
    The id for <a href="#IQVDocumentLink.LinkType">IQVDocumentLink.LinkType</a> == "toc"
    and <a href="#IQVDocumentLink.LinkLevel">IQVDocumentLink.LinkLevel</a> == 6
    """

    link_id_subsection1 = str
    """
    Element index
    Which [link <a href="#IQVDocumentLink">IQVDocumentLink</a>] section is this element in?
    The id for <a href="#IQVDocumentLink.LinkType">IQVDocumentLink.LinkType</a> == "subsection1"
    """

    link_id_subsection2 = str
    """
    Element index
    Which [link <a href="#IQVDocumentLink">IQVDocumentLink</a>] section is this element in?
    The id for <a href="#IQVDocumentLink.LinkType">IQVDocumentLink.LinkType</a> == "subsection2"
    """

    link_id_subsection3 = str
    """
    Element index
    Which [link <a href="#IQVDocumentLink">IQVDocumentLink</a>] section is this element in?
    The id for <a href="#IQVDocumentLink.LinkType">IQVDocumentLink.LinkType</a> == "subsection3"
    """

    parent_id = str
    """
    Element index
    Which item is this element a member of?
    For example, for <a href="#IQVPageROI.Properties">IQVPageROI.Properties</a>, parent_id = <a href="#IQVPageROI.id">IQVPageROI.id</a>
    Possible parents include but are not limited to
    <a href="#IQVDocument">IQVDocument</a><a href="#IQVPageROI">IQVPageROI</a><a href="#IQVDocumentLink">IQVDocumentLink</a>
    SQL code example 1 for usage of index
    <code>
    WHERE parent_id=parent_id AND group_type=group_type
    </code>
    SQL code example 2 for usage of index
    <code>
    WHERE parent_id=parent_id
    </code>
    """

    RawProbabilitiyScore = float
    """
    score assigned to this attribute
    """

    roi_id = str
    """
    id of roi in which this attribute is found
    """

    def __init__(self):
        self.AttributeKey = ''
        self.AttributeValue = ''
        self.CandidateSelected = -1
        self.doc_id = ''
        self.Features = []
        self.group_type = ''
        self.hierarchy = ''
        self.id = ''
        self.iqv_standard_term = ''
        self.link_id = ''
        self.link_id_level2 = ''
        self.link_id_level3 = ''
        self.link_id_level4 = ''
        self.link_id_level5 = ''
        self.link_id_level6 = ''
        self.link_id_subsection1 = ''
        self.link_id_subsection2 = ''
        self.link_id_subsection3 = ''
        self.parent_id = ''
        self.RawProbabilitiyScore = 0.0
        self.roi_id = ''


class IQVBigram(object):
    """
    Common Bigrams used for language identification
    """

    bDutch = bool
    """
    Is common in this language
    """

    bEnglish = bool
    """
    Is common in this language
    """

    bFrench = bool
    """
    Is common in this language
    """

    bGerman = bool
    """
    Is common in this language
    """

    bSpanish = bool
    """
    Is common in this language
    """

    languageCode = str
    """
    Language code if exists only in a single language
    """

    s1 = str
    """
    String 1 in bigram
    """

    s2 = str
    """
    String 2 in bigram
    """

    def __init__(self):
        self.bDutch = False
        self.bEnglish = False
        self.bFrench = False
        self.bGerman = False
        self.bSpanish = False
        self.languageCode = ''
        self.s1 = ''
        self.s2 = ''


class RectangleD(object):
    """
    spatial domain coordinates, typically in pixels
    """

    Height = float
    """
    height (y), typically in pixels
    """

    Width = float
    """
    width (x), typically in pixels
    """

    X = float
    """
    upper left, typically in pixels
    """

    Y = float
    """
    upper left, typically in pixels
    """

    def __init__(self):
        self.Height = 0.0
        self.Width = 0.0
        self.X = 0.0
        self.Y = 0.0


class FontInfo(object):
    """
    Information about the font of the text
    """

    Bold = bool
    """
    Specifies that the text of the text run is to be bold: <b>w:b</b>. This is a toggle property.
    Reference: ECMA-376, 3rd Edition(June, 2011), Fundamentals and Markup Language Reference § 17.3.2.1.
    """

    Caps = bool
    """
    Specifies that any lowercase characters are to be displayed as their uppercase equivalents. It cannot appear with smallCaps in the same text run: <b>w:caps w:val="true"</b>. This is a toggle property.
    Reference: ECMA-376, 3rd Edition(June, 2011), Fundamentals and Markup Language Reference § 17.3.2.5.
    """

    ColorRGB = int
    """
    Specifies the color to be used to display text: <b>w:color w:val="FFFF00"</b>
    Possible attributes are themeColor, themeShade, themeTint, and val.
           The val attribute specifies the color as a hex value in RRGGBB format, or auto may be specified to allow the consuming software to determine the color.
           Reference: ECMA-376, 3rd Edition(June, 2011), Fundamentals and Markup Language Reference § 17.3.2.6.
    """

    doc_id = str
    """
    Element index
    Which document is this element in?
    Top-level id for <a href="#IQVDocument">IQVDocument</a>
    """

    DStrike = bool
    """
    Specifies that the contents are to be displayed with two horizontal lines through each character: w:dstrike w:val="true". It cannot appear with strike in the same text run. This is a toggle property.
    dstrike
    Reference: ECMA-376, 3rd Edition(June, 2011), Fundamentals and Markup Language Reference § 17.3.2.37.
    """

    Emboss = bool
    """
    Specifies that the content should be displayed as if it were embossed, making text appear as if it is raised off of the page: <b>w:emboss w:val="true"</b>. This is a toggle property.
    Embossed text
    Note: The above example specifies emboss, but also sets the color to white: <b>w:emboss</b> OR <b>w:color w:val="FFFFFF"</b>. That seems to be necessary else the result looks like imprint.
    Reference: ECMA-376, 3rd Edition(June, 2011), Fundamentals and Markup Language Reference § 17.3.2.13.
    """

    group_type = str
    """
    Element index
    Which item is this element a member of? (name of member = group_type)
    For example, for <a href="#IQVPageROI.Properties">IQVPageROI.Properties</a>, group_type = "Properties"
    Possible parents include but are not limited to
    <a href="#IQVDocument">IQVDocument</a><a href="#IQVPageROI">IQVPageROI</a><a href="#IQVDocumentLink">IQVDocumentLink</a>
    SQL code example 1 for usage of index
    <code>
    WHERE parent_id=parent_id AND group_type=group_type
    </code>
    """

    hierarchy = str
    """
    image,table,paragraph,item,header,footer,roi
    """

    Highlight = str
    """
    <b>w:highlight w:val="yellow"</b>
    Background
    """

    id = str
    """
    id
    """

    Imprint = bool
    """
    Specifies that the content should be displayed as it it were imprinted (or engraved) into the page: <b>w:imprint w:val="true"</b>. This may not be present with either emboss or outline. This is a toggle property.
    Embossed text
    Reference: ECMA-376, 3rd Edition(June, 2011), Fundamentals and Markup Language Reference § 17.3.2.18.
    """

    iqv_standard_term = str
    """
    Element index
    If this element is a link or header, what is the standard term?
    There is 0 or 1 iqv_standard_term for each element
    """

    Italics = bool
    """
    Specifies that the text of the text run is to be italics: <b>w:i</b>. This is a toggle property.
    Reference: ECMA-376, 3rd Edition(June, 2011), Fundamentals and Markup Language Reference § 17.3.2.16.
    """

    link_id = str
    """
    Element index
    Which [link <a href="#IQVDocumentLink">IQVDocumentLink</a>] section is this element in?
    The id for <a href="#IQVDocumentLink.LinkType">IQVDocumentLink.LinkType</a> == "toc"
    and <a href="#IQVDocumentLink.LinkLevel">IQVDocumentLink.LinkLevel</a> == 1
    """

    link_id_level2 = str
    """
    Element index
    Which [link <a href="#IQVDocumentLink">IQVDocumentLink</a>] section is this element in?
    The id for <a href="#IQVDocumentLink.LinkType">IQVDocumentLink.LinkType</a> == "toc"
    and <a href="#IQVDocumentLink.LinkLevel">IQVDocumentLink.LinkLevel</a> == 2
    """

    link_id_level3 = str
    """
    Element index
    Which [link <a href="#IQVDocumentLink">IQVDocumentLink</a>] section is this element in?
    The id for <a href="#IQVDocumentLink.LinkType">IQVDocumentLink.LinkType</a> == "toc"
    and <a href="#IQVDocumentLink.LinkLevel">IQVDocumentLink.LinkLevel</a> == 3
    """

    link_id_level4 = str
    """
    Element index
    Which [link <a href="#IQVDocumentLink">IQVDocumentLink</a>] section is this element in?
    The id for <a href="#IQVDocumentLink.LinkType">IQVDocumentLink.LinkType</a> == "toc"
    and <a href="#IQVDocumentLink.LinkLevel">IQVDocumentLink.LinkLevel</a> == 4
    """

    link_id_level5 = str
    """
    Element index
    Which [link <a href="#IQVDocumentLink">IQVDocumentLink</a>] section is this element in?
    The id for <a href="#IQVDocumentLink.LinkType">IQVDocumentLink.LinkType</a> == "toc"
    and <a href="#IQVDocumentLink.LinkLevel">IQVDocumentLink.LinkLevel</a> == 5
    """

    link_id_level6 = str
    """
    Element index
    Which [link <a href="#IQVDocumentLink">IQVDocumentLink</a>] section is this element in?
    The id for <a href="#IQVDocumentLink.LinkType">IQVDocumentLink.LinkType</a> == "toc"
    and <a href="#IQVDocumentLink.LinkLevel">IQVDocumentLink.LinkLevel</a> == 6
    """

    link_id_subsection1 = str
    """
    Element index
    Which [link <a href="#IQVDocumentLink">IQVDocumentLink</a>] section is this element in?
    The id for <a href="#IQVDocumentLink.LinkType">IQVDocumentLink.LinkType</a> == "subsection1"
    """

    link_id_subsection2 = str
    """
    Element index
    Which [link <a href="#IQVDocumentLink">IQVDocumentLink</a>] section is this element in?
    The id for <a href="#IQVDocumentLink.LinkType">IQVDocumentLink.LinkType</a> == "subsection2"
    """

    link_id_subsection3 = str
    """
    Element index
    Which [link <a href="#IQVDocumentLink">IQVDocumentLink</a>] section is this element in?
    The id for <a href="#IQVDocumentLink.LinkType">IQVDocumentLink.LinkType</a> == "subsection3"
    """

    Outline = bool
    """
    Specifies that the content should be displayed as if it had an outline. A one-pixel border is drawn around the inside and outside borders of each character. <b>outline w:val="true"</b>. This is a toggle property.
    text outline
    Reference: ECMA-376, 3rd Edition(June, 2011), Fundamentals and Markup Language Reference § 17.3.2.23.
    """

    parent_id = str
    """
    Element index
    Which item is this element a member of?
    For example, for <a href="#IQVPageROI.Properties">IQVPageROI.Properties</a>, parent_id = <a href="#IQVPageROI.id">IQVPageROI.id</a>
    Possible parents include but are not limited to
    <a href="#IQVDocument">IQVDocument</a><a href="#IQVPageROI">IQVPageROI</a><a href="#IQVDocumentLink">IQVDocumentLink</a>
    SQL code example 1 for usage of index
    <code>
    WHERE parent_id=parent_id AND group_type=group_type
    </code>
    SQL code example 2 for usage of index
    <code>
    WHERE parent_id=parent_id
    </code>
    """

    rFonts = str
    """
    Font regular name
    """

    rStyle = str
    """
    Specifies the style ID of the character style to be used to format the contents of the run.
    Reference: ECMA-376, 3rd Edition(June, 2011), Fundamentals and Markup Language Reference § 17.3.2.29.
    """

    Shadow = bool
    """
    Specifies that the content should be displayed as if each character has a shadow: <b>w:shadow w:val="true"</b>. For left-to-right text, the shadow is beneath the text and to its right. shadow may not be present with either emboss or imprint. This is a toggle property.
    Embossed text
    Reference: ECMA-376, 3rd Edition(June, 2011), Fundamentals and Markup Language Reference § 17.3.2.31.
    """

    Size = int
    """
    Specifies the font size in half points: <b>w:sz w:val="28"</b>. Note that szCs is used for complex script fonts such as Arabic.
    The single attribute val specifies a measurement in half-points(1/144 of an inch).
    Reference: ECMA-376, 3rd Edition(June, 2011), Fundamentals and Markup Language Reference § 17.3.2.38.
    """

    SmallCaps = bool
    """
    Specifies that any lowercase characters are to be displayed as their uppercase equivalents in a font size two points smaller than the specified font size: <b>w:smallCaps w:val="true"</b>. It cannot appear with caps in the same text run. This is a toggle property.
    small caps
    Reference: ECMA-376, 3rd Edition(June, 2011), Fundamentals and Markup Language Reference § 17.3.2.33.
    """

    Strike = bool
    """
    Specifies that the contents are to be displayed with a horizontal line through the center of the line: <b>w:strike w:val="true"</b>. It cannot appear with dstrike in the same text run. This is a toggle property.
    Reference: ECMA-376, 3rd Edition(June, 2011), Fundamentals and Markup Language Reference § 17.3.2.37.
    """

    Underline = str
    """
    Specifies that the content should be displayed with an underline: <b>w:u w:val="double"</b>.
    The most common attributes are below(the theme-related attributed are omitted):
    color - specifies the color for the underlining.Values are given as hex values (in RRGGBB format). No #, unlike hex values in HTML/CSS. E.g., color="FFFF00". A value of auto is also permitted and will allow the consuming word processor to determine the color based on the context.
    val - Specifies the pattern to be used to create the underline.Possible values are:
    dash - a dashed line
    dashDotDotHeavy - a series of thick dash, dot, dot characters
    dashDotHeavy - a series of thick dash, dot characters
    dashedHeavy - a series of thick dashes
    dashLong - a series of long dashed characters
    dashLongHeavy - a series of thick, long, dashed characters
    dotDash - a series of dash, dot characters
    dotDotDash - a series of dash, dot, dot characters
    dotted - a series of dot characters
    dottedHeavy - a series of thick dot characters
    double - two lines
    none - no underline
    single - a single line
    thick - a single think line
    wave - a single wavy line
    wavyDouble - a pair of wavy lines
    wavyHeavy - a single thick wavy line
    words - a single line beneath all non-space characters
    Reference: ECMA-376, 3rd Edition (June, 2011), Fundamentals and Markup Language Reference § 17.3.2.40.
    """

    Vanish = bool
    """
    Specifies that the content is to be hidden from display at display time. <b>vanish</b>. This is a toggle property.
    Reference: ECMA-376, 3rd Edition(June, 2011), Fundamentals and Markup Language Reference § 17.3.2.41.
    """

    VertAlign = str
    """
    Subscript and superscript. <b>vertAlign w:val="superscript"</b>.
    The single attribute is val.Permitted values are:
    baseline - regular vertical positioning
    subscript - lowers the text below the baseline and changes it to a small size
    superscript - raises the text above the baseline and changes it to a smaller size
    Reference: ECMA-376, 3rd Edition(June, 2011), Fundamentals and Markup Language Reference § 17.3.2.42.
    """

    def __init__(self):
        self.Bold = False
        self.Caps = False
        self.ColorRGB = -1
        self.doc_id = ''
        self.DStrike = False
        self.Emboss = False
        self.group_type = ''
        self.hierarchy = ''
        self.Highlight = ''
        self.id = ''
        self.Imprint = False
        self.iqv_standard_term = ''
        self.Italics = False
        self.link_id = ''
        self.link_id_level2 = ''
        self.link_id_level3 = ''
        self.link_id_level4 = ''
        self.link_id_level5 = ''
        self.link_id_level6 = ''
        self.link_id_subsection1 = ''
        self.link_id_subsection2 = ''
        self.link_id_subsection3 = ''
        self.Outline = False
        self.parent_id = ''
        self.rFonts = ''
        self.rStyle = ''
        self.Shadow = False
        self.Size = -1
        self.SmallCaps = False
        self.Strike = False
        self.Underline = ''
        self.Vanish = False
        self.VertAlign = ''


class Config(object):
    """
    Class for system configuration. Includes machine setup
    as well as AI configuration.
    """

    AIDocQueue_IsAdmin = int
    """
    Using RabbitMQ etmfa_core.aidoc Queue, will this be reading the queue
    for COMPLETE messages
    and handling display of results from the queue? 1=yes, 0=no
    """

    AIDocQueue_IsWorker = int
    """
    Using RabbitMQ etmfa_core.aidoc Queue, will this be reading the queue
    for REQUEST messages
    and handling requests from the queue? 1=yes, 0=no
    """

    AIDocQueue_NumWorkers = int
    """
    Using RabbitMQ etmfa_core.aidoc Queue, will this be reading the queue
    for REQUEST messages
    and handling requests from the queue... How many
    Number of workers to have running at a time
    """

    API_Endpoint = str
    """
    Swagger API Endpoint for POST
     Use this for running a batch
    PD DEV is originally http://ca2spdml01q:9001/pd/api/v1/documents/
    """

    API_Key = str
    """
    Swagger API Key for POST
     Use this for running a batch
    PD DEV is originally ypd_unit_test:!53*URTa$k1j4t^h2~uSseatnai@nr
    """

    bClearWorkingDirectory = int
    """
    true=1 to clear temp storage
    """

    bCorrectRotation = int
    """
    Perform rotation correction?
    """

    bDeleteAllFilesExceptFinalizerOutputFile = bool
    """
    On successful completion of document processing,
    delete all files (except final IQV.XML and the input source file)
    from processing/output directory, if true.
     Do not delete if false.
     Directory for document is listed at
     <a href="#IQVDocument.QDocumentWorkingDirectory">IQVDocument.QDocumentWorkingDirectory</a>
    Parent directory for collection of documents at
    <a href="#Config.OutputDirectory">Config.OutputDirectory</a>
    """

    bDeleteInputSourceFile = bool
    """
    On successful completion of document processing,
    delete the input source file from
     processing/output directory, if true.
     Do not delete if false.
     Directory for document is listed at
     <a href="#IQVDocument.QDocumentWorkingDirectory">IQVDocument.QDocumentWorkingDirectory</a>
    Parent directory for collection of documents at
    <a href="#Config.OutputDirectory">Config.OutputDirectory</a>
    """

    bDeleteWorkingTempDirOnSuccessComplete = int
    """
    -deleteTmp default = true; files used only for intermediate processing and debugging
    """

    bDictionaryBernoulliSingleCounts = int
    """
    Use single counts (Bernoulli)
    """

    bDocumentManagerEXE_CloseAfterProcessDocument = int
    """
    Close form windows after complete (should be true for production server processing)
    """

    bELK_EnableLogging = int
    """
    Enable logging to elasticsearch
    """

    bMSG_EnableMessaging = int
    """
    Use timer to check RabbitMQ
    """

    bMSG_EnableMessaging_CompareProcessing = int
    """
    Use timer to check RabbitMQ
    """

    bMSG_EnableMessaging_Digitizer2Processing = int
    """
    Use timer to check RabbitMQ
    """

    bMSG_EnableMessaging_NormSOAGenerate = int
    """
    Use timer to check RabbitMQ
    """

    bMSG_EnableMessaging_OMOPGenerate = int
    """
    Use timer to check RabbitMQ
    """

    bMSG_EnableMessaging_OMOPProcessing = int
    """
    Use timer to check RabbitMQ
    """

    bMSG_EnableMessaging_QCFeedbackProcessing = int
    """
    Use timer to check RabbitMQ
    """

    bNoiseGenGreyscale = bool
    """
    Noise Generation settings
    """

    bNoiseGenLegibility = bool
    """
    Noise Generation settings
    """

    bNoiseGenPageBlanks = bool
    """
    Noise Generation settings
    """

    bNoiseGenPageOrientation = bool
    """
    Noise Generation settings
    """

    bNoiseGenPageSequence = bool
    """
    Noise Generation settings
    """

    bOCRRaiseErrorIfScan = int
    """
    Raise error 903 if this is a scanned document
    """

    bOutput_OmopPrefixText = int
    """
    Turn on or off: Text to prepend output file with
    """

    bOutput_PrefixText = int
    """
    Turn on or off: Text to prepend output file with
    """

    bOutput_QCFeedbackPrefixText = int
    """
    QC Ingest
    -bqcprefix
    """

    bOutput_ToMetricsDir = int
    """
    Turn on or off: Directory of metrics files
    """

    bProvideRemoteService = int
    """
    1 or 0
    """

    bRunInternalOCRProcesses = int
    """
    Use internal OCR (.NET calling tesseract)
    """

    bRunPyIPOCRProcesses = int
    """
    Use python--default is no
    """

    bTMFGTOutputConstrained = bool
    """
    Analysis output for GT matching to TMF matrix items
    """

    bUseDBConnection = int
    """
    Database settings
    """

    bUseMTServer = int
    """
    1 to call in to API
    """

    bUseSegServer = int
    """
    1 to call in to API
    """

    bWatchLog_EnableWebserverRequests = int
    """
    Use timer to check Watch Log
    """

    ClfCodePathFilename = str
    """
    Python clf code as in path/tester.py
    """

    ConfigFilename = str
    """
    Read settings from config file
    """

    CorpusLevel = int
    """
    -corpusLevel Training Level for which dictionary items to train on;
    which to include and which to not include
    """

    CorrectRotation_RotationIncrementDegrees = float
    """
    Increment to check in degrees
    """

    CorrectRotation_RotationRangeDegrees = float
    """
    Range from 0 as mean, in each direction (positive and negative), in degrees
    """

    Country = str
    """
    -srclang
    Use to constrain the source country for translation
    """

    CountryMappingFilename = str
    """
    Country Mapping list of <a href="#IQVCountryMapping">IQVCountryMapping</a>
     which contains for each country
    list of <a href="#IQVLanguageMapping">IQVLanguageMapping</a>
    that includes script and <a href="#LanguageCode">LanguageCode</a>
    """

    CustomHostName = str
    """
    For display purposes, provide code name for this machine
    """

    DataSplit_TestPercent = int
    """
    -testRatio Split dataset into training and test;
    """

    DataSplit_TrainingPercent = int
    """
    -trainRatio Split dataset into training and test;
    """

    DBConn_Database = str
    """
    Database settings
    """

    DBConn_Login = str
    """
    Database settings
    """

    DBConn_Password = str
    """
    Database settings
    """

    DBConn_Server = str
    """
    Database settings
    """

    DebugMode = int
    """
    Default = 0 = no debug, otherwise use this as a code to run
     certain stage of the process. Similar to OUTPUT_LEVEL, but not aligned
    with user outputs.
    Aligns with <a href="#DEBUG_MODE">DEBUG_MODE</a>
    """

    DebugType = int
    """
    Default = 0 = no debug, otherwise use this as a code to run debugging
    """

    DefaultRotation = float
    """
    If pre-determined, what rotation to use for this document? in degrees
    """

    DictionarybRemoveCommonTerms = int
    """
    Yes/No remove common terms (more than stop words)
    """

    DictionarybRemoveSparseTerms = int
    """
    Yes/no remove sparse terms <a href="#Config.DictionaryRemoveSparseTerms_MinDocCount">Config.DictionaryRemoveSparseTerms_MinDocCount</a>
    """

    DictionaryIncludeAdditionalFeatures = int
    """
    Part of corpus level now separate
    """

    DictionaryIncludeBigrams = int
    """
    text analysis dictionary
    """

    DictionaryIncludeLines = int
    """
    text analysis dictionary
    """

    DictionaryIncludeStopWords = int
    """
    text analysis dictionary
    """

    DictionaryIncludeTrigrams = int
    """
    text analysis dictionary
    """

    DictionaryRemoveCommonTerms_MaxDocCount = int
    """
    Threshold to remove common terms
    """

    DictionaryRemoveSparseTerms_MinDocCount = int
    """
    Threshold to say is sparse term
    """

    Dig1CodePathFilename = str
    """
    Python Dig1 code as in path/tester.py
    """

    Dig1DocID = str
    """
    Unique document ID, used when invoking Dig1
    and passing in the requested doc id for initialization
    of <a href="#IQVDocument">IQVDocument</a>
    """

    DisplayLabel = str
    """
    -label
    """

    doc_id = str
    """
    Element index
    Which document is this element in?
    Top-level id for <a href="#IQVDocument">IQVDocument</a>
    """

    DOCANALYSIS_TrainedNaiveBayesLibFilename = str
    """
    For document classification
    """

    DocID = str
    """
    Unique document ID
    """

    DocID1 = str
    """
    Unique document ID1 for compare
    """

    DocID2 = str
    """
    Unique document ID2 for compare
    """

    DocumentManagerEXE = str
    """
    Location on server
    """

    DocumentManagerVersion = str
    """
    Location on server
    """

    DropBox1Dir = str
    """
    Original drop box, gets re-assigned during processing of document
    by external process (translation orchestrator).
    """

    DropBoxWebUI = str
    """
    Dynamic drop box, assigned during processing of document
    by external process (translation orchestrator).
    """

    ELK_HostName = str
    """
    ELK Logstash/Elasticsearch service
    """

    ELK_Port = int
    """
    ELK Logstash/Elasticsearch service
    """

    ETMFDocumentSource = str
    """
    eTMF Document Source
    """

    ETMFOutputDir = str
    """
    eTMF Document Directory
    """

    ExcelTemplate_SOA = str
    """
    Template for Excel SOA Output
    """

    EXE_CompareRunner = str
    """
    Location on server
    """

    EXE_FeedbackUpdate = str
    """
    Location on server
    """

    EXE_NormSOA = str
    """
    Location on server
    """

    EXE_OMOPGenerate = str
    """
    Location on server
    """

    EXE_OMOPIngester = str
    """
    Location on server
    """

    FileDownloadStartIndex = int
    """
    Download using links; don't know the suggested filename until
    we get there. So use a known index rather than calculating by filename
    """

    flow_id = str
    """
    flow parameter for service workflow management
    """

    flow_name = str
    """
    flow parameter for service workflow management
    """

    GenerateNoise = int
    """
    0: no action; 1: generate noise according to noise type;
    store results in <a href="#Config.GroundTruthMasterFilename">Config.GroundTruthMasterFilename</a>
    """

    GhostscriptEXEFilename = str
    """
    Location on server
    """

    GroundTruthMasterFilename = str
    """
    Master filename for GT
    """

    GroundTruthOutputDirectory = str
    """
    Used when creating/generating noisy documents;
    create new file for each document or document set
    and save file to this directory
    """

    id = str
    """
    id
    """

    ImageProc_BulletImagesDir = str
    """
    Directory of pre-identified bullet images for
     bullet processing
    """

    ImageQC_GreyscaleThreshold = float
    """
    Threshold for ImageQC
    """

    ImageQC_LegibilityThreshold = float
    """
    Threshold for ImageQC
    """

    ImagesDirectory = str
    """
    Where to put images that are embedded in Document;
    -imgdir
    """

    InputDataDirectory = str
    """
    Directory to process
    """

    InputImageFilename = str
    """
    Input processed into an image
    """

    InputRawFilename = str
    """
    Input received by ingester for one page; Typically PDF format
    """

    InputSourceMasterFilename = str
    """
    Input received by ingester for full file; Typically PDF format
    """

    InputWorkingMasterFilename = str
    """
    Input placed in working directory; copy of InputSourceMasterFilename
    """

    IQVDocumentMappingFilename = str
    """
    Filename of list of <a href="#IQVDocumentMapping">IQVDocumentMapping</a> for
     the various document classifications.
    Related <a href="#Config.CountryMappingFilename">Config.CountryMappingFilename</a>
    """

    IQVEnvironment = str
    """
    environment/system connection
    """

    IQVMeasurementProcedureLUTFilename = str
    """
    Lookup Table (LUT) for
    <a href="#IQVMeasurementProcedure">IQVMeasurementProcedure</a> listing
    """

    IQVXML_DBConn_bUseDBConnection = int
    """
    Database settings
    """

    IQVXML_DBConn_bUseDBConnection_PostDig2 = int
    """
    Database settings
    """

    IQVXML_DBConn_bUseDBConnection_PostOU = int
    """
    Database settings
    """

    IQVXML_DBConn_Database = str
    """
    Database settings
    """

    IQVXML_DBConn_Login = str
    """
    Database settings
    """

    IQVXML_DBConn_Password = str
    """
    Database settings
    """

    IQVXML_DBConn_Port = int
    """
    Database settings
    """

    IQVXML_DBConn_Server = str
    """
    Database settings
    """

    IQVXMLInputFilename = str
    """
    IQV.XML input of previous processing
    -iqvxml
    """

    IQVXMLInputFilename2 = str
    """
    IQV.XML input of previous processing for compare
    -iqvxml2
    """

    LanguageAnalysisLib = str
    """
    Do language analysis to auto-detect language
    """

    LocalTopLevelDataDir = str
    """
    To use 2 computers with different drive names
    or paths, use the common top level directory
    (such as eTMF directory)
    """

    LogDirectory = str
    """
    Log output
    """

    LogFilename = str
    """
    Log file in XML format
    """

    MasterFile = int
    """
    Master File of multiple pages;
    If not master, then single page only (slave)
    """

    MasterIQVDocumentListFilename = str
    """
    List of IQVDocument's that are undergoing processing
    """

    MatrixFile = str
    """
    matrix file
    """

    MaxCellsPerPage = int
    """
    Used for CSV/Excel worksheet, to handle very large files.
    Use in conjunction with <a href="#Config.MaxPagesCoreProcessing_FrontSection">Config.MaxPagesCoreProcessing_FrontSection</a>
    and <a href="#Config.MaxPagesCoreProcessing_BackSection">Config.MaxPagesCoreProcessing_BackSection</a>.
     A "page" is a set of rows. This will allow complete row to be processed
    and prevent partial rows. The number of rows per page = MaxCellsPerPage / num_cols,
    with a lower bound of 1 row per page. For a CSV with 110 columns, there
    will be 1 row per page, if MaxCellsPerPage = 100. For a CSV with 25 columns,
    there will be 4 rows per page, if MaxCellsPerPage = 100.
    """

    MaxNumDocsToProcess = int
    """
    Max number of docs to process total -maxdocs
    """

    MaxPagesCoreProcessing_BackSection = int
    """
    For core processing, this is upper bound for number of pages at the
    end of the document. Pages in the middle of the document will not be
     processed (with the exception of QC). For example, if
     <a href="#Config.MaxPagesCoreProcessing_FrontSection">Config.MaxPagesCoreProcessing_FrontSection</a> = 3,
    <a href="#Config.MaxPagesCoreProcessing_BackSection">Config.MaxPagesCoreProcessing_BackSection</a> = 2, and the
    document has N=20 pages, only pages
    1, 2, and 3 will be processed in the front section, and 19, 20 in the back
    section (last 2 pages of the document)
    """

    MaxPagesCoreProcessing_FrontSection = int
    """
    For core processing, this is upper bound for number of pages at the
    beginning of the document. Pages in the middle of the document will not be
     processed (with the exception of QC). For example, if
     <a href="#Config.MaxPagesCoreProcessing_FrontSection">Config.MaxPagesCoreProcessing_FrontSection</a> = 3,
    <a href="#Config.MaxPagesCoreProcessing_BackSection">Config.MaxPagesCoreProcessing_BackSection</a> = 2, and the
    document has N=20 pages, only pages
    1, 2, and 3 will be processed in the front section, and 19, 20 in the back
    section (last 2 pages of the document)
    """

    MaxPagesToProcess = int
    """
    Max number of pages in a document -maxpages
    """

    MaxPagesToProcessIQVTM = int
    """
    Max number of pages in a document for text mining
    -maxPagesIQVTM
    """

    MaxTimeMinutesPerPage = int
    """
    For each page, interrupt processing if it exceeds
    processing time in minutes past this parameter -maxtime;
    for unlimited time, use -1 value
    """

    MinPixelHeightForOCR = int
    """
    Only process images for OCR  if they meet minimum size requirements, in pixels. Used
    to filter out noise in PDF files
    """

    MinPixelHeightForValidImage = int
    """
    Only save images if they meet minimum size requirements, in pixels. Used
    to filter out noise in PDF files
    """

    MinPixelWidthForOCR = int
    """
    Only process images for OCR if they meet minimum size requirements, in pixels. Used
    to filter out noise in PDF files
    """

    MinPixelWidthForValidImage = int
    """
    Only save images if they meet minimum size requirements, in pixels. Used
    to filter out noise in PDF files
    """

    MSG_ErrorLevelLowerBound = int
    """
    Lower Bound for severity level to be sent to message queue;
    default = 5 <a href="#Q_ERROR_LEVEL.CRITICAL">Q_ERROR_LEVEL.CRITICAL</a>
    """

    MSG_ExchangeIsDurable = int
    """
    AMQP arg 'durable' for exchange;
    expecting true (1)
    """

    MSG_HostName = str
    """
    RabbitMQ service
    """

    MSG_MaxCPU = int
    """
    RabbitMQ service: Will not receive/listen
     for messages if current CPU is above this level
    """

    MSG_MaxRAM = int
    """
    RabbitMQ service: Will not receive/listen
     for messages if current RAM is above this level
    """

    MSG_Password = str
    """
    RabbitMQ service
    """

    MSG_Port = int
    """
    RabbitMQ service
    """

    MSG_QueueIsDurable = int
    """
    AMQP arg 'durable' for queue;
    expecting false (0)
    """

    MSG_User = str
    """
    RabbitMQ service
    """

    MSG_VirtualHost = str
    """
    RabbitMQ service
    """

    MTServer_Endpoint = str
    """
    Translation API
    Translation engine API for bulk document processing.
    Internal API for running XLIFF translation only
    """

    MTServer_LocalPathMapping = str
    """
    Translation API
    Translation engine API for bulk document processing.
    Internal API for running XLIFF translation only
    """

    MTServer_MachineName = str
    """
    Translation API
    Translation engine API for bulk document processing.
    Internal API for running XLIFF translation only
    """

    MTServer_Password = str
    """
    Translation API if HTTPBasicAuth
    """

    MTServer_Port = str
    """
    Translation API
    Translation engine API for bulk document processing.
    Internal API for running XLIFF translation only
    """

    MTServer_SecureHTTP = int
    """
    1 to call in to API with https, 0 with http
    """

    MTServer_SharedDir = str
    """
    Translation API
    Translation engine API for bulk document processing.
    Internal API for running XLIFF translation only
    """

    MTServer_User = str
    """
    Translation API if HTTPBasicAuth
    """

    NLP_CharMatrixDirectory = str
    """
    Language-specific files in this directory for
    character confusion matrices
    """

    NLP_DictionaryDirectory = str
    """
    Language-specific files in this directory for
    dictionary lookup
    """

    NoiseGenMaxRecords = int
    """
    Noise Generation settings
    """

    NoiseGenStartIndex = int
    """
    Noise Generation settings
    """

    NoiseType = int
    """
    For noise generation
    """

    OCR_bUseSpellCheck = int
    """
    Flag to utilize OCR Spell Check or not
    """

    OCR_SpellCheckDirectory = str
    """
    Main directory to keep OCR Spell Check trained engines in; each
    file is labelled using language-specific code
    """

    OCR_UserWordsDirectory = str
    """
    Main directory to keep OCR User Words in; each
    file is labelled using language-specific code
    """

    OMOPUpdateFilename = str
    """
    Updated omop
    -omop
    """

    Output_OmopPrefixText = str
    """
    Text to prepend output file with
    """

    Output_PrefixText = str
    """
    Text to prepend output file with
    """

    Output_QCFeedbackPrefixText = str
    """
    QC Ingest
    -qcprefix
    OutputPrefixText
    """

    Output_ToCompareDir = str
    """
    Directory of compare files
    """

    Output_ToMetricsDir = str
    """
    Directory of metrics files
    """

    OutputDirectory = str
    """
    Persistent output
    """

    OutputFilename = str
    """
    QXML Format
    """

    OutputLevel = int
    """
    processing workflow
    """

    PageIndex = int
    """
    Page index is -1 for master file,
    zero-based for individual pages (slave)
    """

    PerformBatchDocClass = int
    """
    -br arg;
    0=no action
    1=standard action
    """

    PerformDocumentDeconstruction = int
    """
    -docdecon
    """

    PerformDocumentReconstruction = int
    """
    -docrecon
    """

    PerformDuplicateCheck = int
    """
    -dd arg;
    0=no action
    1=standard action
    """

    PerformImageQC = int
    """
    -qc arg;
    0=no action;
    1=standard action;
    """

    PerformMetadata = int
    """
    -md arg;
    0=no action;
    1=standard action
    """

    PerformRotations = int
    """
    -rot arg;
    0=no action;
    1=standard action (4 major rotations at 0,90,180,270 degrees)
    """

    PerformXLIFFReceive = int
    """
    -xliffrecv
    used to update the qiDocument with xliff
    """

    PerformXLIFFSend = int
    """
    -xliffsend
    """

    PerformXLIFFSourceCreation = int
    """
    -xliffsrc
    """

    Priority = int
    """
    processing priority
    """

    ProcessSource = int
    """
    Process either the Input data directory
    or a ground truth list (with filenames)
    """

    PythonEnvironment = str
    """
    Python environment for anaconda activate bat location
    """

    PythonEXEFilename = str
    """
    Python interpreter, or anaconda activate bat location
    """

    QCFeedbackJSONFilename = str
    """
    QC Ingest
    -qcjson
    """

    QCFeedbackRunId = str
    """
    QC Ingest
    -qcrunid
    FeedbackRunId
    """

    Recon_bUseTemplateMatching = int
    """
    Flag to utilize recon template
    """

    Recon_TemplateDirectory = str
    """
    Directory of all Word templates for reconstruction
    Name . numeric code . file extension
    """

    Recon_TemplateFilename = str
    """
    Filename of document template for reconstruction
    """

    RedactionProfileID = str
    """
    Profile ID
    """

    RedactionProfileListingFilename = str
    """
    Filename of all redaction profiles
    """

    RedactionReplacementMethod = str
    """
    label or mask
    """

    RedactionTextMask = str
    """
    if <a href="#Config.RedactionReplacementMethod">Config.RedactionReplacementMethod</a> == mask, then
    the static text string that is used for every
    replacement
    """

    RedactionTextPrefix = str
    """
    if <a href="#Config.RedactionReplacementMethod">Config.RedactionReplacementMethod</a> == mask OR
    <a href="#Config.RedactionReplacementMethod">Config.RedactionReplacementMethod</a> == label
    prefix to apply to every replacement
    (either label or static mask)
    Can be delimiter such as '['
    """

    RedactionTextSuffix = str
    """
    if <a href="#Config.RedactionReplacementMethod">Config.RedactionReplacementMethod</a> == mask OR
    <a href="#Config.RedactionReplacementMethod">Config.RedactionReplacementMethod</a> == label
    suffix to apply to every replacement
    (either label or static mask)
    Can be delimiter such as ']'
    """

    RemoteServer_MachineName = str
    """
    Remote Server
    """

    RemoteServer_Port = str
    """
    Remote Server
    """

    RemoteServer_ServerLocalDir = str
    """
    Here is support for Remote Services processing
      Map the local directory from the webserver to the
      SHARED directory that this process can access
    """

    RemoteServer_SharedDir = str
    """
    Here is support for Remote Services processing
      Map the local directory from the webserver to the
      SHARED directory that this process can access
    """

    Rotation = int
    """
    -rotexe: Forced Rotation to be performed on this image
    """

    RunRemote = bool
    """
    Remote settings
    """

    SegmentationType = int
    """
    Baseline = 1 = segmentation;
    0 = no segmentation,
    2 = language-specific segmentation,
    otherwise use this as a code to run debugging
    """

    SegServer_Endpoint = str
    """
    Segmentation API
    Segmentation engine API for bulk document processing.
    Internal API for running Doc Paragraph Segmentation only
    """

    SegServer_LocalPathMapping = str
    """
    Segmentation API
    Segmentation engine API for bulk document processing.
    Internal API for running Doc Paragraph Segmentation only
    """

    SegServer_MachineName = str
    """
    Segmentation API
    Segmentation engine API for bulk document processing.
    Internal API for running Doc Paragraph Segmentation only
    """

    SegServer_Port = str
    """
    Segmentation API
    Segmentation engine API for bulk document processing.
    Internal API for running Doc Paragraph Segmentation only
    """

    SegServer_SecureHTTP = int
    """
    1 to call in to API with https, 0 with http
    """

    SegServer_SharedDir = str
    """
    Segmentation API
    Segmentation engine API for bulk document processing.
    Internal API for running Doc Paragraph Segmentation only
    """

    ShowProgressForm = int
    """
    -showform show progress form on screen
    """

    sofficeLocation = str
    """
    LibreOffice soffice location, including "soffice",
     as in "C:/Program Files/LibreOffice/program/soffice" for
    a Windows machine
    """

    SourceLanguage = str
    """
    -srclang
    Use to constrain the source language for translation
    """

    StandardTemplateIQVXML = str
    """
    Preprocessed standard template file as IQV.XML.
    This IQV.XML will be ingested as input for
     standard template matching for a given document
    """

    TargetLanguage = str
    """
    -tgtlang
    """

    tessdataDir = str
    """
    For tesseract, where is tessdata? (1+ GB directory)
    """

    TesseractEXEFilename = str
    """
    Location on server
    """

    TMFGTOutputConstrained_AvgPages = int
    """
    Analysis output for GT matching to TMF matrix items
    """

    TMFGTOutputConstrained_MinSamples = int
    """
    Analysis output for GT matching to TMF matrix items
    """

    TMFRawDataSourceDirectory = str
    """
    Used when importing raw TMF Data
    """

    TMSServer_Endpoint = str
    """
    Translation Management Service API
    Translation Management Service API for document translation.
    Document Translate : REST endpoints for document translation workflows.
    External API for Mulesoft/Appian full workflow
    """

    TMSServer_Info = str
    """
    Translation Management Service API
    Translation Management Service API for document translation.
    Document Translate : REST endpoints for document translation workflows.
    External API for Mulesoft/Appian full workflow
    """

    TMSServer_MachineName = str
    """
    Translation Management Service API
    Translation Management Service API for document translation.
    Document Translate : REST endpoints for document translation workflows.
    External API for Mulesoft/Appian full workflow
    """

    TMSServer_Port = str
    """
    Translation Management Service API
    Translation Management Service API for document translation.
    Document Translate : REST endpoints for document translation workflows.
    External API for Mulesoft/Appian full workflow
    """

    TMSSharedDirectoryList = []
    """
    TMS Shared directory location
    """

    UserEmail = str
    """
    End User information
    """

    UserID = str
    """
    End User information
    """

    WatchLogCheckIntervalSeconds = float
    """
    Watch Log settings
    """

    WatchLogFilename = str
    """
    Watch Log settings for input
    """

    WatchLogOutputDir = str
    """
    Watch Log settings for processed output
    """

    WatchLogOutputDirPermanentStorage = str
    """
    Watch Log settings for processed output--full IQV.XML and artifacts
    """

    WorkingDirectory = str
    """
    Working copy of the file
    """

    XLIFFInputFilename = str
    """
    -xliff
    """

    XLIFFMarkupVersion = str
    """
    XLIFF markup 2.0
    """

    def __init__(self):
        self.AIDocQueue_IsAdmin = -1
        self.AIDocQueue_IsWorker = -1
        self.AIDocQueue_NumWorkers = -1
        self.API_Endpoint = ''
        self.API_Key = ''
        self.bClearWorkingDirectory = -1
        self.bCorrectRotation = -1
        self.bDeleteAllFilesExceptFinalizerOutputFile = False
        self.bDeleteInputSourceFile = False
        self.bDeleteWorkingTempDirOnSuccessComplete = -1
        self.bDictionaryBernoulliSingleCounts = -1
        self.bDocumentManagerEXE_CloseAfterProcessDocument = -1
        self.bELK_EnableLogging = -1
        self.bMSG_EnableMessaging = -1
        self.bMSG_EnableMessaging_CompareProcessing = -1
        self.bMSG_EnableMessaging_Digitizer2Processing = -1
        self.bMSG_EnableMessaging_NormSOAGenerate = -1
        self.bMSG_EnableMessaging_OMOPGenerate = -1
        self.bMSG_EnableMessaging_OMOPProcessing = -1
        self.bMSG_EnableMessaging_QCFeedbackProcessing = -1
        self.bNoiseGenGreyscale = False
        self.bNoiseGenLegibility = False
        self.bNoiseGenPageBlanks = False
        self.bNoiseGenPageOrientation = False
        self.bNoiseGenPageSequence = False
        self.bOCRRaiseErrorIfScan = -1
        self.bOutput_OmopPrefixText = -1
        self.bOutput_PrefixText = -1
        self.bOutput_QCFeedbackPrefixText = -1
        self.bOutput_ToMetricsDir = -1
        self.bProvideRemoteService = -1
        self.bRunInternalOCRProcesses = -1
        self.bRunPyIPOCRProcesses = -1
        self.bTMFGTOutputConstrained = False
        self.bUseDBConnection = -1
        self.bUseMTServer = -1
        self.bUseSegServer = -1
        self.bWatchLog_EnableWebserverRequests = -1
        self.ClfCodePathFilename = ''
        self.ConfigFilename = ''
        self.CorpusLevel = -1
        self.CorrectRotation_RotationIncrementDegrees = 0.0
        self.CorrectRotation_RotationRangeDegrees = 0.0
        self.Country = ''
        self.CountryMappingFilename = ''
        self.CustomHostName = ''
        self.DataSplit_TestPercent = -1
        self.DataSplit_TrainingPercent = -1
        self.DBConn_Database = ''
        self.DBConn_Login = ''
        self.DBConn_Password = ''
        self.DBConn_Server = ''
        self.DebugMode = -1
        self.DebugType = -1
        self.DefaultRotation = 0.0
        self.DictionarybRemoveCommonTerms = -1
        self.DictionarybRemoveSparseTerms = -1
        self.DictionaryIncludeAdditionalFeatures = -1
        self.DictionaryIncludeBigrams = -1
        self.DictionaryIncludeLines = -1
        self.DictionaryIncludeStopWords = -1
        self.DictionaryIncludeTrigrams = -1
        self.DictionaryRemoveCommonTerms_MaxDocCount = -1
        self.DictionaryRemoveSparseTerms_MinDocCount = -1
        self.Dig1CodePathFilename = ''
        self.Dig1DocID = ''
        self.DisplayLabel = ''
        self.doc_id = ''
        self.DOCANALYSIS_TrainedNaiveBayesLibFilename = ''
        self.DocID = ''
        self.DocID1 = ''
        self.DocID2 = ''
        self.DocumentManagerEXE = ''
        self.DocumentManagerVersion = ''
        self.DropBox1Dir = ''
        self.DropBoxWebUI = ''
        self.ELK_HostName = ''
        self.ELK_Port = -1
        self.ETMFDocumentSource = ''
        self.ETMFOutputDir = ''
        self.ExcelTemplate_SOA = ''
        self.EXE_CompareRunner = ''
        self.EXE_FeedbackUpdate = ''
        self.EXE_NormSOA = ''
        self.EXE_OMOPGenerate = ''
        self.EXE_OMOPIngester = ''
        self.FileDownloadStartIndex = -1
        self.flow_id = ''
        self.flow_name = ''
        self.GenerateNoise = -1
        self.GhostscriptEXEFilename = ''
        self.GroundTruthMasterFilename = ''
        self.GroundTruthOutputDirectory = ''
        self.id = ''
        self.ImageProc_BulletImagesDir = ''
        self.ImageQC_GreyscaleThreshold = 0.0
        self.ImageQC_LegibilityThreshold = 0.0
        self.ImagesDirectory = ''
        self.InputDataDirectory = ''
        self.InputImageFilename = ''
        self.InputRawFilename = ''
        self.InputSourceMasterFilename = ''
        self.InputWorkingMasterFilename = ''
        self.IQVDocumentMappingFilename = ''
        self.IQVEnvironment = ''
        self.IQVMeasurementProcedureLUTFilename = ''
        self.IQVXML_DBConn_bUseDBConnection = -1
        self.IQVXML_DBConn_bUseDBConnection_PostDig2 = -1
        self.IQVXML_DBConn_bUseDBConnection_PostOU = -1
        self.IQVXML_DBConn_Database = ''
        self.IQVXML_DBConn_Login = ''
        self.IQVXML_DBConn_Password = ''
        self.IQVXML_DBConn_Port = -1
        self.IQVXML_DBConn_Server = ''
        self.IQVXMLInputFilename = ''
        self.IQVXMLInputFilename2 = ''
        self.LanguageAnalysisLib = ''
        self.LocalTopLevelDataDir = ''
        self.LogDirectory = ''
        self.LogFilename = ''
        self.MasterFile = -1
        self.MasterIQVDocumentListFilename = ''
        self.MatrixFile = ''
        self.MaxCellsPerPage = -1
        self.MaxNumDocsToProcess = -1
        self.MaxPagesCoreProcessing_BackSection = -1
        self.MaxPagesCoreProcessing_FrontSection = -1
        self.MaxPagesToProcess = -1
        self.MaxPagesToProcessIQVTM = -1
        self.MaxTimeMinutesPerPage = -1
        self.MinPixelHeightForOCR = -1
        self.MinPixelHeightForValidImage = -1
        self.MinPixelWidthForOCR = -1
        self.MinPixelWidthForValidImage = -1
        self.MSG_ErrorLevelLowerBound = -1
        self.MSG_ExchangeIsDurable = -1
        self.MSG_HostName = ''
        self.MSG_MaxCPU = -1
        self.MSG_MaxRAM = -1
        self.MSG_Password = ''
        self.MSG_Port = -1
        self.MSG_QueueIsDurable = -1
        self.MSG_User = ''
        self.MSG_VirtualHost = ''
        self.MTServer_Endpoint = ''
        self.MTServer_LocalPathMapping = ''
        self.MTServer_MachineName = ''
        self.MTServer_Password = ''
        self.MTServer_Port = ''
        self.MTServer_SecureHTTP = -1
        self.MTServer_SharedDir = ''
        self.MTServer_User = ''
        self.NLP_CharMatrixDirectory = ''
        self.NLP_DictionaryDirectory = ''
        self.NoiseGenMaxRecords = -1
        self.NoiseGenStartIndex = -1
        self.NoiseType = -1
        self.OCR_bUseSpellCheck = -1
        self.OCR_SpellCheckDirectory = ''
        self.OCR_UserWordsDirectory = ''
        self.OMOPUpdateFilename = ''
        self.Output_OmopPrefixText = ''
        self.Output_PrefixText = ''
        self.Output_QCFeedbackPrefixText = ''
        self.Output_ToCompareDir = ''
        self.Output_ToMetricsDir = ''
        self.OutputDirectory = ''
        self.OutputFilename = ''
        self.OutputLevel = -1
        self.PageIndex = -1
        self.PerformBatchDocClass = -1
        self.PerformDocumentDeconstruction = -1
        self.PerformDocumentReconstruction = -1
        self.PerformDuplicateCheck = -1
        self.PerformImageQC = -1
        self.PerformMetadata = -1
        self.PerformRotations = -1
        self.PerformXLIFFReceive = -1
        self.PerformXLIFFSend = -1
        self.PerformXLIFFSourceCreation = -1
        self.Priority = -1
        self.ProcessSource = -1
        self.PythonEnvironment = ''
        self.PythonEXEFilename = ''
        self.QCFeedbackJSONFilename = ''
        self.QCFeedbackRunId = ''
        self.Recon_bUseTemplateMatching = -1
        self.Recon_TemplateDirectory = ''
        self.Recon_TemplateFilename = ''
        self.RedactionProfileID = ''
        self.RedactionProfileListingFilename = ''
        self.RedactionReplacementMethod = ''
        self.RedactionTextMask = ''
        self.RedactionTextPrefix = ''
        self.RedactionTextSuffix = ''
        self.RemoteServer_MachineName = ''
        self.RemoteServer_Port = ''
        self.RemoteServer_ServerLocalDir = ''
        self.RemoteServer_SharedDir = ''
        self.Rotation = -1
        self.RunRemote = False
        self.SegmentationType = -1
        self.SegServer_Endpoint = ''
        self.SegServer_LocalPathMapping = ''
        self.SegServer_MachineName = ''
        self.SegServer_Port = ''
        self.SegServer_SecureHTTP = -1
        self.SegServer_SharedDir = ''
        self.ShowProgressForm = -1
        self.sofficeLocation = ''
        self.SourceLanguage = ''
        self.StandardTemplateIQVXML = ''
        self.TargetLanguage = ''
        self.tessdataDir = ''
        self.TesseractEXEFilename = ''
        self.TMFGTOutputConstrained_AvgPages = -1
        self.TMFGTOutputConstrained_MinSamples = -1
        self.TMFRawDataSourceDirectory = ''
        self.TMSServer_Endpoint = ''
        self.TMSServer_Info = ''
        self.TMSServer_MachineName = ''
        self.TMSServer_Port = ''
        self.TMSSharedDirectoryList = []
        self.UserEmail = ''
        self.UserID = ''
        self.WatchLogCheckIntervalSeconds = 0.0
        self.WatchLogFilename = ''
        self.WatchLogOutputDir = ''
        self.WatchLogOutputDirPermanentStorage = ''
        self.WorkingDirectory = ''
        self.XLIFFInputFilename = ''
        self.XLIFFMarkupVersion = ''


class IQVSubText(object):
    """
    Part of string that exhibits a unique <a href="#FontInfo">FontInfo</a>,
    not necessarily a <a href="#segment">segment</a>
    """

    Attributes = []
    """
    List of attributes, very important for structure such as
    fldChar, in which it is required to know the fldCharType (attribute)
    """

    bNoTranslate = bool
    """
    A subtext item that is purely for document formatting
    such as a line break
    """

    doc_id = str
    """
    Element index
    Which document is this element in?
    Top-level id for <a href="#IQVDocument">IQVDocument</a>
    """

    DocumentSequenceIndex = int
    """
    Global sequence index for both <a href="#IQVDocument.DocumentParagraphs">IQVDocument.DocumentParagraphs</a>
     and <a href="#IQVDocument.DocumentTables">IQVDocument.DocumentTables</a>

    Zero-based sequential order index of document part,
    which could be a table or a paragraph.
     This allows tables and paragraphs to be interlaced together
    and in sequential order

    Used in both
    <see cref="P:IQVFileManagerDLL.IQVDigDocumentTable.DocumentSequenceIndex" />
    and
     <see cref="P:IQVFileManagerDLL.IQVDigDocumentParagraph.DocumentSequenceIndex" />
    """

    fontInfo = FontInfo
    """
    If not null, then apply to all text in this IQVPageROI <a href="#FontInfo">FontInfo</a>
    """

    group_type = str
    """
    Element index
    Which item is this element a member of? (name of member = group_type)
    For example, for <a href="#IQVPageROI.Properties">IQVPageROI.Properties</a>, group_type = "Properties"
    Possible parents include but are not limited to
    <a href="#IQVDocument">IQVDocument</a><a href="#IQVPageROI">IQVPageROI</a><a href="#IQVDocumentLink">IQVDocumentLink</a>
    SQL code example 1 for usage of index
    <code>
    WHERE parent_id=parent_id AND group_type=group_type
    </code>
    """

    hierarchy = str
    """
    image,table,paragraph,item,header,footer,roi
    """

    id = str
    """
    Source document, run id as "paraId" XAttribute. Track
    this so it can be deleted!
    """

    iqv_standard_term = str
    """
    Element index
    If this element is a link or header, what is the standard term?
    There is 0 or 1 iqv_standard_term for each element
    """

    link_id = str
    """
    Element index
    Which [link <a href="#IQVDocumentLink">IQVDocumentLink</a>] section is this element in?
    The id for <a href="#IQVDocumentLink.LinkType">IQVDocumentLink.LinkType</a> == "toc"
    and <a href="#IQVDocumentLink.LinkLevel">IQVDocumentLink.LinkLevel</a> == 1
    """

    link_id_level2 = str
    """
    Element index
    Which [link <a href="#IQVDocumentLink">IQVDocumentLink</a>] section is this element in?
    The id for <a href="#IQVDocumentLink.LinkType">IQVDocumentLink.LinkType</a> == "toc"
    and <a href="#IQVDocumentLink.LinkLevel">IQVDocumentLink.LinkLevel</a> == 2
    """

    link_id_level3 = str
    """
    Element index
    Which [link <a href="#IQVDocumentLink">IQVDocumentLink</a>] section is this element in?
    The id for <a href="#IQVDocumentLink.LinkType">IQVDocumentLink.LinkType</a> == "toc"
    and <a href="#IQVDocumentLink.LinkLevel">IQVDocumentLink.LinkLevel</a> == 3
    """

    link_id_level4 = str
    """
    Element index
    Which [link <a href="#IQVDocumentLink">IQVDocumentLink</a>] section is this element in?
    The id for <a href="#IQVDocumentLink.LinkType">IQVDocumentLink.LinkType</a> == "toc"
    and <a href="#IQVDocumentLink.LinkLevel">IQVDocumentLink.LinkLevel</a> == 4
    """

    link_id_level5 = str
    """
    Element index
    Which [link <a href="#IQVDocumentLink">IQVDocumentLink</a>] section is this element in?
    The id for <a href="#IQVDocumentLink.LinkType">IQVDocumentLink.LinkType</a> == "toc"
    and <a href="#IQVDocumentLink.LinkLevel">IQVDocumentLink.LinkLevel</a> == 5
    """

    link_id_level6 = str
    """
    Element index
    Which [link <a href="#IQVDocumentLink">IQVDocumentLink</a>] section is this element in?
    The id for <a href="#IQVDocumentLink.LinkType">IQVDocumentLink.LinkType</a> == "toc"
    and <a href="#IQVDocumentLink.LinkLevel">IQVDocumentLink.LinkLevel</a> == 6
    """

    link_id_subsection1 = str
    """
    Element index
    Which [link <a href="#IQVDocumentLink">IQVDocumentLink</a>] section is this element in?
    The id for <a href="#IQVDocumentLink.LinkType">IQVDocumentLink.LinkType</a> == "subsection1"
    """

    link_id_subsection2 = str
    """
    Element index
    Which [link <a href="#IQVDocumentLink">IQVDocumentLink</a>] section is this element in?
    The id for <a href="#IQVDocumentLink.LinkType">IQVDocumentLink.LinkType</a> == "subsection2"
    """

    link_id_subsection3 = str
    """
    Element index
    Which [link <a href="#IQVDocumentLink">IQVDocumentLink</a>] section is this element in?
    The id for <a href="#IQVDocumentLink.LinkType">IQVDocumentLink.LinkType</a> == "subsection3"
    """

    NLP_Attributes = []
    """
    This ROI contains the listed attributes
     <a href="#NLP_Attribute">NLP_Attribute</a>
    """

    NLP_Entities = []
    """
    This ROI contains the listed entities
     <a href="#NLP_Entity">NLP_Entity</a>
    """

    OuterXml = str
    """
    For easy reconstruction of the element
    """

    parent_id = str
    """
    Element index
    Which item is this element a member of?
    For example, for <a href="#IQVPageROI.Properties">IQVPageROI.Properties</a>, parent_id = <a href="#IQVPageROI.id">IQVPageROI.id</a>
    Possible parents include but are not limited to
    <a href="#IQVDocument">IQVDocument</a><a href="#IQVPageROI">IQVPageROI</a><a href="#IQVDocumentLink">IQVDocumentLink</a>
    SQL code example 1 for usage of index
    <code>
    WHERE parent_id=parent_id AND group_type=group_type
    </code>
    SQL code example 2 for usage of index
    <code>
    WHERE parent_id=parent_id
    </code>
    """

    parent2LocalName = str
    """
    This is "t"
    Parent2 is "r"
    Grandparent is "p", but may be "hyperlink" or other container
    """

    parentAttributes = []
    """
    List of attributes, very important for structure such as
    fldChar, in which it is required to know the fldCharType (attribute)
    """

    postTags = []
    """
    Non-printed strings after end of text
    """

    postTexts = []
    """
    Non-printed characters after end of text
    """

    preTags = []
    """
    Non-printed strings before beginning of text
    """

    preTexts = []
    """
    Non-printed characters before beginning of text
    """

    QCUpdates = []
    """
    QC Updates
    """

    rawSegments = []
    """
    <a href="#IQVSubText.strText">IQVSubText.strText</a> is subdivided into segments
    according to language-specific segmentation model. This is
    the raw output of the model, which needs to be integrated
     into the formatting
    """

    reservedTypeVal = int
    """
    Is this a reserved type

      w:t text
      DEFAULT=0,

     <br /> or w:br
     LINE_BREAK=1,

      \t or w:tab
     TAB=2,

      w:fldChar
     FIELD_CHAR=3,

      w:instrText
     INSTR_TEXT=4
    """

    runElementName = str
    """
    type of Word Run element
    """

    sequence = int
    """
    numeric sequence zero-based
    """

    startCharIndex = int
    """
    Starting char index for the entire paragraph, zero-based
    """

    strText = str
    """
    Main text element of this data structure
    """

    strTranslatedText = str
    """
    Main text element of this data structure, translated
    """

    Value = str
    """
    Value
    """

    def __init__(self):
        self.Attributes = []
        self.bNoTranslate = False
        self.doc_id = ''
        self.DocumentSequenceIndex = -1
        self.fontInfo = FontInfo()
        self.group_type = ''
        self.hierarchy = ''
        self.id = ''
        self.iqv_standard_term = ''
        self.link_id = ''
        self.link_id_level2 = ''
        self.link_id_level3 = ''
        self.link_id_level4 = ''
        self.link_id_level5 = ''
        self.link_id_level6 = ''
        self.link_id_subsection1 = ''
        self.link_id_subsection2 = ''
        self.link_id_subsection3 = ''
        self.NLP_Attributes = []
        self.NLP_Entities = []
        self.OuterXml = ''
        self.parent_id = ''
        self.parent2LocalName = ''
        self.parentAttributes = []
        self.postTags = []
        self.postTexts = []
        self.preTags = []
        self.preTexts = []
        self.QCUpdates = []
        self.rawSegments = []
        self.reservedType = []
        self.reservedTypeVal = -1
        self.runElementName = ''
        self.sequence = -1
        self.startCharIndex = -1
        self.strText = ''
        self.strTranslatedText = ''
        self.Value = ''


class IQVCharacter(object):
    """
    OCR Character
    """

    Bottom = int
    """
    OCR-provided bottom
    """

    doc_id = str
    """
    Element index
    Which document is this element in?
    Top-level id for <a href="#IQVDocument">IQVDocument</a>
    """

    group_type = str
    """
    Element index
    Which item is this element a member of? (name of member = group_type)
    For example, for <a href="#IQVPageROI.Properties">IQVPageROI.Properties</a>, group_type = "Properties"
    Possible parents include but are not limited to
    <a href="#IQVDocument">IQVDocument</a><a href="#IQVPageROI">IQVPageROI</a><a href="#IQVDocumentLink">IQVDocumentLink</a>
    SQL code example 1 for usage of index
    <code>
    WHERE parent_id=parent_id AND group_type=group_type
    </code>
    """

    hierarchy = str
    """
    image,table,paragraph,item,header,footer,roi
    """

    id = str
    """
    id
    """

    iqv_standard_term = str
    """
    Element index
    If this element is a link or header, what is the standard term?
    There is 0 or 1 iqv_standard_term for each element
    """

    Left = int
    """
    OCR-provided left
    """

    link_id = str
    """
    Element index
    Which [link <a href="#IQVDocumentLink">IQVDocumentLink</a>] section is this element in?
    The id for <a href="#IQVDocumentLink.LinkType">IQVDocumentLink.LinkType</a> == "toc"
    and <a href="#IQVDocumentLink.LinkLevel">IQVDocumentLink.LinkLevel</a> == 1
    """

    link_id_level2 = str
    """
    Element index
    Which [link <a href="#IQVDocumentLink">IQVDocumentLink</a>] section is this element in?
    The id for <a href="#IQVDocumentLink.LinkType">IQVDocumentLink.LinkType</a> == "toc"
    and <a href="#IQVDocumentLink.LinkLevel">IQVDocumentLink.LinkLevel</a> == 2
    """

    link_id_level3 = str
    """
    Element index
    Which [link <a href="#IQVDocumentLink">IQVDocumentLink</a>] section is this element in?
    The id for <a href="#IQVDocumentLink.LinkType">IQVDocumentLink.LinkType</a> == "toc"
    and <a href="#IQVDocumentLink.LinkLevel">IQVDocumentLink.LinkLevel</a> == 3
    """

    link_id_level4 = str
    """
    Element index
    Which [link <a href="#IQVDocumentLink">IQVDocumentLink</a>] section is this element in?
    The id for <a href="#IQVDocumentLink.LinkType">IQVDocumentLink.LinkType</a> == "toc"
    and <a href="#IQVDocumentLink.LinkLevel">IQVDocumentLink.LinkLevel</a> == 4
    """

    link_id_level5 = str
    """
    Element index
    Which [link <a href="#IQVDocumentLink">IQVDocumentLink</a>] section is this element in?
    The id for <a href="#IQVDocumentLink.LinkType">IQVDocumentLink.LinkType</a> == "toc"
    and <a href="#IQVDocumentLink.LinkLevel">IQVDocumentLink.LinkLevel</a> == 5
    """

    link_id_level6 = str
    """
    Element index
    Which [link <a href="#IQVDocumentLink">IQVDocumentLink</a>] section is this element in?
    The id for <a href="#IQVDocumentLink.LinkType">IQVDocumentLink.LinkType</a> == "toc"
    and <a href="#IQVDocumentLink.LinkLevel">IQVDocumentLink.LinkLevel</a> == 6
    """

    link_id_subsection1 = str
    """
    Element index
    Which [link <a href="#IQVDocumentLink">IQVDocumentLink</a>] section is this element in?
    The id for <a href="#IQVDocumentLink.LinkType">IQVDocumentLink.LinkType</a> == "subsection1"
    """

    link_id_subsection2 = str
    """
    Element index
    Which [link <a href="#IQVDocumentLink">IQVDocumentLink</a>] section is this element in?
    The id for <a href="#IQVDocumentLink.LinkType">IQVDocumentLink.LinkType</a> == "subsection2"
    """

    link_id_subsection3 = str
    """
    Element index
    Which [link <a href="#IQVDocumentLink">IQVDocumentLink</a>] section is this element in?
    The id for <a href="#IQVDocumentLink.LinkType">IQVDocumentLink.LinkType</a> == "subsection3"
    """

    parent_id = str
    """
    Element index
    Which item is this element a member of?
    For example, for <a href="#IQVPageROI.Properties">IQVPageROI.Properties</a>, parent_id = <a href="#IQVPageROI.id">IQVPageROI.id</a>
    Possible parents include but are not limited to
    <a href="#IQVDocument">IQVDocument</a><a href="#IQVPageROI">IQVPageROI</a><a href="#IQVDocumentLink">IQVDocumentLink</a>
    SQL code example 1 for usage of index
    <code>
    WHERE parent_id=parent_id AND group_type=group_type
    </code>
    SQL code example 2 for usage of index
    <code>
    WHERE parent_id=parent_id
    </code>
    """

    Right = int
    """
    OCR-provided right
    """

    Tag = str
    """
    OCR-provided tag
    """

    Top = int
    """
    OCR-provided top
    """

    Value = int
    """
    OCR-provided text value (single character)
    """

    def __init__(self):
        self.Bottom = -1
        self.doc_id = ''
        self.group_type = ''
        self.hierarchy = ''
        self.id = ''
        self.iqv_standard_term = ''
        self.Left = -1
        self.link_id = ''
        self.link_id_level2 = ''
        self.link_id_level3 = ''
        self.link_id_level4 = ''
        self.link_id_level5 = ''
        self.link_id_level6 = ''
        self.link_id_subsection1 = ''
        self.link_id_subsection2 = ''
        self.link_id_subsection3 = ''
        self.parent_id = ''
        self.Right = -1
        self.Tag = ''
        self.Top = -1
        self.Value = -1


class IQVWord(object):
    """
    Word data structure elements from OCR output
    """

    Blanks = int
    """
    OCR-provided blanks
    """

    BlockIndex = int
    """
    block on the page, zero-based
    hierarchy is page index, block index, line index, word index
    """

    Bottom = int
    """
    OCR-provided bottom (pixels of input image)
    """

    CharList = []
    """
    OCR-provided character list
    """

    Class = str
    """
    OCR-provided class: we want the ocrx_word for text.
    line, carriage return (carea), page, word, paragraph
    ocr_line, ocr_carea, ocr_page, ocrx_word, ocr_par
    """

    Confidence = float
    """
    OCR-provided confidence score
    """

    doc_id = str
    """
    Element index
    Which document is this element in?
    Top-level id for <a href="#IQVDocument">IQVDocument</a>
    """

    FeedbackItems = []
    """
    Feedback from users
    """

    FontIndex = float
    """
    OCR-provided font index (size)
    """

    FontName = str
    """
    OCR-provided font family name
    """

    Formating = int
    """
    OCR-provided formating: strong = 1; em = 2
    """

    group_type = str
    """
    Element index
    Which item is this element a member of? (name of member = group_type)
    For example, for <a href="#IQVPageROI.Properties">IQVPageROI.Properties</a>, group_type = "Properties"
    Possible parents include but are not limited to
    <a href="#IQVDocument">IQVDocument</a><a href="#IQVPageROI">IQVPageROI</a><a href="#IQVDocumentLink">IQVDocumentLink</a>
    SQL code example 1 for usage of index
    <code>
    WHERE parent_id=parent_id AND group_type=group_type
    </code>
    """

    GT_ScoreMatch = float
    """
    for testing
    """

    GT_TextMatch = str
    """
    For a actual/known/validated output to measure
     against the (predicted output) text
    """

    hierarchy = str
    """
    image,table,paragraph,item,header,footer,roi
    """

    id = str
    """
    id
    """

    iqv_standard_term = str
    """
    Element index
    If this element is a link or header, what is the standard term?
    There is 0 or 1 iqv_standard_term for each element
    """

    Left = int
    """
    OCR-provided left in pixels (input image)
    """

    LineIndex = int
    """
    line in the block, zero-based
    hierarchy is page index, block index, line index, word index
    """

    link_id = str
    """
    Element index
    Which [link <a href="#IQVDocumentLink">IQVDocumentLink</a>] section is this element in?
    The id for <a href="#IQVDocumentLink.LinkType">IQVDocumentLink.LinkType</a> == "toc"
    and <a href="#IQVDocumentLink.LinkLevel">IQVDocumentLink.LinkLevel</a> == 1
    """

    link_id_level2 = str
    """
    Element index
    Which [link <a href="#IQVDocumentLink">IQVDocumentLink</a>] section is this element in?
    The id for <a href="#IQVDocumentLink.LinkType">IQVDocumentLink.LinkType</a> == "toc"
    and <a href="#IQVDocumentLink.LinkLevel">IQVDocumentLink.LinkLevel</a> == 2
    """

    link_id_level3 = str
    """
    Element index
    Which [link <a href="#IQVDocumentLink">IQVDocumentLink</a>] section is this element in?
    The id for <a href="#IQVDocumentLink.LinkType">IQVDocumentLink.LinkType</a> == "toc"
    and <a href="#IQVDocumentLink.LinkLevel">IQVDocumentLink.LinkLevel</a> == 3
    """

    link_id_level4 = str
    """
    Element index
    Which [link <a href="#IQVDocumentLink">IQVDocumentLink</a>] section is this element in?
    The id for <a href="#IQVDocumentLink.LinkType">IQVDocumentLink.LinkType</a> == "toc"
    and <a href="#IQVDocumentLink.LinkLevel">IQVDocumentLink.LinkLevel</a> == 4
    """

    link_id_level5 = str
    """
    Element index
    Which [link <a href="#IQVDocumentLink">IQVDocumentLink</a>] section is this element in?
    The id for <a href="#IQVDocumentLink.LinkType">IQVDocumentLink.LinkType</a> == "toc"
    and <a href="#IQVDocumentLink.LinkLevel">IQVDocumentLink.LinkLevel</a> == 5
    """

    link_id_level6 = str
    """
    Element index
    Which [link <a href="#IQVDocumentLink">IQVDocumentLink</a>] section is this element in?
    The id for <a href="#IQVDocumentLink.LinkType">IQVDocumentLink.LinkType</a> == "toc"
    and <a href="#IQVDocumentLink.LinkLevel">IQVDocumentLink.LinkLevel</a> == 6
    """

    link_id_subsection1 = str
    """
    Element index
    Which [link <a href="#IQVDocumentLink">IQVDocumentLink</a>] section is this element in?
    The id for <a href="#IQVDocumentLink.LinkType">IQVDocumentLink.LinkType</a> == "subsection1"
    """

    link_id_subsection2 = str
    """
    Element index
    Which [link <a href="#IQVDocumentLink">IQVDocumentLink</a>] section is this element in?
    The id for <a href="#IQVDocumentLink.LinkType">IQVDocumentLink.LinkType</a> == "subsection2"
    """

    link_id_subsection3 = str
    """
    Element index
    Which [link <a href="#IQVDocumentLink">IQVDocumentLink</a>] section is this element in?
    The id for <a href="#IQVDocumentLink.LinkType">IQVDocumentLink.LinkType</a> == "subsection3"
    """

    NLP_ScoreMatch = float
    """
    Predicted output score from OCR + NLP
    """

    NLP_TextMatch = str
    """
    Predicted output from OCR + NLP
    """

    NLP_TextMatchReconstructed = str
    """
    Using as a base input <a href="#IQVWord.NLP_TextMatch">IQVWord.NLP_TextMatch</a>,
     add back the prefix <a href="#IQVWord.TextDerivedPrefix">IQVWord.TextDerivedPrefix</a>,
     suffix <a href="#IQVWord.TextDerivedSuffix">IQVWord.TextDerivedSuffix</a>,
    and determine case <a href="#IQVWord.TextDerivedCase">IQVWord.TextDerivedCase</a>. This is
    the final to be used in Document Reconstruction
    """

    parent_id = str
    """
    Element index
    Which item is this element a member of?
    For example, for <a href="#IQVPageROI.Properties">IQVPageROI.Properties</a>, parent_id = <a href="#IQVPageROI.id">IQVPageROI.id</a>
    Possible parents include but are not limited to
    <a href="#IQVDocument">IQVDocument</a><a href="#IQVPageROI">IQVPageROI</a><a href="#IQVDocumentLink">IQVDocumentLink</a>
    SQL code example 1 for usage of index
    <code>
    WHERE parent_id=parent_id AND group_type=group_type
    </code>
    SQL code example 2 for usage of index
    <code>
    WHERE parent_id=parent_id
    </code>
    """

    PointSize = int
    """
    point size
    """

    Right = int
    """
    OCR-provided right pixels (input image)
    """

    Tag = str
    """
    OCR-provided
    """

    Text = str
    """
    Predicted output from OCR
    """

    textangle = int
    """
    OCR-provided text angle in degrees (180 is upside down)
    """

    TextDerivedCase = int
    """
    Lowercase = 0,
    Uppercase = 1,
    Proper Case = 2
    """

    TextDerivedDeconstructed = str
    """
    Using as a base input <a href="#IQVWord.Text">IQVWord.Text</a>, pull out prefix <a href="#IQVWord.TextDerivedPrefix">IQVWord.TextDerivedPrefix</a>,
     suffix <a href="#IQVWord.TextDerivedSuffix">IQVWord.TextDerivedSuffix</a>,
    and determine case <a href="#IQVWord.TextDerivedCase">IQVWord.TextDerivedCase</a>, and use this
     to match and find <a href="#IQVWord.NLP_TextMatch">IQVWord.NLP_TextMatch</a>
    """

    TextDerivedIsNumeric = int
    """
    Not numeric = 0,
    Numeric = 1,
    Numeric + Alpha as Code (not a word) = 2
    """

    TextDerivedPrefix = str
    """
    Punctuation or other symbols at prefix(beginning), removed for
    matching to create <a href="#IQVWord.TextDerivedDeconstructed">IQVWord.TextDerivedDeconstructed</a>,
    replaced to build <a href="#IQVWord.NLP_TextMatchReconstructed">IQVWord.NLP_TextMatchReconstructed</a>
    """

    TextDerivedSuffix = str
    """
    Using as input Punctuation or other symbols at suffix(ending), removed for
    matching to create <a href="#IQVWord.TextDerivedDeconstructed">IQVWord.TextDerivedDeconstructed</a>,
    replaced to build <a href="#IQVWord.NLP_TextMatchReconstructed">IQVWord.NLP_TextMatchReconstructed</a>
    """

    TextLanguage = str
    """
    Language of the text, stored here for easier access and reference
    for ML processes
    """

    Top = int
    """
    OCR-provided top pixels (input image)
    """

    WordIndex = int
    """
    word in the line, zero-based
    hierarchy is page index, block index, line index, word index
    """

    def __init__(self):
        self.Blanks = -1
        self.BlockIndex = -1
        self.Bottom = -1
        self.CharList = []
        self.Class = ''
        self.Confidence = 0.0
        self.doc_id = ''
        self.FeedbackItems = []
        self.FontIndex = 0.0
        self.FontName = ''
        self.Formating = -1
        self.group_type = ''
        self.GT_ScoreMatch = 0.0
        self.GT_TextMatch = ''
        self.hierarchy = ''
        self.id = ''
        self.iqv_standard_term = ''
        self.Left = -1
        self.LineIndex = -1
        self.link_id = ''
        self.link_id_level2 = ''
        self.link_id_level3 = ''
        self.link_id_level4 = ''
        self.link_id_level5 = ''
        self.link_id_level6 = ''
        self.link_id_subsection1 = ''
        self.link_id_subsection2 = ''
        self.link_id_subsection3 = ''
        self.NLP_ScoreMatch = 0.0
        self.NLP_TextMatch = ''
        self.NLP_TextMatchReconstructed = ''
        self.parent_id = ''
        self.PointSize = -1
        self.Right = -1
        self.Tag = ''
        self.Text = ''
        self.textangle = -1
        self.TextDerivedCase = -1
        self.TextDerivedDeconstructed = ''
        self.TextDerivedIsNumeric = -1
        self.TextDerivedPrefix = ''
        self.TextDerivedSuffix = ''
        self.TextLanguage = ''
        self.Top = -1
        self.WordIndex = -1


class IQVKeyValueSet(object):
    """
    Key-value pair
    """

    confidence = float
    """
    Confidence for this value
    """

    doc_id = str
    """
    Element index
    Which document is this element in?
    Top-level id for <a href="#IQVDocument">IQVDocument</a>
    """

    group_type = str
    """
    Element index
    Which item is this element a member of? (name of member = group_type)
    For example, for <a href="#IQVPageROI.Properties">IQVPageROI.Properties</a>, group_type = "Properties"
    Possible parents include but are not limited to
    <a href="#IQVDocument">IQVDocument</a><a href="#IQVPageROI">IQVPageROI</a><a href="#IQVDocumentLink">IQVDocumentLink</a>
    SQL code example 1 for usage of index
    <code>
    WHERE parent_id=parent_id AND group_type=group_type
    </code>
    """

    hierarchy = str
    """
    image,table,paragraph,item,header,footer,roi
    """

    id = str
    """
    id
    """

    iqv_standard_term = str
    """
    Element index
    If this element is a link or header, what is the standard term?
    There is 0 or 1 iqv_standard_term for each element
    """

    key = str
    """
    Attribute/metadata key, such as document_date
    """

    link_id = str
    """
    Element index
    Which [link <a href="#IQVDocumentLink">IQVDocumentLink</a>] section is this element in?
    The id for <a href="#IQVDocumentLink.LinkType">IQVDocumentLink.LinkType</a> == "toc"
    and <a href="#IQVDocumentLink.LinkLevel">IQVDocumentLink.LinkLevel</a> == 1
    """

    link_id_level2 = str
    """
    Element index
    Which [link <a href="#IQVDocumentLink">IQVDocumentLink</a>] section is this element in?
    The id for <a href="#IQVDocumentLink.LinkType">IQVDocumentLink.LinkType</a> == "toc"
    and <a href="#IQVDocumentLink.LinkLevel">IQVDocumentLink.LinkLevel</a> == 2
    """

    link_id_level3 = str
    """
    Element index
    Which [link <a href="#IQVDocumentLink">IQVDocumentLink</a>] section is this element in?
    The id for <a href="#IQVDocumentLink.LinkType">IQVDocumentLink.LinkType</a> == "toc"
    and <a href="#IQVDocumentLink.LinkLevel">IQVDocumentLink.LinkLevel</a> == 3
    """

    link_id_level4 = str
    """
    Element index
    Which [link <a href="#IQVDocumentLink">IQVDocumentLink</a>] section is this element in?
    The id for <a href="#IQVDocumentLink.LinkType">IQVDocumentLink.LinkType</a> == "toc"
    and <a href="#IQVDocumentLink.LinkLevel">IQVDocumentLink.LinkLevel</a> == 4
    """

    link_id_level5 = str
    """
    Element index
    Which [link <a href="#IQVDocumentLink">IQVDocumentLink</a>] section is this element in?
    The id for <a href="#IQVDocumentLink.LinkType">IQVDocumentLink.LinkType</a> == "toc"
    and <a href="#IQVDocumentLink.LinkLevel">IQVDocumentLink.LinkLevel</a> == 5
    """

    link_id_level6 = str
    """
    Element index
    Which [link <a href="#IQVDocumentLink">IQVDocumentLink</a>] section is this element in?
    The id for <a href="#IQVDocumentLink.LinkType">IQVDocumentLink.LinkType</a> == "toc"
    and <a href="#IQVDocumentLink.LinkLevel">IQVDocumentLink.LinkLevel</a> == 6
    """

    link_id_subsection1 = str
    """
    Element index
    Which [link <a href="#IQVDocumentLink">IQVDocumentLink</a>] section is this element in?
    The id for <a href="#IQVDocumentLink.LinkType">IQVDocumentLink.LinkType</a> == "subsection1"
    """

    link_id_subsection2 = str
    """
    Element index
    Which [link <a href="#IQVDocumentLink">IQVDocumentLink</a>] section is this element in?
    The id for <a href="#IQVDocumentLink.LinkType">IQVDocumentLink.LinkType</a> == "subsection2"
    """

    link_id_subsection3 = str
    """
    Element index
    Which [link <a href="#IQVDocumentLink">IQVDocumentLink</a>] section is this element in?
    The id for <a href="#IQVDocumentLink.LinkType">IQVDocumentLink.LinkType</a> == "subsection3"
    """

    NLP_Attributes = []
    """
    This ROI contains the listed attributes
     <a href="#NLP_Attribute">NLP_Attribute</a>
    """

    NLP_Entities = []
    """
    This ROI contains the listed entities
     <a href="#NLP_Entity">NLP_Entity</a>
    """

    parent_id = str
    """
    Element index
    Which item is this element a member of?
    For example, for <a href="#IQVPageROI.Properties">IQVPageROI.Properties</a>, parent_id = <a href="#IQVPageROI.id">IQVPageROI.id</a>
    Possible parents include but are not limited to
    <a href="#IQVDocument">IQVDocument</a><a href="#IQVPageROI">IQVPageROI</a><a href="#IQVDocumentLink">IQVDocumentLink</a>
    SQL code example 1 for usage of index
    <code>
    WHERE parent_id=parent_id AND group_type=group_type
    </code>
    SQL code example 2 for usage of index
    <code>
    WHERE parent_id=parent_id
    </code>
    """

    QCUpdates = []
    """
    Raw score for this value
    """

    rawScore = float
    """
    Raw score for this value
    """

    source_system = str
    """
    LM, QC
    """

    value = str
    """
    Value for this attribute/metadata, such as "20000131" (for Jan 31, 2000)
    """

    def __init__(self):
        self.confidence = 0.0
        self.doc_id = ''
        self.group_type = ''
        self.hierarchy = ''
        self.id = ''
        self.iqv_standard_term = ''
        self.key = ''
        self.link_id = ''
        self.link_id_level2 = ''
        self.link_id_level3 = ''
        self.link_id_level4 = ''
        self.link_id_level5 = ''
        self.link_id_level6 = ''
        self.link_id_subsection1 = ''
        self.link_id_subsection2 = ''
        self.link_id_subsection3 = ''
        self.NLP_Attributes = []
        self.NLP_Entities = []
        self.parent_id = ''
        self.QCUpdates = []
        self.rawScore = 0.0
        self.source_system = ''
        self.value = ''
        self.id = str(uuid.uuid1())


class Q_EVENT_LOG_ENTRY(object):
    """
    Log entry for logging purposes and for creating a document resource
    in WebUI
    """

    bHandled = bool
    """
    has event been handled?
    """

    ClassMapping = str
    """
    if mapping class
    """

    CountReplace = int
    """
    number of replacements
    """

    doc_id = str
    """
    Element index
    Which document is this element in?
    Top-level id for <a href="#IQVDocument">IQVDocument</a>
    """

    DocumentID = str
    """
    document resource (NMT) id
    """

    DocumentName = str
    """
    original source document filename
    """

    DocumentPage = int
    """
    page for this document
    """

    ErrorLevelVal = int
    """
    No error or ignore
     NONE = 0,

      Most verbose is debug, shows everything no matter how trivial
     DEBUG = 1,

      Trivial, probably only for information
     INFORMATIONAL = 2,

      Minor, segment-level
     MINOR = 3,

      Major error with document processing
     MAJOR = 4,

      Reserved for no document being processed
     CRITICAL = 5

     substitue for Error Level; default is -1
    """

    EventTypeVal = int
    """
    substitute for Event Type; default is -1
             DEFAULT = 0,
    ERROR = 1,
    REPORT_MAPPING = 2,
    REPORT_MAPPING_ERROR = 3,
    APPLICATION_EVENT = 4,
    PROCESS_START = 5,
    PROCESS_FINISH = 6,
    PROCESS_ERROR = 7,
    ADD_DOCUMENT = 8,
    UPDATE_ITEM = 9,
    RETRIEVE_DOCUMENT = 10,
    ADD_DOCUMENT_XLIFF = 11,
    STRING_REPLACE = 20,
    STRING_REPLACE_ERROR = 21,
    QUEUE_MESSAGE_SENT = 30,
    QUEUE_MESSAGE_RECEIVED = 31,
    QUEUE_MESSAGE_SENT_RECONSTRUCTION = 32,
    QUEUE_MESSAGE_RECEIVED_RECONSTRUCTION = 33,
    WARNING = 99,
    INFORMATION = 101,
    DOCUMENT_ROTATION_METRICS = 201,
    CREATE_IQV_DOCUMENT = 301,
    CREATE_RECONSTRUCTED_DOCUMENT = 302,
    CREATE_XLIFF_SOURCE = 303,
    CREATE_DECONSTRUCTED_SOURCE = 304,
    ADD_DIRECTORY = 404,
    CONFIGURATION_PARAMETER = 501,
    PROCESS_INFORMATION = 502,
    GENERIC_FORMATTER_ERROR = 900,
    IMAGE_QUALITY_ERROR = 901,
    CORRUPT_DOCUMENT_ERROR = 902,
    IMAGE_REQUIRES_OCR = 903
    """

    FieldMapping = str
    """
    if mapping field, which field
    """

    id = str
    """
    id of this event
    """

    KeyValues = []
    """
    key-value pairs; common ones listed here:
    KEY_SOURCE_LANGUAGE = "SourceLanguage";
    KEY_TARGET_LANGUAGE = "TargetLanguage";
    KEY_SOURCE_FILENAME = "SourceFilename";
    KEY_DISPLAY_LABEL = "DisplayLabel";
    KEY_XLIFF_FILENAME = "XLIFFFilename";
    KEY_SEGMENTATION_TYPE = "SegmentationType";
    KEY_XLIFF_MARKUP_VERSION = "XLIFFMarkupVersion";
    KEY_PRIORITY = "Priority";
    KEY_OUTPUT_LEVEL = "OutputLevel";
    """

    m_DateTimeStampVal = str
    """
    date/time event was raised, in YYYYMMDDHHMMSS format (14 digits)
    """

    Message = str
    """
    For error
    """

    StackTrace = str
    """
    For error
    """

    UserEmail = str
    """
    end user
    """

    UserID = str
    """
    end user
    """

    UserInputMessage = str
    """
    end user
    """

    Value = str
    """
    generic value for this event
    """

    def __init__(self):
        self.bHandled = False
        self.ClassMapping = ''
        self.CountReplace = -1
        self.doc_id = ''
        self.DocumentID = ''
        self.DocumentName = ''
        self.DocumentPage = -1
        self.ErrorLevel = []
        self.ErrorLevelVal = -1
        self.EventType = []
        self.EventTypeVal = -1
        self.FieldMapping = ''
        self.id = ''
        self.KeyValues = []
        self.m_DateTimeStampVal = ''
        self.Message = ''
        self.StackTrace = ''
        self.UserEmail = ''
        self.UserID = ''
        self.UserInputMessage = ''
        self.Value = ''
        self.id = str(uuid.uuid1())


class IQVLine(object):
    """
    A line with points (X1,Y1) and (X2,Y2) and thickness.
     The thickness may be defined at a
     more granular level using (X1Right,Y1Lower) and (X2Right,Y2Lower)
    """

    BackgroundToForeground = bool
    """
    Change is background to foreground
    """

    bIncludedInBox = bool
    """

    """

    bIsHorizontal = bool
    """
    Either horizontal or vertical
    """

    doc_id = str
    """
    Element index
    Which document is this element in?
    Top-level id for <a href="#IQVDocument">IQVDocument</a>
    """

    ForegroundToBackground = bool
    """
    Change is foreground to background
    """

    group_type = str
    """
    Element index
    Which item is this element a member of? (name of member = group_type)
    For example, for <a href="#IQVPageROI.Properties">IQVPageROI.Properties</a>, group_type = "Properties"
    Possible parents include but are not limited to
    <a href="#IQVDocument">IQVDocument</a><a href="#IQVPageROI">IQVPageROI</a><a href="#IQVDocumentLink">IQVDocumentLink</a>
    SQL code example 1 for usage of index
    <code>
    WHERE parent_id=parent_id AND group_type=group_type
    </code>
    """

    hierarchy = str
    """
    image,table,paragraph,item,header,footer,roi
    """

    id = str
    """
    id
    """

    intersections = []
    """
    comma-separated list of id's of intersects
    """

    iqv_standard_term = str
    """
    Element index
    If this element is a link or header, what is the standard term?
    There is 0 or 1 iqv_standard_term for each element
    """

    link_id = str
    """
    Element index
    Which [link <a href="#IQVDocumentLink">IQVDocumentLink</a>] section is this element in?
    The id for <a href="#IQVDocumentLink.LinkType">IQVDocumentLink.LinkType</a> == "toc"
    and <a href="#IQVDocumentLink.LinkLevel">IQVDocumentLink.LinkLevel</a> == 1
    """

    link_id_level2 = str
    """
    Element index
    Which [link <a href="#IQVDocumentLink">IQVDocumentLink</a>] section is this element in?
    The id for <a href="#IQVDocumentLink.LinkType">IQVDocumentLink.LinkType</a> == "toc"
    and <a href="#IQVDocumentLink.LinkLevel">IQVDocumentLink.LinkLevel</a> == 2
    """

    link_id_level3 = str
    """
    Element index
    Which [link <a href="#IQVDocumentLink">IQVDocumentLink</a>] section is this element in?
    The id for <a href="#IQVDocumentLink.LinkType">IQVDocumentLink.LinkType</a> == "toc"
    and <a href="#IQVDocumentLink.LinkLevel">IQVDocumentLink.LinkLevel</a> == 3
    """

    link_id_level4 = str
    """
    Element index
    Which [link <a href="#IQVDocumentLink">IQVDocumentLink</a>] section is this element in?
    The id for <a href="#IQVDocumentLink.LinkType">IQVDocumentLink.LinkType</a> == "toc"
    and <a href="#IQVDocumentLink.LinkLevel">IQVDocumentLink.LinkLevel</a> == 4
    """

    link_id_level5 = str
    """
    Element index
    Which [link <a href="#IQVDocumentLink">IQVDocumentLink</a>] section is this element in?
    The id for <a href="#IQVDocumentLink.LinkType">IQVDocumentLink.LinkType</a> == "toc"
    and <a href="#IQVDocumentLink.LinkLevel">IQVDocumentLink.LinkLevel</a> == 5
    """

    link_id_level6 = str
    """
    Element index
    Which [link <a href="#IQVDocumentLink">IQVDocumentLink</a>] section is this element in?
    The id for <a href="#IQVDocumentLink.LinkType">IQVDocumentLink.LinkType</a> == "toc"
    and <a href="#IQVDocumentLink.LinkLevel">IQVDocumentLink.LinkLevel</a> == 6
    """

    link_id_subsection1 = str
    """
    Element index
    Which [link <a href="#IQVDocumentLink">IQVDocumentLink</a>] section is this element in?
    The id for <a href="#IQVDocumentLink.LinkType">IQVDocumentLink.LinkType</a> == "subsection1"
    """

    link_id_subsection2 = str
    """
    Element index
    Which [link <a href="#IQVDocumentLink">IQVDocumentLink</a>] section is this element in?
    The id for <a href="#IQVDocumentLink.LinkType">IQVDocumentLink.LinkType</a> == "subsection2"
    """

    link_id_subsection3 = str
    """
    Element index
    Which [link <a href="#IQVDocumentLink">IQVDocumentLink</a>] section is this element in?
    The id for <a href="#IQVDocumentLink.LinkType">IQVDocumentLink.LinkType</a> == "subsection3"
    """

    parent_id = str
    """
    Element index
    Which item is this element a member of?
    For example, for <a href="#IQVPageROI.Properties">IQVPageROI.Properties</a>, parent_id = <a href="#IQVPageROI.id">IQVPageROI.id</a>
    Possible parents include but are not limited to
    <a href="#IQVDocument">IQVDocument</a><a href="#IQVPageROI">IQVPageROI</a><a href="#IQVDocumentLink">IQVDocumentLink</a>
    SQL code example 1 for usage of index
    <code>
    WHERE parent_id=parent_id AND group_type=group_type
    </code>
    SQL code example 2 for usage of index
    <code>
    WHERE parent_id=parent_id
    </code>
    """

    ParentID = int
    """
    parent id
    """

    SequenceID = int
    """
    sequential id of line in ROI
    """

    Thickness = int
    """
    Thickness in pixels unless otherwise specified in <a href="#IQVLine.ThicknessUnit">IQVLine.ThicknessUnit</a>
    """

    ThicknessUnit = int
    """
    0=pixels
    1=inches
    """

    TopParentID = int
    """
    Global group of segments identified
    by this value
    """

    X1 = int
    """
    left of horizontal line; should be
    same as X2 for vertical line
    """

    X1Right = int
    """
    thickness of top of vertical line is given here;
    not valid for horizontal line
    """

    X2 = int
    """
    right of horizontal line; should be same as X1
    for vertical line (diff if slanted)
    """

    X2Right = int
    """
    thickness of bottom of vertical line is given here;
    not valid for horizontal line
    """

    Y1 = int
    """
    top of vertical line;
    """

    Y1Lower = int
    """
    thickness of left side of horizontal line given here;
    not valid for vertical line
    """

    Y2 = int
    """
    right side of horizontal line;
    should be same as Y1 for horizontal line (unless slanted)
    """

    Y2Lower = int
    """
    thickness of right side of horizontal line given here;
    not valid for vertical line
    """

    def __init__(self):
        self.BackgroundToForeground = False
        self.bIncludedInBox = False
        self.bIsHorizontal = False
        self.doc_id = ''
        self.ForegroundToBackground = False
        self.group_type = ''
        self.hierarchy = ''
        self.id = ''
        self.intersections = []
        self.iqv_standard_term = ''
        self.link_id = ''
        self.link_id_level2 = ''
        self.link_id_level3 = ''
        self.link_id_level4 = ''
        self.link_id_level5 = ''
        self.link_id_level6 = ''
        self.link_id_subsection1 = ''
        self.link_id_subsection2 = ''
        self.link_id_subsection3 = ''
        self.parent_id = ''
        self.ParentID = -1
        self.SequenceID = -1
        self.Thickness = -1
        self.ThicknessUnit = -1
        self.TopParentID = -1
        self.X1 = -1
        self.X1Right = -1
        self.X2 = -1
        self.X2Right = -1
        self.Y1 = -1
        self.Y1Lower = -1
        self.Y2 = -1
        self.Y2Lower = -1
        self.id = str(uuid.uuid1())


class IQVIntersection(object):
    """
    
    """

    hline_id = str
    """
    horizontal line id <a href="#IQVLine">IQVLine</a>
    """

    id = str
    """
    id
    """

    vline_id = str
    """
    vertical line id <a href="#IQVLine">IQVLine</a>
    """

    X = int
    """
    X
    """

    Y = int
    """
    Y
    """

    def __init__(self):
        self.hline_id = ''
        self.id = ''
        self.vline_id = ''
        self.X = -1
        self.Y = -1
        self.id = str(uuid.uuid1())


class IQVForm(object):
    """
    form data
    """

    Chapter = str
    """
    Chapter in form
    """

    Children = []
    """
    Children
    """

    FormName = str
    """
    Name of form
    """

    id = str
    """
    id of this event
    """

    PrimaryKeyValue = []
    """
    KV at this top level
    """

    def __init__(self):
        self.Chapter = ''
        self.Children = []
        self.FormName = ''
        self.id = ''
        self.PrimaryKeyValue = []
        self.id = str(uuid.uuid1())


class IQVDocumentPage(object):
    """
    Use for PDF Page
    """

    bIsScannedPage = bool
    """
    Assumed to not be scanned until checked
    """

    bNeedsToBeBinarized = bool
    """
    Check quality of image to figure this out
    """

    Boxes = []
    """
    child boxes
    """

    FooterText = str
    """
    text in footer
    """

    HeaderText = str
    """
    text in header
    """

    Hyperlinks = []
    """
    list of hyperlinks
    """

    id = str
    """
    id
    """

    ImageLocationsOnPage = []
    """
    list of image rectangles
    """

    ImageNames = []
    """
    list of image names
    """

    ImageQCError = float
    """
    Error
    """

    ImageQCGT = int
    """
    ground truth
    """

    ImageQCScore = int
    """
    QC
     0=not run, 1=red/illegible, 2=yellow, 3=green/legible
    (for values <a href="#RESULT_SCORE">RESULT_SCORE</a>)
    """

    ImageQCScore_Blank = int
    """
    QC on page blank (fail if blank);
    0=not run, 1=red/illegible, 2=yellow, 3=green/legible
    (for values <a href="#RESULT_SCORE">RESULT_SCORE</a>)
    """

    ImageQCScore_Greyscale = int
    """
    QC on legibility from greyscale;
    0=not run, 1=red/illegible, 2=yellow, 3=green/legible
    (for values <a href="#RESULT_SCORE">RESULT_SCORE</a>)
    """

    ImageQCScore_Legibility = int
    """
    QC on legibility rating;
    0=not run, 1=red/illegible, 2=yellow, 3=green/legible
    (for values <a href="#RESULT_SCORE">RESULT_SCORE</a>)
    """

    ImageQCScore_Orientation = int
    """
    QC on page orientation;
    0=not run, 1=red/illegible, 2=yellow, 3=green/legible
    (for values <a href="#RESULT_SCORE">RESULT_SCORE</a>)
    """

    ImageQCScore_Pages = int
    """
    QC on page sequence;
    0=not run, 1=red/illegible, 2=yellow, 3=green/legible
    (for values <a href="#RESULT_SCORE">RESULT_SCORE</a>)
    """

    in_image_filename = str
    """
    Image for input
    """

    in_raw_filename = str
    """
    raw input
    """

    MeanOffsetAngleInRadians = float
    """
    Use to rotate the image as necessary
    """

    OffsetXInches = float
    """
    offset x
    """

    OffsetYInches = float
    """
    offset y
    """

    OrientationIsPortrait = bool
    """
    true if portrait; false if landscape
    """

    out_filename = str
    """
    Required for processing a single page;
    XML
    """

    PageSequenceIndex = int
    """
    Sequence received in the raw input
    """

    PageSizeRectangle = RectangleD
    """
    Page rectangle (full page)
    """

    PageSizeWithRotationRectangle = RectangleD
    """
    Page rectangle (full page) with rotation taken into account
    """

    PDFDocumentPageText = str
    """
    Page text
    """

    PDFDocumentPageTextNumChars = int
    """
    Raw, counting ALL chars on page
    """

    PDFDocumentPageTextNumWords = int
    """
    Raw, counting ALL words on page
    """

    ProcessFinishTime = str
    """
    End time for running process
    """

    ProcessStartTime = str
    """
    Start time for running process
    """

    Rotation = int
    """
    degrees rotation
    """

    Rotation_MajorAxis = int
    """
    In degrees, {0,90,180,270} to
     show the orientation of the document
    """

    ScannedImageID = str
    """
    GUID of primary image if is a scanned page
    """

    textFromReader = str
    """
    Original raw text
    """

    TitleText = str
    """
    text in title
    """

    def __init__(self):
        self.bIsScannedPage = False
        self.bNeedsToBeBinarized = False
        self.Boxes = []
        self.FooterText = ''
        self.HeaderText = ''
        self.Hyperlinks = []
        self.id = ''
        self.ImageLocationsOnPage = []
        self.ImageNames = []
        self.ImageQCError = 0.0
        self.ImageQCGT = -1
        self.ImageQCScore = -1
        self.ImageQCScore_Blank = -1
        self.ImageQCScore_Greyscale = -1
        self.ImageQCScore_Legibility = -1
        self.ImageQCScore_Orientation = -1
        self.ImageQCScore_Pages = -1
        self.in_image_filename = ''
        self.in_raw_filename = ''
        self.MeanOffsetAngleInRadians = 0.0
        self.OffsetXInches = 0.0
        self.OffsetYInches = 0.0
        self.OrientationIsPortrait = False
        self.out_filename = ''
        self.PageSequenceIndex = -1
        self.PageSizeRectangle = RectangleD()
        self.PageSizeWithRotationRectangle = RectangleD()
        self.PDFDocumentPageText = ''
        self.PDFDocumentPageTextNumChars = -1
        self.PDFDocumentPageTextNumWords = -1
        self.ProcessFinishTime = ''
        self.ProcessStartTime = ''
        self.Rotation = -1
        self.Rotation_MajorAxis = -1
        self.ScannedImageID = ''
        self.textFromReader = ''
        self.TitleText = ''
        self.id = str(uuid.uuid1())


class IQVAttribute(object):
    """
    Possible Attribute found in the document,
    such as document date
    """

    doc_id = str
    """
    Element index
    Which document is this element in?
    Top-level id for <a href="#IQVDocument">IQVDocument</a>
    """

    group_type = str
    """
    Element index
    Which item is this element a member of? (name of member = group_type)
    For example, for <a href="#IQVPageROI.Properties">IQVPageROI.Properties</a>, group_type = "Properties"
    Possible parents include but are not limited to
    <a href="#IQVDocument">IQVDocument</a><a href="#IQVPageROI">IQVPageROI</a><a href="#IQVDocumentLink">IQVDocumentLink</a>
    SQL code example 1 for usage of index
    <code>
    WHERE parent_id=parent_id AND group_type=group_type
    </code>
    """

    hierarchy = str
    """
    image,table,paragraph,item,header,footer,roi
    """

    id = str
    """
    id
    """

    iqv_standard_term = str
    """
    Element index
    If this element is a link or header, what is the standard term?
    There is 0 or 1 iqv_standard_term for each element
    """

    link_id = str
    """
    Element index
    Which [link <a href="#IQVDocumentLink">IQVDocumentLink</a>] section is this element in?
    The id for <a href="#IQVDocumentLink.LinkType">IQVDocumentLink.LinkType</a> == "toc"
    and <a href="#IQVDocumentLink.LinkLevel">IQVDocumentLink.LinkLevel</a> == 1
    """

    link_id_level2 = str
    """
    Element index
    Which [link <a href="#IQVDocumentLink">IQVDocumentLink</a>] section is this element in?
    The id for <a href="#IQVDocumentLink.LinkType">IQVDocumentLink.LinkType</a> == "toc"
    and <a href="#IQVDocumentLink.LinkLevel">IQVDocumentLink.LinkLevel</a> == 2
    """

    link_id_level3 = str
    """
    Element index
    Which [link <a href="#IQVDocumentLink">IQVDocumentLink</a>] section is this element in?
    The id for <a href="#IQVDocumentLink.LinkType">IQVDocumentLink.LinkType</a> == "toc"
    and <a href="#IQVDocumentLink.LinkLevel">IQVDocumentLink.LinkLevel</a> == 3
    """

    link_id_level4 = str
    """
    Element index
    Which [link <a href="#IQVDocumentLink">IQVDocumentLink</a>] section is this element in?
    The id for <a href="#IQVDocumentLink.LinkType">IQVDocumentLink.LinkType</a> == "toc"
    and <a href="#IQVDocumentLink.LinkLevel">IQVDocumentLink.LinkLevel</a> == 4
    """

    link_id_level5 = str
    """
    Element index
    Which [link <a href="#IQVDocumentLink">IQVDocumentLink</a>] section is this element in?
    The id for <a href="#IQVDocumentLink.LinkType">IQVDocumentLink.LinkType</a> == "toc"
    and <a href="#IQVDocumentLink.LinkLevel">IQVDocumentLink.LinkLevel</a> == 5
    """

    link_id_level6 = str
    """
    Element index
    Which [link <a href="#IQVDocumentLink">IQVDocumentLink</a>] section is this element in?
    The id for <a href="#IQVDocumentLink.LinkType">IQVDocumentLink.LinkType</a> == "toc"
    and <a href="#IQVDocumentLink.LinkLevel">IQVDocumentLink.LinkLevel</a> == 6
    """

    link_id_subsection1 = str
    """
    Element index
    Which [link <a href="#IQVDocumentLink">IQVDocumentLink</a>] section is this element in?
    The id for <a href="#IQVDocumentLink.LinkType">IQVDocumentLink.LinkType</a> == "subsection1"
    """

    link_id_subsection2 = str
    """
    Element index
    Which [link <a href="#IQVDocumentLink">IQVDocumentLink</a>] section is this element in?
    The id for <a href="#IQVDocumentLink.LinkType">IQVDocumentLink.LinkType</a> == "subsection2"
    """

    link_id_subsection3 = str
    """
    Element index
    Which [link <a href="#IQVDocumentLink">IQVDocumentLink</a>] section is this element in?
    The id for <a href="#IQVDocumentLink.LinkType">IQVDocumentLink.LinkType</a> == "subsection3"
    """

    LocalName = str
    """
    Short name
    """

    Name = str
    """
    Full name
    """

    parent_id = str
    """
    Element index
    Which item is this element a member of?
    For example, for <a href="#IQVPageROI.Properties">IQVPageROI.Properties</a>, parent_id = <a href="#IQVPageROI.id">IQVPageROI.id</a>
    Possible parents include but are not limited to
    <a href="#IQVDocument">IQVDocument</a><a href="#IQVPageROI">IQVPageROI</a><a href="#IQVDocumentLink">IQVDocumentLink</a>
    SQL code example 1 for usage of index
    <code>
    WHERE parent_id=parent_id AND group_type=group_type
    </code>
    SQL code example 2 for usage of index
    <code>
    WHERE parent_id=parent_id
    </code>
    """

    Value = str
    """
    Attribute value
    """

    def __init__(self):
        self.doc_id = ''
        self.group_type = ''
        self.hierarchy = ''
        self.id = ''
        self.iqv_standard_term = ''
        self.link_id = ''
        self.link_id_level2 = ''
        self.link_id_level3 = ''
        self.link_id_level4 = ''
        self.link_id_level5 = ''
        self.link_id_level6 = ''
        self.link_id_subsection1 = ''
        self.link_id_subsection2 = ''
        self.link_id_subsection3 = ''
        self.LocalName = ''
        self.Name = ''
        self.parent_id = ''
        self.Value = ''
        self.id = str(uuid.uuid1())


class RotationCheck(object):
    """
    Find best rotation for image, assuming text
    arranged in horizontal lines
    """

    degree = float
    """
    Rotation measured in degrees
    """

    filenameVar = str
    """
    File saved for this rotation
    """

    maxVariance = float
    """
    Derived Variance for this rotation
    """

    def __init__(self):
        self.degree = 0.0
        self.filenameVar = ''
        self.maxVariance = 0.0
        self.id = str(uuid.uuid1())


class ValueI(object):
    """
    Integer value
    """

    key = str
    """
    key for value
    """

    value = int
    """
    value as integer
    """

    def __init__(self):
        self.key = ''
        self.value = -1


class LineBoundaries(object):
    """
    Boundaries using set of lines
    """

    bIsVertical = bool
    """
    true if vertical; false if horizontal
    """

    Lines = []
    """
    Lines making up line boundaries
    """

    RecursiveLevel = int
    """
    for recursion
    """

    def __init__(self):
        self.bIsVertical = False
        self.Lines = []
        self.RecursiveLevel = -1
        self.id = str(uuid.uuid1())


class TextMatch(object):
    """
    Text match for OCR output, used in OCR post-processing
    """

    index = int
    """
    index
    """

    Score = float
    """
    score
    """

    text = str
    """
    text
    """

    def __init__(self):
        self.index = -1
        self.Score = 0.0
        self.text = ''


class IQVDocumentFeedbackItem(object):
    """
    
    """

    CheckboxValue = int
    """
    Default is 0, no checkbox. If this is an
     UNCHECKED checkbox = -1
    CHECKED checkbox = 1
    NOT checkbox = 0
    """

    date_time_stamp = str
    """
    14-character datetime string as YYYYMMDDHHMMSS
    default is UTC time zone
    """

    document_composite_confidence = float
    """
    confidence score from 0-100; zero is lowest, 100 is highest
    """

    document_date = str
    """
    8-character date string as YYYYMMDD
    For AI, the selected date (in accordance with
     top-1 classification and corresponding date guidance) is
    posted here in the document_date
    """

    environment = str
    """
    dev, svt, uat, etc. or other environment settings
    """

    feedback_source = str
    """
    post = initial post of document
    user = initial etmf user feedback
    rimqc = records management qc
    filereview = file review done after 3-6 months
    ai = ai engine (optional to align)
    """

    feedback_source_version = str
    """
    version of AI (1.1.0), etc
    """

    id = str
    """
    id for this result set
    """

    Properties = []
    """
    Properties for this
     <a href="#IQVKeyValueSet.key">IQVKeyValueSet.key</a> See standardized key listing
    <a href="#IQVKeyValueSet.value">IQVKeyValueSet.value</a> See standardized key listing
    <a href="#IQVKeyValueSet.confidence">IQVKeyValueSet.confidence</a> is 0 to 1 confidence value
    """

    source_system = str
    """
    system connecting to AI
    """

    user_id = str
    """
    user id for submitter
    """

    def __init__(self):
        self.CheckboxValue = -1
        self.date_time_stamp = ''
        self.document_composite_confidence = 0.0
        self.document_date = ''
        self.environment = ''
        self.feedback_source = ''
        self.feedback_source_version = ''
        self.id = ''
        self.Properties = []
        self.source_system = ''
        self.user_id = ''
        self.id = str(uuid.uuid1())


class IQVDocumentFeedbackResults(object):
    """
    Class that supports PUT Attributes
     for all instances of feedback;
    also supports POST
    """

    alcoac_check_composite_score = float
    """
    confidence score from 0-100; zero is lowest, 100 is highest
    """

    alcoac_check_composite_score_confidence = float
    """
    confidence score from 0-100; zero is lowest, 100 is highest
    """

    alcoac_check_error = []
    """
    List of IQVAttributeCandidate, each IQVAttributeCandidate has the information for an error.

    AttributeKey = 'alcoac_check_error'
    AttributeValue = 'greyscale_error'
    Features = list of IQVKeyValueSet
    Feature 1:
    key = 'alcoac_error_score'
    value = int value 0 (bad) to 100 (good)
    # worse greyscale, closer to zero
    Feature 2:
    key = 'alcoac_error_message'
    value = '3,5' # string
    # string, comma-separated list of int

    key=greyscale_error
    key=legibility_error
    key=clean_image_error
    key=page_skew_error
    key=order_pages_error
    key=blank_pages_error
    key=duplicate_document_error
    key=missing_pages_error
    key=missing_signatures_error
    key=missing_fields_error
    """

    amendment_number = str
    """
    Y or N--is amendment? as string
    """

    attribute_auxiliary_list = []
    """
    list of additional attributes (ip greenlight, etc.)
    """

    blinded = bool
    """
    on post, true/false, default to true (document is NOT unblinded)
    """

    country = str
    """
    if not core-level
    """

    customer = str
    """
    Customer
    """

    date_time_stamp = str
    """
    14-character datetime string as YYYYMMDDHHMMSS
    default is UTC time zone
    """

    DateTimeCreated = str
    """
    Date time stamp the feedback created
    """

    doc_id = str
    """
    Element index
    Which document is this element in?
    Top-level id for <a href="#IQVDocument">IQVDocument</a>
    """

    document_class = str
    """
    study/core;country;site
    """

    document_classification = []
    """
    list of XX.XX.XX.Abbreviation
    X is digit 0-9;
     zone as 2-digit;
     section as 2-digit;
     artifact as 2-digit;
     zone+section+artifact make up the DIA key;
     Abbreviation (sub-type) follows DIA Key;
     period is delimiter between zone, section, artifact, and abbreviation; single (final) document classification selected by user
    XX.XX.XX.Abbreviation, list of string
    """

    document_classification_confidence = []
    """
    confidence score from 0-100; zero is lowest, 100 is highest
    """

    document_composite_confidence = float
    """
    confidence score from 0-100; zero is lowest, 100 is highest
    """

    document_date = str
    """
    8-character date string as YYYYMMDD
    For AI, the selected date (in accordance with
     top-1 classification and corresponding date guidance) is
    posted here in the document_date
    """

    document_date_confidence = float
    """
    confidence score from 0-100; zero is lowest, 100 is highest
    """

    document_date_list = []
    """
    list of dates for this document, keyed on the date
    guidance (type of date)
    <a href="#IQVKeyValueSet.key">IQVKeyValueSet.key</a> is date guidance (type of date)
    such as "Version Date", "Signature Date", etc.
    <a href="#IQVKeyValueSet.value">IQVKeyValueSet.value</a> is 8-character date string as YYYYMMDD
    <a href="#IQVKeyValueSet.confidence">IQVKeyValueSet.confidence</a> is 0 to 1 confidence value
    """

    document_date_type = str
    """
    type of date used
    """

    document_id = str
    """
    id for this document resource
    """

    document_native_classification = []
    """
    The document_native_classification is only used to compare
    the processing output with historical documents for training. In this
    way, the EXACT classification results can be compared with the ground truth.
    list of XX.XX.XX.Abbreviation
    X is digit 0-9;
     zone as 2-digit;
     section as 2-digit;
     artifact as 2-digit;
     zone+section+artifact make up the DIA key;
     Abbreviation (sub-type) follows DIA Key;
     period is delimiter between zone, section, artifact, and abbreviation; single (final) document classification selected by user
    XX.XX.XX.Abbreviation, list of string
    """

    document_native_classification_confidence = []
    """
    confidence score from 0-100; zero is lowest, 100 is highest
    """

    document_rejected = str
    """
    false if document was NOT rejected (assume based on image quality)
    true if document was REJECTED based on image quality
    """

    document_status = str
    """
    final, draft, etc.
    """

    document_subclassification = []
    """
    Only for special cases: provide extra subclassification for subdivisions within the same DIA Ref Model and subtype
    """

    document_subclassification_confidence = []
    """
    confidence score from 0-100; zero is lowest, 100 is highest
    """

    draft_number = str
    """
    draft indicator as string
    """

    environment = str
    """
    dev, svt, uat, etc. or other environment settings
    """

    expiry_date = str
    """
    Secondary date to <a href="#IQVDocumentFeedbackResults.document_date">IQVDocumentFeedbackResults.document_date</a>
    8-character date string as YYYYMMDD
    This is a separate, additional date to
     <a href="#IQVDocumentFeedbackResults.document_date">IQVDocumentFeedbackResults.document_date</a>.
    This is optional and only applied to specific
     document classifications
    """

    expiry_date_confidence = float
    """
    Secondary date to <a href="#IQVDocumentFeedbackResults.document_date">IQVDocumentFeedbackResults.document_date</a>
    confidence score from 0-100; zero is lowest, 100 is highest
    """

    feedback_source = str
    """
    post = initial post of document
    user = initial etmf user feedback
    rimqc = records management qc
    filereview = file review done after 3-6 months
    ai = ai engine (optional to align)
    """

    feedback_source_version = str
    """
    version of AI (1.1.0), etc
    """

    group_type = str
    """
    Element index
    Which item is this element a member of? (name of member = group_type)
    For example, for <a href="#IQVPageROI.Properties">IQVPageROI.Properties</a>, group_type = "Properties"
    Possible parents include but are not limited to
    <a href="#IQVDocument">IQVDocument</a><a href="#IQVPageROI">IQVPageROI</a><a href="#IQVDocumentLink">IQVDocumentLink</a>
    SQL code example 1 for usage of index
    <code>
    WHERE parent_id=parent_id AND group_type=group_type
    </code>
    """

    hierarchy = str
    """
    image,table,paragraph,item,header,footer,roi
    """

    id = str
    """
    id for this result set
    """

    indication = str
    """
    indication of clinical trials study
    """

    iqv_standard_term = str
    """
    Element index
    If this element is a link or header, what is the standard term?
    There is 0 or 1 iqv_standard_term for each element
    """

    iqvdata = str
    """
    JSON string for data returned
    """

    language = str
    """
    Language identifier
     3-character string
    ISO 639-2 Code
    e.g., eng for English
    """

    language_confidence = float
    """
    confidence score from 0-100; zero is lowest, 100 is highest
    """

    link_id = str
    """
    Element index
    Which [link <a href="#IQVDocumentLink">IQVDocumentLink</a>] section is this element in?
    The id for <a href="#IQVDocumentLink.LinkType">IQVDocumentLink.LinkType</a> == "toc"
    and <a href="#IQVDocumentLink.LinkLevel">IQVDocumentLink.LinkLevel</a> == 1
    """

    link_id_level2 = str
    """
    Element index
    Which [link <a href="#IQVDocumentLink">IQVDocumentLink</a>] section is this element in?
    The id for <a href="#IQVDocumentLink.LinkType">IQVDocumentLink.LinkType</a> == "toc"
    and <a href="#IQVDocumentLink.LinkLevel">IQVDocumentLink.LinkLevel</a> == 2
    """

    link_id_level3 = str
    """
    Element index
    Which [link <a href="#IQVDocumentLink">IQVDocumentLink</a>] section is this element in?
    The id for <a href="#IQVDocumentLink.LinkType">IQVDocumentLink.LinkType</a> == "toc"
    and <a href="#IQVDocumentLink.LinkLevel">IQVDocumentLink.LinkLevel</a> == 3
    """

    link_id_level4 = str
    """
    Element index
    Which [link <a href="#IQVDocumentLink">IQVDocumentLink</a>] section is this element in?
    The id for <a href="#IQVDocumentLink.LinkType">IQVDocumentLink.LinkType</a> == "toc"
    and <a href="#IQVDocumentLink.LinkLevel">IQVDocumentLink.LinkLevel</a> == 4
    """

    link_id_level5 = str
    """
    Element index
    Which [link <a href="#IQVDocumentLink">IQVDocumentLink</a>] section is this element in?
    The id for <a href="#IQVDocumentLink.LinkType">IQVDocumentLink.LinkType</a> == "toc"
    and <a href="#IQVDocumentLink.LinkLevel">IQVDocumentLink.LinkLevel</a> == 5
    """

    link_id_level6 = str
    """
    Element index
    Which [link <a href="#IQVDocumentLink">IQVDocumentLink</a>] section is this element in?
    The id for <a href="#IQVDocumentLink.LinkType">IQVDocumentLink.LinkType</a> == "toc"
    and <a href="#IQVDocumentLink.LinkLevel">IQVDocumentLink.LinkLevel</a> == 6
    """

    link_id_subsection1 = str
    """
    Element index
    Which [link <a href="#IQVDocumentLink">IQVDocumentLink</a>] section is this element in?
    The id for <a href="#IQVDocumentLink.LinkType">IQVDocumentLink.LinkType</a> == "subsection1"
    """

    link_id_subsection2 = str
    """
    Element index
    Which [link <a href="#IQVDocumentLink">IQVDocumentLink</a>] section is this element in?
    The id for <a href="#IQVDocumentLink.LinkType">IQVDocumentLink.LinkType</a> == "subsection2"
    """

    link_id_subsection3 = str
    """
    Element index
    Which [link <a href="#IQVDocumentLink">IQVDocumentLink</a>] section is this element in?
    The id for <a href="#IQVDocumentLink.LinkType">IQVDocumentLink.LinkType</a> == "subsection3"
    """

    molecule_device = str
    """
    molecule or device of clinical trials study
    """

    name = str
    """
    first/last name in accordance with site personnel list;
    should match site personnel list
    """

    name_confidence = float
    """
    confidence score from 0-100; zero is lowest, 100 is highest
    """

    parent_id = str
    """
    Element index
    Which item is this element a member of?
    For example, for <a href="#IQVPageROI.Properties">IQVPageROI.Properties</a>, parent_id = <a href="#IQVPageROI.id">IQVPageROI.id</a>
    Possible parents include but are not limited to
    <a href="#IQVDocument">IQVDocument</a><a href="#IQVPageROI">IQVPageROI</a><a href="#IQVDocumentLink">IQVDocumentLink</a>
    SQL code example 1 for usage of index
    <code>
    WHERE parent_id=parent_id AND group_type=group_type
    </code>
    SQL code example 2 for usage of index
    <code>
    WHERE parent_id=parent_id
    </code>
    """

    post_data = str
    """
    Open-ended field to handle extra data
    """

    priority = str
    """
    on post, priority 0 - 5
    0 is default, 5 is high priority
    """

    project_id = str
    """
    Project ID
    """

    protocol = str
    """
    Protocol Number
    """

    received_date = str
    """
    YYYYMMDD from user input
    """

    ref_id = str
    """
    Some value to help uniquely identify this document resource. The
    value should be of type <a href="#IQVDocumentFeedbackResults.ref_id_type">IQVDocumentFeedbackResults.ref_id_type</a>.
     Example: ref_id_type=doc_id; ref_id=1111-aaaa-bbbb-cccc
    Example: ref_id_type=protocol_number; ref_id=P123456
    In the case of ref_id_type other than doc_id, additional information
    may be required to uniquely identify the document, such as version.
    """

    ref_id_type = str
    """
    Used in conjunction with <a href="#IQVDocumentFeedbackResults.ref_id">IQVDocumentFeedbackResults.ref_id</a>.
    The ref_id is some value to help uniquely identify this document resource.
     The ref_id_type is the value type (domain) of ref_id.
    Example: ref_id_type=doc_id; ref_id=1111-aaaa-bbbb-cccc
    Example: ref_id_type=protocol_number; ref_id=P123456
    In the case of ref_id_type other than doc_id, additional information
    may be required to uniquely identify the document, such as version.
    """

    site = str
    """
    if site-level, else blank
    """

    site_personnel_list = []
    """
    key/value pair list of name + role
    ['F M L','y'],['Mary Jones','n'],['Fred Flintstone','o']
    from system lookup
    Y exactly 1 (y = PI)
    N 0+ (n = sub-PI)
    O 0+ (o = other)
    Expected: First + space + middle + space + last
    """

    source_filename = str
    """
    original filename for historical purposes
    """

    source_system = str
    """
    system connecting to AI
    """

    sponsor = str
    """
    Sponsor of trial
    """

    study_status = str
    """
    status of clinical trials study
    """

    subject = str
    """
    extra information about the document
    """

    subject_confidence = float
    """
    confidence score from 0-100; zero is lowest, 100 is highest
    """

    tmf_environment = str
    """
    Wingspan, Documentum, etc.
    """

    tmf_ibr = str
    """
    on post, expected tmf
    """

    user_id = str
    """
    user id for submitter
    """

    version_number = str
    """
    Version number as string
    """

    def __init__(self):
        self.alcoac_check_composite_score = 0.0
        self.alcoac_check_composite_score_confidence = 0.0
        self.alcoac_check_error = []
        self.amendment_number = ''
        self.attribute_auxiliary_list = []
        self.blinded = False
        self.country = ''
        self.customer = ''
        self.date_time_stamp = ''
        self.DateTimeCreated = ''
        self.doc_id = ''
        self.document_class = ''
        self.document_classification = []
        self.document_classification_confidence = []
        self.document_composite_confidence = 0.0
        self.document_date = ''
        self.document_date_confidence = 0.0
        self.document_date_list = []
        self.document_date_type = ''
        self.document_id = ''
        self.document_native_classification = []
        self.document_native_classification_confidence = []
        self.document_rejected = ''
        self.document_status = ''
        self.document_subclassification = []
        self.document_subclassification_confidence = []
        self.draft_number = ''
        self.environment = ''
        self.expiry_date = ''
        self.expiry_date_confidence = 0.0
        self.feedback_source = ''
        self.feedback_source_version = ''
        self.group_type = ''
        self.hierarchy = ''
        self.id = ''
        self.indication = ''
        self.iqv_standard_term = ''
        self.iqvdata = ''
        self.language = ''
        self.language_confidence = 0.0
        self.link_id = ''
        self.link_id_level2 = ''
        self.link_id_level3 = ''
        self.link_id_level4 = ''
        self.link_id_level5 = ''
        self.link_id_level6 = ''
        self.link_id_subsection1 = ''
        self.link_id_subsection2 = ''
        self.link_id_subsection3 = ''
        self.molecule_device = ''
        self.name = ''
        self.name_confidence = 0.0
        self.parent_id = ''
        self.post_data = ''
        self.priority = ''
        self.project_id = ''
        self.protocol = ''
        self.received_date = ''
        self.ref_id = ''
        self.ref_id_type = ''
        self.site = ''
        self.site_personnel_list = []
        self.source_filename = ''
        self.source_system = ''
        self.sponsor = ''
        self.study_status = ''
        self.subject = ''
        self.subject_confidence = 0.0
        self.tmf_environment = ''
        self.tmf_ibr = ''
        self.user_id = ''
        self.version_number = ''
        self.id = str(uuid.uuid1())


class IQVDocumentGroundTruth(object):
    """
    Labelled Metadata for a document that has been human-verified
    """

    AdditionalInstructionsList = []
    """
    Categorized list of additional instructions for metadata
    extraction  as <a href="#IQVKeyValueSet">IQVKeyValueSet</a>
    Examples for key:value
    MeetingTopic:{0 or blank,1}
    IndividualName:{0 or blank,1,2} # Use numeric to specify how many names
    DocumentName:{0 or blank,1,2} # Use numeric to specify how many names
    Version:{0 or blank, 1} # Use original
    AmendmentNumber
    LanguageIdentifier
    """

    AIDocLocation = str
    """
    Verified file exists on AI Doc server
    (i.e., is available for training)
    """

    AIDocLocationOriginal = str
    """
    If a derived document is created,
    original source is listed here. For example,
    a simulated scan for DLA training
    """

    Artifact = str
    """
    Inventory Column F
    Artifact
    Subtype
    Metadata column D
    """

    Batch_Home_Location = str
    """
    Inventory Column T
    """

    bReservedForSVT = int
    """
    0 = not reserved
    1 = reserved
    Indicates whether to
    utilize files reserved for SVT only (not used in
    development, training, or dev testing)
    """

    Certification_Date = str
    """
    Metadata column AM
    """

    Certification_Meaning = str
    """
    Metadata column AL
    """

    Certification_User = str
    """
    Metadata column AK
    """

    Country = str
    """
    Metadata column AC
    """

    Country_Code = str
    """
    Metadata column AB
    """

    dataset = str
    """
    Assignment of this document to a specific dataset
    for a specific purpose, such as training, test, validation
    """

    dataset_source = str
    """
    Assignment of this document to a specific dataset
    for a specific purpose, such as training, test, validation
    """

    Date_Created = str
    """
    Inventory Column M
    Metadata column I
    """

    Date_Created14 = str
    """
    Date/time in YYYYMMDDHHMMSS format (14 characters)
    """

    Date_Identifier = str
    """
    Inventory Column J
    Date Identifier
    Metadata column H
    3 characters as listed here:
    APP Date of Approval or Acknowledgement Applicable to documents where the date of approval or
    acknowledgement is the date to capture.\n
    DOC Date of Correspondence Used for letters received at Quintiles.Use the date that
    appears at the top of the letter.\n
    DOD Date of Document Use if the date of the document does not fit one of the other
    defined abbreviations - see 4.1.1 for more information on
    situations to use\n
    DOE Date of Event Date that an event actually occurred.
    Listed date of a Serious Adverse Event or date of a telephone contact.
    DOV Date of Visit Specific to Visit Documentation
    EFF Effective Date Applicable to document where the effective date is the date to capture
    EXP Date of Expiration Applicable to documents where the date of expiration is the date to capture
    NTF Note to File This identifier is used to indicate the placement of NTF(s)
    within the Central Files Structure - see 4.1.2 for more information
    SIG Date of Signature Applicable to document where the date of signature is the date to capture
    SNT Date Sent Used for letters created at Quintiles that are sent to outside source, for example an Investigator Site
    VER Version Date Applicable to documents where the version date is the dat to capture
    """

    DateID_Index = int
    """
    numeric index
    """

    Description = str
    """
    Inventory Column H
    Comment
    llnode description
    Metadata column F
    """

    DIA_Key = str
    """
    Input column DIA Key for some metadata
    """

    doc_id = str
    """
    Wingspan.
    This is the ###.## Wingspan-specific code.
    Use the <a href="#IQVDocumentGroundTruth.doc_id">IQVDocumentGroundTruth.doc_id</a> and the <a href="#IQVDocumentGroundTruth.ref_model_subtype_code">IQVDocumentGroundTruth.ref_model_subtype_code</a>
    to uniquely classify a document
    Derived from <a href="#tmf_study_item.tmf_item_id">tmf_study_item.tmf_item_id</a>
    """

    doc_type_wingspan = str
    """
    Wingspan.
    This is the long description for the ###.## Wingspan-specific code.
    Use the <a href="#IQVDocumentGroundTruth.doc_id">IQVDocumentGroundTruth.doc_id</a> and the <a href="#IQVDocumentGroundTruth.ref_model_subtype_code">IQVDocumentGroundTruth.ref_model_subtype_code</a>
    to uniquely classify a document.
     This doc_type is redundant information for <a href="#IQVDocumentGroundTruth.doc_id">IQVDocumentGroundTruth.doc_id</a>.
    Derived from <a href="#tmf_study_item.tmf_item_type">tmf_study_item.tmf_item_type</a>
    """

    Document_Abbreviation = str
    """
    Metadata column N
    """

    Document_Abbreviation_Index = int
    """
    numeric index
    """

    Document_Class = str
    """
    Inventory Column A
    Document Class
    Metadata column A
    """

    Document_Date = str
    """
    Inventory Column I
    Document Date
    Format 2015-08-14T00:00:00/n
    Metadata column G/n
    """

    Document_Date_FromNamingConvention = str
    """
    YYYY-MM-DD
    """

    Document_Date_Index = int
    """
    numeric index
    """

    Document_Date14 = str
    """
    Date/time in YYYYMMDDHHMMSS format (14 characters)
    """

    Document_Identifier = str
    """
    Metadata column O
    """

    Document_Identifier_Index = int
    """
    numeric index
    """

    document_instructions = str
    """
    Wingspan.
    Detailed instructions for this document when it was indexed.
    This helps in decoding what is in the subject line
    <a href="#tmf_study_item.subject">tmf_study_item.subject</a>
    (in ELVIS this is similar to <a href="#IQVDocumentGroundTruth.Document_Identifier">IQVDocumentGroundTruth.Document_Identifier</a>).
    The <a href="#IQVDocumentGroundTruth.AdditionalInstructionsList">IQVDocumentGroundTruth.AdditionalInstructionsList</a> is derived from
    these verbose instructions.
    """

    Document_Language = str
    """
    Inventory Column P
    Document Language (non-English)
    Metadata column J
    """

    Document_Naming_Convention = str
    """
    Document Abbreviation-YYYY-MM-DD-Date ID-[Document Identifier (free text)]-[Language Abbreviation]-[Language ID]-SEQ#
    Drug Type-Document Abbreviation-YYYY-MM-DD-Date ID-[Document Identifier (free text)] -[Language Abbreviation]- [Language ID]-SEQ#
    Last Name-First Name- Document Abbreviation-YYYY-MM-DD-Date ID-[Document Identifier (free text)]-[Language Abbreviation]-[Language ID]-SEQ#
    Not applicable
    Organization ID (free text)-Document Abbreviation-YYYY-MM-DD-Date ID- [Document Identifier (free text)] - [Language Abbreviation]-[Language ID]-SEQ#
    YYYY-MM-DD-Date ID-Document Abbreviation- Report Version -Event Identifier (free text) -[Document Identifier (free text)]-[Language Abbreviation]-[Language ID]-SEQ#
    YYYY-MM-DD-Date ID-Document Abbreviation-[Document Identifier (free text)]-[Language Abbreviation]-[Language ID]-SEQ#
    YYYY-MM-DD-DOV-Site ID-Visit Type-Visit Doc ID-[Document Identifier (free text)]-[Language Abbreviation]-[Language ID]-SEQ#
    """

    Document_Sequence_ID = str
    """
    Inventory Column V
    """

    Document_Status = str
    """
    Inventory Column Q
    """

    Document_Type_Unique_Identifier = str
    """
    Match <a href="#IQVTMFMatrixItem.AC_DocumentTypeUniqueIdentifier">IQVTMFMatrixItem.AC_DocumentTypeUniqueIdentifier</a> AC_DocumentTypeUniqueIdentifier
    """

    DocumentImages = []
    """
    In PDF processing (esp. scans), this is the collection of PDF pages. For example,
     one page will be one element in the DocumentImages list. Each page will be
    represented by a hierarchical <a href="#IQVPageROI">IQVPageROI</a> object.
    Originally, used for items retrieved from input Word document during deconstruction. Segmentation
    is performed on these items during creation of <a href="#IQVPageROI.ChildBoxes">IQVPageROI.ChildBoxes</a>.
    """

    DocumentNumChars = int
    """
    derived document analysis value
    """

    DocumentNumImages = int
    """
    derived document analysis value
    """

    DocumentNumPages = int
    """
    derived document analysis value
    """

    DocumentNumWords = int
    """
    derived document analysis value
    """

    DocumentPageLevel = str
    """
    Extended Features Inventory Column Y
    """

    DocumentPathFilename = str
    """
    Extended Features Inventory Column X
    """

    DocumentType = int
    """
    PDF digitized, scanned, excel, etc.
    Not set
    DEFAULT=0,
    doc extension
    WORD_DOC=1,
    docx extension
    WORD_DOCX=2,
    PDF_DIGITIZED=3,
    PDF_SCANNED=4,
    EXCEL_XLS=5,
    EXCEL_XLSX=6,
    standard text file
    TEXT_TXT=7,
    PDF_SCANNED_TO_DOCX=8,
    msg extension for IMAP email
    OUTLOOK_MSG=9,
    TIFF may have multiple frames
    IMAGE_TIFF=10
    IMAGE_JPEG = 11,
    IMAGE_BMP = 12,
    IMAGE_PNG = 13,
    IMAGE_GIF = 14,
    POWERPOINT_PPTX = 15,
    POWERPOINT_PPT = 16,
    TEXT_CSV = 17,
    WORD_ODT = 18,
    SAS_DATA_XPT = 19,
    SAS_PROGRAM_SAS = 20,
    VISIO_VSD = 21,
    WORD_DOTX = 22,
    ZIP_ZIP = 23,
    ZIP_7Z = 24,
    SAS_DATA_SAS7BDAT = 25
    """

    Drug_Type = str
    """
    Metadata column Z
    """

    Drug_Type_Index = int
    """
    numeric index
    """

    EEL_Batch_ID = str
    """
    Inventory Column S
    Metadata column P
    """

    EEL_Batch_Type = str
    """
    Inventory Column R
    """

    Email_FROM = str
    """
    Metadata column AV
    """

    Email_Receive_Date = str
    """
    Metadata column AX
    """

    Email_Send_Date = str
    """
    Metadata column AW
    """

    Email_Subject = str
    """
    Metadata column AT
    """

    Email_TO = str
    """
    Metadata column AU
    """

    Event_Identifier = str
    """
    Metadata column AJ
    """

    Export_File_Name = str
    """
    Metadata column AQ
    """

    Export_Path = str
    """
    Metadata column AP
    """

    File_MimeType = str
    """
    e.g., application/pdf
    """

    File_Name_Modified = str
    """
    Metadata column AR
    """

    File_Plan_Category_Number = str
    """
    Metadata column M
    """

    First_Name = str
    """
    Metadata column AD
    """

    GTArtifact_Code = str
    """
    2-digit numeric code for Artifact
    <a href="#IQVDocumentGroundTruth.GetTwoDigitCode(System.String)">IQVDocumentGroundTruth.GetTwoDigitCode(System.String)</a>
    """

    GTBatch = str
    """
    Extended Features Inventory Column AF
    """

    GTDuplicate = str
    """
    Extended Features Inventory Column AE
    """

    GTGreyscale = str
    """
    Extended Features Inventory Column AB
    """

    GTIndex = str
    """
    Extended Features Inventory Column AG
    """

    GTLegibility = str
    """
    Extended Features Inventory Column AC
    """

    GTPages = str
    """
    Extended Features Inventory Column AD
    """

    GTSection_Code = str
    """
    2-digit numeric code for Section
    <a href="#IQVDocumentGroundTruth.GetTwoDigitCode(System.String)">IQVDocumentGroundTruth.GetTwoDigitCode(System.String)</a>
    """

    GTZone_Code = str
    """
    2-digit numeric code for Zone
    <a href="#IQVDocumentGroundTruth.GetTwoDigitCode(System.String)">IQVDocumentGroundTruth.GetTwoDigitCode(System.String)</a>
    """

    GTZone_Section_Artifact_Code = str
    """
    2.2.2 numeric code for Artifact
    <a href="#IQVDocumentGroundTruth.GetTwoDigitCode(System.String)">IQVDocumentGroundTruth.GetTwoDigitCode(System.String)</a>
    """

    GTZone_Section_Code = str
    """
    2.2 numeric code for Section
    <a href="#IQVDocumentGroundTruth.GetTwoDigitCode(System.String)">IQVDocumentGroundTruth.GetTwoDigitCode(System.String)</a>
    """

    id = str
    """
    Unique (GUID) identifier for the document
    """

    Inventory_Class = str
    """
    class in inventory listing
    """

    Inventory_CountryName = str
    """
    country name in inventory listing
    """

    Investigator_Name = str
    """
    Inventory Column C
    Metadata column V
    """

    IQV_XML_Filename = str
    """
    IQV.XML digital twin if already exists for this document
    """

    Issue = str
    """
    QC Error
    """

    IssueDescription = str
    """
    QC Error description
    """

    Language_Abbreviation = str
    """
    Metadata column K
    """

    Language_Abbreviation_Index = int
    """
    numeric index
    """

    Language_ID_Index = int
    """
    numeric index
    """

    Language_Identifier = str
    """
    Inventory Column O
    Metadata column L
    """

    Last_Name = str
    """
    Metadata column AE
    """

    LastNameFirstName_FromNamingConvention = str
    """
    numeric index
    """

    LastNameFirstName_Index = int
    """
    numeric index
    """

    LocalSubdirectory = str
    """
    Name of subdirectory, such as "00 Core" or "SPAIN"
    under the protocol directory
    """

    Mandatory_Retention = str
    """
    Inventory Column K
    """

    Modify_Date = str
    """
    Inventory Column N
    """

    Name = str
    """
    Inventory Column G\n
    llnode name\n
    no file extension\n
    Metadata column E
    """

    NoisyPageIndex = str
    """
    Ones-based; page numbers are 1-based
    """

    Object_ID = str
    """
    Metadata column AS
    """

    Organization_ID = str
    """
    Metadata column R
    """

    OrganizationID_Index = int
    """
    numeric index
    """

    Original_Inventory_Filename = str
    """
    filename
    """

    Original_Path = str
    """
    Metadata column AO
    """

    OriginalSourceDataDirectory = str
    """
    Original Source Data Directory from which this file
    was obtained
    """

    OriginalSourceDataZipFilename = str
    """
    Original Source Data Zip file (or 7z) from which this file
    was obtained
    """

    PagePathFilenamePDF = str
    """
    Extended Features Inventory Column AA
    """

    PageSequenceNumber = str
    """
    Extended Features Inventory Column Z
    """

    Paper_Received_Date = str
    """
    Inventory Column L
    """

    Phase = str
    """
    Metadata column Y
    """

    Project_Code = str
    """
    Quintiles Project Code
    Metadata column Q
    Quintiles Project Code
    e.g. HXA34189
    """

    Protocol_Number = str
    """
    Metadata column X
    """

    ref_model_subtype_code = str
    """
    Wingspan.
    This is 'similar' to the <a href="#IQVDocumentGroundTruth.Document_Abbreviation">IQVDocumentGroundTruth.Document_Abbreviation</a>.
    Use the <a href="#IQVDocumentGroundTruth.doc_id">IQVDocumentGroundTruth.doc_id</a> and the <a href="#IQVDocumentGroundTruth.ref_model_subtype_code">IQVDocumentGroundTruth.ref_model_subtype_code</a>
    to uniquely classify a document.
    For some document types this is blank.
    """

    Report_Type = str
    """
    Metadata column AH
    """

    Report_Version = str
    """
    Metadata column AI
    """

    Section = str
    """
    Inventory Column E
    Section
    Type
    Metadata column C
    """

    Sequence_Number = str
    """
    numeric index
    """

    Sequence_Number_Index = int
    """
    numeric index
    """

    Site_Name = str
    """
    Metadata column W
    """

    Source_System = str
    """
    Metadata column AN, "wingspan", "elvis"
    """

    Source_System_Version = str
    """
    Version for "wingspan", "elvis"
    """

    Study_Site_ID = str
    """
    Inventory Column B
    Metadata column U
    """

    Therapeutic_Area = str
    """
    Metadata column AA
    """

    TMF = str
    """
    Inventory Column U
    """

    Type = str
    """
    Metadata column S
    """

    Type_Value = str
    """
    Metadata column T
    """

    Visit_Document_ID = str
    """
    Metadata column AG
    """

    Visit_Type = str
    """
    Metadata column AF
    """

    VisitDocID_Index = int
    """
    numeric index
    """

    VisitType_Index = int
    """
    numeric index
    """

    XProperties = []
    """
    'X' Properties as these are properties with multiple values for each key
    key is not unique

    List of additional properties as <a href="#IQVKeyValueSet">IQVKeyValueSet</a><a href="#IQVKeyValueSet.key">IQVKeyValueSet.key</a> See standardized key listing
    <a href="#IQVKeyValueSet.value">IQVKeyValueSet.value</a> See standardized key listing
    <a href="#IQVKeyValueSet.confidence">IQVKeyValueSet.confidence</a> is 0 to 1 confidence value
    gridspan (for table cell)
    """

    Zone = str
    """
    Inventory Column D
    Zone
    Group
    Metadata column B
    """

    def __init__(self):
        self.AdditionalInstructionsList = []
        self.AIDocLocation = ''
        self.AIDocLocationOriginal = ''
        self.Artifact = ''
        self.Batch_Home_Location = ''
        self.bReservedForSVT = -1
        self.Certification_Date = ''
        self.Certification_Meaning = ''
        self.Certification_User = ''
        self.Country = ''
        self.Country_Code = ''
        self.dataset = ''
        self.dataset_source = ''
        self.Date_Created = ''
        self.Date_Created14 = ''
        self.Date_Identifier = ''
        self.DateID_Index = -1
        self.Description = ''
        self.DIA_Key = ''
        self.doc_id = ''
        self.doc_type_wingspan = ''
        self.Document_Abbreviation = ''
        self.Document_Abbreviation_Index = -1
        self.Document_Class = ''
        self.Document_Date = ''
        self.Document_Date_FromNamingConvention = ''
        self.Document_Date_Index = -1
        self.Document_Date14 = ''
        self.Document_Identifier = ''
        self.Document_Identifier_Index = -1
        self.document_instructions = ''
        self.Document_Language = ''
        self.Document_Naming_Convention = ''
        self.Document_Sequence_ID = ''
        self.Document_Status = ''
        self.Document_Type_Unique_Identifier = ''
        self.DocumentImages = []
        self.DocumentNumChars = -1
        self.DocumentNumImages = -1
        self.DocumentNumPages = -1
        self.DocumentNumWords = -1
        self.DocumentPageLevel = ''
        self.DocumentPathFilename = ''
        self.DocumentType = -1
        self.Drug_Type = ''
        self.Drug_Type_Index = -1
        self.EEL_Batch_ID = ''
        self.EEL_Batch_Type = ''
        self.Email_FROM = ''
        self.Email_Receive_Date = ''
        self.Email_Send_Date = ''
        self.Email_Subject = ''
        self.Email_TO = ''
        self.Event_Identifier = ''
        self.Export_File_Name = ''
        self.Export_Path = ''
        self.File_MimeType = ''
        self.File_Name_Modified = ''
        self.File_Plan_Category_Number = ''
        self.First_Name = ''
        self.GTArtifact_Code = ''
        self.GTBatch = ''
        self.GTDuplicate = ''
        self.GTGreyscale = ''
        self.GTIndex = ''
        self.GTLegibility = ''
        self.GTPages = ''
        self.GTSection_Code = ''
        self.GTZone_Code = ''
        self.GTZone_Section_Artifact_Code = ''
        self.GTZone_Section_Code = ''
        self.id = ''
        self.Inventory_Class = ''
        self.Inventory_CountryName = ''
        self.Investigator_Name = ''
        self.IQV_XML_Filename = ''
        self.Issue = ''
        self.IssueDescription = ''
        self.Language_Abbreviation = ''
        self.Language_Abbreviation_Index = -1
        self.Language_ID_Index = -1
        self.Language_Identifier = ''
        self.Last_Name = ''
        self.LastNameFirstName_FromNamingConvention = ''
        self.LastNameFirstName_Index = -1
        self.LocalSubdirectory = ''
        self.Mandatory_Retention = ''
        self.Modify_Date = ''
        self.Name = ''
        self.NoisyPageIndex = ''
        self.Object_ID = ''
        self.Organization_ID = ''
        self.OrganizationID_Index = -1
        self.Original_Inventory_Filename = ''
        self.Original_Path = ''
        self.OriginalSourceDataDirectory = ''
        self.OriginalSourceDataZipFilename = ''
        self.PagePathFilenamePDF = ''
        self.PageSequenceNumber = ''
        self.Paper_Received_Date = ''
        self.Phase = ''
        self.Project_Code = ''
        self.Protocol_Number = ''
        self.ref_model_subtype_code = ''
        self.Report_Type = ''
        self.Report_Version = ''
        self.Section = ''
        self.Sequence_Number = ''
        self.Sequence_Number_Index = -1
        self.Site_Name = ''
        self.Source_System = ''
        self.Source_System_Version = ''
        self.Study_Site_ID = ''
        self.Therapeutic_Area = ''
        self.TMF = ''
        self.Type = ''
        self.Type_Value = ''
        self.Visit_Document_ID = ''
        self.Visit_Type = ''
        self.VisitDocID_Index = -1
        self.VisitType_Index = -1
        self.XProperties = []
        self.Zone = ''
        self.id = str(uuid.uuid1())


class IQVPageROI(object):
    """
    matches <a href="#IQVPageROI">IQVPageROI</a>
    CREATE TABLE public.DocumentParagraphs(
    ) INHERITS(public.iqvpageroi_db);
    """

    Attachments = []
    """
    External ROI strongly linked to this ROI
    Example usage: Table Footnotes as Attachments, where this is a table instance
    """

    bIsCheckbox = bool
    """
    Mark to true if this represents a checkbox on a form
    """

    bIsChecked = bool
    """
    Mark to true if this represents a checkbox and IS CHECKED ON on a form
    """

    bIsImage = bool
    """
    Image information is stored in QPageROI type
    """

    bIsSharedString = bool
    """
    Excel cell value data type
    """

    bNoTranslate = bool
    """
    Default is FALSE: i.e., default is YES TRANSLATE!;
    translate attribute (yes / no) is supported in
    file, group, unit, mrk, sm levels
    """

    bOutputImageCreated = bool
    """
    Use to flag when the output image has been created.
    Default = false
    If the digitizer-DLA creates the image, this flag is set to true.
    If the digitizer-DLA does not create the image, this flag remains false (default).
    When the OCR is triggered on this IQVPageROI, the OCR checks this flag.
    If this flag is true, the OCR will use <a href="#IQVPageROI.OutputImageFilename_FinalImageProcessingOutput">IQVPageROI.OutputImageFilename_FinalImageProcessingOutput</a>
    or <a href="#IQVPageROI.OutputImageFilename">IQVPageROI.OutputImageFilename</a> as input to OCR.
    When this flag is false, the OCR will use <a href="#IQVPageROI.rectangleGlobalLocationOnPage">IQVPageROI.rectangleGlobalLocationOnPage</a> and the
    page image to create the image as input to OCR.
    """

    bScannedOCR = bool
    """
    False if PDF reader, True if use OCR. To see
    which OCR language engine was used, check <a href="#IQVPageROI.scannedOCRCode">IQVPageROI.scannedOCRCode</a>
    """

    BulletIndentationLevel = int
    """
    Default is -1, not set
    """

    BulletTypeVal = int
    """
    Default is -1, not set
    """

    CheckboxFill = float
    """
    Proportion of pixels that are black/foreground, to help determine
    if this is CHECKED ON or NOT, from 0 to 1; e.g., 0.5=50% of pixels are foreground
    """

    ChildBoxes = []
    """
    Recursive ROI within ROI;
    Example usage: Image with boxes processed as separate ROI for each box,
    and image itself is an ROI
    """

    ChildBoxesDeconstructedOCR = []
    """
    child boxes of document, made up of OCR segments
    """

    childListIndexes = []
    """
    For a hierarchical/tree structure, enable
    data structure with children
    """

    contentTypeVal = int
    """
    For text-handling information, such as whether to
     translate this text, etc. References are handled here.
    DEFAULT=0,
    REFERENCES_BIBIOGRAPHY_SECTION=1
    NOT SET = -1
    """

    copyListIndexes = []
    """
    For a hierarchical/tree structure, enable
    data structure with children
    """

    doc_id = str
    """
    Element index
    Which document is this element in?
    Top-level id for <a href="#IQVDocument">IQVDocument</a>
    """

    DocumentRelId = str
    """
    Relationship ID of the image in the Word document;
    Add the image first to the document; use the RelId to reference it
    and position it
    """

    DocumentSequenceIndex = int
    """
    Global sequence index for both <a href="#IQVDocument.DocumentParagraphs">IQVDocument.DocumentParagraphs</a>
     and <a href="#IQVDocument.DocumentTables">IQVDocument.DocumentTables</a>

    Zero-based sequential order index of document part,
    which could be a table or a paragraph.
     This allows tables and paragraphs to be interlaced together
    and in sequential order

    Used in both
    <see cref="P:IQVFileManagerDLL.IQVDigDocumentTable.DocumentSequenceIndex" />
    and
     <see cref="P:IQVFileManagerDLL.IQVDigDocumentParagraph.DocumentSequenceIndex" />
    """

    ExternalLinks = []
    """
    External link, such as to a section in this document
    Example usage: assessment has links to section in document
    """

    FeedbackItems = []
    """
    Feedback from users
    """

    fontInfo = FontInfo
    """
    If not null, then apply to all text in this IQVPageROI.
    See individual <a href="#IQVSubText">IQVSubText</a> for within-segment font formatting
    """

    FooterSequence = int
    """
    sequence of footer element, zero-based
    """

    group_type = str
    """
    Element index
    Which item is this element a member of? (name of member = group_type)
    For example, for <a href="#IQVPageROI.Properties">IQVPageROI.Properties</a>, group_type = "Properties"
    Possible parents include but are not limited to
    <a href="#IQVDocument">IQVDocument</a><a href="#IQVPageROI">IQVPageROI</a><a href="#IQVDocumentLink">IQVDocumentLink</a>
    SQL code example 1 for usage of index
    <code>
    WHERE parent_id=parent_id AND group_type=group_type
    </code>
    """

    GT_ImageFilename = str
    """
    for testing if have ground truth image available
    """

    GT_ScoreMatch = float
    """
    for testing
    """

    GT_TextMatch = str
    """
    For a actual/known/validated output to measure
     against the (predicted output) text
    """

    hAlignmentVal = int
    """
    Value derived from <a href="#IQVPageROI.hAlignment">IQVPageROI.hAlignment</a>
     NOT SET = -1
    """

    HeaderSequence = int
    """
    sequence of header element, zero-based
    """

    hierarchy = str
    """
    image,table,paragraph,item,header,footer,roi
    """

    HorizontalResolution = float
    """
    Resolution of image
    """

    htmlTagType = str
    """
    span, p, div, etc.
    """

    Hue = int
    """
    hue value for primary color of ROI text
    """

    id = str
    """
    Gloablly unique id. Use in conjunction with
    <seealso cref="M:IQVFileManagerDLL.IQVPageROI.GetFullText_WithFormattingPreserved" /> in order to get the
     baseline key-value pair of id/text that can be
     passed through systems such as translation
    """

    ImageFormatVal = str
    """
    Used to set <see cref="!:ImageFormat" />
    Bmp
    Emf
    Exif
    Gif
    Icon
    Jpeg
    MemoryBmp
    Png
    Tiff
    Wmf
    """

    ImageIndex = int
    """
    In overall document, which image did this roi come from???
    """

    imagePaddingPixels = float
    """
    Added as a border around the ROI before OCR;
    must be used in calculation to restore
    """

    imageScaling = float
    """
    Scale up ROI by this factor (horizontal and vertical)
    before OCR; must be used in calculation to restore
    """

    iqv_standard_term = str
    """
    Element index
    If this element is a link or header, what is the standard term?
    There is 0 or 1 iqv_standard_term for each element
    """

    IQVAttributeCandidates = []
    """
    All candidates found in this page, relevant to the
     digitizer pre-processing and
    attribute extraction tasks,
    such as script_detection, orientation_detection

    Sample key (value)
    document_classification (expected document-level only)
    document_date (expected document-level only)
    IndividualName (expected document-level only)
    language (append Feature with num_characters)
    script_detection (name of script denoting 1 or more languages)
    orientation_detection (degrees)
    scan_type (# images and amount of text)
    """

    IQVSubTextList = []
    """
    Used to set within-segment font formatting, refer for deconstruction from Word,
    generation of XLIFF, read of XLIFF, and reconstruction of Word.
    NOTE: Will NOT necessarily match up IQVSubTextList and IQVSubTextListTranslated,
    as real translation may change order of words (sequence) and
     count of IQVSubText
    """

    IQVSubTextListTranslated = []
    """
    Used to set within-segment font formatting, refer for deconstruction from Word,
    generation of XLIFF, read of XLIFF, and reconstruction of Word.
    NOTE: Will NOT necessarily match up IQVSubTextList and IQVSubTextListTranslated,
    as real translation may change order of words (sequence) and
     count of IQVSubText
    """

    IsCopyOfRoiId = str
    """
    If copy of another ROI, set the IsCopyOf to the ID of that ROI
    """

    IsTableCell = bool
    """
    Mark to true if this is part of a table structure
    """

    lineBoundaries = LineBoundaries
    """
    List of lines that make up the bounding box of this ROI; this refers to visible foreground lines;
    for the bounding box of the ROI, <a href="#IQVPageROI.rectangle">IQVPageROI.rectangle</a>
    """

    lineBoundariesParent = []
    """
    List of lines that make up the bounding box of this ROI's parent
    """

    link_id = str
    """
    Element index
    Which [link <a href="#IQVDocumentLink">IQVDocumentLink</a>] section is this element in?
    The id for <a href="#IQVDocumentLink.LinkType">IQVDocumentLink.LinkType</a> == "toc"
    and <a href="#IQVDocumentLink.LinkLevel">IQVDocumentLink.LinkLevel</a> == 1
    """

    link_id_level2 = str
    """
    Element index
    Which [link <a href="#IQVDocumentLink">IQVDocumentLink</a>] section is this element in?
    The id for <a href="#IQVDocumentLink.LinkType">IQVDocumentLink.LinkType</a> == "toc"
    and <a href="#IQVDocumentLink.LinkLevel">IQVDocumentLink.LinkLevel</a> == 2
    """

    link_id_level3 = str
    """
    Element index
    Which [link <a href="#IQVDocumentLink">IQVDocumentLink</a>] section is this element in?
    The id for <a href="#IQVDocumentLink.LinkType">IQVDocumentLink.LinkType</a> == "toc"
    and <a href="#IQVDocumentLink.LinkLevel">IQVDocumentLink.LinkLevel</a> == 3
    """

    link_id_level4 = str
    """
    Element index
    Which [link <a href="#IQVDocumentLink">IQVDocumentLink</a>] section is this element in?
    The id for <a href="#IQVDocumentLink.LinkType">IQVDocumentLink.LinkType</a> == "toc"
    and <a href="#IQVDocumentLink.LinkLevel">IQVDocumentLink.LinkLevel</a> == 4
    """

    link_id_level5 = str
    """
    Element index
    Which [link <a href="#IQVDocumentLink">IQVDocumentLink</a>] section is this element in?
    The id for <a href="#IQVDocumentLink.LinkType">IQVDocumentLink.LinkType</a> == "toc"
    and <a href="#IQVDocumentLink.LinkLevel">IQVDocumentLink.LinkLevel</a> == 5
    """

    link_id_level6 = str
    """
    Element index
    Which [link <a href="#IQVDocumentLink">IQVDocumentLink</a>] section is this element in?
    The id for <a href="#IQVDocumentLink.LinkType">IQVDocumentLink.LinkType</a> == "toc"
    and <a href="#IQVDocumentLink.LinkLevel">IQVDocumentLink.LinkLevel</a> == 6
    """

    link_id_subsection1 = str
    """
    Element index
    Which [link <a href="#IQVDocumentLink">IQVDocumentLink</a>] section is this element in?
    The id for <a href="#IQVDocumentLink.LinkType">IQVDocumentLink.LinkType</a> == "subsection1"
    """

    link_id_subsection2 = str
    """
    Element index
    Which [link <a href="#IQVDocumentLink">IQVDocumentLink</a>] section is this element in?
    The id for <a href="#IQVDocumentLink.LinkType">IQVDocumentLink.LinkType</a> == "subsection2"
    """

    link_id_subsection3 = str
    """
    Element index
    Which [link <a href="#IQVDocumentLink">IQVDocumentLink</a>] section is this element in?
    The id for <a href="#IQVDocumentLink.LinkType">IQVDocumentLink.LinkType</a> == "subsection3"
    """

    m_PARENT_ROI_TYPEVal = int
    """
    derived from <a href="#IQVPageROI.m_PARENT_ROI_TYPE">IQVPageROI.m_PARENT_ROI_TYPE</a>;
    This should be used to help determine the template
     for this document, based on types of ROI
    NOT SET = -1
    """

    m_ROI_TYPEVal = int
    """
    derived from <a href="#IQVPageROI.m_ROI_TYPE">IQVPageROI.m_ROI_TYPE</a>;
    This should be used to help determine the template
     for this document, based on types of ROI
    ROI type of current ROI
    DEFAULT (not set) = -1,
    BOX_AREA_FULL_PAGE_DEFAULT = 0,
    BOX_AREA_LEFT_MARGIN = 1,
    BOX_AREA_RIGHT_MARGIN = 2,
    BOX_AREA_TOP_MARGIN = 3,
    BOX_AREA_BOTTOM_MARGIN = 4,
    BOX_AREA_CENTER_THIRD = 5,
    BOX_AREA_CENTER_1 = 6,
    BOX_AREA_LEFT_TOP_1 = 7,
    BOX_AREA_TOP_1 = 8,
    BOX_AREA_RIGHT_TOP_1 = 9,
    BOX_AREA_RIGHT_1 = 10,
    BOX_AREA_RIGHT_BOTTOM_1 = 11,
    BOX_AREA_BOTTOM_1 = 12,
    BOX_AREA_LEFT_BOTTOM_1 = 13,
    BOX_AREA_LEFT_1 = 14,
    BOX_AREA_CENTER_NEGATIVE_MARGINS = 15,
    category='figure'
    figure; main body of image or figure;
    use <see cref="!:IMAGE_LOGO" /> instead when appropriate
    IMAGE_DEFAULT = 100,
    IMAGE_SHAPE = 101,
    IMAGE_SHAPE_PARAGRAPH_TEXT = 102,
    IMAGE_HEADER = 103,
    IMAGE_FOOTER = 104,
    Removed from scanned image;
    handled as regular image
    IMAGE_BLOB = 105,
    category='logo'
    reserved for company logo, usually in header,
    use this rather than <see cref="!:IMAGE_DEFAULT" /> when
    appropriate
    IMAGE_LOGO = 106,
    category='stamp'
    reserved for stamp on page
    use this rather than <see cref="!:IMAGE_DEFAULT" /> when
    appropriate
    IMAGE_STAMP = 107,
    category='page_header'
    entire header of a page
    HEADER_DEFAULT = 200,
    category='page_header_item'
    any item that is a part of the page header
     (except logo, which should be marked as a logo) <see cref="!:IMAGE_LOGO" />
    (except page number)
    HEADER_w_p = 201,
    HEADER_w_r = 202,
    HEADER_w_t = 203,
    category='title'
    article title, standalone (sub) section title, standalone figure and table label
    TITLE_DEFAULT = 204,
    category='page_footer'
    the entire footer of a page
    FOOTER_DEFAULT = 300,
    category='page_footer_item'
    any item that is a part of the page footer
     (except logo, which should be marked as a logo) <see cref="!:IMAGE_LOGO" />
    (except page number)
    FOOTER_w_p = 301,
    FOOTER_w_r = 302,
    FOOTER_w_t = 303,
    category='text'
    Correlates to pyMuPDF block&gt;line&gt;span.
    paragraph is the block
    PARAGRAPH_DEFAULT = 400,
    PARAGRAPH_w_p = 401,
    PARAGRAPH_w_r = 402,
    PARAGRAPH_w_t = 403,
    A part of the Table of Contents, with hyperlinks.
    Will not be deconstructed at run level but
    rather text level.
    PARAGRAPH_TOC_ELEMENT = 404,
    PARAGRAPH_BULLETED_TEXT = 405,
    Title text, etc.
    PARAGRAPH_CENTERED_TEXT = 406,
    PARAGRAPH_NONSTANDARD_DEFAULT = 407,
    category='signature_block'
    full signature block, including both machine text and handwritten text
    <see cref="!:PARAGRAPH_SIGNATURE_BLOCK" /> and
    <see cref="!:PARAGRAPH_SIGNATURE_ONLY" />
    PARAGRAPH_SIGNATURE_BLOCK = 408,
    category='text_line'
    Correlates to pyMuPDF block&gt;line
    PARAGRAPH_LINE = 409,
    Correlates to pyMuPDF block&gt;line&gt;span
    PARAGRAPH_SPAN = 410,
    PARAGRAPH_SIGNATURE_IMAGE_ONLY = 411,
    category='list_item'
    single item in list
    PARAGRAPH_LIST_ITEM = 412,
    category='handwritten'
    handwritten text anywhere in a document
     (except date—use handwritten_date <see cref="!:HANDWRITTEN_DATE" /> or signature_date <see cref="!:DOCUMENT_SIGNATURE_DATE" />)
     (except signature—use signature_only <see cref="!:DOCUMENT_SIGNATURE_ONLY" />)
    PARAGRAPH_HANDWRITTEN_TEXT = 413,
    category='checkbox_only'
    this is single checkbox only without any corresponding text
    PARAGRAPH_CHECKBOX = 414,
    category='list'
    list of elements, same as a one-column table
    PARAGRAPH_LIST_OF_ELEMENTS = 415,
    category='signature_only'
    only the handwritten name part of the signature block
    <see cref="!:PARAGRAPH_SIGNATURE_BLOCK" /> and
    <see cref="!:PARAGRAPH_SIGNATURE_DATE" />
    DOCUMENT_SIGNATURE_ONLY = 450,
    category='signature_date'
    reserved for date that is part of the signature element, may be handwritten
    <see cref="!:PARAGRAPH_SIGNATURE_BLOCK" /> and
    <see cref="!:PARAGRAPH_SIGNATURE_ONLY" />
    DOCUMENT_SIGNATURE_DATE = 451,
    category='handwritten_date'
    use signature_date <see cref="!:DOCUMENT_SIGNATURE_DATE" /> if part of the signature,
     otherwise use handwritten_date
    HANDWRITTEN_DATE = 460,
    category='checkbox_with_text'
    this is single checkbox WITH corresponding text
    PARAGRAPH_CHECKBOX_WITH_TEXT = 470,
    category='table'
    table
    TABLE = 500,
    category='table_cell'
    table cell--single cell in a table
    TABLE_tc = 501,
    table row
     TABLE_row = 502,
    category='table_header_column'
    column headers—this would indicate top row of a table if applicable
    TABLE_HEADER_COL = 503,
    category='table_header_row'
    row headers—this would indicate the left column of a table if applicable
    TABLE_HEADER_ROW = 504,
    MESSAGE_FROM = 600,
    MESSAGE_RECIPIENT = 601,
    MESSAGE_SUBJECT = 602,
    MESSAGE_BODY = 603,
    MESSAGE_DATE = 604,
    MESSAGE_ATTACHMENT = 605,
    MESSAGE_RECIPIENT_CC = 606,
    MESSAGE_RECIPIENT_BCC = 607,
    LETTER_HEADER_LEFT_COLUMN = 700,
    LETTER_HEADER_RIGHT_COLUMN = 701,
    LETTER_HEADER_CENTER_COLUMN = 702,
    LETTER_HEADER_STAMP = 703,
    category='page_number'
    the page number, may be
     part of header or footer
    PAGE_NUMBER = 800,
    HYPERLINK = 900
    In case of a processed pdf that is not well-behaved, a
     simulated full-page scan is created
    SIMULATED_SCAN = 1000
    """

    m_WORD_LAYOUTVal = int
    """
    derived from <a href="#IQVPageROI.m_WORD_LAYOUT">IQVPageROI.m_WORD_LAYOUT</a>
     NOT SET = -1
    """

    NLP_Attributes = []
    """
    This ROI contains the listed attributes
     <a href="#NLP_Attribute">NLP_Attribute</a>
    """

    NLP_Entities = []
    """
    This ROI contains the listed entities
     <a href="#NLP_Entity">NLP_Entity</a>
    """

    OriginalROIHeightInches = float
    """
    Original resolution of image to match the number of pixels,
    calculaged using DPI and number of pixels. Set because image
    is manipulated after the fact
    """

    OriginalROIWidthInches = float
    """
    Original resolution of image to match the number of pixels,
    calculaged using DPI and number of pixels. Set because image
    is manipulated after the fact
    """

    OriginalSubTexts = []
    """
    sub texts before segmentation
    """

    OutputImageFilename = str
    """
    Save image as this filename
    """

    OutputImageFilename_Cleaned = str
    """
    Binarized, cleaned copy
    """

    OutputImageFilename_FinalImageProcessingOutput = str
    """
    Image Processing completed, ready for OCR pipeline
    """

    OutputImageFilename_FinalImageProcessingOutputToDropBox = str
    """
    Image Processing completed, ready for OCR pipeline
    """

    OutputImageFilename_OriginalSegment = str
    """
    Only for demo purposes, must be cut and saved after the fact
    """

    OutputImageFilename_RotationCorrection = str
    """
    Rotated ready for Image Processing Pipeline
    """

    OutputImageFilename_RotationCorrectionToDropBox = str
    """
    Rotated ready for Image Processing Pipeline
    """

    OutputImageFilename_Segments = str
    """
    Segmented ready for OCR
    """

    OutputImageFilename_SegmentsToDropBox = str
    """
    Segmented ready for OCR
    """

    OutputImageFilenameT = str
    """
    Image output translated
    """

    OutputImageFilenameTDropBox = str
    """
    Image output translated--extra copy
    """

    PageID = str
    """
    GUID of container page in PDF
    """

    PageSequenceIndex = int
    """
    Ones-based for which page this item falls on in the PDF document;
    If this is -1, then no page sequence is available (for instance,
    when Word is used to get the ROI rather than pdf reader)
    """

    parent_id = str
    """
    Element index
    Which item is this element a member of?
    For example, for <a href="#IQVPageROI.Properties">IQVPageROI.Properties</a>, parent_id = <a href="#IQVPageROI.id">IQVPageROI.id</a>
    Possible parents include but are not limited to
    <a href="#IQVDocument">IQVDocument</a><a href="#IQVPageROI">IQVPageROI</a><a href="#IQVDocumentLink">IQVDocumentLink</a>
    SQL code example 1 for usage of index
    <code>
    WHERE parent_id=parent_id AND group_type=group_type
    </code>
    SQL code example 2 for usage of index
    <code>
    WHERE parent_id=parent_id
    </code>
    """

    parentRectangle = Rectangle
    """
    The rectangle after it has been rotated to the proper orientation, clean
    boundary for the ROI, in integer units; expected to be in pixels,
    relevant to the top-level parent ROI(page)
    """

    parentrectangle_height = int
    """
    The rectangle after it has been rotated to the proper orientation, clean
    boundary for the ROI, in integer units; expected to be in pixels,
    relevant to the top-level parent ROI(page)
    """

    parentrectangle_width = int
    """
    The rectangle after it has been rotated to the proper orientation, clean
    boundary for the ROI, in integer units; expected to be in pixels,
    relevant to the top-level parent ROI(page)
    """

    parentrectangle_x = int
    """
    The rectangle after it has been rotated to the proper orientation, clean
    boundary for the ROI, in integer units; expected to be in pixels,
    relevant to the top-level parent ROI(page)
    """

    parentrectangle_y = int
    """
    The rectangle after it has been rotated to the proper orientation, clean
    boundary for the ROI, in integer units; expected to be in pixels,
    relevant to the top-level parent ROI(page)
    """

    postSubTexts = []
    """
    Non-printed <a href="#IQVSubText">IQVSubText</a> after end of text
    """

    postTags = []
    """
    Non-printed characters after end of text
    """

    postTexts = []
    """
    Non-printed characters after end of text
    """

    preSubTexts = []
    """
    Non-printed <a href="#IQVSubText">IQVSubText</a> before beginning of text
    """

    preTags = []
    """
    Non-printed characters before beginning of text
    """

    preTexts = []
    """
    Non-printed characters before beginning of text
    """

    ProcessingResults = []
    """
    List of various processing performed on this ROI. The ROI
    may be a full page or a section of a page.
    Use <a href="#IQVKeyValueSet.key">IQVKeyValueSet.key</a> to denote 'digitizer',
    'ocr', 'image_cleaning', etc.
    Use <a href="#IQVKeyValueSet.confidence">IQVKeyValueSet.confidence</a> to indicate results
    of the process, on a scale from 0.0 (low) to 1.0 (high)
    Use <a href="#IQVKeyValueSet.value">IQVKeyValueSet.value</a> to indicate additional
    information about the process
    """

    Properties = []
    """
    List of additional properties as <a href="#IQVKeyValueSet">IQVKeyValueSet</a><a href="#IQVKeyValueSet.key">IQVKeyValueSet.key</a> See standardized key listing
    <a href="#IQVKeyValueSet.value">IQVKeyValueSet.value</a> See standardized key listing
    <a href="#IQVKeyValueSet.confidence">IQVKeyValueSet.confidence</a> is 0 to 1 confidence value
    gridspan (for table cell)
    """

    QCUpdates = []
    """
    QC Updates
    """

    QWords = []
    """
    List of <a href="#IQVWord">IQVWord</a> from OCR, ocrx_word
    data structure from Tesseract
    """

    rectangle = Rectangle
    """
    The rectangle after it has been rotated to the proper orientation, clean
    boundary for the ROI, in integer units; expected to be in pixels,
    relevant to the top-level parent ROI(page)
    """

    rectangle_height = int
    """
    The rectangle after it has been rotated to the proper orientation, clean
    boundary for the ROI, in integer units; expected to be in pixels,
    relevant to the top-level parent ROI(page)
    """

    rectangle_width = int
    """
    The rectangle after it has been rotated to the proper orientation, clean
    boundary for the ROI, in integer units; expected to be in pixels,
    relevant to the top-level parent ROI(page)
    """

    rectangle_x = int
    """
    The rectangle after it has been rotated to the proper orientation, clean
    boundary for the ROI, in integer units; expected to be in pixels,
    relevant to the top-level parent ROI(page)
    """

    rectangle_y = int
    """
    The rectangle after it has been rotated to the proper orientation, clean
    boundary for the ROI, in integer units; expected to be in pixels,
    relevant to the top-level parent ROI(page)
    """

    rectangleGlobalLocationOnPage = Rectangle
    """
    In pixels, relevant to the highest-level ROI (page)
    """

    rectangleGlobalLocationOnPage_height = int
    """
    In pixels, relevant to the highest-level ROI (page)
    """

    rectangleGlobalLocationOnPage_width = int
    """
    In pixels, relevant to the highest-level ROI (page)
    """

    rectangleGlobalLocationOnPage_x = int
    """
    In pixels, relevant to the highest-level ROI (page)
    """

    rectangleGlobalLocationOnPage_y = int
    """
    In pixels, relevant to the highest-level ROI (page)
    """

    Rotation_MajorAxis = int
    """
    In degrees, {0,90,180,270} to
     show the orientation of the document. This is not the 'corrected'
    orientation.Rather, if the document is 'sideways' then it must be
    rotated 90/270 in order to read it properly.Zero (0) is default.
    """

    RotationChecks = []
    """
    List of results of each rotation check, used to find
     optimal rotation correction for the image or ROI
    """

    RotationCorrectionDegrees = float
    """
    Corrected the image by this angle
    during processing (in degrees)
    """

    scannedOCRCode = str
    """
    3-digit tesseract code used to transform this ROI. This
    aligns with <a href="#LanguageCode.tesseractCode">LanguageCode.tesseractCode</a>, such as
    "eng" for English
    """

    Score = float
    """
    Local copy--what is overall score for this match?
    """

    SegmentationBreakIndexes = []
    """
    Breaks for segmentation
    """

    SegmentationBreakStrings = []
    """
    Breaks for segmentation
    """

    SegmentationMethodVal = int
    """
    derived from <a href="#IQVPageROI.SegmentationMethod">IQVPageROI.SegmentationMethod</a>
    NOT SET = -1
    """

    SegmentationType = int
    """
    0 = no segmentation, 1=baseline segmentation,
     2 = language-specific segmentation (new default, ru, po, etc. as available),
    the
    segmentation done on the text in order to create XLIFF
    for translation
    """

    SequenceID = int
    """
    Within container, for similar items. For example,
    each footer of a set of footers within a document
    will be sequenced using this variable
    """

    SlideIndex = int
    """
    For PowerPoint, zero-based sequence index of slide
     in which this ROI is contained
    """

    SlideRelationshipId = str
    """
    For PowerPoint, relId of slide in which this ROI is contained
    """

    strText = str
    """
    Intermediate
    """

    strTexts = []
    """
    Main printed text
    """

    strTextsOCRInitial = []
    """
    In early pre-processing stage, initial OCR to
    get text for language detection module. This is
     after script detection.
    """

    strTextsOCRUpdated = []
    """
    After initial OCR, apply NLP/AI methodologies and
     update the text here
    """

    strTextsTranslated = []
    """
    Main printed text in target language, as simple string
    """

    strTextTranslated = str
    """
    Intermediate
    """

    tableCell_colIndex = int
    """
    column index if this is a OCR table cell, zero-based
    """

    tableCell_pageIndex = int
    """
    index for multi-page table, zero-based
    """

    tableCell_rowIndex = int
    """
    row index if this is a table cell, zero-based
    """

    tableCell_SharedStringIndex = int
    """
    Excel type index for string, zero-based
    """

    tableCell_SheetCellReference = str
    """
    For OpenXml/Excel Spreadsheet, to identify the cell, as in "A1"
    """

    tableCell_SheetColIndex = int
    """
    Excel type col index, ones-based
    """

    tableCell_SheetName = str
    """
    Excel type sheet name if in Excel table
    """

    tableCell_SheetRowIndex = int
    """
    Excel type row index, ones-based
    """

    tableColumn = IQVTableColumn
    """
    If this is a table cell, the column information for this
    table cell
    """

    TableColumns = []
    """
    Feedback from users
    """

    textMatch = TextMatch
    """
    Match for the source text in OCR/NLP
    """

    textTypeVal = int
    """
    Note: NOT SET = -1
    DEFAULT=0,
    COMMENT=1,
    CONSTANT=2,
    NON_TEXT=3,
    NEWLINE=4,
    TEXTBOX = 5,
    BULLET=6,
    FOOTER=7,
    HEADER=8,
    IMAGE=9,
    """

    TranslatedTextNoSegmentation = str
    """
    If the ID is missing, then the segmentation may not be sync'd. To
    do a simple find/replace using any input, without ID, then use the
    TranslatedTextNoSegmentation instead of the segments found in the <a href="#IQVPageROI.ChildBoxes">IQVPageROI.ChildBoxes</a> .
    Must denote the SegmentationMethod to NONE.
    """

    TranslationMatch = float
    """
    Score for translation
    """

    TranslationMethod1 = str
    """
    MyMemory, google, etc.
    """

    UncorrectedImageFilename = str
    """
    used to track the original source copy of this ROI
    """

    Value = str
    """
    Local copy--what is value from report that maps to this field?
    """

    ValuesI = []
    """
    list of integer values for the ROI
    """

    VerticalResolution = float
    """
    Resolution of image
    """

    def GetLocalText(self):
        """
        Get text at the self-level only
        """
        texts = []
        if len(self.strTexts) != 0:
            for txt in self.strTexts:
                if txt != 'None':
                    texts.append(txt)

        for iqv_word in self.QWords:
            if len(iqv_word.Text) > 0:
                texts.append(iqv_word.Text)

        return ' '.join(texts)

    def GetFullText(self):
        """
        Get text at the self-level only and/or all children
        """
        str1 = ""
        cnt = 0
        #
        # childboxes only
        #
        if len(self.ChildBoxes) > 0:
            for cbox in self.ChildBoxes:
                strChildBox = cbox.GetFullText()
                if len(strChildBox) > 0:
                    if cnt > 0:
                        str1 = str1 + " "
                    str1 = str1 + strChildBox
                    cnt = cnt + 1
            return str1

        #
        # Q Word method (OCR)
        #
        for iqv_word in self.QWords:
            str1 = str1 + iqv_word.Text + " ";

        #
        # strTexts
        #
        if len(self.QWords) == 0:
            if len(self.IQVSubTextList) == 0:
                for s in self.strTexts:
                    if s != 'None':
                        str1 = str1 + s + " ";
            else:
                for st in self.IQVSubTextList:
                    str1 = str1 + st.strText + " ";

        str1 = str1.strip()

        if self.m_ROI_TYPEVal == 409:  # line
            str1 = str1 + "\n"
        return str1

    def GetLocalTextTranslated(self):
        """
        Get text at the self-level only
        """
        texts = []
        if len(self.strTextsTranslated) != 0:
            texts.extend(self.strTextsTranslated)

        return ' '.join(texts)

    def GetFullTextTranslated(self):
        """
        Get text at the self-level only and/or all children
        """
        str1 = ""
        cnt = 0
        strLocal = self.GetLocalTextTranslated()
        if len(strLocal) > 0:
            str1 = strLocal
            cnt = cnt + 1
        for cbox in self.ChildBoxes:
            #
            # If digitized (bScannedOCR == False), include digitized AND scanned
            # If OCR, only include OCR
            # If OCR certain language, only include same language
            #
            if self.bScannedOCR == False or (cbox.bScannedOCR == self.bScannedOCR):  # and (
                # cbox.scannedOCRCode == self.scannedOCRCode or (
                # cbox.scannedOCRCode == 'eng' and self.scannedOCRCode == '') or (
                # cbox.scannedOCRCode == '' and self.scannedOCRCode == 'eng'))):
                strChildBox = cbox.GetFullTextTranslated()
                if cnt > 0:
                    str1 = str1 + " "
                str1 = str1 + strChildBox
                cnt = cnt + 1
        if self.m_ROI_TYPEVal == 409:  # line
            str1 = str1 + "\n"
        return str1

    def __init__(self):
        self.Attachments = []
        self.bIsCheckbox = False
        self.bIsChecked = False
        self.bIsImage = False
        self.bIsSharedString = False
        self.bNoTranslate = False
        self.bOutputImageCreated = False
        self.bScannedOCR = False
        self.BulletIndentationLevel = -1
        self.BulletTypeVal = -1
        self.CheckboxFill = 0.0
        self.ChildBoxes = []
        self.ChildBoxesDeconstructedOCR = []
        self.childListIndexes = []
        self.contentType = []
        self.contentTypeVal = -1
        self.copyListIndexes = []
        self.doc_id = ''
        self.DocumentRelId = ''
        self.DocumentSequenceIndex = -1
        self.ExternalLinks = []
        self.FeedbackItems = []
        self.fontInfo = FontInfo()
        self.FooterSequence = -1
        self.group_type = ''
        self.GT_ImageFilename = ''
        self.GT_ScoreMatch = 0.0
        self.GT_TextMatch = ''
        self.hAlignment = []
        self.hAlignmentVal = -1
        self.HeaderSequence = -1
        self.hierarchy = ''
        self.HorizontalResolution = 0.0
        self.htmlTagType = ''
        self.Hue = -1
        self.id = ''
        self.ImageFormatVal = ''
        self.ImageIndex = -1
        self.imagePaddingPixels = 0.0
        self.imageScaling = 0.0
        self.iqv_standard_term = ''
        self.IQVAttributeCandidates = []
        self.IQVSubTextList = []
        self.IQVSubTextListTranslated = []
        self.IsCopyOfRoiId = ''
        self.IsTableCell = False
        self.lineBoundaries = LineBoundaries()
        self.lineBoundariesParent = []
        self.link_id = ''
        self.link_id_level2 = ''
        self.link_id_level3 = ''
        self.link_id_level4 = ''
        self.link_id_level5 = ''
        self.link_id_level6 = ''
        self.link_id_subsection1 = ''
        self.link_id_subsection2 = ''
        self.link_id_subsection3 = ''
        self.m_PARENT_ROI_TYPE = []
        self.m_PARENT_ROI_TYPEVal = -1
        self.m_ROI_TYPEVal = -1
        self.m_WORD_LAYOUT = []
        self.m_WORD_LAYOUTVal = -1
        self.NLP_Attributes = []
        self.NLP_Entities = []
        self.OriginalROIHeightInches = 0.0
        self.OriginalROIWidthInches = 0.0
        self.OriginalSubTexts = []
        self.OutputImageFilename = ''
        self.OutputImageFilename_Cleaned = ''
        self.OutputImageFilename_FinalImageProcessingOutput = ''
        self.OutputImageFilename_FinalImageProcessingOutputToDropBox = ''
        self.OutputImageFilename_OriginalSegment = ''
        self.OutputImageFilename_RotationCorrection = ''
        self.OutputImageFilename_RotationCorrectionToDropBox = ''
        self.OutputImageFilename_Segments = ''
        self.OutputImageFilename_SegmentsToDropBox = ''
        self.OutputImageFilenameT = ''
        self.OutputImageFilenameTDropBox = ''
        self.PageID = ''
        self.PageSequenceIndex = -1
        self.parent_id = ''
        self.parentRectangle = Rectangle()
        self.parentrectangle_height = -1
        self.parentrectangle_width = -1
        self.parentrectangle_x = -1
        self.parentrectangle_y = -1
        self.postSubTexts = []
        self.postTags = []
        self.postTexts = []
        self.preSubTexts = []
        self.preTags = []
        self.preTexts = []
        self.ProcessingResults = []
        self.Properties = []
        self.QCUpdates = []
        self.QWords = []
        self.rectangle = Rectangle()
        self.rectangle_height = -1
        self.rectangle_width = -1
        self.rectangle_x = -1
        self.rectangle_y = -1
        self.rectangleGlobalLocationOnPage = Rectangle()
        self.rectangleGlobalLocationOnPage_height = -1
        self.rectangleGlobalLocationOnPage_width = -1
        self.rectangleGlobalLocationOnPage_x = -1
        self.rectangleGlobalLocationOnPage_y = -1
        self.Rotation_MajorAxis = -1
        self.RotationChecks = []
        self.RotationCorrectionDegrees = 0.0
        self.scannedOCRCode = ''
        self.Score = 0.0
        self.SegmentationBreakIndexes = []
        self.SegmentationBreakStrings = []
        self.SegmentationMethod = []
        self.SegmentationMethodVal = -1
        self.SegmentationType = -1
        self.SequenceID = -1
        self.SlideIndex = -1
        self.SlideRelationshipId = ''
        self.strText = ''
        self.strTexts = []
        self.strTextsOCRInitial = []
        self.strTextsOCRUpdated = []
        self.strTextsTranslated = []
        self.strTextTranslated = ''
        self.tableCell_colIndex = -1
        self.tableCell_pageIndex = -1
        self.tableCell_rowIndex = -1
        self.tableCell_SharedStringIndex = -1
        self.tableCell_SheetCellReference = ''
        self.tableCell_SheetColIndex = -1
        self.tableCell_SheetName = ''
        self.tableCell_SheetRowIndex = -1
        self.tableColumn = IQVTableColumn()
        self.TableColumns = []
        self.textMatch = TextMatch()
        self.textType = []
        self.textTypeVal = -1
        self.TranslatedTextNoSegmentation = ''
        self.TranslationMatch = 0.0
        self.TranslationMethod1 = ''
        self.UncorrectedImageFilename = ''
        self.Value = ''
        self.ValuesI = []
        self.VerticalResolution = 0.0
        self.id = str(uuid.uuid1())


class IQVDocument(object):
    """
    Assessment and visit record for an SOA
    """

    alcoac_check_error = []
    """
    List of IQVAttributeCandidate, each IQVAttributeCandidate has the information for an error.

    AttributeKey = 'alcoac_check_error'
    AttributeValue = 'greyscale_error'
    Features = list of IQVKeyValueSet
    Feature 1:
    key = 'alcoac_error_score'
    value = int value 0 (bad) to 100 (good)
    # worse greyscale, closer to zero
    Feature 2:
    key = 'alcoac_error_message'
    value = '3,5' # string
    # string, comma-separated list of int

    key=greyscale_error
    key=legibility_error
    key=clean_image_error
    key=page_skew_error
    key=order_pages_error
    key=blank_pages_error
    key=duplicate_document_error
    key=missing_pages_error
    key=missing_signatures_error
    key=missing_fields_error
    """

    bDeleteAllFilesExceptFinalizerOutputFile = bool
    """
    On successful completion of document processing,
    delete the input source file from
     processing/output directory, if true.
     Do not delete if false.
     Directory for document is listed at
     <a href="#IQVDocument.QDocumentWorkingDirectory">IQVDocument.QDocumentWorkingDirectory</a>
    Parent directory for collection of documents at
    <a href="#Config.OutputDirectory">Config.OutputDirectory</a>
    """

    bDeleteInputSourceFile = bool
    """
    On successful completion of document processing,
    delete the input source file from
     processing/output directory, if true.
     Do not delete if false.
     Directory for document is listed at
     <a href="#IQVDocument.QDocumentWorkingDirectory">IQVDocument.QDocumentWorkingDirectory</a>
    Parent directory for collection of documents at
    <a href="#Config.OutputDirectory">Config.OutputDirectory</a>
    """

    bDeleteWorkingTempDirectoryAfterCompletion = int
    """
    Auto-delete working temp directory <a href="#IQVDocument.QDocumentWorkingTempDirectory">IQVDocument.QDocumentWorkingTempDirectory</a>
    """

    bIsFullDocumentScanned = bool
    """
    Assumed not to be scanned until checked
    """

    bIsStandardForm = bool
    """
    Document is in known format
    """

    bIsVisibleInDocumentDisplay = bool
    """
    For Formatter application, should it be displayed in the desktop or be invisible
    """

    CustomHostName = str
    """
    For display purposes, provide code name for the machine
    responsible for processing this IQVDocument
    """

    dateTimeLastModified = str
    """
    Date last modified by the TMS system
    """

    dateTimeUploaded = str
    """
    Date uploaded to the TMS system
    """

    debugModeVal = int
    """

    """

    displayLabel = str
    """
    Display label for document, generated by user
    """

    doc_id = str
    """
    index to query by document
    """

    DOCANALYSIS_DateID = str
    """
    Classification results for document type--Rank # 1 only
    """

    DOCANALYSIS_DateValue = str
    """
    Classification results for document type--Rank # 1 only
    """

    DOCANALYSIS_DocumentClass = str
    """
    Classification results for document type--Rank # 1 only
    """

    DOCANALYSIS_DocumentClassConfidence = float
    """
    Classification results for document type--Rank # 1 only
    """

    DOCANALYSIS_DocumentClassConfidenceList = []
    """
    Classification results for document type
    """

    DOCANALYSIS_DocumentClassList = []
    """
    Classification results for document type
    """

    DOCANALYSIS_DocumentClassList_Description = []
    """
    Classification results for document type
    """

    DOCANALYSIS_DocumentClassList_DIACode = []
    """
    Classification results for document type
    """

    DOCANALYSIS_DocumentClassRawScoreList = []
    """
    Classification results for document type
    """

    DOCANALYSIS_DocumentMetadata = []
    """
    Classification results for document type--Rank # 1 only
    """

    DocumentCompares = []
    """
    List of compares
    """

    DocumentFooters = []
    """
    Items retrieved from input Word document during deconstruction. Segmentation
    is performed on these items during creation of <a href="#IQVPageROI.ChildBoxes">IQVPageROI.ChildBoxes</a>.
    """

    DocumentFootnotes = []
    """
    Items retrieved from input Word document during deconstruction. Segmentation
    is performed on these items during creation of <a href="#IQVPageROI.ChildBoxes">IQVPageROI.ChildBoxes</a>.
    """

    DocumentGroundTruth = IQVDocumentGroundTruth
    """
    Ground truth for this document, for research and development and testing
    """

    DocumentHeaders = []
    """
    Items retrieved from input Word document during deconstruction. Segmentation
    is performed on these items during creation of <a href="#IQVPageROI.ChildBoxes">IQVPageROI.ChildBoxes</a>.
    """

    DocumentImages = []
    """
    In PDF processing (esp. scans), this is the collection of PDF pages. For example,
     one page will be one element in the DocumentImages list. Each page will be
    represented by a hierarchical <a href="#IQVPageROI">IQVPageROI</a> object.
    Originally, used for items retrieved from input Word document during deconstruction. Segmentation
    is performed on these items during creation of <a href="#IQVPageROI.ChildBoxes">IQVPageROI.ChildBoxes</a>.
    """

    DocumentItems = []
    """
    Items retrieved from input Word document during deconstruction. Segmentation
    is performed on these items during creation of <a href="#IQVPageROI.ChildBoxes">IQVPageROI.ChildBoxes</a>.
    """

    DocumentLinks = []
    """
    List of links within document,
    for TOC, section headers, etc.
    """

    DocumentParagraphs = []
    """
    Items retrieved from input Word document during deconstruction. Segmentation
    is performed on these items during creation of <a href="#IQVPageROI.ChildBoxes">IQVPageROI.ChildBoxes</a>.
    """

    DocumentPartsList = []
    """
    List of <a href="#IQVDocument.DocumentParagraphs">IQVDocument.DocumentParagraphs</a> and <a href="#IQVDocument.DocumentTables">IQVDocument.DocumentTables</a>
    by the <a href="#IQVPageROI.id">IQVPageROI.id</a> of each element, in order to know
    the sequence relationship between the paragraphs and tables
    """

    DocumentTables = []
    """
    Items retrieved from input Word document during deconstruction. Segmentation
    is performed on these items during creation of <a href="#IQVPageROI.ChildBoxes">IQVPageROI.ChildBoxes</a>.
    """

    DocumentTypeVal = int
    """
    This is the document type assigned to the document
    as it is being processed through the workflow. This may be
    assigned and re-assigned as necessary (e.g., DOCX -&gt; PDF)

    DEFAULT = 0,
    WORD_DOC = 1,
    WORD_DOCX = 2,
    PDF_DIGITIZED = 3,
    PDF_SCANNED = 4,
    EXCEL_XLS = 5,
    EXCEL_XLSX = 6,
    TEXT_TXT = 7,
    PDF_SCANNED_TO_DOCX = 8,
    OUTLOOK_MSG = 9,
    IMAGE_TIFF = 10,
    IMAGE_JPEG = 11,
    IMAGE_BMP = 12,
    IMAGE_PNG = 13,
    IMAGE_GIF = 14,
    POWERPOINT_PPTX = 15,
    POWERPOINT_PPT = 16,
    TEXT_CSV = 17,
    WORD_ODT = 18,
    SAS_DATA_XPT = 19,
    SAS_PROGRAM_SAS = 20,
    VISIO_VSD = 21,
    WORD_DOTX = 22,
    ZIP_ZIP = 23,
    ZIP_7Z = 24,
    SAS_DATA_SAS7BDAT = 25
    """

    DocumentTypeValOriginal = int
    """
    This is the original document type assigned to the source document
    on initial triage, and will NOT be changed
    as it is being processed through the workflow.
     DEFAULT = 0,
    WORD_DOC = 1,
    WORD_DOCX = 2,
    PDF_DIGITIZED = 3,
    PDF_SCANNED = 4,
    EXCEL_XLS = 5,
    EXCEL_XLSX = 6,
    TEXT_TXT = 7,
    PDF_SCANNED_TO_DOCX = 8,
    OUTLOOK_MSG = 9,
    IMAGE_TIFF = 10,
    IMAGE_JPEG = 11,
    IMAGE_BMP = 12,
    IMAGE_PNG = 13,
    IMAGE_GIF = 14,
    POWERPOINT_PPTX = 15,
    POWERPOINT_PPT = 16,
    TEXT_CSV = 17,
    WORD_ODT = 18,
    SAS_DATA_XPT = 19,
    SAS_PROGRAM_SAS = 20,
    VISIO_VSD = 21,
    WORD_DOTX = 22,
    ZIP_ZIP = 23,
    ZIP_7Z = 24,
    SAS_DATA_SAS7BDAT = 25
    """

    DropBoxDir = str
    """
    Drop box directory
    """

    DropBoxDirWebUI = str
    """
    Drop box directory for web UI only
    """

    EndPage = int
    """
    Ones-based, used to specify partial document;
    value of -1 means do entire document
    """

    id = str
    """
    global unique identifier for this <a href="#IQVDocument">IQVDocument</a>
    """

    image_count = int
    """
    Number of images that have been detected in the document
    """

    InitialConfig = Config
    """
    Initial config when this document was first generated
    """

    IQVAttributeCandidates = []
    """
    All candidates found in this document, relevant to the attribute extraction task,
    such as document_classification, document_date, name

    Sample key (value)
    document_classification
    document_date
    IndividualName
    language
    script_detection
    orientation_detection
    scan_type (# images and amount of text)
    """

    IQVDocumentFeedbackResultsList = []
    """
    List of all feedback received for this document
    """

    IQVDocumentFilename_SourceXML = str
    """
    Copy of IQV Document data structure after segmenting, ocr, creating xml
    """

    IQVDocumentFilename_TranslatedXML = str
    """
    Copy of IQV Document data structure after translating
    """

    IQVDocumentProcesses = []
    """
    List of Sub-processes
     such as
     triage, digitizer, classifier, extractor, finalizer,
    translator
    """

    iqvForm = IQVForm
    """
    Form data
    """

    IsDocInitialWorkflowCompleted = bool
    """
    Tracking variable to test whether initial workflow has been completed
    """

    link_id = str
    """
    index to query by section (document link <a href="#IQVDocumentLink">IQVDocumentLink</a>)
    """

    LogEntries = []
    """
    List of log entries collected while processing this <a href="#IQVDocument">IQVDocument</a>
    """

    logFilename = str
    """
    Name serialized XML file containing list of log events <a href="#IQVDocument.LogEntries">IQVDocument.LogEntries</a>
    """

    logFilenameDropBox = str
    """
    Name (remote drop box) serialized XML file containing list of log events <a href="#IQVDocument.LogEntries">IQVDocument.LogEntries</a>
    """

    MachineName = str
    """
    Code name for the machine
    responsible for processing this IQVDocument
    """

    NLP_Attributes = []
    """
    document-level listed attributes
     <a href="#NLP_Attribute">NLP_Attribute</a>
    """

    NLP_Entities = []
    """
    document-level listed entities
     <a href="#NLP_Entity">NLP_Entity</a>
    """

    NLP_Relations = []
    """
    Relations between entities found in this document
     <a href="#NLP_Relation">NLP_Relation</a>
    """

    numberingGroups = []
    """
    Numbering groups for handling groups of
     bulletized text
    """

    NumPDFPages = int
    """
    Number of pages if the source is a PDF
    """

    NumSegments = int
    """
    Number of translation segments (in XLIFF)
    """

    originalSourceFilename = str
    """
    For tracking purposes, original source for this <a href="#IQVDocument">IQVDocument</a>
    """

    outputHTMLFilename = str
    """
    Filename for final HTML display generated from this document
    """

    outputHTMLFilename_Cleaned = str
    """
    For HTML Demo purposes
    """

    outputHTMLFilename_OCRDig = str
    """
    For HTML Demo purposes
    """

    outputHTMLFilename_Orig = str
    """
    For HTML Demo purposes
    """

    outputHTMLFilename_Segmented = str
    """
    For HTML Demo purposes
    """

    outputHTMLFilename_XMLSource = str
    """
    For HTML Demo purposes
    """

    outputHTMLFilename_XMLTrans = str
    """
    For HTML Demo purposes
    """

    outputHTMLFilenameToDropBox = str
    """
    Filename for final HTML display generated from this document (in drop box)
    """

    outputHTMLFilenameToDropBox_Cleaned = str
    """
    For HTML Demo purposes
    """

    outputHTMLFilenameToDropBox_OCRDig = str
    """
    For HTML Demo purposes
    """

    outputHTMLFilenameToDropBox_Orig = str
    """
    For HTML Demo purposes
    """

    outputHTMLFilenameToDropBox_Segmented = str
    """
    For HTML Demo purposes
    """

    outputHTMLFilenameToDropBox_XMLSource = str
    """
    For HTML Demo purposes
    """

    outputHTMLFilenameToDropBox_XMLTrans = str
    """
    For HTML Demo purposes
    """

    outputHTMLFilenameTranslated = str
    """
    Final HTML output translated
    """

    outputHTMLFilenameTranslatedToDropBox = str
    """
    Final output as HTML serialized file (remote drop box)
    """

    outputHTMLFilenameWithID = str
    """
    Final HTML output
    """

    outputHTMLSideBySideFilename = str
    """
    Filename for final HTML display generated from this document (side by side)
    """

    outputHTMLSideBySideFilename_OCRDig_to_XMLSource = str
    """
    For HTML Demo purposes
    """

    outputHTMLSideBySideFilename_Orig_to_Cleaned = str
    """
    For HTML Demo purposes
    """

    outputHTMLSideBySideFilename_Orig_to_OCRDig = str
    """
    For HTML Demo purposes
    """

    outputHTMLSideBySideFilename_Segmented_to_OCRDig = str
    """
    For HTML Demo purposes
    """

    outputHTMLSideBySideFilename_XMLSource_to_XMLTrans = str
    """
    For HTML Demo purposes
    """

    outputHTMLSideBySideFilenameToDropBox = str
    """
    Use WebUI Drop box for this--not a file download! (side by side remote)
    """

    outputHTMLSideBySideFilenameToDropBox_OCRDig_to_XMLSource = str
    """
    For HTML Demo purposes
    """

    outputHTMLSideBySideFilenameToDropBox_Orig_to_Cleaned = str
    """
    For HTML Demo purposes
    """

    outputHTMLSideBySideFilenameToDropBox_Orig_to_OCRDig = str
    """
    For HTML Demo purposes
    """

    outputHTMLSideBySideFilenameToDropBox_Segmented_to_OCRDig = str
    """
    For Demo
    """

    outputHTMLSideBySideFilenameToDropBox_XMLSource_to_XMLTrans = str
    """
    For HTML Demo purposes
    """

    outputHTMLSideBySideOCRFilename = str
    """
    Dead doc view on left for source
    """

    outputHTMLSideBySideOCRFilenameToDropBox = str
    """
    Dead doc view on left for source
    """

    outputImagesToDropBoxDir = str
    """
    Drop box directory for output images
    """

    outputIQVXMLFilenameToDropBox = str
    """
    Final output of <a href="#IQVDocument">IQVDocument</a> as XML serialized file (remote drop box)
    """

    OutputLevel = int
    """
    Requested by submitter as xliff only (deconstruction)
    or translation
    or reconstruction
    DEFAULT=0,
    DECONSTRUCTION_XLIFF_ONLY=1,
    TRANSLATION_XLIFF_ONLY=2,
    RECONSTRUCTION_DOC_FULL_E2E=3,
    RECONSTRUCTION_DOC_APPLY_NEW_XLIFF = 4,
    E2E_ALL_PRODUCTS_WITH_CLASSIFICATION=5
    <a href="#OUTPUT_LEVEL">OUTPUT_LEVEL</a>
    """

    outputMetadataFilename = str
    """
    Final Metadata output
    """

    outputMetatdataFilenameTranslated = str
    """
    Final Metadata output translated
    """

    outputPDFFilename = str
    """
    Final PDF output
    """

    outputPDFFilenameToDropBox = str
    """
    Final PDF output to drop box
    """

    outputPDFFilenameTranslated = str
    """
    Final PDF output translated
    """

    outputPDFFilenameTranslatedToDropBox = str
    """
    Final PDF output translated to drop box
    """

    outputWordDocFilename = str
    """
    Filename for initial Word Doc generated from this document (Source)
    """

    outputWordDocFilenameDropBox = str
    """
    Filename for initial Word Doc generated from this document (Source) in the Drop Box (remote)
    """

    outputWordDocFilenameTranslated = str
    """
    Final Word output translated
    """

    outputWordDocFilenameTranslatedDropBox = str
    """
    Drop box file for final translated/target Word document
    """

    outputXLIFFFilename = str
    """
    Filename for XLIFF generated from this document (Source)
    """

    outputXLIFFFilenameDropBox = str
    """
    Filename for XLIFF generated from this document (Source) in the Drop Box (remote)
    """

    outputXLIFFFilenameT = str
    """
    Filename for XLIFF generated from this document (Source + Target)
    """

    outputXLIFFFilenameTDropBox = str
    """
    Filename for XLIFF generated from this document (Source + Target) in the Drop Box (remote)
    """

    pages = []
    """
    Use for PDF Pages
    """

    ProcessFinishTime = str
    """
    End time for processing of document
    """

    ProcessingResults = []
    """
    List of various processing performed on this ROI. The ROI
    may be a full page or a section of a page.
    Use <a href="#IQVKeyValueSet.key">IQVKeyValueSet.key</a> to denote 'digitizer',
    'ocr', 'image_cleaning', etc.
    Use <a href="#IQVKeyValueSet.confidence">IQVKeyValueSet.confidence</a> to indicate results
    of the process, on a scale from 0.0 (low) to 1.0 (high)
    Use <a href="#IQVKeyValueSet.value">IQVKeyValueSet.value</a> to indicate additional
    information about the process
    """

    ProcessStartTime = str
    """
    Start time for processing of document
    """

    Properties = []
    """
    List of additional properties as <a href="#IQVKeyValueSet">IQVKeyValueSet</a><a href="#IQVKeyValueSet.key">IQVKeyValueSet.key</a> See standardized key listing
    <a href="#IQVKeyValueSet.value">IQVKeyValueSet.value</a> See standardized key listing
    <a href="#IQVKeyValueSet.confidence">IQVKeyValueSet.confidence</a> is 0 to 1 confidence value
    gridspan (for table cell)
    """

    QDocumentWorkingDirectory = str
    """
    Working directory holds all items we want to persist,
    such as images. Do not use this directory for temporary working
     items such as OCR intermediate output, etc.
    """

    QDocumentWorkingTempDirectory = str
    """
    Items that are used for intermediate processing only
     and can be deleted (except when used for debugging)
    """

    ReconDocumentFooters = []
    """
    Final output of OCR processing. Derived from <a href="#IQVDocument.DocumentImages">IQVDocument.DocumentImages</a>
    which contains all information to create this. This final output is used to
     create the <a href="#IQVDocument.outputWordDocFilename">IQVDocument.outputWordDocFilename</a> Word document, at which
    point the "normal" workflow is assumed.
    """

    ReconDocumentHeaders = []
    """
    Final output of OCR processing. Derived from <a href="#IQVDocument.DocumentImages">IQVDocument.DocumentImages</a>
    which contains all information to create this. This final output is used to
     create the <a href="#IQVDocument.outputWordDocFilename">IQVDocument.outputWordDocFilename</a> Word document, at which
    point the "normal" workflow is assumed.
    """

    ReconDocumentImages = []
    """
    Final output of OCR processing. Derived from <a href="#IQVDocument.DocumentImages">IQVDocument.DocumentImages</a>
    which contains all information to create this. This final output is used to
     create the <a href="#IQVDocument.outputWordDocFilename">IQVDocument.outputWordDocFilename</a> Word document, at which
    point the "normal" workflow is assumed.
    """

    ReconDocumentItems = []
    """
    Final output of OCR processing. Derived from <a href="#IQVDocument.DocumentImages">IQVDocument.DocumentImages</a>
    which contains all information to create this. This final output is used to
     create the <a href="#IQVDocument.outputWordDocFilename">IQVDocument.outputWordDocFilename</a> Word document, at which
    point the "normal" workflow is assumed.
    """

    ReconDocumentParagraphs = []
    """
    Final output of OCR processing. Derived from <a href="#IQVDocument.DocumentImages">IQVDocument.DocumentImages</a>
    which contains all information to create this. This final output is used to
     create the <a href="#IQVDocument.outputWordDocFilename">IQVDocument.outputWordDocFilename</a> Word document, at which
    point the "normal" workflow is assumed.
    """

    ReconDocumentTables = []
    """
    Final output of OCR processing. Derived from <a href="#IQVDocument.DocumentImages">IQVDocument.DocumentImages</a>
    which contains all information to create this. This final output is used to
     create the <a href="#IQVDocument.outputWordDocFilename">IQVDocument.outputWordDocFilename</a> Word document, at which
    point the "normal" workflow is assumed.
    """

    SegmentationFilename_PostSegmentation = str
    """
    Filename of <a href="#SegmentationDocument">SegmentationDocument</a> structure, with segments,
    as output from Segmentation API
    """

    SegmentationFilename_PreSegmentation = str
    """
    Filename of <a href="#SegmentationDocument">SegmentationDocument</a> structure, without segments,
    as input to Segmentation API
    """

    SelectedWordTemplateCode = int
    """

    """

    SelectedWordTemplateFilename = str
    """

    """

    sourceFilename = str
    """
    Source filename
    """

    sourceFilenameWorkingCopy = str
    """
    Working file, a copy of the original source file
    """

    sourceFilenameWorkingCopyToDropBox = str
    """
    Kept for user to check new values against original input
    """

    SourceLanguage = str
    """
    Source language 2-character or 2-character + country, such as
    en, es
    """

    StandardForm = str
    """
    Document is in known format
    """

    StandardFormPageIndex = int
    """
    Document is in known format; page index for this form
    """

    StartPage = int
    """
    Ones-based, used to specify partial document;
    default=1 for full document
    """

    SubmitterEmail = str
    """
    Email of submitter
    """

    SubmitterID = str
    """
    id of person submitting document
    """

    TargetLanguage = str
    """
    Target language 2-character or 2-character + country, such as
    en, es
    """

    workingFilename = str
    """
    Working file
    """

    workingFilename_NoiseGenerator = str
    """
    Working file if this is a generated file
    """

    def __init__(self):
        self.alcoac_check_error = []
        self.bDeleteAllFilesExceptFinalizerOutputFile = False
        self.bDeleteInputSourceFile = False
        self.bDeleteWorkingTempDirectoryAfterCompletion = -1
        self.bIsFullDocumentScanned = False
        self.bIsStandardForm = False
        self.bIsVisibleInDocumentDisplay = False
        self.CustomHostName = ''
        self.dateTimeLastModified = ''
        self.dateTimeUploaded = ''
        self.debugMode = []
        self.debugModeVal = -1
        self.displayLabel = ''
        self.doc_id = ''
        self.DOCANALYSIS_DateID = ''
        self.DOCANALYSIS_DateValue = ''
        self.DOCANALYSIS_DocumentClass = ''
        self.DOCANALYSIS_DocumentClassConfidence = 0.0
        self.DOCANALYSIS_DocumentClassConfidenceList = []
        self.DOCANALYSIS_DocumentClassList = []
        self.DOCANALYSIS_DocumentClassList_Description = []
        self.DOCANALYSIS_DocumentClassList_DIACode = []
        self.DOCANALYSIS_DocumentClassRawScoreList = []
        self.DOCANALYSIS_DocumentMetadata = []
        self.DocumentCompares = []
        self.DocumentFooters = []
        self.DocumentFootnotes = []
        self.DocumentGroundTruth = IQVDocumentGroundTruth()
        self.DocumentHeaders = []
        self.DocumentImages = []
        self.DocumentItems = []
        self.DocumentLinks = []
        self.DocumentParagraphs = []
        self.DocumentPartsList = []
        self.DocumentTables = []
        self.DocumentTypeVal = -1
        self.DocumentTypeValOriginal = -1
        self.DropBoxDir = ''
        self.DropBoxDirWebUI = ''
        self.EndPage = -1
        self.id = ''
        self.image_count = -1
        self.InitialConfig = Config()
        self.IQVAttributeCandidates = []
        self.IQVDocumentFeedbackResultsList = []
        self.IQVDocumentFilename_SourceXML = ''
        self.IQVDocumentFilename_TranslatedXML = ''
        self.IQVDocumentProcesses = []
        self.iqvForm = IQVForm()
        self.IsDocInitialWorkflowCompleted = False
        self.link_id = ''
        self.LogEntries = []
        self.logFilename = ''
        self.logFilenameDropBox = ''
        self.MachineName = ''
        self.NLP_Attributes = []
        self.NLP_Entities = []
        self.NLP_Relations = []
        self.numberingGroups = []
        self.NumPDFPages = -1
        self.NumSegments = -1
        self.originalSourceFilename = ''
        self.outputHTMLFilename = ''
        self.outputHTMLFilename_Cleaned = ''
        self.outputHTMLFilename_OCRDig = ''
        self.outputHTMLFilename_Orig = ''
        self.outputHTMLFilename_Segmented = ''
        self.outputHTMLFilename_XMLSource = ''
        self.outputHTMLFilename_XMLTrans = ''
        self.outputHTMLFilenameToDropBox = ''
        self.outputHTMLFilenameToDropBox_Cleaned = ''
        self.outputHTMLFilenameToDropBox_OCRDig = ''
        self.outputHTMLFilenameToDropBox_Orig = ''
        self.outputHTMLFilenameToDropBox_Segmented = ''
        self.outputHTMLFilenameToDropBox_XMLSource = ''
        self.outputHTMLFilenameToDropBox_XMLTrans = ''
        self.outputHTMLFilenameTranslated = ''
        self.outputHTMLFilenameTranslatedToDropBox = ''
        self.outputHTMLFilenameWithID = ''
        self.outputHTMLSideBySideFilename = ''
        self.outputHTMLSideBySideFilename_OCRDig_to_XMLSource = ''
        self.outputHTMLSideBySideFilename_Orig_to_Cleaned = ''
        self.outputHTMLSideBySideFilename_Orig_to_OCRDig = ''
        self.outputHTMLSideBySideFilename_Segmented_to_OCRDig = ''
        self.outputHTMLSideBySideFilename_XMLSource_to_XMLTrans = ''
        self.outputHTMLSideBySideFilenameToDropBox = ''
        self.outputHTMLSideBySideFilenameToDropBox_OCRDig_to_XMLSource = ''
        self.outputHTMLSideBySideFilenameToDropBox_Orig_to_Cleaned = ''
        self.outputHTMLSideBySideFilenameToDropBox_Orig_to_OCRDig = ''
        self.outputHTMLSideBySideFilenameToDropBox_Segmented_to_OCRDig = ''
        self.outputHTMLSideBySideFilenameToDropBox_XMLSource_to_XMLTrans = ''
        self.outputHTMLSideBySideOCRFilename = ''
        self.outputHTMLSideBySideOCRFilenameToDropBox = ''
        self.outputImagesToDropBoxDir = ''
        self.outputIQVXMLFilenameToDropBox = ''
        self.OutputLevel = -1
        self.outputMetadataFilename = ''
        self.outputMetatdataFilenameTranslated = ''
        self.outputPDFFilename = ''
        self.outputPDFFilenameToDropBox = ''
        self.outputPDFFilenameTranslated = ''
        self.outputPDFFilenameTranslatedToDropBox = ''
        self.outputWordDocFilename = ''
        self.outputWordDocFilenameDropBox = ''
        self.outputWordDocFilenameTranslated = ''
        self.outputWordDocFilenameTranslatedDropBox = ''
        self.outputXLIFFFilename = ''
        self.outputXLIFFFilenameDropBox = ''
        self.outputXLIFFFilenameT = ''
        self.outputXLIFFFilenameTDropBox = ''
        self.pages = []
        self.ProcessFinishTime = ''
        self.ProcessingResults = []
        self.ProcessStartTime = ''
        self.Properties = []
        self.QDocumentWorkingDirectory = ''
        self.QDocumentWorkingTempDirectory = ''
        self.ReconDocumentFooters = []
        self.ReconDocumentHeaders = []
        self.ReconDocumentImages = []
        self.ReconDocumentItems = []
        self.ReconDocumentParagraphs = []
        self.ReconDocumentTables = []
        self.SegmentationFilename_PostSegmentation = ''
        self.SegmentationFilename_PreSegmentation = ''
        self.SelectedWordTemplateCode = -1
        self.SelectedWordTemplateFilename = ''
        self.sourceFilename = ''
        self.sourceFilenameWorkingCopy = ''
        self.sourceFilenameWorkingCopyToDropBox = ''
        self.SourceLanguage = ''
        self.StandardForm = ''
        self.StandardFormPageIndex = -1
        self.StartPage = -1
        self.SubmitterEmail = ''
        self.SubmitterID = ''
        self.TargetLanguage = ''
        self.workingFilename = ''
        self.workingFilename_NoiseGenerator = ''
        self.id = str(uuid.uuid1())


class IQVDocument_db(object):
    """
    matches <a href="#IQVDocument">IQVDocument</a>
    """

    bDeleteAllFilesExceptFinalizerOutputFile = bool
    """

    """

    bDeleteInputSourceFile = bool
    """

    """

    bDeleteWorkingTempDirectoryAfterCompletion = int
    """
    Auto-delete working temp directory <see cref="P:IQVFileManagerDLL.IQVDocument_db.QDocumentWorkingTempDirectory" />
    """

    bIsFullDocumentScanned = bool
    """
    Assumed not to be scanned until checked
    """

    bIsStandardForm = bool
    """
    Document is in known format
    """

    bIsVisibleInDocumentDisplay = bool
    """
    For Formatter application, should it be displayed in the desktop or be invisible
    """

    CustomHostName = str
    """

    """

    dateTimeLastModified = str
    """
    Date last modified by the TMS system
    """

    dateTimeUploaded = str
    """
    Date uploaded to the TMS system
    """

    debugModeVal = int
    """

    """

    displayLabel = str
    """
    Display label for document, generated by user
    """

    doc_id = str
    """
    index to query by document
    """

    DOCANALYSIS_DateID = str
    """
    Classification results for document type--Rank # 1 only
    """

    DOCANALYSIS_DateValue = str
    """
    Classification results for document type--Rank # 1 only
    """

    DOCANALYSIS_DocumentClass = str
    """
    Classification results for document type--Rank # 1 only
    """

    DOCANALYSIS_DocumentClassConfidence = float
    """
    Classification results for document type--Rank # 1 only
    """

    DocumentTypeVal = int
    """

    """

    DocumentTypeValOriginal = int
    """

    """

    DropBoxDir = str
    """

    """

    DropBoxDirWebUI = str
    """

    """

    EndPage = int
    """

    """

    id = str
    """
    global unique identifier for this <a href="#IQVDocument">IQVDocument</a>
    """

    image_count = int
    """
    Number of images that have been detected in the document
    """

    IQVDocumentFilename_SourceXML = str
    """
    Copy of IQV Document data structure after segmenting, ocr, creating xml
    """

    IQVDocumentFilename_TranslatedXML = str
    """
    Copy of IQV Document data structure after translating
    """

    IsDocInitialWorkflowCompleted = bool
    """

    """

    link_id = str
    """
    index to query by section (document link <a href="#IQVDocumentLink">IQVDocumentLink</a>)
    """

    logFilename = str
    """
    Name serialized XML file containing list of log events <a href="#IQVDocument.LogEntries">IQVDocument.LogEntries</a>
    """

    logFilenameDropBox = str
    """
    Name (remote drop box) serialized XML file containing list of log events <a href="#IQVDocument.LogEntries">IQVDocument.LogEntries</a>
    """

    MachineName = str
    """

    """

    NumPDFPages = int
    """
    Number of pages if the source is a PDF
    """

    NumSegments = int
    """

    """

    originalSourceFilename = str
    """
    For tracking purposes, original source for this <a href="#IQVDocument">IQVDocument</a>
    """

    outputHTMLFilename = str
    """
    Filename for final HTML display generated from this document
    """

    outputHTMLFilename_Cleaned = str
    """
    For HTML Demo purposes
    """

    outputHTMLFilename_OCRDig = str
    """
    For HTML Demo purposes
    """

    outputHTMLFilename_Orig = str
    """
    For HTML Demo purposes
    """

    outputHTMLFilename_Segmented = str
    """
    For HTML Demo purposes
    """

    outputHTMLFilename_XMLSource = str
    """
    For HTML Demo purposes
    """

    outputHTMLFilename_XMLTrans = str
    """
    For HTML Demo purposes
    """

    outputHTMLFilenameToDropBox = str
    """
    Filename for final HTML display generated from this document (in drop box)
    """

    outputHTMLFilenameToDropBox_Cleaned = str
    """
    For HTML Demo purposes
    """

    outputHTMLFilenameToDropBox_OCRDig = str
    """
    For HTML Demo purposes
    """

    outputHTMLFilenameToDropBox_Orig = str
    """
    For HTML Demo purposes
    """

    outputHTMLFilenameToDropBox_Segmented = str
    """
    For HTML Demo purposes
    """

    outputHTMLFilenameToDropBox_XMLSource = str
    """
    For HTML Demo purposes
    """

    outputHTMLFilenameToDropBox_XMLTrans = str
    """
    For HTML Demo purposes
    """

    outputHTMLFilenameTranslated = str
    """
    Final HTML output translated
    """

    outputHTMLFilenameTranslatedToDropBox = str
    """
    Final output as HTML serialized file (remote drop box)
    """

    outputHTMLFilenameWithID = str
    """
    Final HTML output
    """

    outputHTMLSideBySideFilename = str
    """
    Filename for final HTML display generated from this document (side by side)
    """

    outputHTMLSideBySideFilename_OCRDig_to_XMLSource = str
    """
    For HTML Demo purposes
    """

    outputHTMLSideBySideFilename_Orig_to_Cleaned = str
    """
    For HTML Demo purposes
    """

    outputHTMLSideBySideFilename_Orig_to_OCRDig = str
    """
    For HTML Demo purposes
    """

    outputHTMLSideBySideFilename_Segmented_to_OCRDig = str
    """
    For HTML Demo purposes
    """

    outputHTMLSideBySideFilename_XMLSource_to_XMLTrans = str
    """
    For HTML Demo purposes
    """

    outputHTMLSideBySideFilenameToDropBox = str
    """
    Use WebUI Drop box for this--not a file download! (side by side remote)
    """

    outputHTMLSideBySideFilenameToDropBox_OCRDig_to_XMLSource = str
    """
    For HTML Demo purposes
    """

    outputHTMLSideBySideFilenameToDropBox_Orig_to_Cleaned = str
    """
    For HTML Demo purposes
    """

    outputHTMLSideBySideFilenameToDropBox_Orig_to_OCRDig = str
    """
    For HTML Demo purposes
    """

    outputHTMLSideBySideFilenameToDropBox_Segmented_to_OCRDig = str
    """
    For Demo
    """

    outputHTMLSideBySideFilenameToDropBox_XMLSource_to_XMLTrans = str
    """
    For HTML Demo purposes
    """

    outputHTMLSideBySideOCRFilename = str
    """
    Dead doc view on left for source
    """

    outputHTMLSideBySideOCRFilenameToDropBox = str
    """
    Dead doc view on left for source
    """

    outputImagesToDropBoxDir = str
    """

    """

    outputIQVXMLFilenameToDropBox = str
    """
    Final output of <a href="#IQVDocument">IQVDocument</a> as XML serialized file (remote drop box)
    """

    OutputLevel = int
    """
    Requested by submitter as xliff only (deconstruction)
    or translation
    or reconstruction
    DEFAULT=0,
    DECONSTRUCTION_XLIFF_ONLY=1,
    TRANSLATION_XLIFF_ONLY=2,
    RECONSTRUCTION_DOC_FULL_E2E=3,
    RECONSTRUCTION_DOC_APPLY_NEW_XLIFF = 4,
    E2E_ALL_PRODUCTS_WITH_CLASSIFICATION=5
    <a href="#OUTPUT_LEVEL">OUTPUT_LEVEL</a>
    """

    outputMetadataFilename = str
    """
    Final Metadata output
    """

    outputMetatdataFilenameTranslated = str
    """
    Final Metadata output translated
    """

    outputPDFFilename = str
    """
    Final PDF output
    """

    outputPDFFilenameToDropBox = str
    """
    Final PDF output to drop box
    """

    outputPDFFilenameTranslated = str
    """
    Final PDF output translated
    """

    outputPDFFilenameTranslatedToDropBox = str
    """
    Final PDF output translated to drop box
    """

    outputWordDocFilename = str
    """
    Filename for initial Word Doc generated from this document (Source)
    """

    outputWordDocFilenameDropBox = str
    """
    Filename for initial Word Doc generated from this document (Source) in the Drop Box (remote)
    """

    outputWordDocFilenameTranslated = str
    """
    Final Word output translated
    """

    outputWordDocFilenameTranslatedDropBox = str
    """

    """

    outputXLIFFFilename = str
    """

    """

    outputXLIFFFilenameDropBox = str
    """
    Filename for XLIFF generated from this document (Source) in the Drop Box (remote)
    """

    outputXLIFFFilenameT = str
    """
    Filename for XLIFF generated from this document (Source + Target)
    """

    outputXLIFFFilenameTDropBox = str
    """
    Filename for XLIFF generated from this document (Source + Target) in the Drop Box (remote)
    """

    ProcessFinishTime = str
    """
    End time for processing of document
    """

    ProcessStartTime = str
    """
    Start time for processing of document
    """

    QDocumentWorkingDirectory = str
    """

    """

    QDocumentWorkingTempDirectory = str
    """
    Items that are used for intermediate processing only
     and can be deleted (except when used for debugging)
    """

    SegmentationFilename_PostSegmentation = str
    """
    Filename of <a href="#SegmentationDocument">SegmentationDocument</a> structure, with segments,
    as output from Segmentation API
    """

    SegmentationFilename_PreSegmentation = str
    """
    Filename of <a href="#SegmentationDocument">SegmentationDocument</a> structure, without segments,
    as input to Segmentation API
    """

    SelectedWordTemplateCode = int
    """

    """

    SelectedWordTemplateFilename = str
    """

    """

    sourceFilename = str
    """
    Source filename
    """

    sourceFilenameWorkingCopy = str
    """
    Working file, a copy of the original source file
    """

    sourceFilenameWorkingCopyToDropBox = str
    """
    Kept for user to check new values against original input
    """

    SourceLanguage = str
    """
    Source language 2-character or 2-character + country, such as
    en, es
    """

    StandardForm = str
    """
    Document is in known format
    """

    StandardFormPageIndex = int
    """
    Document is in known format; page index for this form
    """

    StartPage = int
    """

    """

    SubmitterEmail = str
    """
    Email of submitter
    """

    SubmitterID = str
    """
    id of person submitting document
    """

    TargetLanguage = str
    """
    Target language 2-character or 2-character + country, such as
    en, es
    """

    workingFilename = str
    """
    Working file
    """

    workingFilename_NoiseGenerator = str
    """
    Working file if this is a generated file
    """

    def __init__(self):
        self.bDeleteAllFilesExceptFinalizerOutputFile = False
        self.bDeleteInputSourceFile = False
        self.bDeleteWorkingTempDirectoryAfterCompletion = -1
        self.bIsFullDocumentScanned = False
        self.bIsStandardForm = False
        self.bIsVisibleInDocumentDisplay = False
        self.CustomHostName = ''
        self.dateTimeLastModified = ''
        self.dateTimeUploaded = ''
        self.debugModeVal = -1
        self.displayLabel = ''
        self.doc_id = ''
        self.DOCANALYSIS_DateID = ''
        self.DOCANALYSIS_DateValue = ''
        self.DOCANALYSIS_DocumentClass = ''
        self.DOCANALYSIS_DocumentClassConfidence = 0.0
        self.DocumentTypeVal = -1
        self.DocumentTypeValOriginal = -1
        self.DropBoxDir = ''
        self.DropBoxDirWebUI = ''
        self.EndPage = -1
        self.id = ''
        self.image_count = -1
        self.IQVDocumentFilename_SourceXML = ''
        self.IQVDocumentFilename_TranslatedXML = ''
        self.IsDocInitialWorkflowCompleted = False
        self.link_id = ''
        self.logFilename = ''
        self.logFilenameDropBox = ''
        self.MachineName = ''
        self.NumPDFPages = -1
        self.NumSegments = -1
        self.originalSourceFilename = ''
        self.outputHTMLFilename = ''
        self.outputHTMLFilename_Cleaned = ''
        self.outputHTMLFilename_OCRDig = ''
        self.outputHTMLFilename_Orig = ''
        self.outputHTMLFilename_Segmented = ''
        self.outputHTMLFilename_XMLSource = ''
        self.outputHTMLFilename_XMLTrans = ''
        self.outputHTMLFilenameToDropBox = ''
        self.outputHTMLFilenameToDropBox_Cleaned = ''
        self.outputHTMLFilenameToDropBox_OCRDig = ''
        self.outputHTMLFilenameToDropBox_Orig = ''
        self.outputHTMLFilenameToDropBox_Segmented = ''
        self.outputHTMLFilenameToDropBox_XMLSource = ''
        self.outputHTMLFilenameToDropBox_XMLTrans = ''
        self.outputHTMLFilenameTranslated = ''
        self.outputHTMLFilenameTranslatedToDropBox = ''
        self.outputHTMLFilenameWithID = ''
        self.outputHTMLSideBySideFilename = ''
        self.outputHTMLSideBySideFilename_OCRDig_to_XMLSource = ''
        self.outputHTMLSideBySideFilename_Orig_to_Cleaned = ''
        self.outputHTMLSideBySideFilename_Orig_to_OCRDig = ''
        self.outputHTMLSideBySideFilename_Segmented_to_OCRDig = ''
        self.outputHTMLSideBySideFilename_XMLSource_to_XMLTrans = ''
        self.outputHTMLSideBySideFilenameToDropBox = ''
        self.outputHTMLSideBySideFilenameToDropBox_OCRDig_to_XMLSource = ''
        self.outputHTMLSideBySideFilenameToDropBox_Orig_to_Cleaned = ''
        self.outputHTMLSideBySideFilenameToDropBox_Orig_to_OCRDig = ''
        self.outputHTMLSideBySideFilenameToDropBox_Segmented_to_OCRDig = ''
        self.outputHTMLSideBySideFilenameToDropBox_XMLSource_to_XMLTrans = ''
        self.outputHTMLSideBySideOCRFilename = ''
        self.outputHTMLSideBySideOCRFilenameToDropBox = ''
        self.outputImagesToDropBoxDir = ''
        self.outputIQVXMLFilenameToDropBox = ''
        self.OutputLevel = -1
        self.outputMetadataFilename = ''
        self.outputMetatdataFilenameTranslated = ''
        self.outputPDFFilename = ''
        self.outputPDFFilenameToDropBox = ''
        self.outputPDFFilenameTranslated = ''
        self.outputPDFFilenameTranslatedToDropBox = ''
        self.outputWordDocFilename = ''
        self.outputWordDocFilenameDropBox = ''
        self.outputWordDocFilenameTranslated = ''
        self.outputWordDocFilenameTranslatedDropBox = ''
        self.outputXLIFFFilename = ''
        self.outputXLIFFFilenameDropBox = ''
        self.outputXLIFFFilenameT = ''
        self.outputXLIFFFilenameTDropBox = ''
        self.ProcessFinishTime = ''
        self.ProcessStartTime = ''
        self.QDocumentWorkingDirectory = ''
        self.QDocumentWorkingTempDirectory = ''
        self.SegmentationFilename_PostSegmentation = ''
        self.SegmentationFilename_PreSegmentation = ''
        self.SelectedWordTemplateCode = -1
        self.SelectedWordTemplateFilename = ''
        self.sourceFilename = ''
        self.sourceFilenameWorkingCopy = ''
        self.sourceFilenameWorkingCopyToDropBox = ''
        self.SourceLanguage = ''
        self.StandardForm = ''
        self.StandardFormPageIndex = -1
        self.StartPage = -1
        self.SubmitterEmail = ''
        self.SubmitterID = ''
        self.TargetLanguage = ''
        self.workingFilename = ''
        self.workingFilename_NoiseGenerator = ''
        self.id = str(uuid.uuid1())


class DocumentPartsList_db(object):
    """
    matches <a href="#IQVDocument.DocumentPartsList">IQVDocument.DocumentPartsList</a>
    which is a list of table/paragraphs indexes interlaced
    """

    doc_id = str
    """
    Element index
    Which document is this element in?
    Top-level id for <a href="#IQVDocument">IQVDocument</a>
    """

    group_type = str
    """
    Element index
    Which item is this element a member of? (name of member = group_type)
    For example, for <a href="#IQVPageROI.Properties">IQVPageROI.Properties</a>, group_type = "Properties"
    Possible parents include but are not limited to
    <a href="#IQVDocument">IQVDocument</a><a href="#IQVPageROI">IQVPageROI</a><a href="#IQVDocumentLink">IQVDocumentLink</a>
    SQL code example 1 for usage of index
    <code>
    WHERE parent_id=parent_id AND group_type=group_type
    </code>
    """

    hierarchy = str
    """
    image,table,paragraph,item,header,footer,roi
    """

    id = str
    """
    id of the table/paragraph object
    """

    iqv_standard_term = str
    """
    Element index
    If this element is a link or header, what is the standard term?
    There is 0 or 1 iqv_standard_term for each element
    """

    link_id = str
    """
    Element index
    Which [link <a href="#IQVDocumentLink">IQVDocumentLink</a>] section is this element in?
    The id for <a href="#IQVDocumentLink.LinkType">IQVDocumentLink.LinkType</a> == "toc"
    and <a href="#IQVDocumentLink.LinkLevel">IQVDocumentLink.LinkLevel</a> == 1
    """

    link_id_level2 = str
    """
    Element index
    Which [link <a href="#IQVDocumentLink">IQVDocumentLink</a>] section is this element in?
    The id for <a href="#IQVDocumentLink.LinkType">IQVDocumentLink.LinkType</a> == "toc"
    and <a href="#IQVDocumentLink.LinkLevel">IQVDocumentLink.LinkLevel</a> == 2
    """

    link_id_level3 = str
    """
    Element index
    Which [link <a href="#IQVDocumentLink">IQVDocumentLink</a>] section is this element in?
    The id for <a href="#IQVDocumentLink.LinkType">IQVDocumentLink.LinkType</a> == "toc"
    and <a href="#IQVDocumentLink.LinkLevel">IQVDocumentLink.LinkLevel</a> == 3
    """

    link_id_level4 = str
    """
    Element index
    Which [link <a href="#IQVDocumentLink">IQVDocumentLink</a>] section is this element in?
    The id for <a href="#IQVDocumentLink.LinkType">IQVDocumentLink.LinkType</a> == "toc"
    and <a href="#IQVDocumentLink.LinkLevel">IQVDocumentLink.LinkLevel</a> == 4
    """

    link_id_level5 = str
    """
    Element index
    Which [link <a href="#IQVDocumentLink">IQVDocumentLink</a>] section is this element in?
    The id for <a href="#IQVDocumentLink.LinkType">IQVDocumentLink.LinkType</a> == "toc"
    and <a href="#IQVDocumentLink.LinkLevel">IQVDocumentLink.LinkLevel</a> == 5
    """

    link_id_level6 = str
    """
    Element index
    Which [link <a href="#IQVDocumentLink">IQVDocumentLink</a>] section is this element in?
    The id for <a href="#IQVDocumentLink.LinkType">IQVDocumentLink.LinkType</a> == "toc"
    and <a href="#IQVDocumentLink.LinkLevel">IQVDocumentLink.LinkLevel</a> == 6
    """

    link_id_subsection1 = str
    """
    Element index
    Which [link <a href="#IQVDocumentLink">IQVDocumentLink</a>] section is this element in?
    The id for <a href="#IQVDocumentLink.LinkType">IQVDocumentLink.LinkType</a> == "subsection1"
    """

    link_id_subsection2 = str
    """
    Element index
    Which [link <a href="#IQVDocumentLink">IQVDocumentLink</a>] section is this element in?
    The id for <a href="#IQVDocumentLink.LinkType">IQVDocumentLink.LinkType</a> == "subsection2"
    """

    link_id_subsection3 = str
    """
    Element index
    Which [link <a href="#IQVDocumentLink">IQVDocumentLink</a>] section is this element in?
    The id for <a href="#IQVDocumentLink.LinkType">IQVDocumentLink.LinkType</a> == "subsection3"
    """

    parent_id = str
    """
    Element index
    Which item is this element a member of?
    For example, for <a href="#IQVPageROI.Properties">IQVPageROI.Properties</a>, parent_id = <a href="#IQVPageROI.id">IQVPageROI.id</a>
    Possible parents include but are not limited to
    <a href="#IQVDocument">IQVDocument</a><a href="#IQVPageROI">IQVPageROI</a><a href="#IQVDocumentLink">IQVDocumentLink</a>
    SQL code example 1 for usage of index
    <code>
    WHERE parent_id=parent_id AND group_type=group_type
    </code>
    SQL code example 2 for usage of index
    <code>
    WHERE parent_id=parent_id
    </code>
    """

    sequence_id = int
    """
    sequence_id, start with 0 for each document
    """

    def __init__(self):
        self.doc_id = ''
        self.group_type = ''
        self.hierarchy = ''
        self.id = ''
        self.iqv_standard_term = ''
        self.link_id = ''
        self.link_id_level2 = ''
        self.link_id_level3 = ''
        self.link_id_level4 = ''
        self.link_id_level5 = ''
        self.link_id_level6 = ''
        self.link_id_subsection1 = ''
        self.link_id_subsection2 = ''
        self.link_id_subsection3 = ''
        self.parent_id = ''
        self.sequence_id = -1
        self.id = str(uuid.uuid1())


class IQVPageROI_db(object):
    """
    matches <a href="#IQVPageROI">IQVPageROI</a>
    CREATE TABLE public.DocumentParagraphs(
    ) INHERITS(public.iqvpageroi_db);
    """

    bIsCheckbox = bool
    """
    Mark to true if this represents a checkbox on a form
    """

    bIsChecked = bool
    """
    Mark to true if this represents a checkbox and IS CHECKED ON on a form
    """

    bIsImage = bool
    """
    Image information is stored in QPageROI type
    """

    bIsSharedString = bool
    """
    Excel cell value data type
    """

    bNoTranslate = bool
    """
    Default is FALSE: i.e., default is YES TRANSLATE!;
    translate attribute (yes / no) is supported in
    file, group, unit, mrk, sm levels
    """

    bOutputImageCreated = bool
    """
    Use to flag when the output image has been created.
    Default = false
    If the digitizer-DLA creates the image, this flag is set to true.
    If the digitizer-DLA does not create the image, this flag remains false (default).
    When the OCR is triggered on this IQVPageROI, the OCR checks this flag.
    If this flag is true, the OCR will use <see cref="P:IQVFileManagerDLL.IQVPageROI_db.OutputImageFilename_FinalImageProcessingOutput" />
    or <see cref="P:IQVFileManagerDLL.IQVPageROI_db.OutputImageFilename" /> as input to OCR.
    When this flag is false, the OCR will use <see cref="!:rectangleGlobalLocationOnPage" /> and the
    page image to create the image as input to OCR.
    """

    bScannedOCR = bool
    """
    False if PDF reader, True if use OCR. To see
    which OCR language engine was used, check <see cref="P:IQVFileManagerDLL.IQVPageROI_db.scannedOCRCode" />
    """

    BulletIndentationLevel = int
    """
    Default is -1, not set
    """

    BulletTypeVal = int
    """

    """

    CheckboxFill = float
    """
    Proportion of pixels that are black/foreground, to help determine
    if this is CHECKED ON or NOT, from 0 to 1; e.g., 0.5=50% of pixels are foreground
    """

    contentTypeVal = int
    """
    For text-handling information, such as whether to
     translate this text, etc. References are handled here.
    DEFAULT=0,
    REFERENCES_BIBIOGRAPHY_SECTION=1
    NOT SET = -1
    """

    doc_id = str
    """
    Element index
    Which document is this element in?
    Top-level id for <a href="#IQVDocument">IQVDocument</a>
    """

    DocumentRelId = str
    """
    Relationship ID of the image in the Word document;
    Add the image first to the document; use the RelId to reference it
    and position it
    """

    DocumentSequenceIndex = int
    """
    Global sequence index for both <a href="#IQVDocument.DocumentParagraphs">IQVDocument.DocumentParagraphs</a>
     and <a href="#IQVDocument.DocumentTables">IQVDocument.DocumentTables</a>

    Zero-based sequential order index of document part,
    which could be a table or a paragraph.
     This allows tables and paragraphs to be interlaced together
    and in sequential order

    Used in both
    <see cref="P:IQVFileManagerDLL.IQVDigDocumentTable.DocumentSequenceIndex" />
    and
     <see cref="P:IQVFileManagerDLL.IQVDigDocumentParagraph.DocumentSequenceIndex" />
    """

    FooterSequence = int
    """
    sequence of footer element, zero-based
    """

    group_type = str
    """
    Element index
    Which item is this element a member of? (name of member = group_type)
    For example, for <a href="#IQVPageROI.Properties">IQVPageROI.Properties</a>, group_type = "Properties"
    Possible parents include but are not limited to
    <a href="#IQVDocument">IQVDocument</a><a href="#IQVPageROI">IQVPageROI</a><a href="#IQVDocumentLink">IQVDocumentLink</a>
    SQL code example 1 for usage of index
    <code>
    WHERE parent_id=parent_id AND group_type=group_type
    </code>
    """

    GT_ImageFilename = str
    """
    for testing if have ground truth image available
    """

    GT_ScoreMatch = float
    """
    for testing
    """

    GT_TextMatch = str
    """
    For a actual/known/validated output to measure
     against the (predicted output) text
    """

    hAlignmentVal = int
    """

    """

    HeaderSequence = int
    """
    sequence of header element, zero-based
    """

    hierarchy = str
    """
    image,table,paragraph,item,header,footer,roi
    """

    HorizontalResolution = float
    """
    Resolution of image
    """

    htmlTagType = str
    """
    span, p, div, etc.
    """

    Hue = int
    """
    hue value for primary color of ROI text
    """

    id = str
    """
    Gloablly unique id. Use in conjunction with
    <seealso cref="!:GetFullText_WithFormattingPreserved" /> in order to get the
     baseline key-value pair of id/text that can be
     passed through systems such as translation
    """

    ImageFormatVal = str
    """
    Used to set <see cref="!:ImageFormat" />
    Bmp
    Emf
    Exif
    Gif
    Icon
    Jpeg
    MemoryBmp
    Png
    Tiff
    Wmf
    """

    ImageIndex = int
    """
    In overall document, which image did this roi come from???
    """

    imagePaddingPixels = float
    """
    Added as a border around the ROI before OCR;
    must be used in calculation to restore
    """

    imageScaling = float
    """
    Scale up ROI by this factor (horizontal and vertical)
    before OCR; must be used in calculation to restore
    """

    iqv_standard_term = str
    """
    Element index
    If this element is a link or header, what is the standard term?
    There is 0 or 1 iqv_standard_term for each element
    """

    IsCopyOfRoiId = str
    """
    If copy of another ROI, set the IsCopyOf to the ID of that ROI
    """

    IsTableCell = bool
    """
    Mark to true if this is part of a table structure
    """

    link_id = str
    """
    Element index
    Which [link <a href="#IQVDocumentLink">IQVDocumentLink</a>] section is this element in?
    The id for <a href="#IQVDocumentLink.LinkType">IQVDocumentLink.LinkType</a> == "toc"
    and <a href="#IQVDocumentLink.LinkLevel">IQVDocumentLink.LinkLevel</a> == 1
    """

    link_id_level2 = str
    """
    Element index
    Which [link <a href="#IQVDocumentLink">IQVDocumentLink</a>] section is this element in?
    The id for <a href="#IQVDocumentLink.LinkType">IQVDocumentLink.LinkType</a> == "toc"
    and <a href="#IQVDocumentLink.LinkLevel">IQVDocumentLink.LinkLevel</a> == 2
    """

    link_id_level3 = str
    """
    Element index
    Which [link <a href="#IQVDocumentLink">IQVDocumentLink</a>] section is this element in?
    The id for <a href="#IQVDocumentLink.LinkType">IQVDocumentLink.LinkType</a> == "toc"
    and <a href="#IQVDocumentLink.LinkLevel">IQVDocumentLink.LinkLevel</a> == 3
    """

    link_id_level4 = str
    """
    Element index
    Which [link <a href="#IQVDocumentLink">IQVDocumentLink</a>] section is this element in?
    The id for <a href="#IQVDocumentLink.LinkType">IQVDocumentLink.LinkType</a> == "toc"
    and <a href="#IQVDocumentLink.LinkLevel">IQVDocumentLink.LinkLevel</a> == 4
    """

    link_id_level5 = str
    """
    Element index
    Which [link <a href="#IQVDocumentLink">IQVDocumentLink</a>] section is this element in?
    The id for <a href="#IQVDocumentLink.LinkType">IQVDocumentLink.LinkType</a> == "toc"
    and <a href="#IQVDocumentLink.LinkLevel">IQVDocumentLink.LinkLevel</a> == 5
    """

    link_id_level6 = str
    """
    Element index
    Which [link <a href="#IQVDocumentLink">IQVDocumentLink</a>] section is this element in?
    The id for <a href="#IQVDocumentLink.LinkType">IQVDocumentLink.LinkType</a> == "toc"
    and <a href="#IQVDocumentLink.LinkLevel">IQVDocumentLink.LinkLevel</a> == 6
    """

    link_id_subsection1 = str
    """
    Element index
    Which [link <a href="#IQVDocumentLink">IQVDocumentLink</a>] section is this element in?
    The id for <a href="#IQVDocumentLink.LinkType">IQVDocumentLink.LinkType</a> == "subsection1"
    """

    link_id_subsection2 = str
    """
    Element index
    Which [link <a href="#IQVDocumentLink">IQVDocumentLink</a>] section is this element in?
    The id for <a href="#IQVDocumentLink.LinkType">IQVDocumentLink.LinkType</a> == "subsection2"
    """

    link_id_subsection3 = str
    """
    Element index
    Which [link <a href="#IQVDocumentLink">IQVDocumentLink</a>] section is this element in?
    The id for <a href="#IQVDocumentLink.LinkType">IQVDocumentLink.LinkType</a> == "subsection3"
    """

    m_PARENT_ROI_TYPEVal = int
    """

    """

    m_ROI_TYPEVal = int
    """

    """

    m_WORD_LAYOUTVal = int
    """

    """

    OriginalROIHeightInches = float
    """
    Original resolution of image to match the number of pixels,
    calculaged using DPI and number of pixels. Set because image
    is manipulated after the fact
    """

    OriginalROIWidthInches = float
    """
    Original resolution of image to match the number of pixels,
    calculaged using DPI and number of pixels. Set because image
    is manipulated after the fact
    """

    OutputImageFilename = str
    """
    Save image as this filename
    """

    OutputImageFilename_Cleaned = str
    """
    Binarized, cleaned copy
    """

    OutputImageFilename_FinalImageProcessingOutput = str
    """
    Image Processing completed, ready for OCR pipeline
    """

    OutputImageFilename_FinalImageProcessingOutputToDropBox = str
    """
    Image Processing completed, ready for OCR pipeline
    """

    OutputImageFilename_OriginalSegment = str
    """
    Only for demo purposes, must be cut and saved after the fact
    """

    OutputImageFilename_RotationCorrection = str
    """
    Rotated ready for Image Processing Pipeline
    """

    OutputImageFilename_RotationCorrectionToDropBox = str
    """
    Rotated ready for Image Processing Pipeline
    """

    OutputImageFilename_Segments = str
    """
    Segmented ready for OCR
    """

    OutputImageFilename_SegmentsToDropBox = str
    """
    Segmented ready for OCR
    """

    OutputImageFilenameT = str
    """
    Image output translated
    """

    OutputImageFilenameTDropBox = str
    """
    Image output translated--extra copy
    """

    PageID = str
    """
    GUID of container page in PDF
    """

    PageSequenceIndex = int
    """
    Ones-based for which page this item falls on in the PDF document;
    If this is -1, then no page sequence is available (for instance,
    when Word is used to get the ROI rather than pdf reader)
    """

    parent_id = str
    """
    Element index
    Which item is this element a member of?
    For example, for <a href="#IQVPageROI.Properties">IQVPageROI.Properties</a>, parent_id = <a href="#IQVPageROI.id">IQVPageROI.id</a>
    Possible parents include but are not limited to
    <a href="#IQVDocument">IQVDocument</a><a href="#IQVPageROI">IQVPageROI</a><a href="#IQVDocumentLink">IQVDocumentLink</a>
    SQL code example 1 for usage of index
    <code>
    WHERE parent_id=parent_id AND group_type=group_type
    </code>
    SQL code example 2 for usage of index
    <code>
    WHERE parent_id=parent_id
    </code>
    """

    parentrectangle_height = int
    """

    """

    parentrectangle_width = int
    """

    """

    parentrectangle_x = int
    """

    """

    parentrectangle_y = int
    """

    """

    rectangle_height = int
    """

    """

    rectangle_width = int
    """

    """

    rectangle_x = int
    """

    """

    rectangle_y = int
    """

    """

    rectangleGlobalLocationOnPage_height = int
    """

    """

    rectangleGlobalLocationOnPage_width = int
    """

    """

    rectangleGlobalLocationOnPage_x = int
    """

    """

    rectangleGlobalLocationOnPage_y = int
    """

    """

    Rotation_MajorAxis = int
    """
    In degrees, {0,90,180,270} to
     show the orientation of the document. This is not the 'corrected'
    orientation.Rather, if the document is 'sideways' then it must be
    rotated 90/270 in order to read it properly.Zero (0) is default.
    """

    RotationCorrectionDegrees = float
    """

    """

    scannedOCRCode = str
    """
    3-digit tesseract code used to transform this ROI. This
    aligns with <a href="#LanguageCode.tesseractCode">LanguageCode.tesseractCode</a>, such as
    "eng" for English
    """

    Score = float
    """
    Local copy--what is overall score for this match?
    """

    SegmentationMethodVal = int
    """
    derived from <see cref="!:SegmentationMethod" />
    NOT SET = -1
    """

    SegmentationType = int
    """
    0 = no segmentation, 1=baseline segmentation,
     2 = language-specific segmentation (new default, ru, po, etc. as available),
    the
    segmentation done on the text in order to create XLIFF
    for translation
    """

    SequenceID = int
    """
    Within container, for similar items. For example,
    each footer of a set of footers within a document
    will be sequenced using this variable
    """

    SlideIndex = int
    """
    For PowerPoint, zero-based sequence index of slide
     in which this ROI is contained
    """

    SlideRelationshipId = str
    """
    For PowerPoint, relId of slide in which this ROI is contained
    """

    strText = str
    """
    Main printed text
    """

    strTextTranslated = str
    """
    Main printed text in target language, as simple string
    """

    tableCell_colIndex = int
    """
    column index if this is a OCR table cell, zero-based
    """

    tableCell_pageIndex = int
    """
    index for multi-page table, zero-based
    """

    tableCell_rowIndex = int
    """
    row index if this is a table cell, zero-based
    """

    tableCell_SharedStringIndex = int
    """
    Excel type index for string, zero-based
    """

    tableCell_SheetCellReference = str
    """
    For OpenXml/Excel Spreadsheet, to identify the cell, as in "A1"
    """

    tableCell_SheetColIndex = int
    """
    Excel type col index, ones-based
    """

    tableCell_SheetName = str
    """
    Excel type sheet name if in Excel table
    """

    tableCell_SheetRowIndex = int
    """
    Excel type row index, ones-based
    """

    textTypeVal = int
    """
    Note: NOT SET = -1
    DEFAULT=0,
    COMMENT=1,
    CONSTANT=2,
    NON_TEXT=3,
    NEWLINE=4,
    TEXTBOX = 5,
    BULLET=6,
    FOOTER=7,
    HEADER=8,
    IMAGE=9,
    """

    TranslatedTextNoSegmentation = str
    """
    If the ID is missing, then the segmentation may not be sync'd. To
    do a simple find/replace using any input, without ID, then use the
    TranslatedTextNoSegmentation instead of the segments found in the <see cref="!:ChildBoxes" /> .
    Must denote the SegmentationMethod to NONE.
    """

    TranslationMatch = float
    """
    Score for translation
    """

    TranslationMethod1 = str
    """
    MyMemory, google, etc.
    """

    UncorrectedImageFilename = str
    """
    used to track the original source copy of this ROI
    """

    Value = str
    """
    Local copy--what is value from report that maps to this field?
    """

    VerticalResolution = float
    """
    Resolution of image
    """

    def __init__(self):
        self.bIsCheckbox = False
        self.bIsChecked = False
        self.bIsImage = False
        self.bIsSharedString = False
        self.bNoTranslate = False
        self.bOutputImageCreated = False
        self.bScannedOCR = False
        self.BulletIndentationLevel = -1
        self.BulletTypeVal = -1
        self.CheckboxFill = 0.0
        self.contentTypeVal = -1
        self.doc_id = ''
        self.DocumentRelId = ''
        self.DocumentSequenceIndex = -1
        self.FooterSequence = -1
        self.group_type = ''
        self.GT_ImageFilename = ''
        self.GT_ScoreMatch = 0.0
        self.GT_TextMatch = ''
        self.hAlignmentVal = -1
        self.HeaderSequence = -1
        self.hierarchy = ''
        self.HorizontalResolution = 0.0
        self.htmlTagType = ''
        self.Hue = -1
        self.id = ''
        self.ImageFormatVal = ''
        self.ImageIndex = -1
        self.imagePaddingPixels = 0.0
        self.imageScaling = 0.0
        self.iqv_standard_term = ''
        self.IsCopyOfRoiId = ''
        self.IsTableCell = False
        self.link_id = ''
        self.link_id_level2 = ''
        self.link_id_level3 = ''
        self.link_id_level4 = ''
        self.link_id_level5 = ''
        self.link_id_level6 = ''
        self.link_id_subsection1 = ''
        self.link_id_subsection2 = ''
        self.link_id_subsection3 = ''
        self.m_PARENT_ROI_TYPEVal = -1
        self.m_ROI_TYPEVal = -1
        self.m_WORD_LAYOUTVal = -1
        self.OriginalROIHeightInches = 0.0
        self.OriginalROIWidthInches = 0.0
        self.OutputImageFilename = ''
        self.OutputImageFilename_Cleaned = ''
        self.OutputImageFilename_FinalImageProcessingOutput = ''
        self.OutputImageFilename_FinalImageProcessingOutputToDropBox = ''
        self.OutputImageFilename_OriginalSegment = ''
        self.OutputImageFilename_RotationCorrection = ''
        self.OutputImageFilename_RotationCorrectionToDropBox = ''
        self.OutputImageFilename_Segments = ''
        self.OutputImageFilename_SegmentsToDropBox = ''
        self.OutputImageFilenameT = ''
        self.OutputImageFilenameTDropBox = ''
        self.PageID = ''
        self.PageSequenceIndex = -1
        self.parent_id = ''
        self.parentrectangle_height = -1
        self.parentrectangle_width = -1
        self.parentrectangle_x = -1
        self.parentrectangle_y = -1
        self.rectangle_height = -1
        self.rectangle_width = -1
        self.rectangle_x = -1
        self.rectangle_y = -1
        self.rectangleGlobalLocationOnPage_height = -1
        self.rectangleGlobalLocationOnPage_width = -1
        self.rectangleGlobalLocationOnPage_x = -1
        self.rectangleGlobalLocationOnPage_y = -1
        self.Rotation_MajorAxis = -1
        self.RotationCorrectionDegrees = 0.0
        self.scannedOCRCode = ''
        self.Score = 0.0
        self.SegmentationMethodVal = -1
        self.SegmentationType = -1
        self.SequenceID = -1
        self.SlideIndex = -1
        self.SlideRelationshipId = ''
        self.strText = ''
        self.strTextTranslated = ''
        self.tableCell_colIndex = -1
        self.tableCell_pageIndex = -1
        self.tableCell_rowIndex = -1
        self.tableCell_SharedStringIndex = -1
        self.tableCell_SheetCellReference = ''
        self.tableCell_SheetColIndex = -1
        self.tableCell_SheetName = ''
        self.tableCell_SheetRowIndex = -1
        self.textTypeVal = -1
        self.TranslatedTextNoSegmentation = ''
        self.TranslationMatch = 0.0
        self.TranslationMethod1 = ''
        self.UncorrectedImageFilename = ''
        self.Value = ''
        self.VerticalResolution = 0.0
        self.id = str(uuid.uuid1())


class IQVDocumentLink_db(object):
    """
    Links within document, mostly to handle document-document
    link and section structure
    <a href="#IQVDocumentLink">IQVDocumentLink</a>
    """

    doc_id = str
    """
    Element index
    Which document is this element in?
    Top-level id for <a href="#IQVDocument">IQVDocument</a>
    """

    DocumentSequenceIndex = int
    """
    Zero-based sequence index across a document for all
    links regardless of level.

     The page number can also be used to set the sequence,
    but is sometimes ambiguous.
    """

    group_type = str
    """
    Element index
    Which item is this element a member of? (name of member = group_type)
    For example, for <a href="#IQVPageROI.Properties">IQVPageROI.Properties</a>, group_type = "Properties"
    Possible parents include but are not limited to
    <a href="#IQVDocument">IQVDocument</a><a href="#IQVPageROI">IQVPageROI</a><a href="#IQVDocumentLink">IQVDocumentLink</a>
    SQL code example 1 for usage of index
    <code>
    WHERE parent_id=parent_id AND group_type=group_type
    </code>
    """

    hierarchy = str
    """
    image,table,paragraph,item,header,footer,roi
    """

    id = str
    """
    Unique id for the link
    """

    iqv_standard_term = str
    """
    Element index
    If this element is a link or header, what is the standard term?
    There is 0 or 1 iqv_standard_term for each element
    """

    link_id = str
    """
    Element index
    Which [link <a href="#IQVDocumentLink">IQVDocumentLink</a>] section is this element in?
    The id for <a href="#IQVDocumentLink.LinkType">IQVDocumentLink.LinkType</a> == "toc"
    and <a href="#IQVDocumentLink.LinkLevel">IQVDocumentLink.LinkLevel</a> == 1
    """

    link_id_level2 = str
    """
    Element index
    Which [link <a href="#IQVDocumentLink">IQVDocumentLink</a>] section is this element in?
    The id for <a href="#IQVDocumentLink.LinkType">IQVDocumentLink.LinkType</a> == "toc"
    and <a href="#IQVDocumentLink.LinkLevel">IQVDocumentLink.LinkLevel</a> == 2
    """

    link_id_level3 = str
    """
    Element index
    Which [link <a href="#IQVDocumentLink">IQVDocumentLink</a>] section is this element in?
    The id for <a href="#IQVDocumentLink.LinkType">IQVDocumentLink.LinkType</a> == "toc"
    and <a href="#IQVDocumentLink.LinkLevel">IQVDocumentLink.LinkLevel</a> == 3
    """

    link_id_level4 = str
    """
    Element index
    Which [link <a href="#IQVDocumentLink">IQVDocumentLink</a>] section is this element in?
    The id for <a href="#IQVDocumentLink.LinkType">IQVDocumentLink.LinkType</a> == "toc"
    and <a href="#IQVDocumentLink.LinkLevel">IQVDocumentLink.LinkLevel</a> == 4
    """

    link_id_level5 = str
    """
    Element index
    Which [link <a href="#IQVDocumentLink">IQVDocumentLink</a>] section is this element in?
    The id for <a href="#IQVDocumentLink.LinkType">IQVDocumentLink.LinkType</a> == "toc"
    and <a href="#IQVDocumentLink.LinkLevel">IQVDocumentLink.LinkLevel</a> == 5
    """

    link_id_level6 = str
    """
    Element index
    Which [link <a href="#IQVDocumentLink">IQVDocumentLink</a>] section is this element in?
    The id for <a href="#IQVDocumentLink.LinkType">IQVDocumentLink.LinkType</a> == "toc"
    and <a href="#IQVDocumentLink.LinkLevel">IQVDocumentLink.LinkLevel</a> == 6
    """

    link_id_subsection1 = str
    """
    Element index
    Which [link <a href="#IQVDocumentLink">IQVDocumentLink</a>] section is this element in?
    The id for <a href="#IQVDocumentLink.LinkType">IQVDocumentLink.LinkType</a> == "subsection1"
    """

    link_id_subsection2 = str
    """
    Element index
    Which [link <a href="#IQVDocumentLink">IQVDocumentLink</a>] section is this element in?
    The id for <a href="#IQVDocumentLink.LinkType">IQVDocumentLink.LinkType</a> == "subsection2"
    """

    link_id_subsection3 = str
    """
    Element index
    Which [link <a href="#IQVDocumentLink">IQVDocumentLink</a>] section is this element in?
    The id for <a href="#IQVDocumentLink.LinkType">IQVDocumentLink.LinkType</a> == "subsection3"
    """

    LinkLevel = int
    """
    hierarchical level of the link, with 1=top most level,
    -1=not set
    """

    LinkPage = int
    """
    zero-based page index of link destination point;
    additional information on link destination may be
    found in <see cref="!:LinkDestination" />
    -1 = not set
    """

    LinkPrefix = str
    """
    numeric prefix (section identifier), such as "7.1.1"
    """

    LinkText = str
    """
    raw text of destination
    """

    LinkType = str
    """
    type of link: internal, external, toc, tof, toa, tot
    """

    parent_id = str
    """
    Element index
    Which item is this element a member of?
    For example, for <a href="#IQVPageROI.Properties">IQVPageROI.Properties</a>, parent_id = <a href="#IQVPageROI.id">IQVPageROI.id</a>
    Possible parents include but are not limited to
    <a href="#IQVDocument">IQVDocument</a><a href="#IQVPageROI">IQVPageROI</a><a href="#IQVDocumentLink">IQVDocumentLink</a>
    SQL code example 1 for usage of index
    <code>
    WHERE parent_id=parent_id AND group_type=group_type
    </code>
    SQL code example 2 for usage of index
    <code>
    WHERE parent_id=parent_id
    </code>
    """

    def __init__(self):
        self.doc_id = ''
        self.DocumentSequenceIndex = -1
        self.group_type = ''
        self.hierarchy = ''
        self.id = ''
        self.iqv_standard_term = ''
        self.link_id = ''
        self.link_id_level2 = ''
        self.link_id_level3 = ''
        self.link_id_level4 = ''
        self.link_id_level5 = ''
        self.link_id_level6 = ''
        self.link_id_subsection1 = ''
        self.link_id_subsection2 = ''
        self.link_id_subsection3 = ''
        self.LinkLevel = -1
        self.LinkPage = -1
        self.LinkPrefix = ''
        self.LinkText = ''
        self.LinkType = ''
        self.parent_id = ''
        self.id = str(uuid.uuid1())


class IQVKeyValueSet_db(object):
    """
    Key-value pair
    """

    confidence = float
    """
    Confidence for this value
    """

    doc_id = str
    """
    Element index
    Which document is this element in?
    Top-level id for <a href="#IQVDocument">IQVDocument</a>
    """

    group_type = str
    """
    Element index
    Which item is this element a member of? (name of member = group_type)
    For example, for <a href="#IQVPageROI.Properties">IQVPageROI.Properties</a>, group_type = "Properties"
    Possible parents include but are not limited to
    <a href="#IQVDocument">IQVDocument</a><a href="#IQVPageROI">IQVPageROI</a><a href="#IQVDocumentLink">IQVDocumentLink</a>
    SQL code example 1 for usage of index
    <code>
    WHERE parent_id=parent_id AND group_type=group_type
    </code>
    """

    hierarchy = str
    """
    image,table,paragraph,item,header,footer,roi
    """

    id = str
    """

    """

    iqv_standard_term = str
    """
    Element index
    If this element is a link or header, what is the standard term?
    There is 0 or 1 iqv_standard_term for each element
    """

    key = str
    """
    Attribute/metadata key, such as document_date
    """

    link_id = str
    """
    Element index
    Which [link <a href="#IQVDocumentLink">IQVDocumentLink</a>] section is this element in?
    The id for <a href="#IQVDocumentLink.LinkType">IQVDocumentLink.LinkType</a> == "toc"
    and <a href="#IQVDocumentLink.LinkLevel">IQVDocumentLink.LinkLevel</a> == 1
    """

    link_id_level2 = str
    """
    Element index
    Which [link <a href="#IQVDocumentLink">IQVDocumentLink</a>] section is this element in?
    The id for <a href="#IQVDocumentLink.LinkType">IQVDocumentLink.LinkType</a> == "toc"
    and <a href="#IQVDocumentLink.LinkLevel">IQVDocumentLink.LinkLevel</a> == 2
    """

    link_id_level3 = str
    """
    Element index
    Which [link <a href="#IQVDocumentLink">IQVDocumentLink</a>] section is this element in?
    The id for <a href="#IQVDocumentLink.LinkType">IQVDocumentLink.LinkType</a> == "toc"
    and <a href="#IQVDocumentLink.LinkLevel">IQVDocumentLink.LinkLevel</a> == 3
    """

    link_id_level4 = str
    """
    Element index
    Which [link <a href="#IQVDocumentLink">IQVDocumentLink</a>] section is this element in?
    The id for <a href="#IQVDocumentLink.LinkType">IQVDocumentLink.LinkType</a> == "toc"
    and <a href="#IQVDocumentLink.LinkLevel">IQVDocumentLink.LinkLevel</a> == 4
    """

    link_id_level5 = str
    """
    Element index
    Which [link <a href="#IQVDocumentLink">IQVDocumentLink</a>] section is this element in?
    The id for <a href="#IQVDocumentLink.LinkType">IQVDocumentLink.LinkType</a> == "toc"
    and <a href="#IQVDocumentLink.LinkLevel">IQVDocumentLink.LinkLevel</a> == 5
    """

    link_id_level6 = str
    """
    Element index
    Which [link <a href="#IQVDocumentLink">IQVDocumentLink</a>] section is this element in?
    The id for <a href="#IQVDocumentLink.LinkType">IQVDocumentLink.LinkType</a> == "toc"
    and <a href="#IQVDocumentLink.LinkLevel">IQVDocumentLink.LinkLevel</a> == 6
    """

    link_id_subsection1 = str
    """
    Element index
    Which [link <a href="#IQVDocumentLink">IQVDocumentLink</a>] section is this element in?
    The id for <a href="#IQVDocumentLink.LinkType">IQVDocumentLink.LinkType</a> == "subsection1"
    """

    link_id_subsection2 = str
    """
    Element index
    Which [link <a href="#IQVDocumentLink">IQVDocumentLink</a>] section is this element in?
    The id for <a href="#IQVDocumentLink.LinkType">IQVDocumentLink.LinkType</a> == "subsection2"
    """

    link_id_subsection3 = str
    """
    Element index
    Which [link <a href="#IQVDocumentLink">IQVDocumentLink</a>] section is this element in?
    The id for <a href="#IQVDocumentLink.LinkType">IQVDocumentLink.LinkType</a> == "subsection3"
    """

    parent_id = str
    """
    Element index
    Which item is this element a member of?
    For example, for <a href="#IQVPageROI.Properties">IQVPageROI.Properties</a>, parent_id = <a href="#IQVPageROI.id">IQVPageROI.id</a>
    Possible parents include but are not limited to
    <a href="#IQVDocument">IQVDocument</a><a href="#IQVPageROI">IQVPageROI</a><a href="#IQVDocumentLink">IQVDocumentLink</a>
    SQL code example 1 for usage of index
    <code>
    WHERE parent_id=parent_id AND group_type=group_type
    </code>
    SQL code example 2 for usage of index
    <code>
    WHERE parent_id=parent_id
    </code>
    """

    rawScore = float
    """
    Raw score for this value
    """

    source_system = str
    """

    """

    value = str
    """
    Value for this attribute/metadata, such as "20000131" (for Jan 31, 2000)
    """

    def __init__(self):
        self.confidence = 0.0
        self.doc_id = ''
        self.group_type = ''
        self.hierarchy = ''
        self.id = ''
        self.iqv_standard_term = ''
        self.key = ''
        self.link_id = ''
        self.link_id_level2 = ''
        self.link_id_level3 = ''
        self.link_id_level4 = ''
        self.link_id_level5 = ''
        self.link_id_level6 = ''
        self.link_id_subsection1 = ''
        self.link_id_subsection2 = ''
        self.link_id_subsection3 = ''
        self.parent_id = ''
        self.rawScore = 0.0
        self.source_system = ''
        self.value = ''
        self.id = str(uuid.uuid1())


class IQVQCUpdateTracking_db(object):
    """
    Track individual QC item detail
    """

    doc_id = str
    """
    Element index
    Which document is this element in?
    Top-level id for <a href="#IQVDocument">IQVDocument</a>
    """

    dts = str
    """
    YYYYMMDDHHMMSS
    """

    group_type = str
    """
    Element index
    Which item is this element a member of? (name of member = group_type)
    For example, for <a href="#IQVPageROI.Properties">IQVPageROI.Properties</a>, group_type = "Properties"
    Possible parents include but are not limited to
    <a href="#IQVDocument">IQVDocument</a><a href="#IQVPageROI">IQVPageROI</a><a href="#IQVDocumentLink">IQVDocumentLink</a>
    SQL code example 1 for usage of index
    <code>
    WHERE parent_id=parent_id AND group_type=group_type
    </code>
    """

    hierarchy = str
    """
    image,table,paragraph,item,header,footer,roi
    """

    id = str
    """
    GUID/UUID of the <a href="#IQVQCUpdateTracking">IQVQCUpdateTracking</a> for tracking
    """

    iqv_standard_term = str
    """
    Element index
    If this element is a link or header, what is the standard term?
    There is 0 or 1 iqv_standard_term for each element
    """

    ItemDataType = str
    """
    data type (IQVPageROI, IQVSubText, etc.)
    """

    link_id = str
    """
    Element index
    Which [link <a href="#IQVDocumentLink">IQVDocumentLink</a>] section is this element in?
    The id for <a href="#IQVDocumentLink.LinkType">IQVDocumentLink.LinkType</a> == "toc"
    and <a href="#IQVDocumentLink.LinkLevel">IQVDocumentLink.LinkLevel</a> == 1
    """

    link_id_level2 = str
    """
    Element index
    Which [link <a href="#IQVDocumentLink">IQVDocumentLink</a>] section is this element in?
    The id for <a href="#IQVDocumentLink.LinkType">IQVDocumentLink.LinkType</a> == "toc"
    and <a href="#IQVDocumentLink.LinkLevel">IQVDocumentLink.LinkLevel</a> == 2
    """

    link_id_level3 = str
    """
    Element index
    Which [link <a href="#IQVDocumentLink">IQVDocumentLink</a>] section is this element in?
    The id for <a href="#IQVDocumentLink.LinkType">IQVDocumentLink.LinkType</a> == "toc"
    and <a href="#IQVDocumentLink.LinkLevel">IQVDocumentLink.LinkLevel</a> == 3
    """

    link_id_level4 = str
    """
    Element index
    Which [link <a href="#IQVDocumentLink">IQVDocumentLink</a>] section is this element in?
    The id for <a href="#IQVDocumentLink.LinkType">IQVDocumentLink.LinkType</a> == "toc"
    and <a href="#IQVDocumentLink.LinkLevel">IQVDocumentLink.LinkLevel</a> == 4
    """

    link_id_level5 = str
    """
    Element index
    Which [link <a href="#IQVDocumentLink">IQVDocumentLink</a>] section is this element in?
    The id for <a href="#IQVDocumentLink.LinkType">IQVDocumentLink.LinkType</a> == "toc"
    and <a href="#IQVDocumentLink.LinkLevel">IQVDocumentLink.LinkLevel</a> == 5
    """

    link_id_level6 = str
    """
    Element index
    Which [link <a href="#IQVDocumentLink">IQVDocumentLink</a>] section is this element in?
    The id for <a href="#IQVDocumentLink.LinkType">IQVDocumentLink.LinkType</a> == "toc"
    and <a href="#IQVDocumentLink.LinkLevel">IQVDocumentLink.LinkLevel</a> == 6
    """

    link_id_subsection1 = str
    """
    Element index
    Which [link <a href="#IQVDocumentLink">IQVDocumentLink</a>] section is this element in?
    The id for <a href="#IQVDocumentLink.LinkType">IQVDocumentLink.LinkType</a> == "subsection1"
    """

    link_id_subsection2 = str
    """
    Element index
    Which [link <a href="#IQVDocumentLink">IQVDocumentLink</a>] section is this element in?
    The id for <a href="#IQVDocumentLink.LinkType">IQVDocumentLink.LinkType</a> == "subsection2"
    """

    link_id_subsection3 = str
    """
    Element index
    Which [link <a href="#IQVDocumentLink">IQVDocumentLink</a>] section is this element in?
    The id for <a href="#IQVDocumentLink.LinkType">IQVDocumentLink.LinkType</a> == "subsection3"
    """

    OriginalText = str
    """
    text
    """

    parent_id = str
    """
    Element index
    Which item is this element a member of?
    For example, for <a href="#IQVPageROI.Properties">IQVPageROI.Properties</a>, parent_id = <a href="#IQVPageROI.id">IQVPageROI.id</a>
    Possible parents include but are not limited to
    <a href="#IQVDocument">IQVDocument</a><a href="#IQVPageROI">IQVPageROI</a><a href="#IQVDocumentLink">IQVDocumentLink</a>
    SQL code example 1 for usage of index
    <code>
    WHERE parent_id=parent_id AND group_type=group_type
    </code>
    SQL code example 2 for usage of index
    <code>
    WHERE parent_id=parent_id
    </code>
    """

    QC_id = str
    """
    parent process id:
    id of <a href="#IQVDocument.IQVDocumentProcesses">IQVDocument.IQVDocumentProcesses</a> for
    <a href="#IQVDocumentProcess.ProcessType">IQVDocumentProcess.ProcessType</a> == QC
    <a href="#IQVDocumentProcess.id">IQVDocumentProcess.id</a>
    """

    QCType = str
    """
    add/delete/modify
    """

    roi_id = str
    """
    GUID/UUID of the <a href="#IQVPageROI">IQVPageROI</a> that
     has been modified
    """

    seq_num = int
    """
    seq_num in qc change file
    """

    source_system = str
    """
    LM, QC
    """

    UpdatedText = str
    """
    text
    """

    user_id = str
    """
    user id
    """

    def __init__(self):
        self.doc_id = ''
        self.dts = ''
        self.group_type = ''
        self.hierarchy = ''
        self.id = ''
        self.iqv_standard_term = ''
        self.ItemDataType = ''
        self.link_id = ''
        self.link_id_level2 = ''
        self.link_id_level3 = ''
        self.link_id_level4 = ''
        self.link_id_level5 = ''
        self.link_id_level6 = ''
        self.link_id_subsection1 = ''
        self.link_id_subsection2 = ''
        self.link_id_subsection3 = ''
        self.OriginalText = ''
        self.parent_id = ''
        self.QC_id = ''
        self.QCType = ''
        self.roi_id = ''
        self.seq_num = -1
        self.source_system = ''
        self.UpdatedText = ''
        self.user_id = ''
        self.id = str(uuid.uuid1())


class IQVDocumentProcess_db(object):
    """
    Track individual sub-processes, whether they are
    required in the workflow, etc.
    """

    bProcessRequired = bool
    """
    true or false
    """

    doc_id = str
    """
    Element index
    Which document is this element in?
    Top-level id for <a href="#IQVDocument">IQVDocument</a>
    """

    group_type = str
    """
    Element index
    Which item is this element a member of? (name of member = group_type)
    For example, for <a href="#IQVPageROI.Properties">IQVPageROI.Properties</a>, group_type = "Properties"
    Possible parents include but are not limited to
    <a href="#IQVDocument">IQVDocument</a><a href="#IQVPageROI">IQVPageROI</a><a href="#IQVDocumentLink">IQVDocumentLink</a>
    SQL code example 1 for usage of index
    <code>
    WHERE parent_id=parent_id AND group_type=group_type
    </code>
    """

    hierarchy = str
    """
    image,table,paragraph,item,header,footer,roi
    """

    id = str
    """
    GUID/UUID for tracking
    """

    iqv_standard_term = str
    """
    Element index
    If this element is a link or header, what is the standard term?
    There is 0 or 1 iqv_standard_term for each element
    """

    link_id = str
    """
    Element index
    Which [link <a href="#IQVDocumentLink">IQVDocumentLink</a>] section is this element in?
    The id for <a href="#IQVDocumentLink.LinkType">IQVDocumentLink.LinkType</a> == "toc"
    and <a href="#IQVDocumentLink.LinkLevel">IQVDocumentLink.LinkLevel</a> == 1
    """

    link_id_level2 = str
    """
    Element index
    Which [link <a href="#IQVDocumentLink">IQVDocumentLink</a>] section is this element in?
    The id for <a href="#IQVDocumentLink.LinkType">IQVDocumentLink.LinkType</a> == "toc"
    and <a href="#IQVDocumentLink.LinkLevel">IQVDocumentLink.LinkLevel</a> == 2
    """

    link_id_level3 = str
    """
    Element index
    Which [link <a href="#IQVDocumentLink">IQVDocumentLink</a>] section is this element in?
    The id for <a href="#IQVDocumentLink.LinkType">IQVDocumentLink.LinkType</a> == "toc"
    and <a href="#IQVDocumentLink.LinkLevel">IQVDocumentLink.LinkLevel</a> == 3
    """

    link_id_level4 = str
    """
    Element index
    Which [link <a href="#IQVDocumentLink">IQVDocumentLink</a>] section is this element in?
    The id for <a href="#IQVDocumentLink.LinkType">IQVDocumentLink.LinkType</a> == "toc"
    and <a href="#IQVDocumentLink.LinkLevel">IQVDocumentLink.LinkLevel</a> == 4
    """

    link_id_level5 = str
    """
    Element index
    Which [link <a href="#IQVDocumentLink">IQVDocumentLink</a>] section is this element in?
    The id for <a href="#IQVDocumentLink.LinkType">IQVDocumentLink.LinkType</a> == "toc"
    and <a href="#IQVDocumentLink.LinkLevel">IQVDocumentLink.LinkLevel</a> == 5
    """

    link_id_level6 = str
    """
    Element index
    Which [link <a href="#IQVDocumentLink">IQVDocumentLink</a>] section is this element in?
    The id for <a href="#IQVDocumentLink.LinkType">IQVDocumentLink.LinkType</a> == "toc"
    and <a href="#IQVDocumentLink.LinkLevel">IQVDocumentLink.LinkLevel</a> == 6
    """

    link_id_subsection1 = str
    """
    Element index
    Which [link <a href="#IQVDocumentLink">IQVDocumentLink</a>] section is this element in?
    The id for <a href="#IQVDocumentLink.LinkType">IQVDocumentLink.LinkType</a> == "subsection1"
    """

    link_id_subsection2 = str
    """
    Element index
    Which [link <a href="#IQVDocumentLink">IQVDocumentLink</a>] section is this element in?
    The id for <a href="#IQVDocumentLink.LinkType">IQVDocumentLink.LinkType</a> == "subsection2"
    """

    link_id_subsection3 = str
    """
    Element index
    Which [link <a href="#IQVDocumentLink">IQVDocumentLink</a>] section is this element in?
    The id for <a href="#IQVDocumentLink.LinkType">IQVDocumentLink.LinkType</a> == "subsection3"
    """

    parent_id = str
    """
    Element index
    Which item is this element a member of?
    For example, for <a href="#IQVPageROI.Properties">IQVPageROI.Properties</a>, parent_id = <a href="#IQVPageROI.id">IQVPageROI.id</a>
    Possible parents include but are not limited to
    <a href="#IQVDocument">IQVDocument</a><a href="#IQVPageROI">IQVPageROI</a><a href="#IQVDocumentLink">IQVDocumentLink</a>
    SQL code example 1 for usage of index
    <code>
    WHERE parent_id=parent_id AND group_type=group_type
    </code>
    SQL code example 2 for usage of index
    <code>
    WHERE parent_id=parent_id
    </code>
    """

    ProcessEnvironment = str
    """
    dev, test, prod, mobile, etc
    """

    ProcessFinishTime = str
    """
    End time for processing of document datetime string
    """

    ProcessMachineName = str
    """
    name of machine where processing took place
    """

    ProcessName = str
    """
    triage, digitizer, classifier, extractor, finalizer, QC
    """

    ProcessStartTime = str
    """
    Start time for processing of document datetime string
    """

    ProcessType = str
    """
    more detailed info, such as type of QC
    """

    ProcessUserID = str
    """
    name of user process/ user id
    """

    ProcessVersion = str
    """
    Code version, human-readable value, such as 1.0
    """

    ProcessVersionHash = str
    """
    Code version, formal hash value. Object ID for git (source code repo) revision.
    """

    def __init__(self):
        self.bProcessRequired = False
        self.doc_id = ''
        self.group_type = ''
        self.hierarchy = ''
        self.id = ''
        self.iqv_standard_term = ''
        self.link_id = ''
        self.link_id_level2 = ''
        self.link_id_level3 = ''
        self.link_id_level4 = ''
        self.link_id_level5 = ''
        self.link_id_level6 = ''
        self.link_id_subsection1 = ''
        self.link_id_subsection2 = ''
        self.link_id_subsection3 = ''
        self.parent_id = ''
        self.ProcessEnvironment = ''
        self.ProcessFinishTime = ''
        self.ProcessMachineName = ''
        self.ProcessName = ''
        self.ProcessStartTime = ''
        self.ProcessType = ''
        self.ProcessUserID = ''
        self.ProcessVersion = ''
        self.ProcessVersionHash = ''
        self.id = str(uuid.uuid1())


class IQVSubText_db(object):
    """
    Part of string that exhibits a unique <a href="#FontInfo">FontInfo</a>,
    not necessarily a <a href="#segment">segment</a>
    """

    bNoTranslate = bool
    """
    A subtext item that is purely for document formatting
    such as a line break
    """

    doc_id = str
    """
    Element index
    Which document is this element in?
    Top-level id for <a href="#IQVDocument">IQVDocument</a>
    """

    DocumentSequenceIndex = int
    """
    Global sequence index for both <a href="#IQVDocument.DocumentParagraphs">IQVDocument.DocumentParagraphs</a>
     and <a href="#IQVDocument.DocumentTables">IQVDocument.DocumentTables</a>

    Zero-based sequential order index of document part,
    which could be a table or a paragraph.
     This allows tables and paragraphs to be interlaced together
    and in sequential order

    Used in both
    <see cref="P:IQVFileManagerDLL.IQVDigDocumentTable.DocumentSequenceIndex" />
    and
     <see cref="P:IQVFileManagerDLL.IQVDigDocumentParagraph.DocumentSequenceIndex" />
    """

    group_type = str
    """
    Element index
    Which item is this element a member of? (name of member = group_type)
    For example, for <a href="#IQVPageROI.Properties">IQVPageROI.Properties</a>, group_type = "Properties"
    Possible parents include but are not limited to
    <a href="#IQVDocument">IQVDocument</a><a href="#IQVPageROI">IQVPageROI</a><a href="#IQVDocumentLink">IQVDocumentLink</a>
    SQL code example 1 for usage of index
    <code>
    WHERE parent_id=parent_id AND group_type=group_type
    </code>
    """

    hierarchy = str
    """
    image,table,paragraph,item,header,footer,roi
    """

    id = str
    """
    Source document, run id as "paraId" XAttribute. Track
    this so it can be deleted!
    """

    iqv_standard_term = str
    """
    Element index
    If this element is a link or header, what is the standard term?
    There is 0 or 1 iqv_standard_term for each element
    """

    link_id = str
    """
    Element index
    Which [link <a href="#IQVDocumentLink">IQVDocumentLink</a>] section is this element in?
    The id for <a href="#IQVDocumentLink.LinkType">IQVDocumentLink.LinkType</a> == "toc"
    and <a href="#IQVDocumentLink.LinkLevel">IQVDocumentLink.LinkLevel</a> == 1
    """

    link_id_level2 = str
    """
    Element index
    Which [link <a href="#IQVDocumentLink">IQVDocumentLink</a>] section is this element in?
    The id for <a href="#IQVDocumentLink.LinkType">IQVDocumentLink.LinkType</a> == "toc"
    and <a href="#IQVDocumentLink.LinkLevel">IQVDocumentLink.LinkLevel</a> == 2
    """

    link_id_level3 = str
    """
    Element index
    Which [link <a href="#IQVDocumentLink">IQVDocumentLink</a>] section is this element in?
    The id for <a href="#IQVDocumentLink.LinkType">IQVDocumentLink.LinkType</a> == "toc"
    and <a href="#IQVDocumentLink.LinkLevel">IQVDocumentLink.LinkLevel</a> == 3
    """

    link_id_level4 = str
    """
    Element index
    Which [link <a href="#IQVDocumentLink">IQVDocumentLink</a>] section is this element in?
    The id for <a href="#IQVDocumentLink.LinkType">IQVDocumentLink.LinkType</a> == "toc"
    and <a href="#IQVDocumentLink.LinkLevel">IQVDocumentLink.LinkLevel</a> == 4
    """

    link_id_level5 = str
    """
    Element index
    Which [link <a href="#IQVDocumentLink">IQVDocumentLink</a>] section is this element in?
    The id for <a href="#IQVDocumentLink.LinkType">IQVDocumentLink.LinkType</a> == "toc"
    and <a href="#IQVDocumentLink.LinkLevel">IQVDocumentLink.LinkLevel</a> == 5
    """

    link_id_level6 = str
    """
    Element index
    Which [link <a href="#IQVDocumentLink">IQVDocumentLink</a>] section is this element in?
    The id for <a href="#IQVDocumentLink.LinkType">IQVDocumentLink.LinkType</a> == "toc"
    and <a href="#IQVDocumentLink.LinkLevel">IQVDocumentLink.LinkLevel</a> == 6
    """

    link_id_subsection1 = str
    """
    Element index
    Which [link <a href="#IQVDocumentLink">IQVDocumentLink</a>] section is this element in?
    The id for <a href="#IQVDocumentLink.LinkType">IQVDocumentLink.LinkType</a> == "subsection1"
    """

    link_id_subsection2 = str
    """
    Element index
    Which [link <a href="#IQVDocumentLink">IQVDocumentLink</a>] section is this element in?
    The id for <a href="#IQVDocumentLink.LinkType">IQVDocumentLink.LinkType</a> == "subsection2"
    """

    link_id_subsection3 = str
    """
    Element index
    Which [link <a href="#IQVDocumentLink">IQVDocumentLink</a>] section is this element in?
    The id for <a href="#IQVDocumentLink.LinkType">IQVDocumentLink.LinkType</a> == "subsection3"
    """

    OuterXml = str
    """
    For easy reconstruction of the element
    """

    parent_id = str
    """
    Element index
    Which item is this element a member of?
    For example, for <a href="#IQVPageROI.Properties">IQVPageROI.Properties</a>, parent_id = <a href="#IQVPageROI.id">IQVPageROI.id</a>
    Possible parents include but are not limited to
    <a href="#IQVDocument">IQVDocument</a><a href="#IQVPageROI">IQVPageROI</a><a href="#IQVDocumentLink">IQVDocumentLink</a>
    SQL code example 1 for usage of index
    <code>
    WHERE parent_id=parent_id AND group_type=group_type
    </code>
    SQL code example 2 for usage of index
    <code>
    WHERE parent_id=parent_id
    </code>
    """

    parent2LocalName = str
    """
    This is "t"
    Parent2 is "r"
    Grandparent is "p", but may be "hyperlink" or other container
    """

    reservedTypeVal = int
    """
    Is this a reserved type

      w:t text
      DEFAULT=0,

     <br /> or w:br
     LINE_BREAK=1,

      \t or w:tab
     TAB=2,

      w:fldChar
     FIELD_CHAR=3,

      w:instrText
     INSTR_TEXT=4
    """

    runElementName = str
    """
    type of Word Run element
    """

    sequence = int
    """
    numeric sequence zero-based
    """

    startCharIndex = int
    """
    Starting char index for the entire paragraph, zero-based
    """

    strText = str
    """
    Main text element of this data structure
    """

    strTranslatedText = str
    """
    Main text element of this data structure, translated
    """

    Value = str
    """
    Value
    """

    def __init__(self):
        self.bNoTranslate = False
        self.doc_id = ''
        self.DocumentSequenceIndex = -1
        self.group_type = ''
        self.hierarchy = ''
        self.id = ''
        self.iqv_standard_term = ''
        self.link_id = ''
        self.link_id_level2 = ''
        self.link_id_level3 = ''
        self.link_id_level4 = ''
        self.link_id_level5 = ''
        self.link_id_level6 = ''
        self.link_id_subsection1 = ''
        self.link_id_subsection2 = ''
        self.link_id_subsection3 = ''
        self.OuterXml = ''
        self.parent_id = ''
        self.parent2LocalName = ''
        self.reservedTypeVal = -1
        self.runElementName = ''
        self.sequence = -1
        self.startCharIndex = -1
        self.strText = ''
        self.strTranslatedText = ''
        self.Value = ''
        self.id = str(uuid.uuid1())


class IQVDocumentFeedbackQC_db(object):
    """
    
    """

    bIsActive = bool
    """
    is active
    """

    doc_id = str
    """
    Element index
    Which document is this element in?
    Top-level id for <a href="#IQVDocument">IQVDocument</a>
    """

    documentFilePath = str
    """
    directory
    """

    fileName = str
    """
    source filename
    """

    group_type = str
    """
    Element index
    Which item is this element a member of? (name of member = group_type)
    For example, for <a href="#IQVPageROI.Properties">IQVPageROI.Properties</a>, group_type = "Properties"
    Possible parents include but are not limited to
    <a href="#IQVDocument">IQVDocument</a><a href="#IQVPageROI">IQVPageROI</a><a href="#IQVDocumentLink">IQVDocumentLink</a>
    SQL code example 1 for usage of index
    <code>
    WHERE parent_id=parent_id AND group_type=group_type
    </code>
    """

    hierarchy = str
    """
    image,table,paragraph,item,header,footer,roi
    """

    id = str
    """
    unique document id for feedback
    """

    iqv_standard_term = str
    """
    Element index
    If this element is a link or header, what is the standard term?
    There is 0 or 1 iqv_standard_term for each element
    """

    link_id = str
    """
    Element index
    Which [link <a href="#IQVDocumentLink">IQVDocumentLink</a>] section is this element in?
    The id for <a href="#IQVDocumentLink.LinkType">IQVDocumentLink.LinkType</a> == "toc"
    and <a href="#IQVDocumentLink.LinkLevel">IQVDocumentLink.LinkLevel</a> == 1
    """

    link_id_level2 = str
    """
    Element index
    Which [link <a href="#IQVDocumentLink">IQVDocumentLink</a>] section is this element in?
    The id for <a href="#IQVDocumentLink.LinkType">IQVDocumentLink.LinkType</a> == "toc"
    and <a href="#IQVDocumentLink.LinkLevel">IQVDocumentLink.LinkLevel</a> == 2
    """

    link_id_level3 = str
    """
    Element index
    Which [link <a href="#IQVDocumentLink">IQVDocumentLink</a>] section is this element in?
    The id for <a href="#IQVDocumentLink.LinkType">IQVDocumentLink.LinkType</a> == "toc"
    and <a href="#IQVDocumentLink.LinkLevel">IQVDocumentLink.LinkLevel</a> == 3
    """

    link_id_level4 = str
    """
    Element index
    Which [link <a href="#IQVDocumentLink">IQVDocumentLink</a>] section is this element in?
    The id for <a href="#IQVDocumentLink.LinkType">IQVDocumentLink.LinkType</a> == "toc"
    and <a href="#IQVDocumentLink.LinkLevel">IQVDocumentLink.LinkLevel</a> == 4
    """

    link_id_level5 = str
    """
    Element index
    Which [link <a href="#IQVDocumentLink">IQVDocumentLink</a>] section is this element in?
    The id for <a href="#IQVDocumentLink.LinkType">IQVDocumentLink.LinkType</a> == "toc"
    and <a href="#IQVDocumentLink.LinkLevel">IQVDocumentLink.LinkLevel</a> == 5
    """

    link_id_level6 = str
    """
    Element index
    Which [link <a href="#IQVDocumentLink">IQVDocumentLink</a>] section is this element in?
    The id for <a href="#IQVDocumentLink.LinkType">IQVDocumentLink.LinkType</a> == "toc"
    and <a href="#IQVDocumentLink.LinkLevel">IQVDocumentLink.LinkLevel</a> == 6
    """

    link_id_subsection1 = str
    """
    Element index
    Which [link <a href="#IQVDocumentLink">IQVDocumentLink</a>] section is this element in?
    The id for <a href="#IQVDocumentLink.LinkType">IQVDocumentLink.LinkType</a> == "subsection1"
    """

    link_id_subsection2 = str
    """
    Element index
    Which [link <a href="#IQVDocumentLink">IQVDocumentLink</a>] section is this element in?
    The id for <a href="#IQVDocumentLink.LinkType">IQVDocumentLink.LinkType</a> == "subsection2"
    """

    link_id_subsection3 = str
    """
    Element index
    Which [link <a href="#IQVDocumentLink">IQVDocumentLink</a>] section is this element in?
    The id for <a href="#IQVDocumentLink.LinkType">IQVDocumentLink.LinkType</a> == "subsection3"
    """

    parent_id = str
    """
    Element index
    Which item is this element a member of?
    For example, for <a href="#IQVPageROI.Properties">IQVPageROI.Properties</a>, parent_id = <a href="#IQVPageROI.id">IQVPageROI.id</a>
    Possible parents include but are not limited to
    <a href="#IQVDocument">IQVDocument</a><a href="#IQVPageROI">IQVPageROI</a><a href="#IQVDocumentLink">IQVDocumentLink</a>
    SQL code example 1 for usage of index
    <code>
    WHERE parent_id=parent_id AND group_type=group_type
    </code>
    SQL code example 2 for usage of index
    <code>
    WHERE parent_id=parent_id
    </code>
    """

    source_system = str
    """
    LM, QC, etc.
    """

    timeCreated = str
    """
    unique document id for feedback
    """

    timeUpdated = str
    """
    unique document id for feedback
    """

    userId = str
    """
    user
    """

    def __init__(self):
        self.bIsActive = False
        self.doc_id = ''
        self.documentFilePath = ''
        self.fileName = ''
        self.group_type = ''
        self.hierarchy = ''
        self.id = ''
        self.iqv_standard_term = ''
        self.link_id = ''
        self.link_id_level2 = ''
        self.link_id_level3 = ''
        self.link_id_level4 = ''
        self.link_id_level5 = ''
        self.link_id_level6 = ''
        self.link_id_subsection1 = ''
        self.link_id_subsection2 = ''
        self.link_id_subsection3 = ''
        self.parent_id = ''
        self.source_system = ''
        self.timeCreated = ''
        self.timeUpdated = ''
        self.userId = ''
        self.id = str(uuid.uuid1())


class IQVDocumentFeedbackResults_db(object):
    """
    Class that supports PUT Attributes
     for all instances of feedback;
    also supports POST
    """

    alcoac_check_composite_score = float
    """
    confidence score from 0-100; zero is lowest, 100 is highest
    """

    alcoac_check_composite_score_confidence = float
    """
    confidence score from 0-100; zero is lowest, 100 is highest
    """

    amendment_number = str
    """
    Y or N--is amendment? as string
    """

    blinded = bool
    """
    on post, true/false, default to true (document is NOT unblinded)
    """

    country = str
    """
    if not core-level
    """

    customer = str
    """
    Customer
    """

    date_time_stamp = str
    """
    14-character datetime string as YYYYMMDDHHMMSS
    default is UTC time zone
    """

    doc_id = str
    """
    Element index
    Which document is this element in?
    Top-level id for <a href="#IQVDocument">IQVDocument</a>
    """

    document_class = str
    """
    study/core;country;site
    """

    document_composite_confidence = float
    """
    confidence score from 0-100; zero is lowest, 100 is highest
    """

    document_date = str
    """
    8-character date string as YYYYMMDD
    For AI, the selected date (in accordance with
     top-1 classification and corresponding date guidance) is
    posted here in the document_date
    """

    document_date_confidence = float
    """
    confidence score from 0-100; zero is lowest, 100 is highest
    """

    document_date_type = str
    """
    type of date used
    """

    document_id = str
    """
    id for this document resource
    """

    document_rejected = str
    """
    false if document was NOT rejected (assume based on image quality)
    true if document was REJECTED based on image quality
    """

    document_status = str
    """
    final, draft, etc.
    """

    draft_number = str
    """
    draft indicator as string
    """

    environment = str
    """
    dev, svt, uat, etc. or other environment settings
    """

    expiry_date = str
    """
    Secondary date to <see cref="P:IQVFileManagerDLL.IQVDocumentFeedbackResults_db.document_date" />
    8-character date string as YYYYMMDD
    This is a separate, additional date to
     <see cref="P:IQVFileManagerDLL.IQVDocumentFeedbackResults_db.document_date" />.
    This is optional and only applied to specific
     document classifications
    """

    expiry_date_confidence = float
    """
    Secondary date to <see cref="P:IQVFileManagerDLL.IQVDocumentFeedbackResults_db.document_date" />
    confidence score from 0-100; zero is lowest, 100 is highest
    """

    feedback_source = str
    """
    post = initial post of document
    user = initial etmf user feedback
    rimqc = records management qc
    filereview = file review done after 3-6 months
    ai = ai engine (optional to align)
    """

    feedback_source_version = str
    """
    version of AI (1.1.0), etc
    """

    group_type = str
    """
    Element index
    Which item is this element a member of? (name of member = group_type)
    For example, for <a href="#IQVPageROI.Properties">IQVPageROI.Properties</a>, group_type = "Properties"
    Possible parents include but are not limited to
    <a href="#IQVDocument">IQVDocument</a><a href="#IQVPageROI">IQVPageROI</a><a href="#IQVDocumentLink">IQVDocumentLink</a>
    SQL code example 1 for usage of index
    <code>
    WHERE parent_id=parent_id AND group_type=group_type
    </code>
    """

    hierarchy = str
    """
    image,table,paragraph,item,header,footer,roi
    """

    id = str
    """
    id for this result set
    """

    indication = str
    """
    indication of clinical trials study
    """

    iqv_standard_term = str
    """

    """

    iqvdata = str
    """
    JSON string for data returned
    """

    language = str
    """
    Language identifier
     3-character string
    ISO 639-2 Code
    e.g., eng for English
    """

    language_confidence = float
    """
    confidence score from 0-100; zero is lowest, 100 is highest
    """

    link_id = str
    """
    Element index
    Which [link <a href="#IQVDocumentLink">IQVDocumentLink</a>] section is this element in?
    The id for <a href="#IQVDocumentLink.LinkType">IQVDocumentLink.LinkType</a> == "toc"
    and <a href="#IQVDocumentLink.LinkLevel">IQVDocumentLink.LinkLevel</a> == 1
    """

    link_id_level2 = str
    """
    Element index
    Which [link <a href="#IQVDocumentLink">IQVDocumentLink</a>] section is this element in?
    The id for <a href="#IQVDocumentLink.LinkType">IQVDocumentLink.LinkType</a> == "toc"
    and <a href="#IQVDocumentLink.LinkLevel">IQVDocumentLink.LinkLevel</a> == 2
    """

    link_id_level3 = str
    """
    Element index
    Which [link <a href="#IQVDocumentLink">IQVDocumentLink</a>] section is this element in?
    The id for <a href="#IQVDocumentLink.LinkType">IQVDocumentLink.LinkType</a> == "toc"
    and <a href="#IQVDocumentLink.LinkLevel">IQVDocumentLink.LinkLevel</a> == 3
    """

    link_id_level4 = str
    """
    Element index
    Which [link <a href="#IQVDocumentLink">IQVDocumentLink</a>] section is this element in?
    The id for <a href="#IQVDocumentLink.LinkType">IQVDocumentLink.LinkType</a> == "toc"
    and <a href="#IQVDocumentLink.LinkLevel">IQVDocumentLink.LinkLevel</a> == 4
    """

    link_id_level5 = str
    """
    Element index
    Which [link <a href="#IQVDocumentLink">IQVDocumentLink</a>] section is this element in?
    The id for <a href="#IQVDocumentLink.LinkType">IQVDocumentLink.LinkType</a> == "toc"
    and <a href="#IQVDocumentLink.LinkLevel">IQVDocumentLink.LinkLevel</a> == 5
    """

    link_id_level6 = str
    """
    Element index
    Which [link <a href="#IQVDocumentLink">IQVDocumentLink</a>] section is this element in?
    The id for <a href="#IQVDocumentLink.LinkType">IQVDocumentLink.LinkType</a> == "toc"
    and <a href="#IQVDocumentLink.LinkLevel">IQVDocumentLink.LinkLevel</a> == 6
    """

    link_id_subsection1 = str
    """
    Element index
    Which [link <a href="#IQVDocumentLink">IQVDocumentLink</a>] section is this element in?
    The id for <a href="#IQVDocumentLink.LinkType">IQVDocumentLink.LinkType</a> == "subsection1"
    """

    link_id_subsection2 = str
    """
    Element index
    Which [link <a href="#IQVDocumentLink">IQVDocumentLink</a>] section is this element in?
    The id for <a href="#IQVDocumentLink.LinkType">IQVDocumentLink.LinkType</a> == "subsection2"
    """

    link_id_subsection3 = str
    """
    Element index
    Which [link <a href="#IQVDocumentLink">IQVDocumentLink</a>] section is this element in?
    The id for <a href="#IQVDocumentLink.LinkType">IQVDocumentLink.LinkType</a> == "subsection3"
    """

    molecule_device = str
    """
    molecule or device of clinical trials study
    """

    name = str
    """
    first/last name in accordance with site personnel list;
    should match site personnel list
    """

    name_confidence = float
    """
    confidence score from 0-100; zero is lowest, 100 is highest
    """

    parent_id = str
    """
    Element index
    Which item is this element a member of?
    For example, for <a href="#IQVPageROI.Properties">IQVPageROI.Properties</a>, parent_id = <a href="#IQVPageROI.id">IQVPageROI.id</a>
    Possible parents include but are not limited to
    <a href="#IQVDocument">IQVDocument</a><a href="#IQVPageROI">IQVPageROI</a><a href="#IQVDocumentLink">IQVDocumentLink</a>
    SQL code example 1 for usage of index
    <code>
    WHERE parent_id=parent_id AND group_type=group_type
    </code>
    SQL code example 2 for usage of index
    <code>
    WHERE parent_id=parent_id
    </code>
    """

    post_data = str
    """
    Open-ended field to handle extra data
    """

    priority = str
    """
    on post, priority 0 - 5
    0 is default, 5 is high priority
    """

    project_id = str
    """
    Project ID
    """

    protocol = str
    """
    Protocol Number
    """

    received_date = str
    """
    YYYYMMDD from user input
    """

    ref_id = str
    """
    Some value to help uniquely identify this document resource. The
    value should be of type <see cref="P:IQVFileManagerDLL.IQVDocumentFeedbackResults_db.ref_id_type" />.
     Example: ref_id_type=doc_id; ref_id=1111-aaaa-bbbb-cccc
    Example: ref_id_type=protocol_number; ref_id=P123456
    In the case of ref_id_type other than doc_id, additional information
    may be required to uniquely identify the document, such as version.
    """

    ref_id_type = str
    """
    Used in conjunction with <see cref="P:IQVFileManagerDLL.IQVDocumentFeedbackResults_db.ref_id" />.
    The ref_id is some value to help uniquely identify this document resource.
     The ref_id_type is the value type (domain) of ref_id.
    Example: ref_id_type=doc_id; ref_id=1111-aaaa-bbbb-cccc
    Example: ref_id_type=protocol_number; ref_id=P123456
    In the case of ref_id_type other than doc_id, additional information
    may be required to uniquely identify the document, such as version.
    """

    site = str
    """
    if site-level, else blank
    """

    source_filename = str
    """
    original filename for historical purposes
    """

    source_system = str
    """
    system connecting to AI
    """

    sponsor = str
    """
    Sponsor of trial
    """

    study_status = str
    """
    status of clinical trials study
    """

    subject = str
    """
    extra information about the document
    """

    subject_confidence = float
    """
    confidence score from 0-100; zero is lowest, 100 is highest
    """

    tmf_environment = str
    """
    Wingspan, Documentum, etc.
    """

    tmf_ibr = str
    """
    on post, expected tmf
    """

    user_id = str
    """
    user id for submitter
    """

    version_number = str
    """
    Version number as string
    """

    def __init__(self):
        self.alcoac_check_composite_score = 0.0
        self.alcoac_check_composite_score_confidence = 0.0
        self.amendment_number = ''
        self.blinded = False
        self.country = ''
        self.customer = ''
        self.date_time_stamp = ''
        self.doc_id = ''
        self.document_class = ''
        self.document_composite_confidence = 0.0
        self.document_date = ''
        self.document_date_confidence = 0.0
        self.document_date_type = ''
        self.document_id = ''
        self.document_rejected = ''
        self.document_status = ''
        self.draft_number = ''
        self.environment = ''
        self.expiry_date = ''
        self.expiry_date_confidence = 0.0
        self.feedback_source = ''
        self.feedback_source_version = ''
        self.group_type = ''
        self.hierarchy = ''
        self.id = ''
        self.indication = ''
        self.iqv_standard_term = ''
        self.iqvdata = ''
        self.language = ''
        self.language_confidence = 0.0
        self.link_id = ''
        self.link_id_level2 = ''
        self.link_id_level3 = ''
        self.link_id_level4 = ''
        self.link_id_level5 = ''
        self.link_id_level6 = ''
        self.link_id_subsection1 = ''
        self.link_id_subsection2 = ''
        self.link_id_subsection3 = ''
        self.molecule_device = ''
        self.name = ''
        self.name_confidence = 0.0
        self.parent_id = ''
        self.post_data = ''
        self.priority = ''
        self.project_id = ''
        self.protocol = ''
        self.received_date = ''
        self.ref_id = ''
        self.ref_id_type = ''
        self.site = ''
        self.source_filename = ''
        self.source_system = ''
        self.sponsor = ''
        self.study_status = ''
        self.subject = ''
        self.subject_confidence = 0.0
        self.tmf_environment = ''
        self.tmf_ibr = ''
        self.user_id = ''
        self.version_number = ''
        self.id = str(uuid.uuid1())


class IQVLanguageMapping_db(object):
    """
    Prior information about each language
    based on historical documents, such as
    counts
    """

    HistoricalCount = int
    """
    Count in historical document set
    """

    HistoricalCountWeight = float
    """
    Normalized Count in historical document set,
    with total=1.0
    """

    id = str
    """
    id
    """

    script_list = str
    """
    Script or writing system for the language
    There may be more than one per language
    """

    def __init__(self):
        self.HistoricalCount = -1
        self.HistoricalCountWeight = 0.0
        self.id = ''
        self.script_list = ''
        self.id = str(uuid.uuid1())


class LanguageCode_db(object):
    """
    
    """

    code = str
    """
    2-character code
    """

    description = str
    """
    Description of language
    """

    eTMFCode = str
    """
    Special code for eTMF if necessary
    """

    fourLetterCode = str
    """
    en-US, es-ES
    """

    id = str
    """

    """

    ReleaseVersionAvailability = int
    """
    Major release version
    """

    tesseractCode = str
    """
    standard code for tesseract, such as 3-char code
    """

    def __init__(self):
        self.code = ''
        self.description = ''
        self.eTMFCode = ''
        self.fourLetterCode = ''
        self.id = ''
        self.ReleaseVersionAvailability = -1
        self.tesseractCode = ''
        self.id = str(uuid.uuid1())


class IQVDocumentMapping_db(object):
    """
    
    """

    Additional_instructions = str
    """
    Subject line/ Additional instructions   updated instructions
     which may impact the subject field (upcoming config update)
        e.g., 'Enter topic of meeting in subject field if applicable.'
    """

    CONTENT_TYPE = str
    """
    ELVIS artifact names(source for the machine learning)
       e.g., 'DOC'
    """

    DateGuidance = str
    """
    Date identifier, what type of date to use for the document date,
    such as:
    Signature Date
    File Date
    Version Date
    Meeting Start Date
    """

    DateGuidanceSecondary = str
    """
    This is secondary to <see cref="P:IQVFileManagerDLL.IQVDocumentMapping_db.DateGuidance" />. If the
    preferred date of <see cref="P:IQVFileManagerDLL.IQVDocumentMapping_db.DateGuidance" /> is not
     found, then this fallback date is used.
    Date identifier, what type of date to use for the document date,
    such as:
    Signature Date
    File Date
    Version Date
    Meeting Start Date
    """

    DIA_KEY = str
    """
    ELVIS artifact names(source for the machine learning)
      e.g., '01.05.03'
    """

    DOC_ABBREVIATION = str
    """
    ELVIS artifact names(source for the machine learning)
      e.g., 'PM-SponsMtgMin'
    """

    DOC_ARTIFACT = str
    """
    ELVIS artifact names(source for the machine learning)
      e.g., '03 Project Management- Sponsor Meeting Material'
    """

    DOC_CLASS = str
    """
    ELVIS artifact names(source for the machine learning)
      e.g., 'Core'
    """

    DOC_COUNT = int
    """
    ELVIS historical counts	
    e.g., 75234
    """

    DOC_COUNT_CURRENT = int
    """
    Wingspan current counts	
    e.g., 75234
    """

    DOC_SECTION = str
    """
    ELVIS artifact names(source for the machine learning)
      e.g., '05 General'
    """

    DOC_ZONE = str
    """
    ELVIS artifact names(source for the machine learning)
      e.g., '01 Trial Management'
    """

    Document_Description = str
    """
    Description of document
    """

    ExpirationDateExpected = int
    """
    This is separate from <see cref="P:IQVFileManagerDLL.IQVDocumentMapping_db.DateGuidance" />. If the
    expiration date is expected for this document
     classification, value = 1.
    If no expiration date is expected, value = 0.
    """

    Full_Classification_Historical = str
    """
    ELVIS classification Zone.Section.Artifact.Abbreviation
    as XX.XX.XX.Abbreviation
    artifact names(source for the machine learning)
      e.g., '01.05.03.PM-SponsMtgMin'
    e.g., '05.04.09.AlertLtr_SubmPack'
    """

    Full_Classification_Wingspan = str
    """
    Derived from <see cref="P:IQVFileManagerDLL.IQVDocumentMapping_db.Wingspan_Doc_ID" /> PLUS <see cref="P:IQVFileManagerDLL.IQVDocumentMapping_db.Subtype" />
    Wingspan document ID(which also determines level (study, country, site)
    PLUS Subtype if exists
    Add a period '.' delimiter if the subtype exists
    e.g., '100.58'
    e.g., '105.44.Alert Letter Submission Package'
    """

    id = str
    """

    """

    MLClassificationGroup = str
    """
    In MLGroup matrix, the output of the classifier.
     e.g., 'CV' for all of the following {05.02.04.P-InvCV,
    05.02.05.Sub-InvCV,05.02.06.OtherCV,08.01.07.LabDirCV,01.02.02.ProjTeamCV}
    """

    MLClassificationRole = str
    """
    In MLGroup matrix, the role of the individual.
    e.g., PI,
    SubInv,
    Other,
    HeadOfFacility,
    ProjTeam
    """

    MLConfusionCluster = str
    """
    Confusion cluster/group that this predicted class label belongs to.
    If a document is predicted as this class label, and a
     MLConfusionCluster exists, then we have the option to push the
     document to the specialized ConfusionCluster Model for
    improved classification.
    The MLConfusionCluster should be a uuid, that is linked
    to the specialized ConfusionCluster Model
    """

    Subject = str
    """
    suggested subject line, for specific docs that do not have a subtype.
     This is only applicable for 5 doc types
    """

    Subtype = str
    """
    Wingspan applicable subtype
      e.g., 'Minutes'
    """

    TargetSystemName = str
    """
    Name of target system
    Prevents ambiguity when handle multiple target systems with same model and mapping
    """

    TargetSystemVersion = str
    """
    Version of target system
    Prevents ambiguity when handle multiple target systems with same model and mapping
    """

    Wingspan_DIA = str
    """
    DIA reference number
        e.g., '01.05.03'
    """

    Wingspan_Doc_ID = str
    """
    Wingspan document ID(which also determines level (study, country, site)
        e.g., '100.58'
    """

    Wingspan_doc_type = str
    """
    Document type
     e.g., 'Other Trial Management Meeting Material (Study Level)'
    """

    def __init__(self):
        self.Additional_instructions = ''
        self.CONTENT_TYPE = ''
        self.DateGuidance = ''
        self.DateGuidanceSecondary = ''
        self.DIA_KEY = ''
        self.DOC_ABBREVIATION = ''
        self.DOC_ARTIFACT = ''
        self.DOC_CLASS = ''
        self.DOC_COUNT = -1
        self.DOC_COUNT_CURRENT = -1
        self.DOC_SECTION = ''
        self.DOC_ZONE = ''
        self.Document_Description = ''
        self.ExpirationDateExpected = -1
        self.Full_Classification_Historical = ''
        self.Full_Classification_Wingspan = ''
        self.id = ''
        self.MLClassificationGroup = ''
        self.MLClassificationRole = ''
        self.MLConfusionCluster = ''
        self.Subject = ''
        self.Subtype = ''
        self.TargetSystemName = ''
        self.TargetSystemVersion = ''
        self.Wingspan_DIA = ''
        self.Wingspan_Doc_ID = ''
        self.Wingspan_doc_type = ''
        self.id = str(uuid.uuid1())


class Config_db(object):
    """
    Class for system configuration. Includes machine setup
    as well as AI configuration.
    """

    AIDocQueue_IsAdmin = int
    """
    Using RabbitMQ etmfa_core.aidoc Queue, will this be reading the queue
    for COMPLETE messages
    and handling display of results from the queue? 1=yes, 0=no
    """

    AIDocQueue_IsWorker = int
    """
    Using RabbitMQ etmfa_core.aidoc Queue, will this be reading the queue
    for REQUEST messages
    and handling requests from the queue? 1=yes, 0=no
    """

    AIDocQueue_NumWorkers = int
    """
    Using RabbitMQ etmfa_core.aidoc Queue, will this be reading the queue
    for REQUEST messages
    and handling requests from the queue... How many
    Number of workers to have running at a time
    """

    API_Endpoint = str
    """
    Swagger API Endpoint for POST
     Use this for running a batch
    PD DEV is originally http://ca2spdml01q:9001/pd/api/v1/documents/
    """

    API_Key = str
    """
    Swagger API Key for POST
     Use this for running a batch
    PD DEV is originally ypd_unit_test:!53*URTa$k1j4t^h2~uSseatnai@nr
    """

    bClearWorkingDirectory = int
    """
    true=1 to clear temp storage
    """

    bCorrectRotation = int
    """
    Perform rotation correction?
    """

    bDeleteAllFilesExceptFinalizerOutputFile = bool
    """
    On successful completion of document processing,
    delete all files (except final IQV.XML and the input source file)
    from processing/output directory, if true.
     Do not delete if false.
     Directory for document is listed at
     <a href="#IQVDocument.QDocumentWorkingDirectory">IQVDocument.QDocumentWorkingDirectory</a>
    Parent directory for collection of documents at
    <a href="#Config.OutputDirectory">Config.OutputDirectory</a>
    """

    bDeleteInputSourceFile = bool
    """
    On successful completion of document processing,
    delete the input source file from
     processing/output directory, if true.
     Do not delete if false.
     Directory for document is listed at
     <a href="#IQVDocument.QDocumentWorkingDirectory">IQVDocument.QDocumentWorkingDirectory</a>
    Parent directory for collection of documents at
    <a href="#Config.OutputDirectory">Config.OutputDirectory</a>
    """

    bDeleteWorkingTempDirOnSuccessComplete = int
    """
    -deleteTmp default { get; set; } files used only for intermediate processing and debugging
    """

    bDictionaryBernoulliSingleCounts = int
    """
    Use single counts (Bernoulli)
    """

    bDocumentManagerEXE_CloseAfterProcessDocument = int
    """
    Close form windows after complete (should be true for production server processing)
    """

    bELK_EnableLogging = int
    """
    Enable logging to elasticsearch
    """

    bMSG_EnableMessaging = int
    """
    Use timer to check RabbitMQ
    """

    bMSG_EnableMessaging_CompareProcessing = int
    """
    Use timer to check RabbitMQ
    """

    bMSG_EnableMessaging_Digitizer2Processing = int
    """
    Use timer to check RabbitMQ
    """

    bMSG_EnableMessaging_OMOPGenerate = int
    """
    Use timer to check RabbitMQ
    """

    bMSG_EnableMessaging_OMOPProcessing = int
    """
    Use timer to check RabbitMQ
    """

    bMSG_EnableMessaging_QCFeedbackProcessing = int
    """
    Use timer to check RabbitMQ
    """

    bNoiseGenGreyscale = bool
    """
    Noise Generation settings
    """

    bNoiseGenLegibility = bool
    """
    Noise Generation settings
    """

    bNoiseGenPageBlanks = bool
    """
    Noise Generation settings
    """

    bNoiseGenPageOrientation = bool
    """
    Noise Generation settings
    """

    bNoiseGenPageSequence = bool
    """
    Noise Generation settings
    """

    bOCRRaiseErrorIfScan = int
    """
    Raise error 903 if this is a scanned document
    """

    bOutput_OmopPrefixText = int
    """
    Turn on or off: Text to prepend output file with
    """

    bOutput_PrefixText = int
    """
    Turn on or off: Text to prepend output file with
    """

    bOutput_QCFeedbackPrefixText = int
    """
    QC Ingest
    -bqcprefix
    """

    bOutput_ToMetricsDir = int
    """
    Turn on or off: Directory of metrics files
    """

    bProvideRemoteService = int
    """
    1 or 0
    """

    bRunInternalOCRProcesses = int
    """
    Use internal OCR (.NET calling tesseract)
    """

    bRunPyIPOCRProcesses = int
    """
    Use python--default is no
    """

    bTMFGTOutputConstrained = bool
    """
    Analysis output for GT matching to TMF matrix items
    """

    bUseDBConnection = int
    """
    Database settings
    """

    bUseMTServer = int
    """
    1 to call in to API
    """

    bUseSegServer = int
    """
    1 to call in to API
    """

    bWatchLog_EnableWebserverRequests = int
    """
    Use timer to check Watch Log
    """

    ConfigFilename = str
    """
    Read settings from config file
    """

    CorpusLevel = int
    """
    -corpusLevel Training Level for which dictionary items to train on;
    which to include and which to not include
    """

    CorrectRotation_RotationIncrementDegrees = float
    """
    Increment to check in degrees
    """

    CorrectRotation_RotationRangeDegrees = float
    """
    Range from 0 as mean, in each direction (positive and negative), in degrees
    """

    CountryMappingFilename = str
    """
    Country Mapping list of <a href="#IQVCountryMapping">IQVCountryMapping</a>
     which contains for each country
    list of <a href="#IQVLanguageMapping">IQVLanguageMapping</a>
    that includes script and <a href="#LanguageCode">LanguageCode</a>
    """

    CustomHostName = str
    """
    For display purposes, provide code name for this machine
    """

    DataSplit_TestPercent = int
    """
    -testRatio Split dataset into training and test;
    """

    DataSplit_TrainingPercent = int
    """
    -trainRatio Split dataset into training and test;
    """

    DBConn_Database = str
    """
    Database settings
    """

    DBConn_Login = str
    """
    Database settings
    """

    DBConn_Password = str
    """
    Database settings
    """

    DBConn_Server = str
    """
    Database settings
    """

    DebugMode = int
    """
    Default = 0 = no debug, otherwise use this as a code to run
     certain stage of the process. Similar to OUTPUT_LEVEL, but not aligned
    with user outputs.
    Aligns with <a href="#DEBUG_MODE">DEBUG_MODE</a>
    """

    DebugType = int
    """
    Default = 0 = no debug, otherwise use this as a code to run debugging
    """

    DefaultRotation = float
    """
    If pre-determined, what rotation to use for this document? in degrees
    """

    DictionarybRemoveCommonTerms = int
    """
    Yes/No remove common terms (more than stop words)
    """

    DictionarybRemoveSparseTerms = int
    """
    Yes/no remove sparse terms <see cref="P:IQVFileManagerDLL.Config_db.DictionaryRemoveSparseTerms_MinDocCount" />
    """

    DictionaryIncludeAdditionalFeatures = int
    """
    Part of corpus level now separate
    """

    DictionaryIncludeBigrams = int
    """
    text analysis dictionary
    """

    DictionaryIncludeLines = int
    """
    text analysis dictionary
    """

    DictionaryIncludeStopWords = int
    """
    text analysis dictionary
    """

    DictionaryIncludeTrigrams = int
    """
    text analysis dictionary
    """

    DictionaryRemoveCommonTerms_MaxDocCount = int
    """
    Threshold to remove common terms
    """

    DictionaryRemoveSparseTerms_MinDocCount = int
    """
    Threshold to say is sparse term
    """

    Dig1CodePathFilename = str
    """
    Python Dig1 code as in path/tester.py
    """

    Dig1DocID = str
    """
    Unique document ID, used when invoking Dig1
    and passing in the requested doc id for initialization
    of <a href="#IQVDocument">IQVDocument</a>
    """

    DisplayLabel = str
    """
    -label
    """

    DOCANALYSIS_TrainedNaiveBayesLibFilename = str
    """
    For document classification
    """

    DocID = str
    """
    Unique document ID
    """

    DocID1 = str
    """
    Unique document ID1 for compare
    """

    DocID2 = str
    """
    Unique document ID2 for compare
    """

    DocumentManagerEXE = str
    """
    Location on server
    """

    DocumentManagerVersion = str
    """
    Location on server
    """

    DropBox1Dir = str
    """
    Original drop box, gets re-assigned during processing of document
    by external process (translation orchestrator).
    """

    DropBoxWebUI = str
    """
    Dynamic drop box, assigned during processing of document
    by external process (translation orchestrator).
    """

    ELK_HostName = str
    """
    ELK Logstash/Elasticsearch service
    """

    ELK_Port = int
    """
    ELK Logstash/Elasticsearch service
    """

    ETMFDocumentSource = str
    """
    eTMF Document Source
    """

    ETMFOutputDir = str
    """
    eTMF Document Directory
    """

    ExcelTemplate_SOA = str
    """
    Template for Excel SOA Output
    """

    FileDownloadStartIndex = int
    """
    Download using links; don't know the suggested filename until
    we get there. So use a known index rather than calculating by filename
    """

    flow_id = str
    """
    flow parameter for service workflow management
    """

    flow_name = str
    """
    flow parameter for service workflow management
    """

    GenerateNoise = int
    """
    0: no action; 1: generate noise according to noise type;
    store results in <see cref="P:IQVFileManagerDLL.Config_db.GroundTruthMasterFilename" />
    """

    GhostscriptEXEFilename = str
    """
    Location on server
    """

    GroundTruthMasterFilename = str
    """
    Master filename for GT
    """

    GroundTruthOutputDirectory = str
    """
    Used when creating/generating noisy documents;
    create new file for each document or document set
    and save file to this directory
    """

    id = str
    """

    """

    ImageProc_BulletImagesDir = str
    """
    Directory of pre-identified bullet images for
     bullet processing
    """

    ImageQC_GreyscaleThreshold = float
    """
    Threshold for ImageQC
    """

    ImageQC_LegibilityThreshold = float
    """
    Threshold for ImageQC
    """

    ImagesDirectory = str
    """
    Where to put images that are embedded in Document;
    -imgdir
    """

    InputDataDirectory = str
    """
    Directory to process
    """

    InputImageFilename = str
    """
    Input processed into an image
    """

    InputRawFilename = str
    """
    Input received by ingester for one page; Typically PDF format
    """

    InputSourceMasterFilename = str
    """
    Input received by ingester for full file; Typically PDF format
    """

    InputWorkingMasterFilename = str
    """
    Input placed in working directory; copy of InputSourceMasterFilename
    """

    IQVDocumentMappingFilename = str
    """
    Filename of list of <a href="#IQVDocumentMapping">IQVDocumentMapping</a> for
     the various document classifications.
    Related <see cref="P:IQVFileManagerDLL.Config_db.CountryMappingFilename" />
    """

    IQVEnvironment = str
    """
    environment/system connection
    """

    IQVXML_DBConn_bUseDBConnection = int
    """
    Database settings
    """

    IQVXML_DBConn_Database = str
    """
    Database settings
    """

    IQVXML_DBConn_Login = str
    """
    Database settings
    """

    IQVXML_DBConn_Password = str
    """
    Database settings
    """

    IQVXML_DBConn_Port = int
    """
    Database settings
    """

    IQVXML_DBConn_Server = str
    """
    Database settings
    """

    IQVXMLInputFilename = str
    """
    IQV.XML input of previous processing
    -iqvxml
    """

    IQVXMLInputFilename2 = str
    """
    IQV.XML input of previous processing for compare
    -iqvxml2
    """

    LanguageAnalysisLib = str
    """
    Do language analysis to auto-detect language
    """

    LocalTopLevelDataDir = str
    """
    To use 2 computers with different drive names
    or paths, use the common top level directory
    (such as eTMF directory)
    """

    LogDirectory = str
    """
    Log output
    """

    LogFilename = str
    """
    Log file in XML format
    """

    MasterFile = int
    """
    Master File of multiple pages;
    If not master, then single page only (slave)
    """

    MasterIQVDocumentListFilename = str
    """
    List of IQVDocument's that are undergoing processing
    """

    MatrixFile = str
    """
    matrix file
    """

    MaxCellsPerPage = int
    """
    Used for CSV/Excel worksheet, to handle very large files.
    Use in conjunction with <see cref="P:IQVFileManagerDLL.Config_db.MaxPagesCoreProcessing_FrontSection" />
    and <see cref="P:IQVFileManagerDLL.Config_db.MaxPagesCoreProcessing_BackSection" />.
     A "page" is a set of rows. This will allow complete row to be processed
    and prevent partial rows. The number of rows per page = MaxCellsPerPage / num_cols,
    with a lower bound of 1 row per page. For a CSV with 110 columns, there
    will be 1 row per page, if MaxCellsPerPage = 100. For a CSV with 25 columns,
    there will be 4 rows per page, if MaxCellsPerPage = 100.
    """

    MaxNumDocsToProcess = int
    """
    Max number of docs to process total -maxdocs
    """

    MaxPagesCoreProcessing_BackSection = int
    """
    For core processing, this is upper bound for number of pages at the
    end of the document. Pages in the middle of the document will not be
     processed (with the exception of QC). For example, if
     <see cref="P:IQVFileManagerDLL.Config_db.MaxPagesCoreProcessing_FrontSection" /> = 3,
    <see cref="P:IQVFileManagerDLL.Config_db.MaxPagesCoreProcessing_BackSection" /> = 2, and the
    document has N=20 pages, only pages
    1, 2, and 3 will be processed in the front section, and 19, 20 in the back
    section (last 2 pages of the document)
    """

    MaxPagesCoreProcessing_FrontSection = int
    """
    For core processing, this is upper bound for number of pages at the
    beginning of the document. Pages in the middle of the document will not be
     processed (with the exception of QC). For example, if
     <see cref="P:IQVFileManagerDLL.Config_db.MaxPagesCoreProcessing_FrontSection" /> = 3,
    <see cref="P:IQVFileManagerDLL.Config_db.MaxPagesCoreProcessing_BackSection" /> = 2, and the
    document has N=20 pages, only pages
    1, 2, and 3 will be processed in the front section, and 19, 20 in the back
    section (last 2 pages of the document)
    """

    MaxPagesToProcess = int
    """
    Max number of pages in a document -maxpages
    """

    MaxPagesToProcessIQVTM = int
    """
    Max number of pages in a document for text mining
    -maxPagesIQVTM
    """

    MaxTimeMinutesPerPage = int
    """
    For each page, interrupt processing if it exceeds
    processing time in minutes past this parameter -maxtime;
    for unlimited time, use -1 value
    """

    MinPixelHeightForOCR = int
    """
    Only process images for OCR  if they meet minimum size requirements, in pixels. Used
    to filter out noise in PDF files
    """

    MinPixelHeightForValidImage = int
    """
    Only save images if they meet minimum size requirements, in pixels. Used
    to filter out noise in PDF files
    """

    MinPixelWidthForOCR = int
    """
    Only process images for OCR if they meet minimum size requirements, in pixels. Used
    to filter out noise in PDF files
    """

    MinPixelWidthForValidImage = int
    """
    Only save images if they meet minimum size requirements, in pixels. Used
    to filter out noise in PDF files
    """

    MSG_ErrorLevelLowerBound = int
    """
    Lower Bound for severity level to be sent to message queue;
    default = 5 <a href="#Q_ERROR_LEVEL.CRITICAL">Q_ERROR_LEVEL.CRITICAL</a>
    """

    MSG_ExchangeIsDurable = int
    """
    AMQP arg 'durable' for exchange;
    expecting true (1)
    """

    MSG_HostName = str
    """
    RabbitMQ service
    """

    MSG_MaxCPU = int
    """
    RabbitMQ service: Will not receive/listen
     for messages if current CPU is above this level
    """

    MSG_MaxRAM = int
    """
    RabbitMQ service: Will not receive/listen
     for messages if current RAM is above this level
    """

    MSG_Password = str
    """
    RabbitMQ service
    """

    MSG_Port = int
    """
    RabbitMQ service
    """

    MSG_QueueIsDurable = int
    """
    AMQP arg 'durable' for queue;
    expecting false (0)
    """

    MSG_User = str
    """
    RabbitMQ service
    """

    MSG_VirtualHost = str
    """
    RabbitMQ service
    """

    MTServer_Endpoint = str
    """
    Translation API
    Translation engine API for bulk document processing.
    Internal API for running XLIFF translation only
    """

    MTServer_LocalPathMapping = str
    """
    Translation API
    Translation engine API for bulk document processing.
    Internal API for running XLIFF translation only
    """

    MTServer_MachineName = str
    """
    Translation API
    Translation engine API for bulk document processing.
    Internal API for running XLIFF translation only
    """

    MTServer_Password = str
    """
    Translation API if HTTPBasicAuth
    """

    MTServer_Port = str
    """
    Translation API
    Translation engine API for bulk document processing.
    Internal API for running XLIFF translation only
    """

    MTServer_SecureHTTP = int
    """
    1 to call in to API with https, 0 with http
    """

    MTServer_SharedDir = str
    """
    Translation API
    Translation engine API for bulk document processing.
    Internal API for running XLIFF translation only
    """

    MTServer_User = str
    """
    Translation API if HTTPBasicAuth
    """

    NLP_CharMatrixDirectory = str
    """
    Language-specific files in this directory for
    character confusion matrices
    """

    NLP_DictionaryDirectory = str
    """
    Language-specific files in this directory for
    dictionary lookup
    """

    NoiseGenMaxRecords = int
    """
    Noise Generation settings
    """

    NoiseGenStartIndex = int
    """
    Noise Generation settings
    """

    NoiseType = int
    """
    For noise generation
    """

    OCR_bUseSpellCheck = int
    """
    Flag to utilize OCR Spell Check or not
    """

    OCR_SpellCheckDirectory = str
    """
    Main directory to keep OCR Spell Check trained engines in; each
    file is labelled using language-specific code
    """

    OCR_UserWordsDirectory = str
    """
    Main directory to keep OCR User Words in; each
    file is labelled using language-specific code
    """

    OMOPUpdateFilename = str
    """
    Updated omop
    -omop
    """

    Output_OmopPrefixText = str
    """
    Text to prepend output file with
    """

    Output_PrefixText = str
    """
    Text to prepend output file with
    """

    Output_QCFeedbackPrefixText = str
    """
    QC Ingest
    -qcprefix
    OutputPrefixText
    """

    Output_ToCompareDir = str
    """
    Directory of compare files
    """

    Output_ToMetricsDir = str
    """
    Directory of metrics files
    """

    OutputDirectory = str
    """
    Persistent output
    """

    OutputFilename = str
    """
    QXML Format
    """

    OutputLevel = int
    """
    processing workflow
    """

    PageIndex = int
    """
    Page index is -1 for master file,
    zero-based for individual pages (slave)
    """

    PerformBatchDocClass = int
    """
    -br arg;
    0=no action
    1=standard action
    """

    PerformDocumentDeconstruction = int
    """
    -docdecon
    """

    PerformDocumentReconstruction = int
    """
    -docrecon
    """

    PerformDuplicateCheck = int
    """
    -dd arg;
    0=no action
    1=standard action
    """

    PerformImageQC = int
    """
    -qc arg;
    0=no action;
    1=standard action;
    """

    PerformMetadata = int
    """
    -md arg;
    0=no action;
    1=standard action
    """

    PerformRotations = int
    """
    -rot arg;
    0=no action;
    1=standard action (4 major rotations at 0,90,180,270 degrees)
    """

    PerformXLIFFReceive = int
    """
    -xliffrecv
    used to update the qiDocument with xliff
    """

    PerformXLIFFSend = int
    """
    -xliffsend
    """

    PerformXLIFFSourceCreation = int
    """
    -xliffsrc
    """

    Priority = int
    """
    processing priority
    """

    ProcessSource = int
    """
    Process either the Input data directory
    or a ground truth list (with filenames)
    """

    PythonEnvironment = str
    """
    Python environment for anaconda activate bat location
    """

    PythonEXEFilename = str
    """
    Python interpreter, or anaconda activate bat location
    """

    QCFeedbackJSONFilename = str
    """
    QC Ingest
    -qcjson
    """

    QCFeedbackRunId = str
    """
    QC Ingest
    -qcrunid
    FeedbackRunId
    """

    Recon_bUseTemplateMatching = int
    """
    Flag to utilize recon template
    """

    Recon_TemplateDirectory = str
    """
    Directory of all Word templates for reconstruction
    Name . numeric code . file extension
    """

    Recon_TemplateFilename = str
    """
    Filename of document template for reconstruction
    """

    RedactionProfileID = str
    """
    Profile ID
    """

    RedactionProfileListingFilename = str
    """
    Filename of all redaction profiles
    """

    RedactionReplacementMethod = str
    """
    label or mask
    """

    RedactionTextMask = str
    """
    if <see cref="P:IQVFileManagerDLL.Config_db.RedactionReplacementMethod" /> == mask, then
    the static text string that is used for every
    replacement
    """

    RedactionTextPrefix = str
    """
    if <see cref="P:IQVFileManagerDLL.Config_db.RedactionReplacementMethod" /> == mask OR
    <see cref="P:IQVFileManagerDLL.Config_db.RedactionReplacementMethod" /> == label
    prefix to apply to every replacement
    (either label or static mask)
    Can be delimiter such as '['
    """

    RedactionTextSuffix = str
    """
    if <see cref="P:IQVFileManagerDLL.Config_db.RedactionReplacementMethod" /> == mask OR
    <see cref="P:IQVFileManagerDLL.Config_db.RedactionReplacementMethod" /> == label
    suffix to apply to every replacement
    (either label or static mask)
    Can be delimiter such as ']'
    """

    RemoteServer_MachineName = str
    """
    Remote Server
    """

    RemoteServer_Port = str
    """
    Remote Server
    """

    RemoteServer_ServerLocalDir = str
    """
    Here is support for Remote Services processing
      Map the local directory from the webserver to the
      SHARED directory that this process can access
    """

    RemoteServer_SharedDir = str
    """
    Here is support for Remote Services processing
      Map the local directory from the webserver to the
      SHARED directory that this process can access
    """

    Rotation = int
    """
    -rotexe: Forced Rotation to be performed on this image
    """

    RunRemote = bool
    """
    Remote settings
    """

    SegmentationType = int
    """
    Baseline = 1 = segmentation;
    0 = no segmentation,
    2 = language-specific segmentation,
    otherwise use this as a code to run debugging
    """

    SegServer_Endpoint = str
    """
    Segmentation API
    Segmentation engine API for bulk document processing.
    Internal API for running Doc Paragraph Segmentation only
    """

    SegServer_LocalPathMapping = str
    """
    Segmentation API
    Segmentation engine API for bulk document processing.
    Internal API for running Doc Paragraph Segmentation only
    """

    SegServer_MachineName = str
    """
    Segmentation API
    Segmentation engine API for bulk document processing.
    Internal API for running Doc Paragraph Segmentation only
    """

    SegServer_Port = str
    """
    Segmentation API
    Segmentation engine API for bulk document processing.
    Internal API for running Doc Paragraph Segmentation only
    """

    SegServer_SecureHTTP = int
    """
    1 to call in to API with https, 0 with http
    """

    SegServer_SharedDir = str
    """
    Segmentation API
    Segmentation engine API for bulk document processing.
    Internal API for running Doc Paragraph Segmentation only
    """

    ShowProgressForm = int
    """
    -showform show progress form on screen
    """

    sofficeLocation = str
    """
    LibreOffice soffice location, including "soffice",
     as in "C:/Program Files/LibreOffice/program/soffice" for
    a Windows machine
    """

    SourceLanguage = str
    """
    -srclang
    Use to constrain the source language for translation
    """

    StandardTemplateIQVXML = str
    """
    Preprocessed standard template file as IQV.XML.
    This IQV.XML will be ingested as input for
     standard template matching for a given document
    """

    TargetLanguage = str
    """
    -tgtlang
    """

    tessdataDir = str
    """
    For tesseract, where is tessdata? (1+ GB directory)
    """

    TesseractEXEFilename = str
    """
    Location on server
    """

    TMFGTOutputConstrained_AvgPages = int
    """
    Analysis output for GT matching to TMF matrix items
    """

    TMFGTOutputConstrained_MinSamples = int
    """
    Analysis output for GT matching to TMF matrix items
    """

    TMFRawDataSourceDirectory = str
    """
    Used when importing raw TMF Data
    """

    TMSServer_Endpoint = str
    """
    Translation Management Service API
    Translation Management Service API for document translation.
    Document Translate : REST endpoints for document translation workflows.
    External API for Mulesoft/Appian full workflow
    """

    TMSServer_Info = str
    """
    Translation Management Service API
    Translation Management Service API for document translation.
    Document Translate : REST endpoints for document translation workflows.
    External API for Mulesoft/Appian full workflow
    """

    TMSServer_MachineName = str
    """
    Translation Management Service API
    Translation Management Service API for document translation.
    Document Translate : REST endpoints for document translation workflows.
    External API for Mulesoft/Appian full workflow
    """

    TMSServer_Port = str
    """
    Translation Management Service API
    Translation Management Service API for document translation.
    Document Translate : REST endpoints for document translation workflows.
    External API for Mulesoft/Appian full workflow
    """

    UserEmail = str
    """
    End User information
    """

    UserID = str
    """
    End User information
    """

    WatchLogCheckIntervalSeconds = float
    """
    Watch Log settings
    """

    WatchLogFilename = str
    """
    Watch Log settings
    """

    WatchLogOutputDir = str
    """
    Watch Log settings for processed output
    """

    WorkingDirectory = str
    """
    Working copy of the file
    """

    XLIFFInputFilename = str
    """
    -xliff
    """

    XLIFFMarkupVersion = str
    """
    XLIFF markup 2.0
    """

    def __init__(self):
        self.AIDocQueue_IsAdmin = -1
        self.AIDocQueue_IsWorker = -1
        self.AIDocQueue_NumWorkers = -1
        self.API_Endpoint = ''
        self.API_Key = ''
        self.bClearWorkingDirectory = -1
        self.bCorrectRotation = -1
        self.bDeleteAllFilesExceptFinalizerOutputFile = False
        self.bDeleteInputSourceFile = False
        self.bDeleteWorkingTempDirOnSuccessComplete = -1
        self.bDictionaryBernoulliSingleCounts = -1
        self.bDocumentManagerEXE_CloseAfterProcessDocument = -1
        self.bELK_EnableLogging = -1
        self.bMSG_EnableMessaging = -1
        self.bMSG_EnableMessaging_CompareProcessing = -1
        self.bMSG_EnableMessaging_Digitizer2Processing = -1
        self.bMSG_EnableMessaging_OMOPGenerate = -1
        self.bMSG_EnableMessaging_OMOPProcessing = -1
        self.bMSG_EnableMessaging_QCFeedbackProcessing = -1
        self.bNoiseGenGreyscale = False
        self.bNoiseGenLegibility = False
        self.bNoiseGenPageBlanks = False
        self.bNoiseGenPageOrientation = False
        self.bNoiseGenPageSequence = False
        self.bOCRRaiseErrorIfScan = -1
        self.bOutput_OmopPrefixText = -1
        self.bOutput_PrefixText = -1
        self.bOutput_QCFeedbackPrefixText = -1
        self.bOutput_ToMetricsDir = -1
        self.bProvideRemoteService = -1
        self.bRunInternalOCRProcesses = -1
        self.bRunPyIPOCRProcesses = -1
        self.bTMFGTOutputConstrained = False
        self.bUseDBConnection = -1
        self.bUseMTServer = -1
        self.bUseSegServer = -1
        self.bWatchLog_EnableWebserverRequests = -1
        self.ConfigFilename = ''
        self.CorpusLevel = -1
        self.CorrectRotation_RotationIncrementDegrees = 0.0
        self.CorrectRotation_RotationRangeDegrees = 0.0
        self.CountryMappingFilename = ''
        self.CustomHostName = ''
        self.DataSplit_TestPercent = -1
        self.DataSplit_TrainingPercent = -1
        self.DBConn_Database = ''
        self.DBConn_Login = ''
        self.DBConn_Password = ''
        self.DBConn_Server = ''
        self.DebugMode = -1
        self.DebugType = -1
        self.DefaultRotation = 0.0
        self.DictionarybRemoveCommonTerms = -1
        self.DictionarybRemoveSparseTerms = -1
        self.DictionaryIncludeAdditionalFeatures = -1
        self.DictionaryIncludeBigrams = -1
        self.DictionaryIncludeLines = -1
        self.DictionaryIncludeStopWords = -1
        self.DictionaryIncludeTrigrams = -1
        self.DictionaryRemoveCommonTerms_MaxDocCount = -1
        self.DictionaryRemoveSparseTerms_MinDocCount = -1
        self.Dig1CodePathFilename = ''
        self.Dig1DocID = ''
        self.DisplayLabel = ''
        self.DOCANALYSIS_TrainedNaiveBayesLibFilename = ''
        self.DocID = ''
        self.DocID1 = ''
        self.DocID2 = ''
        self.DocumentManagerEXE = ''
        self.DocumentManagerVersion = ''
        self.DropBox1Dir = ''
        self.DropBoxWebUI = ''
        self.ELK_HostName = ''
        self.ELK_Port = -1
        self.ETMFDocumentSource = ''
        self.ETMFOutputDir = ''
        self.ExcelTemplate_SOA = ''
        self.FileDownloadStartIndex = -1
        self.flow_id = ''
        self.flow_name = ''
        self.GenerateNoise = -1
        self.GhostscriptEXEFilename = ''
        self.GroundTruthMasterFilename = ''
        self.GroundTruthOutputDirectory = ''
        self.id = ''
        self.ImageProc_BulletImagesDir = ''
        self.ImageQC_GreyscaleThreshold = 0.0
        self.ImageQC_LegibilityThreshold = 0.0
        self.ImagesDirectory = ''
        self.InputDataDirectory = ''
        self.InputImageFilename = ''
        self.InputRawFilename = ''
        self.InputSourceMasterFilename = ''
        self.InputWorkingMasterFilename = ''
        self.IQVDocumentMappingFilename = ''
        self.IQVEnvironment = ''
        self.IQVXML_DBConn_bUseDBConnection = -1
        self.IQVXML_DBConn_Database = ''
        self.IQVXML_DBConn_Login = ''
        self.IQVXML_DBConn_Password = ''
        self.IQVXML_DBConn_Port = -1
        self.IQVXML_DBConn_Server = ''
        self.IQVXMLInputFilename = ''
        self.IQVXMLInputFilename2 = ''
        self.LanguageAnalysisLib = ''
        self.LocalTopLevelDataDir = ''
        self.LogDirectory = ''
        self.LogFilename = ''
        self.MasterFile = -1
        self.MasterIQVDocumentListFilename = ''
        self.MatrixFile = ''
        self.MaxCellsPerPage = -1
        self.MaxNumDocsToProcess = -1
        self.MaxPagesCoreProcessing_BackSection = -1
        self.MaxPagesCoreProcessing_FrontSection = -1
        self.MaxPagesToProcess = -1
        self.MaxPagesToProcessIQVTM = -1
        self.MaxTimeMinutesPerPage = -1
        self.MinPixelHeightForOCR = -1
        self.MinPixelHeightForValidImage = -1
        self.MinPixelWidthForOCR = -1
        self.MinPixelWidthForValidImage = -1
        self.MSG_ErrorLevelLowerBound = -1
        self.MSG_ExchangeIsDurable = -1
        self.MSG_HostName = ''
        self.MSG_MaxCPU = -1
        self.MSG_MaxRAM = -1
        self.MSG_Password = ''
        self.MSG_Port = -1
        self.MSG_QueueIsDurable = -1
        self.MSG_User = ''
        self.MSG_VirtualHost = ''
        self.MTServer_Endpoint = ''
        self.MTServer_LocalPathMapping = ''
        self.MTServer_MachineName = ''
        self.MTServer_Password = ''
        self.MTServer_Port = ''
        self.MTServer_SecureHTTP = -1
        self.MTServer_SharedDir = ''
        self.MTServer_User = ''
        self.NLP_CharMatrixDirectory = ''
        self.NLP_DictionaryDirectory = ''
        self.NoiseGenMaxRecords = -1
        self.NoiseGenStartIndex = -1
        self.NoiseType = -1
        self.OCR_bUseSpellCheck = -1
        self.OCR_SpellCheckDirectory = ''
        self.OCR_UserWordsDirectory = ''
        self.OMOPUpdateFilename = ''
        self.Output_OmopPrefixText = ''
        self.Output_PrefixText = ''
        self.Output_QCFeedbackPrefixText = ''
        self.Output_ToCompareDir = ''
        self.Output_ToMetricsDir = ''
        self.OutputDirectory = ''
        self.OutputFilename = ''
        self.OutputLevel = -1
        self.PageIndex = -1
        self.PerformBatchDocClass = -1
        self.PerformDocumentDeconstruction = -1
        self.PerformDocumentReconstruction = -1
        self.PerformDuplicateCheck = -1
        self.PerformImageQC = -1
        self.PerformMetadata = -1
        self.PerformRotations = -1
        self.PerformXLIFFReceive = -1
        self.PerformXLIFFSend = -1
        self.PerformXLIFFSourceCreation = -1
        self.Priority = -1
        self.ProcessSource = -1
        self.PythonEnvironment = ''
        self.PythonEXEFilename = ''
        self.QCFeedbackJSONFilename = ''
        self.QCFeedbackRunId = ''
        self.Recon_bUseTemplateMatching = -1
        self.Recon_TemplateDirectory = ''
        self.Recon_TemplateFilename = ''
        self.RedactionProfileID = ''
        self.RedactionProfileListingFilename = ''
        self.RedactionReplacementMethod = ''
        self.RedactionTextMask = ''
        self.RedactionTextPrefix = ''
        self.RedactionTextSuffix = ''
        self.RemoteServer_MachineName = ''
        self.RemoteServer_Port = ''
        self.RemoteServer_ServerLocalDir = ''
        self.RemoteServer_SharedDir = ''
        self.Rotation = -1
        self.RunRemote = False
        self.SegmentationType = -1
        self.SegServer_Endpoint = ''
        self.SegServer_LocalPathMapping = ''
        self.SegServer_MachineName = ''
        self.SegServer_Port = ''
        self.SegServer_SecureHTTP = -1
        self.SegServer_SharedDir = ''
        self.ShowProgressForm = -1
        self.sofficeLocation = ''
        self.SourceLanguage = ''
        self.StandardTemplateIQVXML = ''
        self.TargetLanguage = ''
        self.tessdataDir = ''
        self.TesseractEXEFilename = ''
        self.TMFGTOutputConstrained_AvgPages = -1
        self.TMFGTOutputConstrained_MinSamples = -1
        self.TMFRawDataSourceDirectory = ''
        self.TMSServer_Endpoint = ''
        self.TMSServer_Info = ''
        self.TMSServer_MachineName = ''
        self.TMSServer_Port = ''
        self.UserEmail = ''
        self.UserID = ''
        self.WatchLogCheckIntervalSeconds = 0.0
        self.WatchLogFilename = ''
        self.WatchLogOutputDir = ''
        self.WorkingDirectory = ''
        self.XLIFFInputFilename = ''
        self.XLIFFMarkupVersion = ''
        self.id = str(uuid.uuid1())


class FontInfo_db(object):
    """
    Information about the font of the text
    """

    Bold = bool
    """
    Specifies that the text of the text run is to be bold: <b>w:b</b>. This is a toggle property.
    Reference: ECMA-376, 3rd Edition(June, 2011), Fundamentals and Markup Language Reference § 17.3.2.1.
    """

    Caps = bool
    """
    Specifies that any lowercase characters are to be displayed as their uppercase equivalents. It cannot appear with smallCaps in the same text run: <b>w:caps w:val="true"</b>. This is a toggle property.
    Reference: ECMA-376, 3rd Edition(June, 2011), Fundamentals and Markup Language Reference § 17.3.2.5.
    """

    ColorRGB = int
    """
    Specifies the color to be used to display text: <b>w:color w:val="FFFF00"</b>
    Possible attributes are themeColor, themeShade, themeTint, and val.
           The val attribute specifies the color as a hex value in RRGGBB format, or auto may be specified to allow the consuming software to determine the color.
           Reference: ECMA-376, 3rd Edition(June, 2011), Fundamentals and Markup Language Reference § 17.3.2.6.
    """

    doc_id = str
    """
    Element index
    Which document is this element in?
    Top-level id for <a href="#IQVDocument">IQVDocument</a>
    """

    DStrike = bool
    """
    Specifies that the contents are to be displayed with two horizontal lines through each character: w:dstrike w:val="true". It cannot appear with strike in the same text run. This is a toggle property.
    dstrike
    Reference: ECMA-376, 3rd Edition(June, 2011), Fundamentals and Markup Language Reference § 17.3.2.37.
    """

    Emboss = bool
    """
    Specifies that the content should be displayed as if it were embossed, making text appear as if it is raised off of the page: <b>w:emboss w:val="true"</b>. This is a toggle property.
    Embossed text
    Note: The above example specifies emboss, but also sets the color to white: <b>w:emboss</b> OR <b>w:color w:val="FFFFFF"</b>. That seems to be necessary else the result looks like imprint.
    Reference: ECMA-376, 3rd Edition(June, 2011), Fundamentals and Markup Language Reference § 17.3.2.13.
    """

    group_type = str
    """
    Element index
    Which item is this element a member of? (name of member = group_type)
    For example, for <a href="#IQVPageROI.Properties">IQVPageROI.Properties</a>, group_type = "Properties"
    Possible parents include but are not limited to
    <a href="#IQVDocument">IQVDocument</a><a href="#IQVPageROI">IQVPageROI</a><a href="#IQVDocumentLink">IQVDocumentLink</a>
    SQL code example 1 for usage of index
    <code>
    WHERE parent_id=parent_id AND group_type=group_type
    </code>
    """

    hierarchy = str
    """
    image,table,paragraph,item,header,footer,roi
    """

    Highlight = str
    """
    <b>w:highlight w:val="yellow"</b>
    Background
    """

    id = str
    """

    """

    Imprint = bool
    """
    Specifies that the content should be displayed as it it were imprinted (or engraved) into the page: <b>w:imprint w:val="true"</b>. This may not be present with either emboss or outline. This is a toggle property.
    Embossed text
    Reference: ECMA-376, 3rd Edition(June, 2011), Fundamentals and Markup Language Reference § 17.3.2.18.
    """

    iqv_standard_term = str
    """
    Element index
    If this element is a link or header, what is the standard term?
    There is 0 or 1 iqv_standard_term for each element
    """

    Italics = bool
    """
    Specifies that the text of the text run is to be italics: <b>w:i</b>. This is a toggle property.
    Reference: ECMA-376, 3rd Edition(June, 2011), Fundamentals and Markup Language Reference § 17.3.2.16.
    """

    link_id = str
    """
    Element index
    Which [link <a href="#IQVDocumentLink">IQVDocumentLink</a>] section is this element in?
    The id for <a href="#IQVDocumentLink.LinkType">IQVDocumentLink.LinkType</a> == "toc"
    and <a href="#IQVDocumentLink.LinkLevel">IQVDocumentLink.LinkLevel</a> == 1
    """

    link_id_level2 = str
    """
    Element index
    Which [link <a href="#IQVDocumentLink">IQVDocumentLink</a>] section is this element in?
    The id for <a href="#IQVDocumentLink.LinkType">IQVDocumentLink.LinkType</a> == "toc"
    and <a href="#IQVDocumentLink.LinkLevel">IQVDocumentLink.LinkLevel</a> == 2
    """

    link_id_level3 = str
    """
    Element index
    Which [link <a href="#IQVDocumentLink">IQVDocumentLink</a>] section is this element in?
    The id for <a href="#IQVDocumentLink.LinkType">IQVDocumentLink.LinkType</a> == "toc"
    and <a href="#IQVDocumentLink.LinkLevel">IQVDocumentLink.LinkLevel</a> == 3
    """

    link_id_level4 = str
    """
    Element index
    Which [link <a href="#IQVDocumentLink">IQVDocumentLink</a>] section is this element in?
    The id for <a href="#IQVDocumentLink.LinkType">IQVDocumentLink.LinkType</a> == "toc"
    and <a href="#IQVDocumentLink.LinkLevel">IQVDocumentLink.LinkLevel</a> == 4
    """

    link_id_level5 = str
    """
    Element index
    Which [link <a href="#IQVDocumentLink">IQVDocumentLink</a>] section is this element in?
    The id for <a href="#IQVDocumentLink.LinkType">IQVDocumentLink.LinkType</a> == "toc"
    and <a href="#IQVDocumentLink.LinkLevel">IQVDocumentLink.LinkLevel</a> == 5
    """

    link_id_level6 = str
    """
    Element index
    Which [link <a href="#IQVDocumentLink">IQVDocumentLink</a>] section is this element in?
    The id for <a href="#IQVDocumentLink.LinkType">IQVDocumentLink.LinkType</a> == "toc"
    and <a href="#IQVDocumentLink.LinkLevel">IQVDocumentLink.LinkLevel</a> == 6
    """

    link_id_subsection1 = str
    """
    Element index
    Which [link <a href="#IQVDocumentLink">IQVDocumentLink</a>] section is this element in?
    The id for <a href="#IQVDocumentLink.LinkType">IQVDocumentLink.LinkType</a> == "subsection1"
    """

    link_id_subsection2 = str
    """
    Element index
    Which [link <a href="#IQVDocumentLink">IQVDocumentLink</a>] section is this element in?
    The id for <a href="#IQVDocumentLink.LinkType">IQVDocumentLink.LinkType</a> == "subsection2"
    """

    link_id_subsection3 = str
    """
    Element index
    Which [link <a href="#IQVDocumentLink">IQVDocumentLink</a>] section is this element in?
    The id for <a href="#IQVDocumentLink.LinkType">IQVDocumentLink.LinkType</a> == "subsection3"
    """

    Outline = bool
    """
    Specifies that the content should be displayed as if it had an outline. A one-pixel border is drawn around the inside and outside borders of each character. <b>outline w:val="true"</b>. This is a toggle property.
    text outline
    Reference: ECMA-376, 3rd Edition(June, 2011), Fundamentals and Markup Language Reference § 17.3.2.23.
    """

    parent_id = str
    """
    Element index
    Which item is this element a member of?
    For example, for <a href="#IQVPageROI.Properties">IQVPageROI.Properties</a>, parent_id = <a href="#IQVPageROI.id">IQVPageROI.id</a>
    Possible parents include but are not limited to
    <a href="#IQVDocument">IQVDocument</a><a href="#IQVPageROI">IQVPageROI</a><a href="#IQVDocumentLink">IQVDocumentLink</a>
    SQL code example 1 for usage of index
    <code>
    WHERE parent_id=parent_id AND group_type=group_type
    </code>
    SQL code example 2 for usage of index
    <code>
    WHERE parent_id=parent_id
    </code>
    """

    rFonts = str
    """
    Font regular name
    """

    rStyle = str
    """
    Specifies the style ID of the character style to be used to format the contents of the run.
    Reference: ECMA-376, 3rd Edition(June, 2011), Fundamentals and Markup Language Reference § 17.3.2.29.
    """

    Shadow = bool
    """
    Specifies that the content should be displayed as if each character has a shadow: <b>w:shadow w:val="true"</b>. For left-to-right text, the shadow is beneath the text and to its right. shadow may not be present with either emboss or imprint. This is a toggle property.
    Embossed text
    Reference: ECMA-376, 3rd Edition(June, 2011), Fundamentals and Markup Language Reference § 17.3.2.31.
    """

    Size = int
    """
    Specifies the font size in half points: <b>w:sz w:val="28"</b>. Note that szCs is used for complex script fonts such as Arabic.
    The single attribute val specifies a measurement in half-points(1/144 of an inch).
    Reference: ECMA-376, 3rd Edition(June, 2011), Fundamentals and Markup Language Reference § 17.3.2.38.
    """

    SmallCaps = bool
    """
    Specifies that any lowercase characters are to be displayed as their uppercase equivalents in a font size two points smaller than the specified font size: <b>w:smallCaps w:val="true"</b>. It cannot appear with caps in the same text run. This is a toggle property.
    small caps
    Reference: ECMA-376, 3rd Edition(June, 2011), Fundamentals and Markup Language Reference § 17.3.2.33.
    """

    Strike = bool
    """
    Specifies that the contents are to be displayed with a horizontal line through the center of the line: <b>w:strike w:val="true"</b>. It cannot appear with dstrike in the same text run. This is a toggle property.
    Reference: ECMA-376, 3rd Edition(June, 2011), Fundamentals and Markup Language Reference § 17.3.2.37.
    """

    Underline = str
    """
    Specifies that the content should be displayed with an underline: <b>w:u w:val="double"</b>.
    The most common attributes are below(the theme-related attributed are omitted):
    color - specifies the color for the underlining.Values are given as hex values (in RRGGBB format). No #, unlike hex values in HTML/CSS. E.g., color="FFFF00". A value of auto is also permitted and will allow the consuming word processor to determine the color based on the context.
    val - Specifies the pattern to be used to create the underline.Possible values are:
    dash - a dashed line
    dashDotDotHeavy - a series of thick dash, dot, dot characters
    dashDotHeavy - a series of thick dash, dot characters
    dashedHeavy - a series of thick dashes
    dashLong - a series of long dashed characters
    dashLongHeavy - a series of thick, long, dashed characters
    dotDash - a series of dash, dot characters
    dotDotDash - a series of dash, dot, dot characters
    dotted - a series of dot characters
    dottedHeavy - a series of thick dot characters
    double - two lines
    none - no underline
    single - a single line
    thick - a single think line
    wave - a single wavy line
    wavyDouble - a pair of wavy lines
    wavyHeavy - a single thick wavy line
    words - a single line beneath all non-space characters
    Reference: ECMA-376, 3rd Edition (June, 2011), Fundamentals and Markup Language Reference § 17.3.2.40.
    """

    Vanish = bool
    """
    Specifies that the content is to be hidden from display at display time. <b>vanish</b>. This is a toggle property.
    Reference: ECMA-376, 3rd Edition(June, 2011), Fundamentals and Markup Language Reference § 17.3.2.41.
    """

    VertAlign = str
    """
    Subscript and superscript. <b>vertAlign w:val="superscript"</b>.
    The single attribute is val.Permitted values are:
    baseline - regular vertical positioning
    subscript - lowers the text below the baseline and changes it to a small size
    superscript - raises the text above the baseline and changes it to a smaller size
    Reference: ECMA-376, 3rd Edition(June, 2011), Fundamentals and Markup Language Reference § 17.3.2.42.
    """

    def __init__(self):
        self.Bold = False
        self.Caps = False
        self.ColorRGB = -1
        self.doc_id = ''
        self.DStrike = False
        self.Emboss = False
        self.group_type = ''
        self.hierarchy = ''
        self.Highlight = ''
        self.id = ''
        self.Imprint = False
        self.iqv_standard_term = ''
        self.Italics = False
        self.link_id = ''
        self.link_id_level2 = ''
        self.link_id_level3 = ''
        self.link_id_level4 = ''
        self.link_id_level5 = ''
        self.link_id_level6 = ''
        self.link_id_subsection1 = ''
        self.link_id_subsection2 = ''
        self.link_id_subsection3 = ''
        self.Outline = False
        self.parent_id = ''
        self.rFonts = ''
        self.rStyle = ''
        self.Shadow = False
        self.Size = -1
        self.SmallCaps = False
        self.Strike = False
        self.Underline = ''
        self.Vanish = False
        self.VertAlign = ''
        self.id = str(uuid.uuid1())


class IQVAttribute_db(object):
    """
    Attributes for XElements
    """

    doc_id = str
    """
    Element index
    Which document is this element in?
    Top-level id for <a href="#IQVDocument">IQVDocument</a>
    """

    group_type = str
    """
    Element index
    Which item is this element a member of? (name of member = group_type)
    For example, for <a href="#IQVPageROI.Properties">IQVPageROI.Properties</a>, group_type = "Properties"
    Possible parents include but are not limited to
    <a href="#IQVDocument">IQVDocument</a><a href="#IQVPageROI">IQVPageROI</a><a href="#IQVDocumentLink">IQVDocumentLink</a>
    SQL code example 1 for usage of index
    <code>
    WHERE parent_id=parent_id AND group_type=group_type
    </code>
    """

    hierarchy = str
    """
    image,table,paragraph,item,header,footer,roi
    """

    id = str
    """

    """

    iqv_standard_term = str
    """
    Element index
    If this element is a link or header, what is the standard term?
    There is 0 or 1 iqv_standard_term for each element
    """

    link_id = str
    """
    Element index
    Which [link <a href="#IQVDocumentLink">IQVDocumentLink</a>] section is this element in?
    The id for <a href="#IQVDocumentLink.LinkType">IQVDocumentLink.LinkType</a> == "toc"
    and <a href="#IQVDocumentLink.LinkLevel">IQVDocumentLink.LinkLevel</a> == 1
    """

    link_id_level2 = str
    """
    Element index
    Which [link <a href="#IQVDocumentLink">IQVDocumentLink</a>] section is this element in?
    The id for <a href="#IQVDocumentLink.LinkType">IQVDocumentLink.LinkType</a> == "toc"
    and <a href="#IQVDocumentLink.LinkLevel">IQVDocumentLink.LinkLevel</a> == 2
    """

    link_id_level3 = str
    """
    Element index
    Which [link <a href="#IQVDocumentLink">IQVDocumentLink</a>] section is this element in?
    The id for <a href="#IQVDocumentLink.LinkType">IQVDocumentLink.LinkType</a> == "toc"
    and <a href="#IQVDocumentLink.LinkLevel">IQVDocumentLink.LinkLevel</a> == 3
    """

    link_id_level4 = str
    """
    Element index
    Which [link <a href="#IQVDocumentLink">IQVDocumentLink</a>] section is this element in?
    The id for <a href="#IQVDocumentLink.LinkType">IQVDocumentLink.LinkType</a> == "toc"
    and <a href="#IQVDocumentLink.LinkLevel">IQVDocumentLink.LinkLevel</a> == 4
    """

    link_id_level5 = str
    """
    Element index
    Which [link <a href="#IQVDocumentLink">IQVDocumentLink</a>] section is this element in?
    The id for <a href="#IQVDocumentLink.LinkType">IQVDocumentLink.LinkType</a> == "toc"
    and <a href="#IQVDocumentLink.LinkLevel">IQVDocumentLink.LinkLevel</a> == 5
    """

    link_id_level6 = str
    """
    Element index
    Which [link <a href="#IQVDocumentLink">IQVDocumentLink</a>] section is this element in?
    The id for <a href="#IQVDocumentLink.LinkType">IQVDocumentLink.LinkType</a> == "toc"
    and <a href="#IQVDocumentLink.LinkLevel">IQVDocumentLink.LinkLevel</a> == 6
    """

    link_id_subsection1 = str
    """
    Element index
    Which [link <a href="#IQVDocumentLink">IQVDocumentLink</a>] section is this element in?
    The id for <a href="#IQVDocumentLink.LinkType">IQVDocumentLink.LinkType</a> == "subsection1"
    """

    link_id_subsection2 = str
    """
    Element index
    Which [link <a href="#IQVDocumentLink">IQVDocumentLink</a>] section is this element in?
    The id for <a href="#IQVDocumentLink.LinkType">IQVDocumentLink.LinkType</a> == "subsection2"
    """

    link_id_subsection3 = str
    """
    Element index
    Which [link <a href="#IQVDocumentLink">IQVDocumentLink</a>] section is this element in?
    The id for <a href="#IQVDocumentLink.LinkType">IQVDocumentLink.LinkType</a> == "subsection3"
    """

    LocalName = str
    """
    Short name
    """

    Name = str
    """
    Full name
    """

    parent_id = str
    """
    Element index
    Which item is this element a member of?
    For example, for <a href="#IQVPageROI.Properties">IQVPageROI.Properties</a>, parent_id = <a href="#IQVPageROI.id">IQVPageROI.id</a>
    Possible parents include but are not limited to
    <a href="#IQVDocument">IQVDocument</a><a href="#IQVPageROI">IQVPageROI</a><a href="#IQVDocumentLink">IQVDocumentLink</a>
    SQL code example 1 for usage of index
    <code>
    WHERE parent_id=parent_id AND group_type=group_type
    </code>
    SQL code example 2 for usage of index
    <code>
    WHERE parent_id=parent_id
    </code>
    """

    Value = str
    """
    Attribute value
    """

    def __init__(self):
        self.doc_id = ''
        self.group_type = ''
        self.hierarchy = ''
        self.id = ''
        self.iqv_standard_term = ''
        self.link_id = ''
        self.link_id_level2 = ''
        self.link_id_level3 = ''
        self.link_id_level4 = ''
        self.link_id_level5 = ''
        self.link_id_level6 = ''
        self.link_id_subsection1 = ''
        self.link_id_subsection2 = ''
        self.link_id_subsection3 = ''
        self.LocalName = ''
        self.Name = ''
        self.parent_id = ''
        self.Value = ''
        self.id = str(uuid.uuid1())


class IQVAttributeCandidate_db(object):
    """
    Possible Attribute found in the document,
    such as document date
    """

    AttributeKey = str
    """
    key, such as document_date
    """

    AttributeValue = str
    """
    value of the attribute, such as date string
    """

    CandidateSelected = int
    """
    is this selected as top candidate?
    """

    doc_id = str
    """
    Element index
    Which document is this element in?
    Top-level id for <a href="#IQVDocument">IQVDocument</a>
    """

    group_type = str
    """
    Element index
    Which item is this element a member of? (name of member = group_type)
    For example, for <a href="#IQVPageROI.Properties">IQVPageROI.Properties</a>, group_type = "Properties"
    Possible parents include but are not limited to
    <a href="#IQVDocument">IQVDocument</a><a href="#IQVPageROI">IQVPageROI</a><a href="#IQVDocumentLink">IQVDocumentLink</a>
    SQL code example 1 for usage of index
    <code>
    WHERE parent_id=parent_id AND group_type=group_type
    </code>
    """

    hierarchy = str
    """
    image,table,paragraph,item,header,footer,roi
    """

    id = str
    """

    """

    iqv_standard_term = str
    """
    Element index
    If this element is a link or header, what is the standard term?
    There is 0 or 1 iqv_standard_term for each element
    """

    link_id = str
    """
    Element index
    Which [link <a href="#IQVDocumentLink">IQVDocumentLink</a>] section is this element in?
    The id for <a href="#IQVDocumentLink.LinkType">IQVDocumentLink.LinkType</a> == "toc"
    and <a href="#IQVDocumentLink.LinkLevel">IQVDocumentLink.LinkLevel</a> == 1
    """

    link_id_level2 = str
    """
    Element index
    Which [link <a href="#IQVDocumentLink">IQVDocumentLink</a>] section is this element in?
    The id for <a href="#IQVDocumentLink.LinkType">IQVDocumentLink.LinkType</a> == "toc"
    and <a href="#IQVDocumentLink.LinkLevel">IQVDocumentLink.LinkLevel</a> == 2
    """

    link_id_level3 = str
    """
    Element index
    Which [link <a href="#IQVDocumentLink">IQVDocumentLink</a>] section is this element in?
    The id for <a href="#IQVDocumentLink.LinkType">IQVDocumentLink.LinkType</a> == "toc"
    and <a href="#IQVDocumentLink.LinkLevel">IQVDocumentLink.LinkLevel</a> == 3
    """

    link_id_level4 = str
    """
    Element index
    Which [link <a href="#IQVDocumentLink">IQVDocumentLink</a>] section is this element in?
    The id for <a href="#IQVDocumentLink.LinkType">IQVDocumentLink.LinkType</a> == "toc"
    and <a href="#IQVDocumentLink.LinkLevel">IQVDocumentLink.LinkLevel</a> == 4
    """

    link_id_level5 = str
    """
    Element index
    Which [link <a href="#IQVDocumentLink">IQVDocumentLink</a>] section is this element in?
    The id for <a href="#IQVDocumentLink.LinkType">IQVDocumentLink.LinkType</a> == "toc"
    and <a href="#IQVDocumentLink.LinkLevel">IQVDocumentLink.LinkLevel</a> == 5
    """

    link_id_level6 = str
    """
    Element index
    Which [link <a href="#IQVDocumentLink">IQVDocumentLink</a>] section is this element in?
    The id for <a href="#IQVDocumentLink.LinkType">IQVDocumentLink.LinkType</a> == "toc"
    and <a href="#IQVDocumentLink.LinkLevel">IQVDocumentLink.LinkLevel</a> == 6
    """

    link_id_subsection1 = str
    """
    Element index
    Which [link <a href="#IQVDocumentLink">IQVDocumentLink</a>] section is this element in?
    The id for <a href="#IQVDocumentLink.LinkType">IQVDocumentLink.LinkType</a> == "subsection1"
    """

    link_id_subsection2 = str
    """
    Element index
    Which [link <a href="#IQVDocumentLink">IQVDocumentLink</a>] section is this element in?
    The id for <a href="#IQVDocumentLink.LinkType">IQVDocumentLink.LinkType</a> == "subsection2"
    """

    link_id_subsection3 = str
    """
    Element index
    Which [link <a href="#IQVDocumentLink">IQVDocumentLink</a>] section is this element in?
    The id for <a href="#IQVDocumentLink.LinkType">IQVDocumentLink.LinkType</a> == "subsection3"
    """

    parent_id = str
    """
    Element index
    Which item is this element a member of?
    For example, for <a href="#IQVPageROI.Properties">IQVPageROI.Properties</a>, parent_id = <a href="#IQVPageROI.id">IQVPageROI.id</a>
    Possible parents include but are not limited to
    <a href="#IQVDocument">IQVDocument</a><a href="#IQVPageROI">IQVPageROI</a><a href="#IQVDocumentLink">IQVDocumentLink</a>
    SQL code example 1 for usage of index
    <code>
    WHERE parent_id=parent_id AND group_type=group_type
    </code>
    SQL code example 2 for usage of index
    <code>
    WHERE parent_id=parent_id
    </code>
    """

    RawProbabilitiyScore = float
    """
    score assigned to this attribute
    """

    roi_id = str
    """
    id of roi in which this attribute is found
    """

    def __init__(self):
        self.AttributeKey = ''
        self.AttributeValue = ''
        self.CandidateSelected = -1
        self.doc_id = ''
        self.group_type = ''
        self.hierarchy = ''
        self.id = ''
        self.iqv_standard_term = ''
        self.link_id = ''
        self.link_id_level2 = ''
        self.link_id_level3 = ''
        self.link_id_level4 = ''
        self.link_id_level5 = ''
        self.link_id_level6 = ''
        self.link_id_subsection1 = ''
        self.link_id_subsection2 = ''
        self.link_id_subsection3 = ''
        self.parent_id = ''
        self.RawProbabilitiyScore = 0.0
        self.roi_id = ''
        self.id = str(uuid.uuid1())


class IQVCharacter_db(object):
    """
    OCR Character
    """

    Bottom = int
    """
    OCR-provided bottom
    """

    doc_id = str
    """
    Element index
    Which document is this element in?
    Top-level id for <a href="#IQVDocument">IQVDocument</a>
    """

    group_type = str
    """
    Element index
    Which item is this element a member of? (name of member = group_type)
    For example, for <a href="#IQVPageROI.Properties">IQVPageROI.Properties</a>, group_type = "Properties"
    Possible parents include but are not limited to
    <a href="#IQVDocument">IQVDocument</a><a href="#IQVPageROI">IQVPageROI</a><a href="#IQVDocumentLink">IQVDocumentLink</a>
    SQL code example 1 for usage of index
    <code>
    WHERE parent_id=parent_id AND group_type=group_type
    </code>
    """

    hierarchy = str
    """
    image,table,paragraph,item,header,footer,roi
    """

    id = str
    """

    """

    iqv_standard_term = str
    """
    Element index
    If this element is a link or header, what is the standard term?
    There is 0 or 1 iqv_standard_term for each element
    """

    Left = int
    """
    OCR-provided left
    """

    link_id = str
    """
    Element index
    Which [link <a href="#IQVDocumentLink">IQVDocumentLink</a>] section is this element in?
    The id for <a href="#IQVDocumentLink.LinkType">IQVDocumentLink.LinkType</a> == "toc"
    and <a href="#IQVDocumentLink.LinkLevel">IQVDocumentLink.LinkLevel</a> == 1
    """

    link_id_level2 = str
    """
    Element index
    Which [link <a href="#IQVDocumentLink">IQVDocumentLink</a>] section is this element in?
    The id for <a href="#IQVDocumentLink.LinkType">IQVDocumentLink.LinkType</a> == "toc"
    and <a href="#IQVDocumentLink.LinkLevel">IQVDocumentLink.LinkLevel</a> == 2
    """

    link_id_level3 = str
    """
    Element index
    Which [link <a href="#IQVDocumentLink">IQVDocumentLink</a>] section is this element in?
    The id for <a href="#IQVDocumentLink.LinkType">IQVDocumentLink.LinkType</a> == "toc"
    and <a href="#IQVDocumentLink.LinkLevel">IQVDocumentLink.LinkLevel</a> == 3
    """

    link_id_level4 = str
    """
    Element index
    Which [link <a href="#IQVDocumentLink">IQVDocumentLink</a>] section is this element in?
    The id for <a href="#IQVDocumentLink.LinkType">IQVDocumentLink.LinkType</a> == "toc"
    and <a href="#IQVDocumentLink.LinkLevel">IQVDocumentLink.LinkLevel</a> == 4
    """

    link_id_level5 = str
    """
    Element index
    Which [link <a href="#IQVDocumentLink">IQVDocumentLink</a>] section is this element in?
    The id for <a href="#IQVDocumentLink.LinkType">IQVDocumentLink.LinkType</a> == "toc"
    and <a href="#IQVDocumentLink.LinkLevel">IQVDocumentLink.LinkLevel</a> == 5
    """

    link_id_level6 = str
    """
    Element index
    Which [link <a href="#IQVDocumentLink">IQVDocumentLink</a>] section is this element in?
    The id for <a href="#IQVDocumentLink.LinkType">IQVDocumentLink.LinkType</a> == "toc"
    and <a href="#IQVDocumentLink.LinkLevel">IQVDocumentLink.LinkLevel</a> == 6
    """

    link_id_subsection1 = str
    """
    Element index
    Which [link <a href="#IQVDocumentLink">IQVDocumentLink</a>] section is this element in?
    The id for <a href="#IQVDocumentLink.LinkType">IQVDocumentLink.LinkType</a> == "subsection1"
    """

    link_id_subsection2 = str
    """
    Element index
    Which [link <a href="#IQVDocumentLink">IQVDocumentLink</a>] section is this element in?
    The id for <a href="#IQVDocumentLink.LinkType">IQVDocumentLink.LinkType</a> == "subsection2"
    """

    link_id_subsection3 = str
    """
    Element index
    Which [link <a href="#IQVDocumentLink">IQVDocumentLink</a>] section is this element in?
    The id for <a href="#IQVDocumentLink.LinkType">IQVDocumentLink.LinkType</a> == "subsection3"
    """

    parent_id = str
    """
    Element index
    Which item is this element a member of?
    For example, for <a href="#IQVPageROI.Properties">IQVPageROI.Properties</a>, parent_id = <a href="#IQVPageROI.id">IQVPageROI.id</a>
    Possible parents include but are not limited to
    <a href="#IQVDocument">IQVDocument</a><a href="#IQVPageROI">IQVPageROI</a><a href="#IQVDocumentLink">IQVDocumentLink</a>
    SQL code example 1 for usage of index
    <code>
    WHERE parent_id=parent_id AND group_type=group_type
    </code>
    SQL code example 2 for usage of index
    <code>
    WHERE parent_id=parent_id
    </code>
    """

    Right = int
    """
    OCR-provided right
    """

    Tag = str
    """
    OCR-provided tag
    """

    Top = int
    """
    OCR-provided top
    """

    Value = int
    """
    OCR-provided text value (single character)
    """

    def __init__(self):
        self.Bottom = -1
        self.doc_id = ''
        self.group_type = ''
        self.hierarchy = ''
        self.id = ''
        self.iqv_standard_term = ''
        self.Left = -1
        self.link_id = ''
        self.link_id_level2 = ''
        self.link_id_level3 = ''
        self.link_id_level4 = ''
        self.link_id_level5 = ''
        self.link_id_level6 = ''
        self.link_id_subsection1 = ''
        self.link_id_subsection2 = ''
        self.link_id_subsection3 = ''
        self.parent_id = ''
        self.Right = -1
        self.Tag = ''
        self.Top = -1
        self.Value = -1
        self.id = str(uuid.uuid1())


class IQVWord_db(object):
    """
    Word data structure elements from OCR output
    """

    Blanks = int
    """
    OCR-provided blanks
    """

    BlockIndex = int
    """
    block on the page, zero-based
    hierarchy is page index, block index, line index, word index
    """

    Bottom = int
    """
    OCR-provided bottom (pixels of input image)
    """

    Class = str
    """
    OCR-provided class: we want the ocrx_word for text.
    line, carriage return (carea), page, word, paragraph
    ocr_line, ocr_carea, ocr_page, ocrx_word, ocr_par
    """

    Confidence = float
    """
    OCR-provided confidence score
    """

    doc_id = str
    """
    Element index
    Which document is this element in?
    Top-level id for <a href="#IQVDocument">IQVDocument</a>
    """

    FontIndex = float
    """
    OCR-provided font index (size)
    """

    FontName = str
    """
    OCR-provided font family name
    """

    Formating = int
    """
    OCR-provided formating: strong { get; set; } em = 2
    """

    group_type = str
    """
    Element index
    Which item is this element a member of? (name of member = group_type)
    For example, for <a href="#IQVPageROI.Properties">IQVPageROI.Properties</a>, group_type = "Properties"
    Possible parents include but are not limited to
    <a href="#IQVDocument">IQVDocument</a><a href="#IQVPageROI">IQVPageROI</a><a href="#IQVDocumentLink">IQVDocumentLink</a>
    SQL code example 1 for usage of index
    <code>
    WHERE parent_id=parent_id AND group_type=group_type
    </code>
    """

    GT_ScoreMatch = float
    """
    for testing
    """

    GT_TextMatch = str
    """
    For a actual/known/validated output to measure
     against the (predicted output) text
    """

    hierarchy = str
    """
    image,table,paragraph,item,header,footer,roi
    """

    id = str
    """

    """

    iqv_standard_term = str
    """
    Element index
    If this element is a link or header, what is the standard term?
    There is 0 or 1 iqv_standard_term for each element
    """

    Left = int
    """
    OCR-provided left in pixels (input image)
    """

    LineIndex = int
    """
    line in the block, zero-based
    hierarchy is page index, block index, line index, word index
    """

    link_id = str
    """
    Element index
    Which [link <a href="#IQVDocumentLink">IQVDocumentLink</a>] section is this element in?
    The id for <a href="#IQVDocumentLink.LinkType">IQVDocumentLink.LinkType</a> == "toc"
    and <a href="#IQVDocumentLink.LinkLevel">IQVDocumentLink.LinkLevel</a> == 1
    """

    link_id_level2 = str
    """
    Element index
    Which [link <a href="#IQVDocumentLink">IQVDocumentLink</a>] section is this element in?
    The id for <a href="#IQVDocumentLink.LinkType">IQVDocumentLink.LinkType</a> == "toc"
    and <a href="#IQVDocumentLink.LinkLevel">IQVDocumentLink.LinkLevel</a> == 2
    """

    link_id_level3 = str
    """
    Element index
    Which [link <a href="#IQVDocumentLink">IQVDocumentLink</a>] section is this element in?
    The id for <a href="#IQVDocumentLink.LinkType">IQVDocumentLink.LinkType</a> == "toc"
    and <a href="#IQVDocumentLink.LinkLevel">IQVDocumentLink.LinkLevel</a> == 3
    """

    link_id_level4 = str
    """
    Element index
    Which [link <a href="#IQVDocumentLink">IQVDocumentLink</a>] section is this element in?
    The id for <a href="#IQVDocumentLink.LinkType">IQVDocumentLink.LinkType</a> == "toc"
    and <a href="#IQVDocumentLink.LinkLevel">IQVDocumentLink.LinkLevel</a> == 4
    """

    link_id_level5 = str
    """
    Element index
    Which [link <a href="#IQVDocumentLink">IQVDocumentLink</a>] section is this element in?
    The id for <a href="#IQVDocumentLink.LinkType">IQVDocumentLink.LinkType</a> == "toc"
    and <a href="#IQVDocumentLink.LinkLevel">IQVDocumentLink.LinkLevel</a> == 5
    """

    link_id_level6 = str
    """
    Element index
    Which [link <a href="#IQVDocumentLink">IQVDocumentLink</a>] section is this element in?
    The id for <a href="#IQVDocumentLink.LinkType">IQVDocumentLink.LinkType</a> == "toc"
    and <a href="#IQVDocumentLink.LinkLevel">IQVDocumentLink.LinkLevel</a> == 6
    """

    link_id_subsection1 = str
    """
    Element index
    Which [link <a href="#IQVDocumentLink">IQVDocumentLink</a>] section is this element in?
    The id for <a href="#IQVDocumentLink.LinkType">IQVDocumentLink.LinkType</a> == "subsection1"
    """

    link_id_subsection2 = str
    """
    Element index
    Which [link <a href="#IQVDocumentLink">IQVDocumentLink</a>] section is this element in?
    The id for <a href="#IQVDocumentLink.LinkType">IQVDocumentLink.LinkType</a> == "subsection2"
    """

    link_id_subsection3 = str
    """
    Element index
    Which [link <a href="#IQVDocumentLink">IQVDocumentLink</a>] section is this element in?
    The id for <a href="#IQVDocumentLink.LinkType">IQVDocumentLink.LinkType</a> == "subsection3"
    """

    NLP_ScoreMatch = float
    """
    Predicted output score from OCR + NLP
    """

    NLP_TextMatch = str
    """
    Predicted output from OCR + NLP
    """

    NLP_TextMatchReconstructed = str
    """
    Using as a base input <see cref="P:IQVFileManagerDLL.IQVWord_db.NLP_TextMatch" />,
     add back the prefix <see cref="P:IQVFileManagerDLL.IQVWord_db.TextDerivedPrefix" />,
     suffix <see cref="P:IQVFileManagerDLL.IQVWord_db.TextDerivedSuffix" />,
    and determine case <see cref="P:IQVFileManagerDLL.IQVWord_db.TextDerivedCase" />. This is
    the final to be used in Document Reconstruction
    """

    parent_id = str
    """
    Element index
    Which item is this element a member of?
    For example, for <a href="#IQVPageROI.Properties">IQVPageROI.Properties</a>, parent_id = <a href="#IQVPageROI.id">IQVPageROI.id</a>
    Possible parents include but are not limited to
    <a href="#IQVDocument">IQVDocument</a><a href="#IQVPageROI">IQVPageROI</a><a href="#IQVDocumentLink">IQVDocumentLink</a>
    SQL code example 1 for usage of index
    <code>
    WHERE parent_id=parent_id AND group_type=group_type
    </code>
    SQL code example 2 for usage of index
    <code>
    WHERE parent_id=parent_id
    </code>
    """

    PointSize = int
    """
    point size
    """

    Right = int
    """
    OCR-provided right pixels (input image)
    """

    Tag = str
    """
    OCR-provided
    """

    Text = str
    """
    Predicted output from OCR
    """

    textangle = int
    """
    OCR-provided text angle in degrees (180 is upside down)
    """

    TextDerivedCase = int
    """
    Lowercase = 0,
    Uppercase = 1,
    Proper Case = 2
    """

    TextDerivedDeconstructed = str
    """
    Using as a base input <see cref="P:IQVFileManagerDLL.IQVWord_db.Text" />, pull out prefix <see cref="P:IQVFileManagerDLL.IQVWord_db.TextDerivedPrefix" />,
     suffix <see cref="P:IQVFileManagerDLL.IQVWord_db.TextDerivedSuffix" />,
    and determine case <see cref="P:IQVFileManagerDLL.IQVWord_db.TextDerivedCase" />, and use this
     to match and find <see cref="P:IQVFileManagerDLL.IQVWord_db.NLP_TextMatch" />
    """

    TextDerivedIsNumeric = int
    """
    Not numeric = 0,
    Numeric = 1,
    Numeric + Alpha as Code (not a word) = 2
    """

    TextDerivedPrefix = str
    """
    Punctuation or other symbols at prefix(beginning), removed for
    matching to create <see cref="P:IQVFileManagerDLL.IQVWord_db.TextDerivedDeconstructed" />,
    replaced to build <see cref="P:IQVFileManagerDLL.IQVWord_db.NLP_TextMatchReconstructed" />
    """

    TextDerivedSuffix = str
    """
    Using as input Punctuation or other symbols at suffix(ending), removed for
    matching to create <see cref="P:IQVFileManagerDLL.IQVWord_db.TextDerivedDeconstructed" />,
    replaced to build <see cref="P:IQVFileManagerDLL.IQVWord_db.NLP_TextMatchReconstructed" />
    """

    TextLanguage = str
    """
    Language of the text, stored here for easier access and reference
    for ML processes
    """

    Top = int
    """
    OCR-provided top pixels (input image)
    """

    WordIndex = int
    """
    word in the line, zero-based
    hierarchy is page index, block index, line index, word index
    """

    def __init__(self):
        self.Blanks = -1
        self.BlockIndex = -1
        self.Bottom = -1
        self.Class = ''
        self.Confidence = 0.0
        self.doc_id = ''
        self.FontIndex = 0.0
        self.FontName = ''
        self.Formating = -1
        self.group_type = ''
        self.GT_ScoreMatch = 0.0
        self.GT_TextMatch = ''
        self.hierarchy = ''
        self.id = ''
        self.iqv_standard_term = ''
        self.Left = -1
        self.LineIndex = -1
        self.link_id = ''
        self.link_id_level2 = ''
        self.link_id_level3 = ''
        self.link_id_level4 = ''
        self.link_id_level5 = ''
        self.link_id_level6 = ''
        self.link_id_subsection1 = ''
        self.link_id_subsection2 = ''
        self.link_id_subsection3 = ''
        self.NLP_ScoreMatch = 0.0
        self.NLP_TextMatch = ''
        self.NLP_TextMatchReconstructed = ''
        self.parent_id = ''
        self.PointSize = -1
        self.Right = -1
        self.Tag = ''
        self.Text = ''
        self.textangle = -1
        self.TextDerivedCase = -1
        self.TextDerivedDeconstructed = ''
        self.TextDerivedIsNumeric = -1
        self.TextDerivedPrefix = ''
        self.TextDerivedSuffix = ''
        self.TextLanguage = ''
        self.Top = -1
        self.WordIndex = -1
        self.id = str(uuid.uuid1())


class IQVClassifierModel_db(object):
    """
    Used to specify 2nd-level and other specialized models
    """

    Base_Model_Version = str
    """
    1st-level model
    """

    Country = str
    """
    If specified, model is for
     one country
    """

    Doc_Class = str
    """
    If specified, model is for one of the following
    site, country, study
    """

    Full_Classification_List_list = []
    """
    List of document classifications that are used
    as input to this model
    """

    id = str
    """

    """

    Language = str
    """
    If specified, model is for
     one language
    """

    Model_Directory = str
    """
    Relative path where model artifacts are
    """

    Model_Index = str
    """
    Unique index within this list of models at this level
    """

    Model_Label = str
    """
    Unique label within this list of models at this level
    """

    Model_Name = str
    """
    Unique name within this list of models at this level
    """

    Model_Sequence = str
    """
    Level of model,
     2 for 2nd-level model
    """

    def __init__(self):
        self.Base_Model_Version = ''
        self.Country = ''
        self.Doc_Class = ''
        self.Full_Classification_List_list = []
        self.id = ''
        self.Language = ''
        self.Model_Directory = ''
        self.Model_Index = ''
        self.Model_Label = ''
        self.Model_Name = ''
        self.Model_Sequence = ''
        self.id = str(uuid.uuid1())


class IQVCountryMapping_db(object):
    """
    Prior information about each country
    based on historical documents, such as
    language of documents, date format of documents
    """

    Country = str
    """
    Name of the country
    """

    DateFormats_list = []
    """
    MDY, DMY, YMD
    """

    id = str
    """

    """

    def __init__(self):
        self.Country = ''
        self.DateFormats_list = []
        self.id = ''
        self.id = str(uuid.uuid1())


class IQVDocumentCompare_db(object):
    """
    Comparison between 2 documents <a href="#IQVDocument">IQVDocument</a>
    """

    base_doc_id = str
    """
    base/LHS doc id
    """

    base_doc_name = str
    """
    Base/LHS document short filename
    """

    compare_doc_id = str
    """
    comparison/RHS doc id
    """

    compare_doc_name = str
    """
    Comparison/RHS document short filename
    """

    id = str
    """

    """

    redaction_profile_id = str
    """
    id for redaction profile used in compare
    """

    def __init__(self):
        self.base_doc_id = ''
        self.base_doc_name = ''
        self.compare_doc_id = ''
        self.compare_doc_name = ''
        self.id = ''
        self.redaction_profile_id = ''
        self.id = str(uuid.uuid1())


class IQVDocumentDiff_db(object):
    """
    
    """

    compare_roi_id = str
    """
    id of the <a href="#IQVPageROI">IQVPageROI</a> in compare document
    alternatively, id of <a href="#IQVDocumentLink">IQVDocumentLink</a>, id of <a href="#IQVTableColumn">IQVTableColumn</a>, etc.

    Important to have this, as may be multiple diffs for a single component.
    For example, diffs of <a href="#IQVDocumentLink">IQVDocumentLink</a> might include
    1. diff of numeric prefix
    2. diff of text
    3. diff of page number

    Thus, having the "parent" id here makes it possible to compile all child diffs
    of the same parent component
    """

    confidence = float
    """
    Probability score of correctness of this diff,
    0.0 is low, 1.0 is high
    """

    diff_category = str
    """
    What category of object are we comparing?
    soa, table, attributes, etc.
    """

    diff_string = str
    """
    What is the string that is different???
    (where it is found in the big string is location)
    """

    diff_subcategory = str
    """
    What subcategory of object are we comparing?
    soa_timeline, soa_assessment, attribute key, etc.
    May be blank
    """

    diff_type = int
    """
    <a href="#IQVDocumentDiffType">IQVDocumentDiffType</a>
    0=default, no difference
    1=local only
    2=compare only
    3=modification
    4=alignment only (no comparison, used for reference)
    """

    id = str
    """

    """

    IsPreferredTermComparison = bool
    """
    Only for compare of preferred term, default is false
    """

    local_roi_id = str
    """
    id of the <a href="#IQVPageROI">IQVPageROI</a> in this document
    alternatively, id of <a href="#IQVDocumentLink">IQVDocumentLink</a>, id of <a href="#IQVTableColumn">IQVTableColumn</a>, etc.

    Important to have this, as may be multiple diffs for a single component.
    For example, diffs of <a href="#IQVDocumentLink">IQVDocumentLink</a> might include
    1. diff of numeric prefix
    2. diff of text
    3. diff of page number

    Thus, having the "parent" id here makes it possible to compile all child diffs
    of the same parent component
    """

    def __init__(self):
        self.compare_roi_id = ''
        self.confidence = 0.0
        self.diff_category = ''
        self.diff_string = ''
        self.diff_subcategory = ''
        self.diff_type = -1
        self.id = ''
        self.IsPreferredTermComparison = False
        self.local_roi_id = ''
        self.id = str(uuid.uuid1())


class IQVExternalLink_db(object):
    """
    link from IQVPageROI
    """

    connection_type = str
    """
    type of link connection
    """

    destination_link_id = str
    """
    Destination to where this is pointing to, if destination
    is in the same document

    Assumed that the destination_link already
    exists in the <a href="#IQVDocument.DocumentLinks">IQVDocument.DocumentLinks</a>
    """

    destination_link_prefix = str
    """
    If applicable, the prefix of the destination link

    Destination to where this is pointing to, if destination
    is in the same document

    Assumed that the destination_link already
    exists in the <a href="#IQVDocument.DocumentLinks">IQVDocument.DocumentLinks</a>
    """

    destination_link_text = str
    """
    The header/link text of destination link

    Destination to where this is pointing to, if destination
    is in the same document

    Assumed that the destination_link already
    exists in the <a href="#IQVDocument.DocumentLinks">IQVDocument.DocumentLinks</a>
    """

    destination_url = str
    """
    Destination to where this is pointing to, if destination
    is to a URL (not in the same document)
    """

    doc_id = str
    """
    Element index
    Which document is this element in?
    Top-level id for <a href="#IQVDocument">IQVDocument</a>
    """

    group_type = str
    """
    Element index
    Which item is this element a member of? (name of member = group_type)
    For example, for <a href="#IQVPageROI.Properties">IQVPageROI.Properties</a>, group_type = "Properties"
    Possible parents include but are not limited to
    <a href="#IQVDocument">IQVDocument</a><a href="#IQVPageROI">IQVPageROI</a><a href="#IQVDocumentLink">IQVDocumentLink</a>
    SQL code example 1 for usage of index
    <code>
    WHERE parent_id=parent_id AND group_type=group_type
    </code>
    """

    hierarchy = str
    """
    image,table,paragraph,item,header,footer,roi
    """

    id = str
    """

    """

    iqv_standard_term = str
    """
    Element index
    If this element is a link or header, what is the standard term?
    There is 0 or 1 iqv_standard_term for each element
    """

    length = int
    """
    length (num chars) of <see cref="P:IQVFileManagerDLL.IQVExternalLink_db.source_text" />
    """

    link_id = str
    """
    Element index
    Which [link <a href="#IQVDocumentLink">IQVDocumentLink</a>] section is this element in?
    The id for <a href="#IQVDocumentLink.LinkType">IQVDocumentLink.LinkType</a> == "toc"
    and <a href="#IQVDocumentLink.LinkLevel">IQVDocumentLink.LinkLevel</a> == 1
    """

    link_id_level2 = str
    """
    Element index
    Which [link <a href="#IQVDocumentLink">IQVDocumentLink</a>] section is this element in?
    The id for <a href="#IQVDocumentLink.LinkType">IQVDocumentLink.LinkType</a> == "toc"
    and <a href="#IQVDocumentLink.LinkLevel">IQVDocumentLink.LinkLevel</a> == 2
    """

    link_id_level3 = str
    """
    Element index
    Which [link <a href="#IQVDocumentLink">IQVDocumentLink</a>] section is this element in?
    The id for <a href="#IQVDocumentLink.LinkType">IQVDocumentLink.LinkType</a> == "toc"
    and <a href="#IQVDocumentLink.LinkLevel">IQVDocumentLink.LinkLevel</a> == 3
    """

    link_id_level4 = str
    """
    Element index
    Which [link <a href="#IQVDocumentLink">IQVDocumentLink</a>] section is this element in?
    The id for <a href="#IQVDocumentLink.LinkType">IQVDocumentLink.LinkType</a> == "toc"
    and <a href="#IQVDocumentLink.LinkLevel">IQVDocumentLink.LinkLevel</a> == 4
    """

    link_id_level5 = str
    """
    Element index
    Which [link <a href="#IQVDocumentLink">IQVDocumentLink</a>] section is this element in?
    The id for <a href="#IQVDocumentLink.LinkType">IQVDocumentLink.LinkType</a> == "toc"
    and <a href="#IQVDocumentLink.LinkLevel">IQVDocumentLink.LinkLevel</a> == 5
    """

    link_id_level6 = str
    """
    Element index
    Which [link <a href="#IQVDocumentLink">IQVDocumentLink</a>] section is this element in?
    The id for <a href="#IQVDocumentLink.LinkType">IQVDocumentLink.LinkType</a> == "toc"
    and <a href="#IQVDocumentLink.LinkLevel">IQVDocumentLink.LinkLevel</a> == 6
    """

    link_id_subsection1 = str
    """
    Element index
    Which [link <a href="#IQVDocumentLink">IQVDocumentLink</a>] section is this element in?
    The id for <a href="#IQVDocumentLink.LinkType">IQVDocumentLink.LinkType</a> == "subsection1"
    """

    link_id_subsection2 = str
    """
    Element index
    Which [link <a href="#IQVDocumentLink">IQVDocumentLink</a>] section is this element in?
    The id for <a href="#IQVDocumentLink.LinkType">IQVDocumentLink.LinkType</a> == "subsection2"
    """

    link_id_subsection3 = str
    """
    Element index
    Which [link <a href="#IQVDocumentLink">IQVDocumentLink</a>] section is this element in?
    The id for <a href="#IQVDocumentLink.LinkType">IQVDocumentLink.LinkType</a> == "subsection3"
    """

    link_text = str
    """
    text that is the key to finding this link,
    such as the section prefix number (e.g., "8.1"),
    but *not* the entire text contained in the link
    """

    parent_id = str
    """
    Element index
    Which item is this element a member of?
    For example, for <a href="#IQVPageROI.Properties">IQVPageROI.Properties</a>, parent_id = <a href="#IQVPageROI.id">IQVPageROI.id</a>
    Possible parents include but are not limited to
    <a href="#IQVDocument">IQVDocument</a><a href="#IQVPageROI">IQVPageROI</a><a href="#IQVDocumentLink">IQVDocumentLink</a>
    SQL code example 1 for usage of index
    <code>
    WHERE parent_id=parent_id AND group_type=group_type
    </code>
    SQL code example 2 for usage of index
    <code>
    WHERE parent_id=parent_id
    </code>
    """

    source_text = str
    """
    part (substring) of the parent item text

    text string for the source link
    """

    startIndex = int
    """
    start location of <see cref="P:IQVFileManagerDLL.IQVExternalLink_db.source_text" /> within
    the parent item
    """

    def __init__(self):
        self.connection_type = ''
        self.destination_link_id = ''
        self.destination_link_prefix = ''
        self.destination_link_text = ''
        self.destination_url = ''
        self.doc_id = ''
        self.group_type = ''
        self.hierarchy = ''
        self.id = ''
        self.iqv_standard_term = ''
        self.length = -1
        self.link_id = ''
        self.link_id_level2 = ''
        self.link_id_level3 = ''
        self.link_id_level4 = ''
        self.link_id_level5 = ''
        self.link_id_level6 = ''
        self.link_id_subsection1 = ''
        self.link_id_subsection2 = ''
        self.link_id_subsection3 = ''
        self.link_text = ''
        self.parent_id = ''
        self.source_text = ''
        self.startIndex = -1
        self.id = str(uuid.uuid1())


class IQVExternalLinkElement_db(object):
    """
    
    """

    doc_id = str
    """
    Element index
    Which document is this element in?
    Top-level id for <a href="#IQVDocument">IQVDocument</a>
    """

    group_type = str
    """
    Element index
    Which item is this element a member of? (name of member = group_type)
    For example, for <a href="#IQVPageROI.Properties">IQVPageROI.Properties</a>, group_type = "Properties"
    Possible parents include but are not limited to
    <a href="#IQVDocument">IQVDocument</a><a href="#IQVPageROI">IQVPageROI</a><a href="#IQVDocumentLink">IQVDocumentLink</a>
    SQL code example 1 for usage of index
    <code>
    WHERE parent_id=parent_id AND group_type=group_type
    </code>
    """

    hierarchy = str
    """
    image,table,paragraph,item,header,footer,roi
    """

    id = str
    """

    """

    iqv_standard_term = str
    """
    Element index
    If this element is a link or header, what is the standard term?
    There is 0 or 1 iqv_standard_term for each element
    """

    length = int
    """
    length of text string for this element within the link
    """

    link_id = str
    """
    Element index
    Which [link <a href="#IQVDocumentLink">IQVDocumentLink</a>] section is this element in?
    The id for <a href="#IQVDocumentLink.LinkType">IQVDocumentLink.LinkType</a> == "toc"
    and <a href="#IQVDocumentLink.LinkLevel">IQVDocumentLink.LinkLevel</a> == 1
    """

    link_id_level2 = str
    """
    Element index
    Which [link <a href="#IQVDocumentLink">IQVDocumentLink</a>] section is this element in?
    The id for <a href="#IQVDocumentLink.LinkType">IQVDocumentLink.LinkType</a> == "toc"
    and <a href="#IQVDocumentLink.LinkLevel">IQVDocumentLink.LinkLevel</a> == 2
    """

    link_id_level3 = str
    """
    Element index
    Which [link <a href="#IQVDocumentLink">IQVDocumentLink</a>] section is this element in?
    The id for <a href="#IQVDocumentLink.LinkType">IQVDocumentLink.LinkType</a> == "toc"
    and <a href="#IQVDocumentLink.LinkLevel">IQVDocumentLink.LinkLevel</a> == 3
    """

    link_id_level4 = str
    """
    Element index
    Which [link <a href="#IQVDocumentLink">IQVDocumentLink</a>] section is this element in?
    The id for <a href="#IQVDocumentLink.LinkType">IQVDocumentLink.LinkType</a> == "toc"
    and <a href="#IQVDocumentLink.LinkLevel">IQVDocumentLink.LinkLevel</a> == 4
    """

    link_id_level5 = str
    """
    Element index
    Which [link <a href="#IQVDocumentLink">IQVDocumentLink</a>] section is this element in?
    The id for <a href="#IQVDocumentLink.LinkType">IQVDocumentLink.LinkType</a> == "toc"
    and <a href="#IQVDocumentLink.LinkLevel">IQVDocumentLink.LinkLevel</a> == 5
    """

    link_id_level6 = str
    """
    Element index
    Which [link <a href="#IQVDocumentLink">IQVDocumentLink</a>] section is this element in?
    The id for <a href="#IQVDocumentLink.LinkType">IQVDocumentLink.LinkType</a> == "toc"
    and <a href="#IQVDocumentLink.LinkLevel">IQVDocumentLink.LinkLevel</a> == 6
    """

    link_id_subsection1 = str
    """
    Element index
    Which [link <a href="#IQVDocumentLink">IQVDocumentLink</a>] section is this element in?
    The id for <a href="#IQVDocumentLink.LinkType">IQVDocumentLink.LinkType</a> == "subsection1"
    """

    link_id_subsection2 = str
    """
    Element index
    Which [link <a href="#IQVDocumentLink">IQVDocumentLink</a>] section is this element in?
    The id for <a href="#IQVDocumentLink.LinkType">IQVDocumentLink.LinkType</a> == "subsection2"
    """

    link_id_subsection3 = str
    """
    Element index
    Which [link <a href="#IQVDocumentLink">IQVDocumentLink</a>] section is this element in?
    The id for <a href="#IQVDocumentLink.LinkType">IQVDocumentLink.LinkType</a> == "subsection3"
    """

    parent_id = str
    """
    Element index
    Which item is this element a member of?
    For example, for <a href="#IQVPageROI.Properties">IQVPageROI.Properties</a>, parent_id = <a href="#IQVPageROI.id">IQVPageROI.id</a>
    Possible parents include but are not limited to
    <a href="#IQVDocument">IQVDocument</a><a href="#IQVPageROI">IQVPageROI</a><a href="#IQVDocumentLink">IQVDocumentLink</a>
    SQL code example 1 for usage of index
    <code>
    WHERE parent_id=parent_id AND group_type=group_type
    </code>
    SQL code example 2 for usage of index
    <code>
    WHERE parent_id=parent_id
    </code>
    """

    startIndex = int
    """
    location of text string for this element within the link
    """

    text = str
    """
    text string for this element within the link
    """

    def __init__(self):
        self.doc_id = ''
        self.group_type = ''
        self.hierarchy = ''
        self.id = ''
        self.iqv_standard_term = ''
        self.length = -1
        self.link_id = ''
        self.link_id_level2 = ''
        self.link_id_level3 = ''
        self.link_id_level4 = ''
        self.link_id_level5 = ''
        self.link_id_level6 = ''
        self.link_id_subsection1 = ''
        self.link_id_subsection2 = ''
        self.link_id_subsection3 = ''
        self.parent_id = ''
        self.startIndex = -1
        self.text = ''
        self.id = str(uuid.uuid1())


class IQVLine_db(object):
    """
    A line with points (X1,Y1) and (X2,Y2) and thickness.
     The thickness may be defined at a
     more granular level using (X1Right,Y1Lower) and (X2Right,Y2Lower)
    """

    BackgroundToForeground = bool
    """
    Change is background to foreground
    """

    bIncludedInBox = bool
    """

    """

    bIsHorizontal = bool
    """
    Either horizontal or vertical
    """

    doc_id = str
    """
    Element index
    Which document is this element in?
    Top-level id for <a href="#IQVDocument">IQVDocument</a>
    """

    ForegroundToBackground = bool
    """
    Change is foreground to background
    """

    group_type = str
    """
    Element index
    Which item is this element a member of? (name of member = group_type)
    For example, for <a href="#IQVPageROI.Properties">IQVPageROI.Properties</a>, group_type = "Properties"
    Possible parents include but are not limited to
    <a href="#IQVDocument">IQVDocument</a><a href="#IQVPageROI">IQVPageROI</a><a href="#IQVDocumentLink">IQVDocumentLink</a>
    SQL code example 1 for usage of index
    <code>
    WHERE parent_id=parent_id AND group_type=group_type
    </code>
    """

    hierarchy = str
    """
    image,table,paragraph,item,header,footer,roi
    """

    id = str
    """

    """

    iqv_standard_term = str
    """
    Element index
    If this element is a link or header, what is the standard term?
    There is 0 or 1 iqv_standard_term for each element
    """

    link_id = str
    """
    Element index
    Which [link <a href="#IQVDocumentLink">IQVDocumentLink</a>] section is this element in?
    The id for <a href="#IQVDocumentLink.LinkType">IQVDocumentLink.LinkType</a> == "toc"
    and <a href="#IQVDocumentLink.LinkLevel">IQVDocumentLink.LinkLevel</a> == 1
    """

    link_id_level2 = str
    """
    Element index
    Which [link <a href="#IQVDocumentLink">IQVDocumentLink</a>] section is this element in?
    The id for <a href="#IQVDocumentLink.LinkType">IQVDocumentLink.LinkType</a> == "toc"
    and <a href="#IQVDocumentLink.LinkLevel">IQVDocumentLink.LinkLevel</a> == 2
    """

    link_id_level3 = str
    """
    Element index
    Which [link <a href="#IQVDocumentLink">IQVDocumentLink</a>] section is this element in?
    The id for <a href="#IQVDocumentLink.LinkType">IQVDocumentLink.LinkType</a> == "toc"
    and <a href="#IQVDocumentLink.LinkLevel">IQVDocumentLink.LinkLevel</a> == 3
    """

    link_id_level4 = str
    """
    Element index
    Which [link <a href="#IQVDocumentLink">IQVDocumentLink</a>] section is this element in?
    The id for <a href="#IQVDocumentLink.LinkType">IQVDocumentLink.LinkType</a> == "toc"
    and <a href="#IQVDocumentLink.LinkLevel">IQVDocumentLink.LinkLevel</a> == 4
    """

    link_id_level5 = str
    """
    Element index
    Which [link <a href="#IQVDocumentLink">IQVDocumentLink</a>] section is this element in?
    The id for <a href="#IQVDocumentLink.LinkType">IQVDocumentLink.LinkType</a> == "toc"
    and <a href="#IQVDocumentLink.LinkLevel">IQVDocumentLink.LinkLevel</a> == 5
    """

    link_id_level6 = str
    """
    Element index
    Which [link <a href="#IQVDocumentLink">IQVDocumentLink</a>] section is this element in?
    The id for <a href="#IQVDocumentLink.LinkType">IQVDocumentLink.LinkType</a> == "toc"
    and <a href="#IQVDocumentLink.LinkLevel">IQVDocumentLink.LinkLevel</a> == 6
    """

    link_id_subsection1 = str
    """
    Element index
    Which [link <a href="#IQVDocumentLink">IQVDocumentLink</a>] section is this element in?
    The id for <a href="#IQVDocumentLink.LinkType">IQVDocumentLink.LinkType</a> == "subsection1"
    """

    link_id_subsection2 = str
    """
    Element index
    Which [link <a href="#IQVDocumentLink">IQVDocumentLink</a>] section is this element in?
    The id for <a href="#IQVDocumentLink.LinkType">IQVDocumentLink.LinkType</a> == "subsection2"
    """

    link_id_subsection3 = str
    """
    Element index
    Which [link <a href="#IQVDocumentLink">IQVDocumentLink</a>] section is this element in?
    The id for <a href="#IQVDocumentLink.LinkType">IQVDocumentLink.LinkType</a> == "subsection3"
    """

    parent_id = str
    """
    Element index
    Which item is this element a member of?
    For example, for <a href="#IQVPageROI.Properties">IQVPageROI.Properties</a>, parent_id = <a href="#IQVPageROI.id">IQVPageROI.id</a>
    Possible parents include but are not limited to
    <a href="#IQVDocument">IQVDocument</a><a href="#IQVPageROI">IQVPageROI</a><a href="#IQVDocumentLink">IQVDocumentLink</a>
    SQL code example 1 for usage of index
    <code>
    WHERE parent_id=parent_id AND group_type=group_type
    </code>
    SQL code example 2 for usage of index
    <code>
    WHERE parent_id=parent_id
    </code>
    """

    ParentID = int
    """
    parent id
    """

    SequenceID = int
    """
    sequential id of line in ROI
    """

    Thickness = int
    """
    Thickness in pixels unless otherwise specified in <see cref="P:IQVFileManagerDLL.IQVLine_db.ThicknessUnit" />
    """

    ThicknessUnit = int
    """
    0=pixels
    1=inches
    """

    TopParentID = int
    """
    Global group of segments identified
    by this value
    """

    X1 = int
    """
    left of horizontal line; should be
    same as X2 for vertical line
    """

    X1Right = int
    """
    thickness of top of vertical line is given here;
    not valid for horizontal line
    """

    X2 = int
    """
    right of horizontal line; should be same as X1
    for vertical line (diff if slanted)
    """

    X2Right = int
    """
    thickness of bottom of vertical line is given here;
    not valid for horizontal line
    """

    Y1 = int
    """
    top of vertical line;
    """

    Y1Lower = int
    """
    thickness of left side of horizontal line given here;
    not valid for vertical line
    """

    Y2 = int
    """
    right side of horizontal line;
    should be same as Y1 for horizontal line (unless slanted)
    """

    Y2Lower = int
    """
    thickness of right side of horizontal line given here;
    not valid for vertical line
    """

    def __init__(self):
        self.BackgroundToForeground = False
        self.bIncludedInBox = False
        self.bIsHorizontal = False
        self.doc_id = ''
        self.ForegroundToBackground = False
        self.group_type = ''
        self.hierarchy = ''
        self.id = ''
        self.iqv_standard_term = ''
        self.link_id = ''
        self.link_id_level2 = ''
        self.link_id_level3 = ''
        self.link_id_level4 = ''
        self.link_id_level5 = ''
        self.link_id_level6 = ''
        self.link_id_subsection1 = ''
        self.link_id_subsection2 = ''
        self.link_id_subsection3 = ''
        self.parent_id = ''
        self.ParentID = -1
        self.SequenceID = -1
        self.Thickness = -1
        self.ThicknessUnit = -1
        self.TopParentID = -1
        self.X1 = -1
        self.X1Right = -1
        self.X2 = -1
        self.X2Right = -1
        self.Y1 = -1
        self.Y1Lower = -1
        self.Y2 = -1
        self.Y2Lower = -1
        self.id = str(uuid.uuid1())


class IQVNumberingGroup_db(object):
    """
    Information about bullets
    """

    abstractNumId = int
    """
    id for formatting of bullet
    """

    countItems = int
    """
    num items with this numbering
    """

    doc_id = str
    """
    Element index
    Which document is this element in?
    Top-level id for <a href="#IQVDocument">IQVDocument</a>
    """

    group_type = str
    """
    Element index
    Which item is this element a member of? (name of member = group_type)
    For example, for <a href="#IQVPageROI.Properties">IQVPageROI.Properties</a>, group_type = "Properties"
    Possible parents include but are not limited to
    <a href="#IQVDocument">IQVDocument</a><a href="#IQVPageROI">IQVPageROI</a><a href="#IQVDocumentLink">IQVDocumentLink</a>
    SQL code example 1 for usage of index
    <code>
    WHERE parent_id=parent_id AND group_type=group_type
    </code>
    """

    hierarchy = str
    """
    image,table,paragraph,item,header,footer,roi
    """

    id = str
    """

    """

    iqv_standard_term = str
    """
    Element index
    If this element is a link or header, what is the standard term?
    There is 0 or 1 iqv_standard_term for each element
    """

    link_id = str
    """
    Element index
    Which [link <a href="#IQVDocumentLink">IQVDocumentLink</a>] section is this element in?
    The id for <a href="#IQVDocumentLink.LinkType">IQVDocumentLink.LinkType</a> == "toc"
    and <a href="#IQVDocumentLink.LinkLevel">IQVDocumentLink.LinkLevel</a> == 1
    """

    link_id_level2 = str
    """
    Element index
    Which [link <a href="#IQVDocumentLink">IQVDocumentLink</a>] section is this element in?
    The id for <a href="#IQVDocumentLink.LinkType">IQVDocumentLink.LinkType</a> == "toc"
    and <a href="#IQVDocumentLink.LinkLevel">IQVDocumentLink.LinkLevel</a> == 2
    """

    link_id_level3 = str
    """
    Element index
    Which [link <a href="#IQVDocumentLink">IQVDocumentLink</a>] section is this element in?
    The id for <a href="#IQVDocumentLink.LinkType">IQVDocumentLink.LinkType</a> == "toc"
    and <a href="#IQVDocumentLink.LinkLevel">IQVDocumentLink.LinkLevel</a> == 3
    """

    link_id_level4 = str
    """
    Element index
    Which [link <a href="#IQVDocumentLink">IQVDocumentLink</a>] section is this element in?
    The id for <a href="#IQVDocumentLink.LinkType">IQVDocumentLink.LinkType</a> == "toc"
    and <a href="#IQVDocumentLink.LinkLevel">IQVDocumentLink.LinkLevel</a> == 4
    """

    link_id_level5 = str
    """
    Element index
    Which [link <a href="#IQVDocumentLink">IQVDocumentLink</a>] section is this element in?
    The id for <a href="#IQVDocumentLink.LinkType">IQVDocumentLink.LinkType</a> == "toc"
    and <a href="#IQVDocumentLink.LinkLevel">IQVDocumentLink.LinkLevel</a> == 5
    """

    link_id_level6 = str
    """
    Element index
    Which [link <a href="#IQVDocumentLink">IQVDocumentLink</a>] section is this element in?
    The id for <a href="#IQVDocumentLink.LinkType">IQVDocumentLink.LinkType</a> == "toc"
    and <a href="#IQVDocumentLink.LinkLevel">IQVDocumentLink.LinkLevel</a> == 6
    """

    link_id_subsection1 = str
    """
    Element index
    Which [link <a href="#IQVDocumentLink">IQVDocumentLink</a>] section is this element in?
    The id for <a href="#IQVDocumentLink.LinkType">IQVDocumentLink.LinkType</a> == "subsection1"
    """

    link_id_subsection2 = str
    """
    Element index
    Which [link <a href="#IQVDocumentLink">IQVDocumentLink</a>] section is this element in?
    The id for <a href="#IQVDocumentLink.LinkType">IQVDocumentLink.LinkType</a> == "subsection2"
    """

    link_id_subsection3 = str
    """
    Element index
    Which [link <a href="#IQVDocumentLink">IQVDocumentLink</a>] section is this element in?
    The id for <a href="#IQVDocumentLink.LinkType">IQVDocumentLink.LinkType</a> == "subsection3"
    """

    numId = int
    """
    all items with same numId are of same group, with same numbering system
    """

    paraEndIndex = int
    """
    Last para index in this numbering group
    """

    paraIds_list = str
    """
    All ids in this numbering group
    """

    paraStartIndex = int
    """
    First para index in this numbering group
    """

    parent_id = str
    """
    Element index
    Which item is this element a member of?
    For example, for <a href="#IQVPageROI.Properties">IQVPageROI.Properties</a>, parent_id = <a href="#IQVPageROI.id">IQVPageROI.id</a>
    Possible parents include but are not limited to
    <a href="#IQVDocument">IQVDocument</a><a href="#IQVPageROI">IQVPageROI</a><a href="#IQVDocumentLink">IQVDocumentLink</a>
    SQL code example 1 for usage of index
    <code>
    WHERE parent_id=parent_id AND group_type=group_type
    </code>
    SQL code example 2 for usage of index
    <code>
    WHERE parent_id=parent_id
    </code>
    """

    def __init__(self):
        self.abstractNumId = -1
        self.countItems = -1
        self.doc_id = ''
        self.group_type = ''
        self.hierarchy = ''
        self.id = ''
        self.iqv_standard_term = ''
        self.link_id = ''
        self.link_id_level2 = ''
        self.link_id_level3 = ''
        self.link_id_level4 = ''
        self.link_id_level5 = ''
        self.link_id_level6 = ''
        self.link_id_subsection1 = ''
        self.link_id_subsection2 = ''
        self.link_id_subsection3 = ''
        self.numId = -1
        self.paraEndIndex = -1
        self.paraIds_list = ''
        self.paraStartIndex = -1
        self.parent_id = ''
        self.id = str(uuid.uuid1())


class IQVNumberingLevel_db(object):
    """
    Format for each level, starting with level 0
    """

    doc_id = str
    """
    Element index
    Which document is this element in?
    Top-level id for <a href="#IQVDocument">IQVDocument</a>
    """

    group_type = str
    """
    Element index
    Which item is this element a member of? (name of member = group_type)
    For example, for <a href="#IQVPageROI.Properties">IQVPageROI.Properties</a>, group_type = "Properties"
    Possible parents include but are not limited to
    <a href="#IQVDocument">IQVDocument</a><a href="#IQVPageROI">IQVPageROI</a><a href="#IQVDocumentLink">IQVDocumentLink</a>
    SQL code example 1 for usage of index
    <code>
    WHERE parent_id=parent_id AND group_type=group_type
    </code>
    """

    hierarchy = str
    """
    image,table,paragraph,item,header,footer,roi
    """

    id = str
    """

    """

    ilvl = int
    """
    ilvl index
    """

    iqv_standard_term = str
    """
    Element index
    If this element is a link or header, what is the standard term?
    There is 0 or 1 iqv_standard_term for each element
    """

    link_id = str
    """
    Element index
    Which [link <a href="#IQVDocumentLink">IQVDocumentLink</a>] section is this element in?
    The id for <a href="#IQVDocumentLink.LinkType">IQVDocumentLink.LinkType</a> == "toc"
    and <a href="#IQVDocumentLink.LinkLevel">IQVDocumentLink.LinkLevel</a> == 1
    """

    link_id_level2 = str
    """
    Element index
    Which [link <a href="#IQVDocumentLink">IQVDocumentLink</a>] section is this element in?
    The id for <a href="#IQVDocumentLink.LinkType">IQVDocumentLink.LinkType</a> == "toc"
    and <a href="#IQVDocumentLink.LinkLevel">IQVDocumentLink.LinkLevel</a> == 2
    """

    link_id_level3 = str
    """
    Element index
    Which [link <a href="#IQVDocumentLink">IQVDocumentLink</a>] section is this element in?
    The id for <a href="#IQVDocumentLink.LinkType">IQVDocumentLink.LinkType</a> == "toc"
    and <a href="#IQVDocumentLink.LinkLevel">IQVDocumentLink.LinkLevel</a> == 3
    """

    link_id_level4 = str
    """
    Element index
    Which [link <a href="#IQVDocumentLink">IQVDocumentLink</a>] section is this element in?
    The id for <a href="#IQVDocumentLink.LinkType">IQVDocumentLink.LinkType</a> == "toc"
    and <a href="#IQVDocumentLink.LinkLevel">IQVDocumentLink.LinkLevel</a> == 4
    """

    link_id_level5 = str
    """
    Element index
    Which [link <a href="#IQVDocumentLink">IQVDocumentLink</a>] section is this element in?
    The id for <a href="#IQVDocumentLink.LinkType">IQVDocumentLink.LinkType</a> == "toc"
    and <a href="#IQVDocumentLink.LinkLevel">IQVDocumentLink.LinkLevel</a> == 5
    """

    link_id_level6 = str
    """
    Element index
    Which [link <a href="#IQVDocumentLink">IQVDocumentLink</a>] section is this element in?
    The id for <a href="#IQVDocumentLink.LinkType">IQVDocumentLink.LinkType</a> == "toc"
    and <a href="#IQVDocumentLink.LinkLevel">IQVDocumentLink.LinkLevel</a> == 6
    """

    link_id_subsection1 = str
    """
    Element index
    Which [link <a href="#IQVDocumentLink">IQVDocumentLink</a>] section is this element in?
    The id for <a href="#IQVDocumentLink.LinkType">IQVDocumentLink.LinkType</a> == "subsection1"
    """

    link_id_subsection2 = str
    """
    Element index
    Which [link <a href="#IQVDocumentLink">IQVDocumentLink</a>] section is this element in?
    The id for <a href="#IQVDocumentLink.LinkType">IQVDocumentLink.LinkType</a> == "subsection2"
    """

    link_id_subsection3 = str
    """
    Element index
    Which [link <a href="#IQVDocumentLink">IQVDocumentLink</a>] section is this element in?
    The id for <a href="#IQVDocumentLink.LinkType">IQVDocumentLink.LinkType</a> == "subsection3"
    """

    lvlText = str
    """
    "·"
    "•"
    %2
    %1.
    """

    numFmt = str
    """
    bullet
    lowerLetter
    lowerRoman
    decimal
    upperLetter
    """

    parent_id = str
    """
    Element index
    Which item is this element a member of?
    For example, for <a href="#IQVPageROI.Properties">IQVPageROI.Properties</a>, parent_id = <a href="#IQVPageROI.id">IQVPageROI.id</a>
    Possible parents include but are not limited to
    <a href="#IQVDocument">IQVDocument</a><a href="#IQVPageROI">IQVPageROI</a><a href="#IQVDocumentLink">IQVDocumentLink</a>
    SQL code example 1 for usage of index
    <code>
    WHERE parent_id=parent_id AND group_type=group_type
    </code>
    SQL code example 2 for usage of index
    <code>
    WHERE parent_id=parent_id
    </code>
    """

    start = str
    """
    start text
    """

    def __init__(self):
        self.doc_id = ''
        self.group_type = ''
        self.hierarchy = ''
        self.id = ''
        self.ilvl = -1
        self.iqv_standard_term = ''
        self.link_id = ''
        self.link_id_level2 = ''
        self.link_id_level3 = ''
        self.link_id_level4 = ''
        self.link_id_level5 = ''
        self.link_id_level6 = ''
        self.link_id_subsection1 = ''
        self.link_id_subsection2 = ''
        self.link_id_subsection3 = ''
        self.lvlText = ''
        self.numFmt = ''
        self.parent_id = ''
        self.start = ''
        self.id = str(uuid.uuid1())


class IQVRedactionProfile_db(object):
    """
    Used to assign role-based redaction. Role should
    be assigned a profile. The profile lists all
    possible <a href="#IQVRedactionCategory">IQVRedactionCategory</a> and
    indicator whether to redact or not <a href="#IQVRedactionCategory.IsRedacted">IQVRedactionCategory.IsRedacted</a>
    """

    DefaultIsRedacted = int
    """
    0 or 1
    0 = Do not redact this item
    1 = Do redact this item
    """

    id = str
    """

    """

    def __init__(self):
        self.DefaultIsRedacted = -1
        self.id = ''
        self.id = str(uuid.uuid1())


class IQVRedactionCategory_db(object):
    """
    Redaction Category with specification if
     redacted or not. See <a href="#IQVRedactionProfile">IQVRedactionProfile</a>
    for building a profile of a list of these
    """

    Category = str
    """
    Label for category as found in i2e results,
    IQV.XML, and JSON tags
    """

    id = str
    """

    """

    IsRedacted = int
    """
    0 or 1
    0 = Do not redact this item
    1 = Do redact this item
    """

    Query = str
    """
    i2e Query name
    """

    def __init__(self):
        self.Category = ''
        self.id = ''
        self.IsRedacted = -1
        self.Query = ''
        self.id = str(uuid.uuid1())


class NLP_System_Mapping_db(object):
    """
    NLP System such as LM
    """

    DataType = str
    """

    """

    doc_id = str
    """
    Element index
    Which document is this element in?
    Top-level id for <a href="#IQVDocument">IQVDocument</a>
    """

    EntityKey = str
    """
    Used in Property in IQV.XML
    """

    FilenameKey = str
    """

    """

    group_type = str
    """
    Element index
    Which item is this element a member of? (name of member = group_type)
    For example, for <a href="#IQVPageROI.Properties">IQVPageROI.Properties</a>, group_type = "Properties"
    Possible parents include but are not limited to
    <a href="#IQVDocument">IQVDocument</a><a href="#IQVPageROI">IQVPageROI</a><a href="#IQVDocumentLink">IQVDocumentLink</a>
    SQL code example 1 for usage of index
    <code>
    WHERE parent_id=parent_id AND group_type=group_type
    </code>
    """

    hierarchy = str
    """
    image,table,paragraph,item,header,footer,roi
    """

    id = str
    """
    Unique id for element using <see cref="T:System.Guid" />
    """

    iqv_standard_term = str
    """
    Element index
    If this element is a link or header, what is the standard term?
    There is 0 or 1 iqv_standard_term for each element
    """

    link_id = str
    """
    Element index
    Which [link <a href="#IQVDocumentLink">IQVDocumentLink</a>] section is this element in?
    The id for <a href="#IQVDocumentLink.LinkType">IQVDocumentLink.LinkType</a> == "toc"
    and <a href="#IQVDocumentLink.LinkLevel">IQVDocumentLink.LinkLevel</a> == 1
    """

    link_id_level2 = str
    """
    Element index
    Which [link <a href="#IQVDocumentLink">IQVDocumentLink</a>] section is this element in?
    The id for <a href="#IQVDocumentLink.LinkType">IQVDocumentLink.LinkType</a> == "toc"
    and <a href="#IQVDocumentLink.LinkLevel">IQVDocumentLink.LinkLevel</a> == 2
    """

    link_id_level3 = str
    """
    Element index
    Which [link <a href="#IQVDocumentLink">IQVDocumentLink</a>] section is this element in?
    The id for <a href="#IQVDocumentLink.LinkType">IQVDocumentLink.LinkType</a> == "toc"
    and <a href="#IQVDocumentLink.LinkLevel">IQVDocumentLink.LinkLevel</a> == 3
    """

    link_id_level4 = str
    """
    Element index
    Which [link <a href="#IQVDocumentLink">IQVDocumentLink</a>] section is this element in?
    The id for <a href="#IQVDocumentLink.LinkType">IQVDocumentLink.LinkType</a> == "toc"
    and <a href="#IQVDocumentLink.LinkLevel">IQVDocumentLink.LinkLevel</a> == 4
    """

    link_id_level5 = str
    """
    Element index
    Which [link <a href="#IQVDocumentLink">IQVDocumentLink</a>] section is this element in?
    The id for <a href="#IQVDocumentLink.LinkType">IQVDocumentLink.LinkType</a> == "toc"
    and <a href="#IQVDocumentLink.LinkLevel">IQVDocumentLink.LinkLevel</a> == 5
    """

    link_id_level6 = str
    """
    Element index
    Which [link <a href="#IQVDocumentLink">IQVDocumentLink</a>] section is this element in?
    The id for <a href="#IQVDocumentLink.LinkType">IQVDocumentLink.LinkType</a> == "toc"
    and <a href="#IQVDocumentLink.LinkLevel">IQVDocumentLink.LinkLevel</a> == 6
    """

    link_id_subsection1 = str
    """
    Element index
    Which [link <a href="#IQVDocumentLink">IQVDocumentLink</a>] section is this element in?
    The id for <a href="#IQVDocumentLink.LinkType">IQVDocumentLink.LinkType</a> == "subsection1"
    """

    link_id_subsection2 = str
    """
    Element index
    Which [link <a href="#IQVDocumentLink">IQVDocumentLink</a>] section is this element in?
    The id for <a href="#IQVDocumentLink.LinkType">IQVDocumentLink.LinkType</a> == "subsection2"
    """

    link_id_subsection3 = str
    """
    Element index
    Which [link <a href="#IQVDocumentLink">IQVDocumentLink</a>] section is this element in?
    The id for <a href="#IQVDocumentLink.LinkType">IQVDocumentLink.LinkType</a> == "subsection3"
    """

    NLPSystem = str
    """

    """

    NLPSystemQueryName = str
    """

    """

    NLPSystemVersion = str
    """

    """

    parent_id = str
    """
    Element index
    Which item is this element a member of?
    For example, for <a href="#IQVPageROI.Properties">IQVPageROI.Properties</a>, parent_id = <a href="#IQVPageROI.id">IQVPageROI.id</a>
    Possible parents include but are not limited to
    <a href="#IQVDocument">IQVDocument</a><a href="#IQVPageROI">IQVPageROI</a><a href="#IQVDocumentLink">IQVDocumentLink</a>
    SQL code example 1 for usage of index
    <code>
    WHERE parent_id=parent_id AND group_type=group_type
    </code>
    SQL code example 2 for usage of index
    <code>
    WHERE parent_id=parent_id
    </code>
    """

    QCFeedbackUIKey = str
    """
    Used in qc feedback as field_name
    """

    def __init__(self):
        self.DataType = ''
        self.doc_id = ''
        self.EntityKey = ''
        self.FilenameKey = ''
        self.group_type = ''
        self.hierarchy = ''
        self.id = ''
        self.iqv_standard_term = ''
        self.link_id = ''
        self.link_id_level2 = ''
        self.link_id_level3 = ''
        self.link_id_level4 = ''
        self.link_id_level5 = ''
        self.link_id_level6 = ''
        self.link_id_subsection1 = ''
        self.link_id_subsection2 = ''
        self.link_id_subsection3 = ''
        self.NLPSystem = ''
        self.NLPSystemQueryName = ''
        self.NLPSystemVersion = ''
        self.parent_id = ''
        self.QCFeedbackUIKey = ''
        self.id = str(uuid.uuid1())


class NLP_Segment_db(object):
    """
    Extracted from <a href="#IQVPageROI">IQVPageROI</a>
    For OMOP XML--based on https://www.ohdsi.org/data-standardization/the-common-data-model/
    Observational Medical Outcomes Partnership
    """

    doc_id = str
    """
    Element index
    Which document is this element in?
    Top-level id for <a href="#IQVDocument">IQVDocument</a>
    """

    group_type = str
    """
    Element index
    Which item is this element a member of? (name of member = group_type)
    For example, for <a href="#IQVPageROI.Properties">IQVPageROI.Properties</a>, group_type = "Properties"
    Possible parents include but are not limited to
    <a href="#IQVDocument">IQVDocument</a><a href="#IQVPageROI">IQVPageROI</a><a href="#IQVDocumentLink">IQVDocumentLink</a>
    SQL code example 1 for usage of index
    <code>
    WHERE parent_id=parent_id AND group_type=group_type
    </code>
    """

    hierarchy = str
    """
    image,table,paragraph,item,header,footer,roi
    """

    id = str
    """
    Unique id for element using <see cref="T:System.Guid" />
    """

    iqv_standard_term = str
    """
    Element index
    If this element is a link or header, what is the standard term?
    There is 0 or 1 iqv_standard_term for each element
    """

    link_id = str
    """
    Element index
    Which [link <a href="#IQVDocumentLink">IQVDocumentLink</a>] section is this element in?
    The id for <a href="#IQVDocumentLink.LinkType">IQVDocumentLink.LinkType</a> == "toc"
    and <a href="#IQVDocumentLink.LinkLevel">IQVDocumentLink.LinkLevel</a> == 1
    """

    link_id_level2 = str
    """
    Element index
    Which [link <a href="#IQVDocumentLink">IQVDocumentLink</a>] section is this element in?
    The id for <a href="#IQVDocumentLink.LinkType">IQVDocumentLink.LinkType</a> == "toc"
    and <a href="#IQVDocumentLink.LinkLevel">IQVDocumentLink.LinkLevel</a> == 2
    """

    link_id_level3 = str
    """
    Element index
    Which [link <a href="#IQVDocumentLink">IQVDocumentLink</a>] section is this element in?
    The id for <a href="#IQVDocumentLink.LinkType">IQVDocumentLink.LinkType</a> == "toc"
    and <a href="#IQVDocumentLink.LinkLevel">IQVDocumentLink.LinkLevel</a> == 3
    """

    link_id_level4 = str
    """
    Element index
    Which [link <a href="#IQVDocumentLink">IQVDocumentLink</a>] section is this element in?
    The id for <a href="#IQVDocumentLink.LinkType">IQVDocumentLink.LinkType</a> == "toc"
    and <a href="#IQVDocumentLink.LinkLevel">IQVDocumentLink.LinkLevel</a> == 4
    """

    link_id_level5 = str
    """
    Element index
    Which [link <a href="#IQVDocumentLink">IQVDocumentLink</a>] section is this element in?
    The id for <a href="#IQVDocumentLink.LinkType">IQVDocumentLink.LinkType</a> == "toc"
    and <a href="#IQVDocumentLink.LinkLevel">IQVDocumentLink.LinkLevel</a> == 5
    """

    link_id_level6 = str
    """
    Element index
    Which [link <a href="#IQVDocumentLink">IQVDocumentLink</a>] section is this element in?
    The id for <a href="#IQVDocumentLink.LinkType">IQVDocumentLink.LinkType</a> == "toc"
    and <a href="#IQVDocumentLink.LinkLevel">IQVDocumentLink.LinkLevel</a> == 6
    """

    link_id_subsection1 = str
    """
    Element index
    Which [link <a href="#IQVDocumentLink">IQVDocumentLink</a>] section is this element in?
    The id for <a href="#IQVDocumentLink.LinkType">IQVDocumentLink.LinkType</a> == "subsection1"
    """

    link_id_subsection2 = str
    """
    Element index
    Which [link <a href="#IQVDocumentLink">IQVDocumentLink</a>] section is this element in?
    The id for <a href="#IQVDocumentLink.LinkType">IQVDocumentLink.LinkType</a> == "subsection2"
    """

    link_id_subsection3 = str
    """
    Element index
    Which [link <a href="#IQVDocumentLink">IQVDocumentLink</a>] section is this element in?
    The id for <a href="#IQVDocumentLink.LinkType">IQVDocumentLink.LinkType</a> == "subsection3"
    """

    parent_id = str
    """
    Element index
    Which item is this element a member of?
    For example, for <a href="#IQVPageROI.Properties">IQVPageROI.Properties</a>, parent_id = <a href="#IQVPageROI.id">IQVPageROI.id</a>
    Possible parents include but are not limited to
    <a href="#IQVDocument">IQVDocument</a><a href="#IQVPageROI">IQVPageROI</a><a href="#IQVDocumentLink">IQVDocumentLink</a>
    SQL code example 1 for usage of index
    <code>
    WHERE parent_id=parent_id AND group_type=group_type
    </code>
    SQL code example 2 for usage of index
    <code>
    WHERE parent_id=parent_id
    </code>
    """

    primary_section = str
    """
    primary section of the document in which text is located
    """

    secondary_section = str
    """
    secondary section of the document in which text is located
    """

    segment_type = str
    """
    table, tr, td, section, etc.
    """

    text = str
    """
    segment text
    """

    text_footnotes_list = []
    """
    segment text footnotes
    """

    def __init__(self):
        self.doc_id = ''
        self.group_type = ''
        self.hierarchy = ''
        self.id = ''
        self.iqv_standard_term = ''
        self.link_id = ''
        self.link_id_level2 = ''
        self.link_id_level3 = ''
        self.link_id_level4 = ''
        self.link_id_level5 = ''
        self.link_id_level6 = ''
        self.link_id_subsection1 = ''
        self.link_id_subsection2 = ''
        self.link_id_subsection3 = ''
        self.parent_id = ''
        self.primary_section = ''
        self.secondary_section = ''
        self.segment_type = ''
        self.text = ''
        self.text_footnotes_list = []
        self.id = str(uuid.uuid1())


class NLP_Relation_db(object):
    """
    For OMOP XML--based on https://www.ohdsi.org/data-standardization/the-common-data-model/
    Observational Medical Outcomes Partnership
    """

    confidence = float
    """
    Probability score of correctness of this label
    """

    doc_id = str
    """
    Element index
    Which document is this element in?
    Top-level id for <a href="#IQVDocument">IQVDocument</a>
    """

    entities_list = str
    """

    """

    group_type = str
    """
    Element index
    Which item is this element a member of? (name of member = group_type)
    For example, for <a href="#IQVPageROI.Properties">IQVPageROI.Properties</a>, group_type = "Properties"
    Possible parents include but are not limited to
    <a href="#IQVDocument">IQVDocument</a><a href="#IQVPageROI">IQVPageROI</a><a href="#IQVDocumentLink">IQVDocumentLink</a>
    SQL code example 1 for usage of index
    <code>
    WHERE parent_id=parent_id AND group_type=group_type
    </code>
    """

    hierarchy = str
    """
    image,table,paragraph,item,header,footer,roi
    """

    id = str
    """
    Unique id for element using <see cref="T:System.Guid" />
    """

    iqv_standard_term = str
    """
    Element index
    If this element is a link or header, what is the standard term?
    There is 0 or 1 iqv_standard_term for each element
    """

    is_bidirectional = int
    """
    0=no (default), 1=yes
    """

    is_hierarchical = int
    """
    0=no (default), 1=yes
    """

    link_id = str
    """
    Element index
    Which [link <a href="#IQVDocumentLink">IQVDocumentLink</a>] section is this element in?
    The id for <a href="#IQVDocumentLink.LinkType">IQVDocumentLink.LinkType</a> == "toc"
    and <a href="#IQVDocumentLink.LinkLevel">IQVDocumentLink.LinkLevel</a> == 1
    """

    link_id_level2 = str
    """
    Element index
    Which [link <a href="#IQVDocumentLink">IQVDocumentLink</a>] section is this element in?
    The id for <a href="#IQVDocumentLink.LinkType">IQVDocumentLink.LinkType</a> == "toc"
    and <a href="#IQVDocumentLink.LinkLevel">IQVDocumentLink.LinkLevel</a> == 2
    """

    link_id_level3 = str
    """
    Element index
    Which [link <a href="#IQVDocumentLink">IQVDocumentLink</a>] section is this element in?
    The id for <a href="#IQVDocumentLink.LinkType">IQVDocumentLink.LinkType</a> == "toc"
    and <a href="#IQVDocumentLink.LinkLevel">IQVDocumentLink.LinkLevel</a> == 3
    """

    link_id_level4 = str
    """
    Element index
    Which [link <a href="#IQVDocumentLink">IQVDocumentLink</a>] section is this element in?
    The id for <a href="#IQVDocumentLink.LinkType">IQVDocumentLink.LinkType</a> == "toc"
    and <a href="#IQVDocumentLink.LinkLevel">IQVDocumentLink.LinkLevel</a> == 4
    """

    link_id_level5 = str
    """
    Element index
    Which [link <a href="#IQVDocumentLink">IQVDocumentLink</a>] section is this element in?
    The id for <a href="#IQVDocumentLink.LinkType">IQVDocumentLink.LinkType</a> == "toc"
    and <a href="#IQVDocumentLink.LinkLevel">IQVDocumentLink.LinkLevel</a> == 5
    """

    link_id_level6 = str
    """
    Element index
    Which [link <a href="#IQVDocumentLink">IQVDocumentLink</a>] section is this element in?
    The id for <a href="#IQVDocumentLink.LinkType">IQVDocumentLink.LinkType</a> == "toc"
    and <a href="#IQVDocumentLink.LinkLevel">IQVDocumentLink.LinkLevel</a> == 6
    """

    link_id_subsection1 = str
    """
    Element index
    Which [link <a href="#IQVDocumentLink">IQVDocumentLink</a>] section is this element in?
    The id for <a href="#IQVDocumentLink.LinkType">IQVDocumentLink.LinkType</a> == "subsection1"
    """

    link_id_subsection2 = str
    """
    Element index
    Which [link <a href="#IQVDocumentLink">IQVDocumentLink</a>] section is this element in?
    The id for <a href="#IQVDocumentLink.LinkType">IQVDocumentLink.LinkType</a> == "subsection2"
    """

    link_id_subsection3 = str
    """
    Element index
    Which [link <a href="#IQVDocumentLink">IQVDocumentLink</a>] section is this element in?
    The id for <a href="#IQVDocumentLink.LinkType">IQVDocumentLink.LinkType</a> == "subsection3"
    """

    parent_id = str
    """
    Element index
    Which item is this element a member of?
    For example, for <a href="#IQVPageROI.Properties">IQVPageROI.Properties</a>, parent_id = <a href="#IQVPageROI.id">IQVPageROI.id</a>
    Possible parents include but are not limited to
    <a href="#IQVDocument">IQVDocument</a><a href="#IQVPageROI">IQVPageROI</a><a href="#IQVDocumentLink">IQVDocumentLink</a>
    SQL code example 1 for usage of index
    <code>
    WHERE parent_id=parent_id AND group_type=group_type
    </code>
    SQL code example 2 for usage of index
    <code>
    WHERE parent_id=parent_id
    </code>
    """

    process_source = str
    """
    Process that indicated this entity
    """

    relation_name = str
    """
    type of relation
    """

    relation_type = str
    """
    type of relation
    """

    def __init__(self):
        self.confidence = 0.0
        self.doc_id = ''
        self.entities_list = ''
        self.group_type = ''
        self.hierarchy = ''
        self.id = ''
        self.iqv_standard_term = ''
        self.is_bidirectional = -1
        self.is_hierarchical = -1
        self.link_id = ''
        self.link_id_level2 = ''
        self.link_id_level3 = ''
        self.link_id_level4 = ''
        self.link_id_level5 = ''
        self.link_id_level6 = ''
        self.link_id_subsection1 = ''
        self.link_id_subsection2 = ''
        self.link_id_subsection3 = ''
        self.parent_id = ''
        self.process_source = ''
        self.relation_name = ''
        self.relation_type = ''
        self.id = str(uuid.uuid1())


class IQVTableRow_db(object):
    """
    Structure for the column in a table
    """

    doc_id = str
    """
    Element index
    Which document is this element in?
    Top-level id for <a href="#IQVDocument">IQVDocument</a>
    """

    group_type = str
    """
    Element index
    Which item is this element a member of? (name of member = group_type)
    For example, for <a href="#IQVPageROI.Properties">IQVPageROI.Properties</a>, group_type = "Properties"
    Possible parents include but are not limited to
    <a href="#IQVDocument">IQVDocument</a><a href="#IQVPageROI">IQVPageROI</a><a href="#IQVDocumentLink">IQVDocumentLink</a>
    SQL code example 1 for usage of index
    <code>
    WHERE parent_id=parent_id AND group_type=group_type
    </code>
    """

    header = str
    """

    """

    hierarchy = str
    """
    image,table,paragraph,item,header,footer,roi
    """

    id = str
    """
    Unique id for element using <see cref="T:System.Guid" />
    """

    iqv_standard_term = str
    """
    Element index
    If this element is a link or header, what is the standard term?
    There is 0 or 1 iqv_standard_term for each element
    """

    link_id = str
    """
    Element index
    Which [link <a href="#IQVDocumentLink">IQVDocumentLink</a>] section is this element in?
    The id for <a href="#IQVDocumentLink.LinkType">IQVDocumentLink.LinkType</a> == "toc"
    and <a href="#IQVDocumentLink.LinkLevel">IQVDocumentLink.LinkLevel</a> == 1
    """

    link_id_level2 = str
    """
    Element index
    Which [link <a href="#IQVDocumentLink">IQVDocumentLink</a>] section is this element in?
    The id for <a href="#IQVDocumentLink.LinkType">IQVDocumentLink.LinkType</a> == "toc"
    and <a href="#IQVDocumentLink.LinkLevel">IQVDocumentLink.LinkLevel</a> == 2
    """

    link_id_level3 = str
    """
    Element index
    Which [link <a href="#IQVDocumentLink">IQVDocumentLink</a>] section is this element in?
    The id for <a href="#IQVDocumentLink.LinkType">IQVDocumentLink.LinkType</a> == "toc"
    and <a href="#IQVDocumentLink.LinkLevel">IQVDocumentLink.LinkLevel</a> == 3
    """

    link_id_level4 = str
    """
    Element index
    Which [link <a href="#IQVDocumentLink">IQVDocumentLink</a>] section is this element in?
    The id for <a href="#IQVDocumentLink.LinkType">IQVDocumentLink.LinkType</a> == "toc"
    and <a href="#IQVDocumentLink.LinkLevel">IQVDocumentLink.LinkLevel</a> == 4
    """

    link_id_level5 = str
    """
    Element index
    Which [link <a href="#IQVDocumentLink">IQVDocumentLink</a>] section is this element in?
    The id for <a href="#IQVDocumentLink.LinkType">IQVDocumentLink.LinkType</a> == "toc"
    and <a href="#IQVDocumentLink.LinkLevel">IQVDocumentLink.LinkLevel</a> == 5
    """

    link_id_level6 = str
    """
    Element index
    Which [link <a href="#IQVDocumentLink">IQVDocumentLink</a>] section is this element in?
    The id for <a href="#IQVDocumentLink.LinkType">IQVDocumentLink.LinkType</a> == "toc"
    and <a href="#IQVDocumentLink.LinkLevel">IQVDocumentLink.LinkLevel</a> == 6
    """

    link_id_subsection1 = str
    """
    Element index
    Which [link <a href="#IQVDocumentLink">IQVDocumentLink</a>] section is this element in?
    The id for <a href="#IQVDocumentLink.LinkType">IQVDocumentLink.LinkType</a> == "subsection1"
    """

    link_id_subsection2 = str
    """
    Element index
    Which [link <a href="#IQVDocumentLink">IQVDocumentLink</a>] section is this element in?
    The id for <a href="#IQVDocumentLink.LinkType">IQVDocumentLink.LinkType</a> == "subsection2"
    """

    link_id_subsection3 = str
    """
    Element index
    Which [link <a href="#IQVDocumentLink">IQVDocumentLink</a>] section is this element in?
    The id for <a href="#IQVDocumentLink.LinkType">IQVDocumentLink.LinkType</a> == "subsection3"
    """

    maxY = int
    """
    max x in spatial dimensions
    """

    minY = int
    """
    min x in spatial dimensions
    """

    parent_id = str
    """
    Element index
    Which item is this element a member of?
    For example, for <a href="#IQVPageROI.Properties">IQVPageROI.Properties</a>, parent_id = <a href="#IQVPageROI.id">IQVPageROI.id</a>
    Possible parents include but are not limited to
    <a href="#IQVDocument">IQVDocument</a><a href="#IQVPageROI">IQVPageROI</a><a href="#IQVDocumentLink">IQVDocumentLink</a>
    SQL code example 1 for usage of index
    <code>
    WHERE parent_id=parent_id AND group_type=group_type
    </code>
    SQL code example 2 for usage of index
    <code>
    WHERE parent_id=parent_id
    </code>
    """

    tableIndex = int
    """
    sequence index table_id ones-based
    """

    tableRowIndex = int
    """
    sequence index col_id ones-based
    """

    tableRowRef = str
    """
    unique id for this columnheader as in t#c#;
    if merged with other columns, list columnheaders as single string
    with space delimiter
    """

    def __init__(self):
        self.doc_id = ''
        self.group_type = ''
        self.header = ''
        self.hierarchy = ''
        self.id = ''
        self.iqv_standard_term = ''
        self.link_id = ''
        self.link_id_level2 = ''
        self.link_id_level3 = ''
        self.link_id_level4 = ''
        self.link_id_level5 = ''
        self.link_id_level6 = ''
        self.link_id_subsection1 = ''
        self.link_id_subsection2 = ''
        self.link_id_subsection3 = ''
        self.maxY = -1
        self.minY = -1
        self.parent_id = ''
        self.tableIndex = -1
        self.tableRowIndex = -1
        self.tableRowRef = ''
        self.id = str(uuid.uuid1())


class IQVTableColumn_db(object):
    """
    Structure for the column in a table
    """

    doc_id = str
    """
    Element index
    Which document is this element in?
    Top-level id for <a href="#IQVDocument">IQVDocument</a>
    """

    group_type = str
    """
    Element index
    Which item is this element a member of? (name of member = group_type)
    For example, for <a href="#IQVPageROI.Properties">IQVPageROI.Properties</a>, group_type = "Properties"
    Possible parents include but are not limited to
    <a href="#IQVDocument">IQVDocument</a><a href="#IQVPageROI">IQVPageROI</a><a href="#IQVDocumentLink">IQVDocumentLink</a>
    SQL code example 1 for usage of index
    <code>
    WHERE parent_id=parent_id AND group_type=group_type
    </code>
    """

    hierarchy = str
    """
    image,table,paragraph,item,header,footer,roi
    """

    id = str
    """
    Unique id for element using <see cref="T:System.Guid" />
    """

    iqv_standard_term = str
    """
    Element index
    If this element is a link or header, what is the standard term?
    There is 0 or 1 iqv_standard_term for each element
    """

    link_id = str
    """
    Element index
    Which [link <a href="#IQVDocumentLink">IQVDocumentLink</a>] section is this element in?
    The id for <a href="#IQVDocumentLink.LinkType">IQVDocumentLink.LinkType</a> == "toc"
    and <a href="#IQVDocumentLink.LinkLevel">IQVDocumentLink.LinkLevel</a> == 1
    """

    link_id_level2 = str
    """
    Element index
    Which [link <a href="#IQVDocumentLink">IQVDocumentLink</a>] section is this element in?
    The id for <a href="#IQVDocumentLink.LinkType">IQVDocumentLink.LinkType</a> == "toc"
    and <a href="#IQVDocumentLink.LinkLevel">IQVDocumentLink.LinkLevel</a> == 2
    """

    link_id_level3 = str
    """
    Element index
    Which [link <a href="#IQVDocumentLink">IQVDocumentLink</a>] section is this element in?
    The id for <a href="#IQVDocumentLink.LinkType">IQVDocumentLink.LinkType</a> == "toc"
    and <a href="#IQVDocumentLink.LinkLevel">IQVDocumentLink.LinkLevel</a> == 3
    """

    link_id_level4 = str
    """
    Element index
    Which [link <a href="#IQVDocumentLink">IQVDocumentLink</a>] section is this element in?
    The id for <a href="#IQVDocumentLink.LinkType">IQVDocumentLink.LinkType</a> == "toc"
    and <a href="#IQVDocumentLink.LinkLevel">IQVDocumentLink.LinkLevel</a> == 4
    """

    link_id_level5 = str
    """
    Element index
    Which [link <a href="#IQVDocumentLink">IQVDocumentLink</a>] section is this element in?
    The id for <a href="#IQVDocumentLink.LinkType">IQVDocumentLink.LinkType</a> == "toc"
    and <a href="#IQVDocumentLink.LinkLevel">IQVDocumentLink.LinkLevel</a> == 5
    """

    link_id_level6 = str
    """
    Element index
    Which [link <a href="#IQVDocumentLink">IQVDocumentLink</a>] section is this element in?
    The id for <a href="#IQVDocumentLink.LinkType">IQVDocumentLink.LinkType</a> == "toc"
    and <a href="#IQVDocumentLink.LinkLevel">IQVDocumentLink.LinkLevel</a> == 6
    """

    link_id_subsection1 = str
    """
    Element index
    Which [link <a href="#IQVDocumentLink">IQVDocumentLink</a>] section is this element in?
    The id for <a href="#IQVDocumentLink.LinkType">IQVDocumentLink.LinkType</a> == "subsection1"
    """

    link_id_subsection2 = str
    """
    Element index
    Which [link <a href="#IQVDocumentLink">IQVDocumentLink</a>] section is this element in?
    The id for <a href="#IQVDocumentLink.LinkType">IQVDocumentLink.LinkType</a> == "subsection2"
    """

    link_id_subsection3 = str
    """
    Element index
    Which [link <a href="#IQVDocumentLink">IQVDocumentLink</a>] section is this element in?
    The id for <a href="#IQVDocumentLink.LinkType">IQVDocumentLink.LinkType</a> == "subsection3"
    """

    maxX = int
    """
    max x in spatial dimensions
    """

    minX = int
    """
    min x in spatial dimensions
    """

    parent_id = str
    """
    Element index
    Which item is this element a member of?
    For example, for <a href="#IQVPageROI.Properties">IQVPageROI.Properties</a>, parent_id = <a href="#IQVPageROI.id">IQVPageROI.id</a>
    Possible parents include but are not limited to
    <a href="#IQVDocument">IQVDocument</a><a href="#IQVPageROI">IQVPageROI</a><a href="#IQVDocumentLink">IQVDocumentLink</a>
    SQL code example 1 for usage of index
    <code>
    WHERE parent_id=parent_id AND group_type=group_type
    </code>
    SQL code example 2 for usage of index
    <code>
    WHERE parent_id=parent_id
    </code>
    """

    table_roi_id = str
    """
    unique id for table
    """

    tableColumnIndex = int
    """
    sequence index col_id ones-based
    """

    tableColumnRef = str
    """
    unique id for this columnheader as in t#c#;
    if merged with other columns, list columnheaders as single string
    with space delimiter
    """

    tableIndex = int
    """
    sequence index table_id ones-based
    """

    def __init__(self):
        self.doc_id = ''
        self.group_type = ''
        self.hierarchy = ''
        self.id = ''
        self.iqv_standard_term = ''
        self.link_id = ''
        self.link_id_level2 = ''
        self.link_id_level3 = ''
        self.link_id_level4 = ''
        self.link_id_level5 = ''
        self.link_id_level6 = ''
        self.link_id_subsection1 = ''
        self.link_id_subsection2 = ''
        self.link_id_subsection3 = ''
        self.maxX = -1
        self.minX = -1
        self.parent_id = ''
        self.table_roi_id = ''
        self.tableColumnIndex = -1
        self.tableColumnRef = ''
        self.tableIndex = -1
        self.id = str(uuid.uuid1())


class IQVTableColumnHeader_db(object):
    """
    Structure for one of the headers of
     the column in a table
    """

    doc_id = str
    """
    Element index
    Which document is this element in?
    Top-level id for <a href="#IQVDocument">IQVDocument</a>
    """

    group_type = str
    """
    Element index
    Which item is this element a member of? (name of member = group_type)
    For example, for <a href="#IQVPageROI.Properties">IQVPageROI.Properties</a>, group_type = "Properties"
    Possible parents include but are not limited to
    <a href="#IQVDocument">IQVDocument</a><a href="#IQVPageROI">IQVPageROI</a><a href="#IQVDocumentLink">IQVDocumentLink</a>
    SQL code example 1 for usage of index
    <code>
    WHERE parent_id=parent_id AND group_type=group_type
    </code>
    """

    hierarchy = str
    """
    image,table,paragraph,item,header,footer,roi
    """

    id = str
    """
    Unique id for element using <see cref="T:System.Guid" />
    """

    iqv_standard_term = str
    """
    Element index
    If this element is a link or header, what is the standard term?
    There is 0 or 1 iqv_standard_term for each element
    """

    link_id = str
    """
    Element index
    Which [link <a href="#IQVDocumentLink">IQVDocumentLink</a>] section is this element in?
    The id for <a href="#IQVDocumentLink.LinkType">IQVDocumentLink.LinkType</a> == "toc"
    and <a href="#IQVDocumentLink.LinkLevel">IQVDocumentLink.LinkLevel</a> == 1
    """

    link_id_level2 = str
    """
    Element index
    Which [link <a href="#IQVDocumentLink">IQVDocumentLink</a>] section is this element in?
    The id for <a href="#IQVDocumentLink.LinkType">IQVDocumentLink.LinkType</a> == "toc"
    and <a href="#IQVDocumentLink.LinkLevel">IQVDocumentLink.LinkLevel</a> == 2
    """

    link_id_level3 = str
    """
    Element index
    Which [link <a href="#IQVDocumentLink">IQVDocumentLink</a>] section is this element in?
    The id for <a href="#IQVDocumentLink.LinkType">IQVDocumentLink.LinkType</a> == "toc"
    and <a href="#IQVDocumentLink.LinkLevel">IQVDocumentLink.LinkLevel</a> == 3
    """

    link_id_level4 = str
    """
    Element index
    Which [link <a href="#IQVDocumentLink">IQVDocumentLink</a>] section is this element in?
    The id for <a href="#IQVDocumentLink.LinkType">IQVDocumentLink.LinkType</a> == "toc"
    and <a href="#IQVDocumentLink.LinkLevel">IQVDocumentLink.LinkLevel</a> == 4
    """

    link_id_level5 = str
    """
    Element index
    Which [link <a href="#IQVDocumentLink">IQVDocumentLink</a>] section is this element in?
    The id for <a href="#IQVDocumentLink.LinkType">IQVDocumentLink.LinkType</a> == "toc"
    and <a href="#IQVDocumentLink.LinkLevel">IQVDocumentLink.LinkLevel</a> == 5
    """

    link_id_level6 = str
    """
    Element index
    Which [link <a href="#IQVDocumentLink">IQVDocumentLink</a>] section is this element in?
    The id for <a href="#IQVDocumentLink.LinkType">IQVDocumentLink.LinkType</a> == "toc"
    and <a href="#IQVDocumentLink.LinkLevel">IQVDocumentLink.LinkLevel</a> == 6
    """

    link_id_subsection1 = str
    """
    Element index
    Which [link <a href="#IQVDocumentLink">IQVDocumentLink</a>] section is this element in?
    The id for <a href="#IQVDocumentLink.LinkType">IQVDocumentLink.LinkType</a> == "subsection1"
    """

    link_id_subsection2 = str
    """
    Element index
    Which [link <a href="#IQVDocumentLink">IQVDocumentLink</a>] section is this element in?
    The id for <a href="#IQVDocumentLink.LinkType">IQVDocumentLink.LinkType</a> == "subsection2"
    """

    link_id_subsection3 = str
    """
    Element index
    Which [link <a href="#IQVDocumentLink">IQVDocumentLink</a>] section is this element in?
    The id for <a href="#IQVDocumentLink.LinkType">IQVDocumentLink.LinkType</a> == "subsection3"
    """

    OriginalText = str
    """
    original text from document
    """

    parent_id = str
    """
    Element index
    Which item is this element a member of?
    For example, for <a href="#IQVPageROI.Properties">IQVPageROI.Properties</a>, parent_id = <a href="#IQVPageROI.id">IQVPageROI.id</a>
    Possible parents include but are not limited to
    <a href="#IQVDocument">IQVDocument</a><a href="#IQVPageROI">IQVPageROI</a><a href="#IQVDocumentLink">IQVDocumentLink</a>
    SQL code example 1 for usage of index
    <code>
    WHERE parent_id=parent_id AND group_type=group_type
    </code>
    SQL code example 2 for usage of index
    <code>
    WHERE parent_id=parent_id
    </code>
    """

    roi_id = str
    """
    pointer to id of <a href="#IQVPageROI">IQVPageROI</a> of header cell,
    the cell in the table
     (childbox of row, which is childbox of table in
    <a href="#IQVDocument.DocumentTables">IQVDocument.DocumentTables</a>
    """

    rowIndex = int
    """
    sequence index row_id ones-based
    """

    rowRef = str
    """
    unique id for this columnheader as in t#r#
    """

    def __init__(self):
        self.doc_id = ''
        self.group_type = ''
        self.hierarchy = ''
        self.id = ''
        self.iqv_standard_term = ''
        self.link_id = ''
        self.link_id_level2 = ''
        self.link_id_level3 = ''
        self.link_id_level4 = ''
        self.link_id_level5 = ''
        self.link_id_level6 = ''
        self.link_id_subsection1 = ''
        self.link_id_subsection2 = ''
        self.link_id_subsection3 = ''
        self.OriginalText = ''
        self.parent_id = ''
        self.roi_id = ''
        self.rowIndex = -1
        self.rowRef = ''
        self.id = str(uuid.uuid1())


class NLP_Entity_db(object):
    """
    list of entities found for a <a href="#IQVPageROI">IQVPageROI</a>
    or <a href="#IQVSubText">IQVSubText</a>
    For OMOP XML--based on https://www.ohdsi.org/data-standardization/the-common-data-model/
    Observational Medical Outcomes Partnership
    """

    confidence = float
    """
    Probability score of correctness of this label
    """

    doc_id = str
    """
    Element index
    Which document is this element in?
    Top-level id for <a href="#IQVDocument">IQVDocument</a>
    """

    dts = str
    """
    datetimestamp (YYYYMMDDHHMMSS UTC) of Process that indicated this entity
    """

    entity_class = str
    """
    condition, drug, procedure, etc.
    """

    entity_index = str
    """
    index within segment
    """

    entity_key = str
    """
    If this pt is a key-value pair or Q/A, use this key
    For instance,
     <see cref="P:IQVFileManagerDLL.NLP_Entity_db.entity_key" /> = blinding
    <see cref="P:IQVFileManagerDLL.NLP_Entity_db.standard_entity_name" /> = OPEN LABEL
    """

    group_type = str
    """
    Element index
    Which item is this element a member of? (name of member = group_type)
    For example, for <a href="#IQVPageROI.Properties">IQVPageROI.Properties</a>, group_type = "Properties"
    Possible parents include but are not limited to
    <a href="#IQVDocument">IQVDocument</a><a href="#IQVPageROI">IQVPageROI</a><a href="#IQVDocumentLink">IQVDocumentLink</a>
    SQL code example 1 for usage of index
    <code>
    WHERE parent_id=parent_id AND group_type=group_type
    </code>
    """

    hierarchy = str
    """
    image,table,paragraph,item,header,footer,roi
    """

    id = str
    """
    Unique id for element using <see cref="T:System.Guid" />
    """

    iqv_standard_term = str
    """
    Element index
    If this element is a link or header, what is the standard term?
    There is 0 or 1 iqv_standard_term for each element
    """

    link_id = str
    """
    Element index
    Which [link <a href="#IQVDocumentLink">IQVDocumentLink</a>] section is this element in?
    The id for <a href="#IQVDocumentLink.LinkType">IQVDocumentLink.LinkType</a> == "toc"
    and <a href="#IQVDocumentLink.LinkLevel">IQVDocumentLink.LinkLevel</a> == 1
    """

    link_id_level2 = str
    """
    Element index
    Which [link <a href="#IQVDocumentLink">IQVDocumentLink</a>] section is this element in?
    The id for <a href="#IQVDocumentLink.LinkType">IQVDocumentLink.LinkType</a> == "toc"
    and <a href="#IQVDocumentLink.LinkLevel">IQVDocumentLink.LinkLevel</a> == 2
    """

    link_id_level3 = str
    """
    Element index
    Which [link <a href="#IQVDocumentLink">IQVDocumentLink</a>] section is this element in?
    The id for <a href="#IQVDocumentLink.LinkType">IQVDocumentLink.LinkType</a> == "toc"
    and <a href="#IQVDocumentLink.LinkLevel">IQVDocumentLink.LinkLevel</a> == 3
    """

    link_id_level4 = str
    """
    Element index
    Which [link <a href="#IQVDocumentLink">IQVDocumentLink</a>] section is this element in?
    The id for <a href="#IQVDocumentLink.LinkType">IQVDocumentLink.LinkType</a> == "toc"
    and <a href="#IQVDocumentLink.LinkLevel">IQVDocumentLink.LinkLevel</a> == 4
    """

    link_id_level5 = str
    """
    Element index
    Which [link <a href="#IQVDocumentLink">IQVDocumentLink</a>] section is this element in?
    The id for <a href="#IQVDocumentLink.LinkType">IQVDocumentLink.LinkType</a> == "toc"
    and <a href="#IQVDocumentLink.LinkLevel">IQVDocumentLink.LinkLevel</a> == 5
    """

    link_id_level6 = str
    """
    Element index
    Which [link <a href="#IQVDocumentLink">IQVDocumentLink</a>] section is this element in?
    The id for <a href="#IQVDocumentLink.LinkType">IQVDocumentLink.LinkType</a> == "toc"
    and <a href="#IQVDocumentLink.LinkLevel">IQVDocumentLink.LinkLevel</a> == 6
    """

    link_id_subsection1 = str
    """
    Element index
    Which [link <a href="#IQVDocumentLink">IQVDocumentLink</a>] section is this element in?
    The id for <a href="#IQVDocumentLink.LinkType">IQVDocumentLink.LinkType</a> == "subsection1"
    """

    link_id_subsection2 = str
    """
    Element index
    Which [link <a href="#IQVDocumentLink">IQVDocumentLink</a>] section is this element in?
    The id for <a href="#IQVDocumentLink.LinkType">IQVDocumentLink.LinkType</a> == "subsection2"
    """

    link_id_subsection3 = str
    """
    Element index
    Which [link <a href="#IQVDocumentLink">IQVDocumentLink</a>] section is this element in?
    The id for <a href="#IQVDocumentLink.LinkType">IQVDocumentLink.LinkType</a> == "subsection3"
    """

    negated = str
    """
    Default is blank; N=no, Y=yes
    """

    ontology = str
    """
    Ontology such as
     MedDRA, MMI, etc.
    """

    ontology_item_code = str
    """
    Unique item code within the <see cref="P:IQVFileManagerDLL.NLP_Entity_db.ontology" />
    """

    ontology_version = str
    """
    Version of <see cref="P:IQVFileManagerDLL.NLP_Entity_db.ontology" />
    """

    parent_id = str
    """
    Element index
    Which item is this element a member of?
    For example, for <a href="#IQVPageROI.Properties">IQVPageROI.Properties</a>, parent_id = <a href="#IQVPageROI.id">IQVPageROI.id</a>
    Possible parents include but are not limited to
    <a href="#IQVDocument">IQVDocument</a><a href="#IQVPageROI">IQVPageROI</a><a href="#IQVDocumentLink">IQVDocumentLink</a>
    SQL code example 1 for usage of index
    <code>
    WHERE parent_id=parent_id AND group_type=group_type
    </code>
    SQL code example 2 for usage of index
    <code>
    WHERE parent_id=parent_id
    </code>
    """

    process_source = str
    """
    Process that indicated this entity
    """

    standard_entity_name = str
    """
    based on <see cref="P:IQVFileManagerDLL.NLP_Entity_db.ontology" />
    pt (preferred term)
    """

    start = int
    """
    Zero-based start index within the segment.
      -1=not set
    """

    text = str
    """
    entire string that makes up this entity
    """

    text_len = int
    """
    length of inner text
    0=default
    """

    user_id = str
    """
    user id of Process that indicated this entity
    """

    def __init__(self):
        self.confidence = 0.0
        self.doc_id = ''
        self.dts = ''
        self.entity_class = ''
        self.entity_index = ''
        self.entity_key = ''
        self.group_type = ''
        self.hierarchy = ''
        self.id = ''
        self.iqv_standard_term = ''
        self.link_id = ''
        self.link_id_level2 = ''
        self.link_id_level3 = ''
        self.link_id_level4 = ''
        self.link_id_level5 = ''
        self.link_id_level6 = ''
        self.link_id_subsection1 = ''
        self.link_id_subsection2 = ''
        self.link_id_subsection3 = ''
        self.negated = ''
        self.ontology = ''
        self.ontology_item_code = ''
        self.ontology_version = ''
        self.parent_id = ''
        self.process_source = ''
        self.standard_entity_name = ''
        self.start = -1
        self.text = ''
        self.text_len = -1
        self.user_id = ''
        self.id = str(uuid.uuid1())


class IQVConceptTerm_db(object):
    """
    Common Concept
    """

    cui = str
    """
    concept unique ID per the ontology
    """

    entity_class = str
    """
    keyword, timeline, reference, etc.
    """

    entity_text = str
    """
    commonly displayed text of the entity (e.g., "pulse rate")
    """

    entity_xref = str
    """
    list of synonyms
    """

    id = str
    """
    Unique index in IQV concepts list
    """

    info = str
    """
    any definitions/additional information per ontology
    """

    ontology = str
    """
    short/abbreviated name of ontology (e.g., NCI)
    """

    preferred_term = str
    """
    preferred term per ontology
    """

    def __init__(self):
        self.cui = ''
        self.entity_class = ''
        self.entity_text = ''
        self.entity_xref = ''
        self.id = ''
        self.info = ''
        self.ontology = ''
        self.preferred_term = ''
        self.id = str(uuid.uuid1())


class IQVConceptRelation_db(object):
    """
    Relation between 2 concepts
    """

    context_unit = str
    """
    in which context this relation is relevant
    """

    dts = str
    """
    date time stamp of creation
    """

    id = str
    """
    Unique index in IQV concept relations list
    """

    id1 = str
    """
    id of concept 1 from <a href="#IQVConceptTerm.id">IQVConceptTerm.id</a>
    """

    id2 = str
    """
    id of concept 2 from <a href="#IQVConceptTerm.id">IQVConceptTerm.id</a>
    """

    relation_type = str
    """
    hierarchy (parent-child relation, where id1 is parent, id2 is child)
    synonym
    other
    """

    user_id = str
    """
    user_id when created
    """

    weight = float
    """
    Weight of strength of relation
    from 0 to 1
    0 is weak, 1 is strong
    """

    def __init__(self):
        self.context_unit = ''
        self.dts = ''
        self.id = ''
        self.id1 = ''
        self.id2 = ''
        self.relation_type = ''
        self.user_id = ''
        self.weight = 0.0
        self.id = str(uuid.uuid1())


class NLP_Attribute_db(object):
    """
    For OMOP XML--based on https://www.ohdsi.org/data-standardization/the-common-data-model/
    Observational Medical Outcomes Partnership
    """

    attribute_class = str
    """
    measurements, modifier, qualifier, etc
    """

    attribute_index = str
    """
    index within segment
    """

    doc_id = str
    """
    Element index
    Which document is this element in?
    Top-level id for <a href="#IQVDocument">IQVDocument</a>
    """

    group_type = str
    """
    Element index
    Which item is this element a member of? (name of member = group_type)
    For example, for <a href="#IQVPageROI.Properties">IQVPageROI.Properties</a>, group_type = "Properties"
    Possible parents include but are not limited to
    <a href="#IQVDocument">IQVDocument</a><a href="#IQVPageROI">IQVPageROI</a><a href="#IQVDocumentLink">IQVDocumentLink</a>
    SQL code example 1 for usage of index
    <code>
    WHERE parent_id=parent_id AND group_type=group_type
    </code>
    """

    hierarchy = str
    """
    image,table,paragraph,item,header,footer,roi
    """

    id = str
    """
    Unique id for element using <see cref="T:System.Guid" />
    """

    iqv_standard_term = str
    """
    Element index
    If this element is a link or header, what is the standard term?
    There is 0 or 1 iqv_standard_term for each element
    """

    link_id = str
    """
    Element index
    Which [link <a href="#IQVDocumentLink">IQVDocumentLink</a>] section is this element in?
    The id for <a href="#IQVDocumentLink.LinkType">IQVDocumentLink.LinkType</a> == "toc"
    and <a href="#IQVDocumentLink.LinkLevel">IQVDocumentLink.LinkLevel</a> == 1
    """

    link_id_level2 = str
    """
    Element index
    Which [link <a href="#IQVDocumentLink">IQVDocumentLink</a>] section is this element in?
    The id for <a href="#IQVDocumentLink.LinkType">IQVDocumentLink.LinkType</a> == "toc"
    and <a href="#IQVDocumentLink.LinkLevel">IQVDocumentLink.LinkLevel</a> == 2
    """

    link_id_level3 = str
    """
    Element index
    Which [link <a href="#IQVDocumentLink">IQVDocumentLink</a>] section is this element in?
    The id for <a href="#IQVDocumentLink.LinkType">IQVDocumentLink.LinkType</a> == "toc"
    and <a href="#IQVDocumentLink.LinkLevel">IQVDocumentLink.LinkLevel</a> == 3
    """

    link_id_level4 = str
    """
    Element index
    Which [link <a href="#IQVDocumentLink">IQVDocumentLink</a>] section is this element in?
    The id for <a href="#IQVDocumentLink.LinkType">IQVDocumentLink.LinkType</a> == "toc"
    and <a href="#IQVDocumentLink.LinkLevel">IQVDocumentLink.LinkLevel</a> == 4
    """

    link_id_level5 = str
    """
    Element index
    Which [link <a href="#IQVDocumentLink">IQVDocumentLink</a>] section is this element in?
    The id for <a href="#IQVDocumentLink.LinkType">IQVDocumentLink.LinkType</a> == "toc"
    and <a href="#IQVDocumentLink.LinkLevel">IQVDocumentLink.LinkLevel</a> == 5
    """

    link_id_level6 = str
    """
    Element index
    Which [link <a href="#IQVDocumentLink">IQVDocumentLink</a>] section is this element in?
    The id for <a href="#IQVDocumentLink.LinkType">IQVDocumentLink.LinkType</a> == "toc"
    and <a href="#IQVDocumentLink.LinkLevel">IQVDocumentLink.LinkLevel</a> == 6
    """

    link_id_subsection1 = str
    """
    Element index
    Which [link <a href="#IQVDocumentLink">IQVDocumentLink</a>] section is this element in?
    The id for <a href="#IQVDocumentLink.LinkType">IQVDocumentLink.LinkType</a> == "subsection1"
    """

    link_id_subsection2 = str
    """
    Element index
    Which [link <a href="#IQVDocumentLink">IQVDocumentLink</a>] section is this element in?
    The id for <a href="#IQVDocumentLink.LinkType">IQVDocumentLink.LinkType</a> == "subsection2"
    """

    link_id_subsection3 = str
    """
    Element index
    Which [link <a href="#IQVDocumentLink">IQVDocumentLink</a>] section is this element in?
    The id for <a href="#IQVDocumentLink.LinkType">IQVDocumentLink.LinkType</a> == "subsection3"
    """

    parent_id = str
    """
    Element index
    Which item is this element a member of?
    For example, for <a href="#IQVPageROI.Properties">IQVPageROI.Properties</a>, parent_id = <a href="#IQVPageROI.id">IQVPageROI.id</a>
    Possible parents include but are not limited to
    <a href="#IQVDocument">IQVDocument</a><a href="#IQVPageROI">IQVPageROI</a><a href="#IQVDocumentLink">IQVDocumentLink</a>
    SQL code example 1 for usage of index
    <code>
    WHERE parent_id=parent_id AND group_type=group_type
    </code>
    SQL code example 2 for usage of index
    <code>
    WHERE parent_id=parent_id
    </code>
    """

    process_source = str
    """
    Process that indicated this entity
    """

    start = int
    """
    Zero-based start index within the segment.
      -1=not set
    """

    text = str
    """
    entire string that makes up this attribute
    """

    def __init__(self):
        self.attribute_class = ''
        self.attribute_index = ''
        self.doc_id = ''
        self.group_type = ''
        self.hierarchy = ''
        self.id = ''
        self.iqv_standard_term = ''
        self.link_id = ''
        self.link_id_level2 = ''
        self.link_id_level3 = ''
        self.link_id_level4 = ''
        self.link_id_level5 = ''
        self.link_id_level6 = ''
        self.link_id_subsection1 = ''
        self.link_id_subsection2 = ''
        self.link_id_subsection3 = ''
        self.parent_id = ''
        self.process_source = ''
        self.start = -1
        self.text = ''
        self.id = str(uuid.uuid1())


class IQVAssessmentVisitRecord_db(object):
    """
    Assessment and visit record for an SOA
    """

    assessment = str
    """
    Protocol ROI id
    RHS/compare document
    roi_id_b
    """

    assessment_text = str
    """
    text in protocol
    """

    cycle_timepoint = str
    """
    timeline
    """

    day_timepoint = str
    """
    timeline
    """

    doc_id = str
    """
    Element index
    Which document is this element in?
    Top-level id for <a href="#IQVDocument">IQVDocument</a>
    """

    DocumentSequenceIndex = int
    """
    Sequence for assessment within SOA table
    """

    dts = str
    """
    Date/Time Stamp
    string (YYYYMMDDHHMMSS in UTC)
    """

    epoch_timepoint = str
    """
    timeline for epoch
    """

    footnote_0 = str
    """
    footnote text (for visit or assessment)
    """

    footnote_1 = str
    """
    footnote text (for visit or assessment)
    """

    footnote_2 = str
    """
    footnote text (for visit or assessment)
    """

    footnote_3 = str
    """
    footnote text (for visit or assessment)
    """

    footnote_4 = str
    """
    footnote text (for visit or assessment)
    """

    footnote_5 = str
    """
    footnote text (for visit or assessment)
    """

    footnote_6 = str
    """
    footnote text (for visit or assessment)
    """

    footnote_7 = str
    """
    footnote text (for visit or assessment)
    """

    footnote_8 = str
    """
    footnote text (for visit or assessment)
    """

    footnote_9 = str
    """
    footnote text (for visit or assessment)
    """

    id = str
    """

    """

    indicator_text = str
    """
    "X" or other indicator inside of SOA cells
    default is blank
    Can include all records even if blank
     to help identify orphaned assessments, etc.
    """

    month_timepoint = str
    """
    timeline
    """

    pname = str
    """
    Protocol file name
    file name ending in .pdf, .docx, etc.
    LHS/base document
    doc_id_a
    """

    procedure = str
    """
    text in protocol
    """

    procedure_text = str
    """
    text in protocol
    """

    ProcessMachineName = str
    """
    server on which protocol is processed
    """

    ProcessVersion = str
    """
    Code Version
    """

    roi_id = str
    """
    Protocol ROI id
    LHS/base document
    roi_id_a
    """

    run_id = str
    """
    Which run of the data?
    """

    section = str
    """
    text in protocol
    """

    study_cohort = str
    """
    cohort/arm for the table
    """

    table_link_text = str
    """
    header for the table
    """

    table_roi_id = str
    """
    id for the table
    """

    table_sequence_index = int
    """
    id for the table
    """

    visit_timepoint = str
    """
    Visit timeline
    e.g., 1, 2, 3,...
    """

    week_timepoint = str
    """
    timeline
    """

    window_timepoint = str
    """
    timeline
    """

    year_timepoint = str
    """
    timeline
    """

    def __init__(self):
        self.assessment = ''
        self.assessment_text = ''
        self.cycle_timepoint = ''
        self.day_timepoint = ''
        self.doc_id = ''
        self.DocumentSequenceIndex = -1
        self.dts = ''
        self.epoch_timepoint = ''
        self.footnote_0 = ''
        self.footnote_1 = ''
        self.footnote_2 = ''
        self.footnote_3 = ''
        self.footnote_4 = ''
        self.footnote_5 = ''
        self.footnote_6 = ''
        self.footnote_7 = ''
        self.footnote_8 = ''
        self.footnote_9 = ''
        self.id = ''
        self.indicator_text = ''
        self.month_timepoint = ''
        self.pname = ''
        self.procedure = ''
        self.procedure_text = ''
        self.ProcessMachineName = ''
        self.ProcessVersion = ''
        self.roi_id = ''
        self.run_id = ''
        self.section = ''
        self.study_cohort = ''
        self.table_link_text = ''
        self.table_roi_id = ''
        self.table_sequence_index = -1
        self.visit_timepoint = ''
        self.week_timepoint = ''
        self.window_timepoint = ''
        self.year_timepoint = ''
        self.id = str(uuid.uuid1())


class IQVAssessmentRecord_db(object):
    """
    Assessment record for an SOA
    """

    assessment = str
    """
    Protocol ROI id
    RHS/compare document
    roi_id_b
    """

    assessment_text = str
    """
    text in protocol
    """

    doc_id = str
    """
    Element index
    Which document is this element in?
    Top-level id for <a href="#IQVDocument">IQVDocument</a>
    """

    DocumentSequenceIndex = int
    """
    Sequence for assessment within SOA table
    """

    dts = str
    """
    Date/Time Stamp
    string (YYYYMMDDHHMMSS in UTC)
    """

    footnote_0 = str
    """
    footnote text (for visit or assessment)
    """

    footnote_1 = str
    """
    footnote text (for visit or assessment)
    """

    footnote_2 = str
    """
    footnote text (for visit or assessment)
    """

    footnote_3 = str
    """
    footnote text (for visit or assessment)
    """

    footnote_4 = str
    """
    footnote text (for visit or assessment)
    """

    footnote_5 = str
    """
    footnote text (for visit or assessment)
    """

    footnote_6 = str
    """
    footnote text (for visit or assessment)
    """

    footnote_7 = str
    """
    footnote text (for visit or assessment)
    """

    footnote_8 = str
    """
    footnote text (for visit or assessment)
    """

    footnote_9 = str
    """
    footnote text (for visit or assessment)
    """

    id = str
    """

    """

    num_visits = int
    """
    Num visits for this assessment
    """

    pname = str
    """
    Protocol file name
    file name ending in .pdf, .docx, etc.
    LHS/base document
    doc_id_a
    """

    procedure = str
    """
    text in protocol
    """

    procedure_text = str
    """
    text in protocol
    """

    ProcessMachineName = str
    """
    server on which protocol is processed
    """

    ProcessVersion = str
    """
    Code Version
    """

    roi_id = str
    """
    Protocol ROI id
    LHS/base document
    roi_id_a
    """

    run_id = str
    """
    Which run of the data?
    """

    section = str
    """
    text in protocol
    """

    study_cohort = str
    """
    cohort/arm for the table
    """

    table_link_text = str
    """
    header for the table
    """

    table_roi_id = str
    """
    id for the table
    """

    table_sequence_index = int
    """
    id for the table
    """

    def __init__(self):
        self.assessment = ''
        self.assessment_text = ''
        self.doc_id = ''
        self.DocumentSequenceIndex = -1
        self.dts = ''
        self.footnote_0 = ''
        self.footnote_1 = ''
        self.footnote_2 = ''
        self.footnote_3 = ''
        self.footnote_4 = ''
        self.footnote_5 = ''
        self.footnote_6 = ''
        self.footnote_7 = ''
        self.footnote_8 = ''
        self.footnote_9 = ''
        self.id = ''
        self.num_visits = -1
        self.pname = ''
        self.procedure = ''
        self.procedure_text = ''
        self.ProcessMachineName = ''
        self.ProcessVersion = ''
        self.roi_id = ''
        self.run_id = ''
        self.section = ''
        self.study_cohort = ''
        self.table_link_text = ''
        self.table_roi_id = ''
        self.table_sequence_index = -1
        self.id = str(uuid.uuid1())


class IQVLabParameterRecord_db(object):
    """
    Lab data individual parameter
    
    1+ parameter(s) per panel/procedure
    """

    assessment = str
    """
    If known, the assessment in the SOA
    """

    doc_id = str
    """
    Protocol document id
    LHS/base document
    doc_id_a
    """

    dts = str
    """
    Date/Time Stamp
    string (YYYYMMDDHHMMSS in UTC)
    """

    id = str
    """
    id for this record
    """

    parameter = str
    """
    normalized text in protocol
    multiple parameters per procedure/panel
    """

    parameter_text = str
    """
    raw text in protocol
    multiple parameters per procedure/panel
    """

    pname = str
    """
    Protocol file name
    file name ending in .pdf, .docx, etc.
    LHS/base document
    doc_id_a
    """

    procedure_panel = str
    """
    normalized text of procedure/panel
    procedure/panel may be the same as the assessment
    """

    procedure_panel_text = str
    """
    raw text in protocol
    procedure/panel may be the same as the assessment
    """

    ProcessMachineName = str
    """
    server on which protocol is processed
    """

    ProcessVersion = str
    """
    Code Version
    """

    roi_id = str
    """
    Protocol ROI id
    for the assessment!
    """

    run_id = str
    """
    Which run of the data?
    """

    section = str
    """
    text in protocol
    """

    table_link_text = str
    """
    header for the table
    """

    table_roi_id = str
    """
    id for the table
    """

    table_sequence_index = int
    """
    id for the table
    """

    def __init__(self):
        self.assessment = ''
        self.doc_id = ''
        self.dts = ''
        self.id = ''
        self.parameter = ''
        self.parameter_text = ''
        self.pname = ''
        self.procedure_panel = ''
        self.procedure_panel_text = ''
        self.ProcessMachineName = ''
        self.ProcessVersion = ''
        self.roi_id = ''
        self.run_id = ''
        self.section = ''
        self.table_link_text = ''
        self.table_roi_id = ''
        self.table_sequence_index = -1
        self.id = str(uuid.uuid1())


class IQVVisitRecord_db(object):
    """
    Visit record for an SOA
    """

    cycle_timepoint = str
    """
    timeline
    """

    day_timepoint = str
    """
    timeline
    """

    doc_id = str
    """
    Element index
    Which document is this element in?
    Top-level id for <a href="#IQVDocument">IQVDocument</a>
    """

    DocumentSequenceIndex = int
    """
    Sequence for assessment within SOA table
    """

    dts = str
    """
    Date/Time Stamp
    string (YYYYMMDDHHMMSS in UTC)
    """

    epoch_timepoint = str
    """
    timeline for epoch
    """

    footnote_0 = str
    """
    footnote text (for visit or assessment)
    """

    footnote_1 = str
    """
    footnote text (for visit or assessment)
    """

    footnote_2 = str
    """
    footnote text (for visit or assessment)
    """

    footnote_3 = str
    """
    footnote text (for visit or assessment)
    """

    footnote_4 = str
    """
    footnote text (for visit or assessment)
    """

    footnote_5 = str
    """
    footnote text (for visit or assessment)
    """

    footnote_6 = str
    """
    footnote text (for visit or assessment)
    """

    footnote_7 = str
    """
    footnote text (for visit or assessment)
    """

    footnote_8 = str
    """
    footnote text (for visit or assessment)
    """

    footnote_9 = str
    """
    footnote text (for visit or assessment)
    """

    id = str
    """

    """

    month_timepoint = str
    """
    timeline
    """

    num_assessments = int
    """
    Num visits for this assessment
    """

    pname = str
    """
    Protocol file name
    file name ending in .pdf, .docx, etc.
    LHS/base document
    doc_id_a
    """

    ProcessMachineName = str
    """
    server on which protocol is processed
    """

    ProcessVersion = str
    """
    Code Version
    """

    run_id = str
    """
    Which run of the data?
    """

    study_cohort = str
    """
    cohort/arm for the table
    """

    table_link_text = str
    """
    header for the table
    """

    table_roi_id = str
    """
    id for the table
    """

    table_sequence_index = int
    """
    id for the table
    """

    visit_timepoint = str
    """
    Visit timeline
    e.g., 1, 2, 3,...
    """

    week_timepoint = str
    """
    timeline
    """

    window_timepoint = str
    """
    timeline
    """

    year_timepoint = str
    """
    timeline
    """

    def __init__(self):
        self.cycle_timepoint = ''
        self.day_timepoint = ''
        self.doc_id = ''
        self.DocumentSequenceIndex = -1
        self.dts = ''
        self.epoch_timepoint = ''
        self.footnote_0 = ''
        self.footnote_1 = ''
        self.footnote_2 = ''
        self.footnote_3 = ''
        self.footnote_4 = ''
        self.footnote_5 = ''
        self.footnote_6 = ''
        self.footnote_7 = ''
        self.footnote_8 = ''
        self.footnote_9 = ''
        self.id = ''
        self.month_timepoint = ''
        self.num_assessments = -1
        self.pname = ''
        self.ProcessMachineName = ''
        self.ProcessVersion = ''
        self.run_id = ''
        self.study_cohort = ''
        self.table_link_text = ''
        self.table_roi_id = ''
        self.table_sequence_index = -1
        self.visit_timepoint = ''
        self.week_timepoint = ''
        self.window_timepoint = ''
        self.year_timepoint = ''
        self.id = str(uuid.uuid1())


class IQVIECriteriaRecord_db(object):
    """
    Assessment and visit record for an SOA
    """

    doc_id = str
    """
    Element index
    Which document is this element in?
    Top-level id for <a href="#IQVDocument">IQVDocument</a>
    """

    DocumentSequenceIndex = int
    """
    Sequence for assessment within SOA table
    """

    dts = str
    """
    Date/Time Stamp
    string (YYYYMMDDHHMMSS in UTC)
    """

    footnote_0 = str
    """
    footnote text (for visit or assessment)
    """

    footnote_1 = str
    """
    footnote text (for visit or assessment)
    """

    footnote_2 = str
    """
    footnote text (for visit or assessment)
    """

    footnote_3 = str
    """
    footnote text (for visit or assessment)
    """

    footnote_4 = str
    """
    footnote text (for visit or assessment)
    """

    footnote_5 = str
    """
    footnote text (for visit or assessment)
    """

    footnote_6 = str
    """
    footnote text (for visit or assessment)
    """

    footnote_7 = str
    """
    footnote text (for visit or assessment)
    """

    footnote_8 = str
    """
    footnote text (for visit or assessment)
    """

    footnote_9 = str
    """
    footnote text (for visit or assessment)
    """

    id = str
    """

    """

    ie_type = str
    """
    inclusion, exclusion, other
    """

    item_text = str
    """
    header for the table
    """

    link_text = str
    """
    header for the table
    """

    pname = str
    """
    Protocol file name
    file name ending in .pdf, .docx, etc.
    LHS/base document
    doc_id_a
    """

    procedure = str
    """
    text in protocol
    """

    ProcessMachineName = str
    """
    server on which protocol is processed
    """

    ProcessVersion = str
    """
    Code Version
    """

    roi_id = str
    """
    Protocol ROI id
    LHS/base document
    roi_id_a
    """

    section = str
    """
    text in protocol
    """

    study_cohort = str
    """
    cohort/arm for the table
    """

    def __init__(self):
        self.doc_id = ''
        self.DocumentSequenceIndex = -1
        self.dts = ''
        self.footnote_0 = ''
        self.footnote_1 = ''
        self.footnote_2 = ''
        self.footnote_3 = ''
        self.footnote_4 = ''
        self.footnote_5 = ''
        self.footnote_6 = ''
        self.footnote_7 = ''
        self.footnote_8 = ''
        self.footnote_9 = ''
        self.id = ''
        self.ie_type = ''
        self.item_text = ''
        self.link_text = ''
        self.pname = ''
        self.procedure = ''
        self.ProcessMachineName = ''
        self.ProcessVersion = ''
        self.roi_id = ''
        self.section = ''
        self.study_cohort = ''
        self.id = str(uuid.uuid1())


class IQVDocumentVariable_db(object):
    """
    Assessment and visit record for an SOA
    """

    doc_id = str
    """
    Which document is this element in?  (blank for GT documents)
    """

    dts = str
    """
    datetimestamp in YYYYMMDDHHMMSS
    """

    id = str
    """
    Element index for this variable
    """

    run_id = str
    """
    Which run of the data?
    Note: Use <see cref="P:IQVFileManagerDLL.IQVDocumentVariable_db.variable_source" /> to track code version
    """

    source_filename = str
    """
    document content source
    use this to align GT with system output
    """

    variable_category = str
    """
    category of variable
    'pb' for patient burden
    'sb' for site burden
    """

    variable_datatype = str
    """
    datatype boolean, double, integer
    """

    variable_index = int
    """
    for future use
    """

    variable_key = str
    """
    key, such as document_date
     For full list of keys see https://wiki.quintiles.net/display/PD/Patient+Burden+%28PB%29+Variables
    """

    variable_label = str
    """
    verbose display label for key
    """

    variable_listing_filename = str
    """
    ground truth data filename
    """

    variable_notes = str
    """
    additional notes
    """

    variable_score = float
    """
    confidence level, probability that this is correct
    """

    variable_source = str
    """
    SME input ('GT'), AI algorithm, etc.
    Put version of algorithm build here.
    """

    variable_value = str
    """
    value of the attribute, as string
    """

    def __init__(self):
        self.doc_id = ''
        self.dts = ''
        self.id = ''
        self.run_id = ''
        self.source_filename = ''
        self.variable_category = ''
        self.variable_datatype = ''
        self.variable_index = -1
        self.variable_key = ''
        self.variable_label = ''
        self.variable_listing_filename = ''
        self.variable_notes = ''
        self.variable_score = 0.0
        self.variable_source = ''
        self.variable_value = ''
        self.id = str(uuid.uuid1())


class Q_EVENT_LOG_ENTRY_db(object):
    """
    Log entry for logging purposes and for creating a document resource
    in WebUI
    """

    bHandled = bool
    """
    has event been handled?
    """

    ClassMapping = str
    """
    if mapping class
    """

    CountReplace = int
    """
    number of replacements
    """

    DocumentID = str
    """
    document resource (NMT) id
    """

    DocumentName = str
    """
    original source document filename
    """

    DocumentPage = int
    """
    page for this document
    """

    ErrorLevelVal = int
    """
    No error or ignore
     NONE = 0,

      Most verbose is debug, shows everything no matter how trivial
     DEBUG = 1,

      Trivial, probably only for information
     INFORMATIONAL = 2,

      Minor, segment-level
     MINOR = 3,

      Major error with document processing
     MAJOR = 4,

      Reserved for no document being processed
     CRITICAL = 5

     substitue for Error Level; default is -1
    """

    EventTypeVal = int
    """
    substitute for Event Type; default is -1
             DEFAULT = 0,
    ERROR = 1,
    REPORT_MAPPING = 2,
    REPORT_MAPPING_ERROR = 3,
    APPLICATION_EVENT = 4,
    PROCESS_START = 5,
    PROCESS_FINISH = 6,
    PROCESS_ERROR = 7,
    ADD_DOCUMENT = 8,
    UPDATE_ITEM = 9,
    RETRIEVE_DOCUMENT = 10,
    ADD_DOCUMENT_XLIFF = 11,
    STRING_REPLACE = 20,
    STRING_REPLACE_ERROR = 21,
    QUEUE_MESSAGE_SENT = 30,
    QUEUE_MESSAGE_RECEIVED = 31,
    QUEUE_MESSAGE_SENT_RECONSTRUCTION = 32,
    QUEUE_MESSAGE_RECEIVED_RECONSTRUCTION = 33,
    WARNING = 99,
    INFORMATION = 101,
    DOCUMENT_ROTATION_METRICS = 201,
    CREATE_IQV_DOCUMENT = 301,
    CREATE_RECONSTRUCTED_DOCUMENT = 302,
    CREATE_XLIFF_SOURCE = 303,
    CREATE_DECONSTRUCTED_SOURCE = 304,
    ADD_DIRECTORY = 404,
    CONFIGURATION_PARAMETER = 501,
    PROCESS_INFORMATION = 502,
    GENERIC_FORMATTER_ERROR = 900,
    IMAGE_QUALITY_ERROR = 901,
    CORRUPT_DOCUMENT_ERROR = 902,
    IMAGE_REQUIRES_OCR = 903
    """

    FieldMapping = str
    """
    if mapping field, which field
    """

    id = str
    """

    """

    Message = str
    """
    For error
    """

    StackTrace = str
    """
    For error
    """

    UserEmail = str
    """
    end user
    """

    UserID = str
    """
    end user
    """

    UserInputMessage = str
    """
    end user
    """

    Value = str
    """
    generic value for this event
    """

    def __init__(self):
        self.bHandled = False
        self.ClassMapping = ''
        self.CountReplace = -1
        self.DocumentID = ''
        self.DocumentName = ''
        self.DocumentPage = -1
        self.ErrorLevelVal = -1
        self.EventTypeVal = -1
        self.FieldMapping = ''
        self.id = ''
        self.Message = ''
        self.StackTrace = ''
        self.UserEmail = ''
        self.UserID = ''
        self.UserInputMessage = ''
        self.Value = ''
        self.id = str(uuid.uuid1())


class IQVTM_PDFDocumentPage(object):
    """
    Page elements extracted from <a href="#IQVDocument">IQVDocument</a> and used for classification
    """

    FooterText = str
    """
    text in the footer
    """

    HeaderText = str
    """
    text in the header
    """

    Hyperlinks = []
    """
    Hyperlinks pulled from document
    """

    ImageNames = []
    """
    Names of images pulled from document
    """

    OrientationIsPortrait = bool
    """
    If portrait, set to True; else false
    """

    PageSizeRectangle = Rectangle
    """
    Page
    """

    PageSizeWithRotationRectangle = Rectangle
    """
    Page with PDF rotation
    """

    PDFDocumentPageIndex = int
    """
    Index is ones-based
    """

    PDFDocumentPageText = str
    """
    Text is actual text to be used for classification
    """

    PDFDocumentPageTextNumChars = int
    """
    Raw, counting ALL chars on page
    """

    PDFDocumentPageTextNumWords = int
    """
    Raw, counting ALL words on page
    """

    Rotation = int
    """
    rotation in degrees
    """

    TitleText = str
    """
    text in the title
    """

    def __init__(self):
        self.FooterText = ''
        self.HeaderText = ''
        self.Hyperlinks = []
        self.ImageNames = []
        self.OrientationIsPortrait = False
        self.PageSizeRectangle = Rectangle()
        self.PageSizeWithRotationRectangle = Rectangle()
        self.PDFDocumentPageIndex = -1
        self.PDFDocumentPageText = ''
        self.PDFDocumentPageTextNumChars = -1
        self.PDFDocumentPageTextNumWords = -1
        self.Rotation = -1
        self.TitleText = ''
        self.id = str(uuid.uuid1())


class IQVDocumentTest(object):
    """
    Class used to gather metrics about classifier results
    """

    ActualClassFromGT = str
    """
    Actual full classification
    """

    ActualDIACodeFromGT = str
    """
    Actual partial classification
    """

    CodeVersion = str
    """
    Version of AI Code being used
    """

    Confidence = float
    """
    Confidence measure
    """

    ConfuserClasses = []
    """
    All confuser classes, list of string
    """

    ConfuserRawLogProbScores = []
    """
    All confuser classes raw log prob, list of double
    """

    MeanLogProbScoreAllClasses = float
    """
    Mean raw log prob of all classes
    """

    PredictedClass = str
    """
    Predicted full classification
    """

    PredictedDIACode = str
    """
    Predicted partial classification
    """

    RankingActualClass = int
    """
    Where actual class was ranked in list
    """

    RawLogProbScoreActualClass = float
    """
    Top actual class raw log prob
    """

    RawLogProbScoreSelectedClass = float
    """
    Top selected/predicted class raw log prob
    """

    TestDate = str
    """
    Datetimestamp of test
    """

    Variance = float
    """
    Variance of all classes
    """

    ZScore = float
    """
    z-score of all classes
    """

    def __init__(self):
        self.ActualClassFromGT = ''
        self.ActualDIACodeFromGT = ''
        self.CodeVersion = ''
        self.Confidence = 0.0
        self.ConfuserClasses = []
        self.ConfuserRawLogProbScores = []
        self.MeanLogProbScoreAllClasses = 0.0
        self.PredictedClass = ''
        self.PredictedDIACode = ''
        self.RankingActualClass = -1
        self.RawLogProbScoreActualClass = 0.0
        self.RawLogProbScoreSelectedClass = 0.0
        self.TestDate = ''
        self.Variance = 0.0
        self.ZScore = 0.0
        self.id = str(uuid.uuid1())


class IQVTM_PDFDocument(object):
    """
    Page elements extracted from <a href="#IQVDocument">IQVDocument</a> and used for classification
    """

    DocumentClass = str
    """
    Actual class for this document
    """

    DocumentGroundTruth = IQVDocumentGroundTruth
    """
    Document ground truth with actual values
    """

    DocumentName = str
    """
    Actual name for this document
    """

    id = str
    """
    id for this IQVTM_PDFDocument
    """

    IQVDocumentTests = []
    """
    All <a href="#IQVDocumentTest">IQVDocumentTest</a> pulled from this dataset
    """

    NumberOfPages = int
    """
    Processed and unprocessed: number of pages in this document
    """

    PDFDocumentPageList = []
    """
    List of all pages with text
    """

    PDFDocumentTextNumChars = int
    """
    All characters
    """

    def __init__(self):
        self.DocumentClass = ''
        self.DocumentGroundTruth = IQVDocumentGroundTruth()
        self.DocumentName = ''
        self.id = ''
        self.IQVDocumentTests = []
        self.NumberOfPages = -1
        self.PDFDocumentPageList = []
        self.PDFDocumentTextNumChars = -1
        self.id = str(uuid.uuid1())


class IQV_STRING(object):
    """
    
    """

    ALCOAC_CONFIDENCE_FEATURE = str
    """

    """

    ALCOAC_ERROR = str
    """

    """

    ALCOAC_ERROR_TYPE_BLANK_PAGES_ERROR = str
    """

    """

    ALCOAC_ERROR_TYPE_CLEAN_IMAGE_ERROR = str
    """

    """

    ALCOAC_ERROR_TYPE_DUPLICATE_DOCUMENT_ERROR = str
    """

    """

    ALCOAC_ERROR_TYPE_FILETYPE_ERROR = str
    """

    """

    ALCOAC_ERROR_TYPE_GREYSCALE_ERROR = str
    """

    """

    ALCOAC_ERROR_TYPE_LEGIBILITY_ERROR = str
    """

    """

    ALCOAC_ERROR_TYPE_MISSING_FIELDS_ERROR = str
    """

    """

    ALCOAC_ERROR_TYPE_MISSING_PAGES_ERROR = str
    """

    """

    ALCOAC_ERROR_TYPE_MISSING_SIGNATURES_ERROR = str
    """

    """

    ALCOAC_ERROR_TYPE_ORDER_PAGES_ERROR = str
    """

    """

    ALCOAC_ERROR_TYPE_PAGE_SKEW_ERROR = str
    """

    """

    ALCOAC_MESSAGE_FEATURE = str
    """

    """

    ALCOAC_SCORE_FEATURE = str
    """

    """

    UNKNOWN = str
    """

    """

    def __init__(self):
        self.ALCOAC_CONFIDENCE_FEATURE = 'alcoac_error_confidence'
        self.ALCOAC_ERROR = 'alcoac_check_error'
        self.ALCOAC_ERROR_TYPE_BLANK_PAGES_ERROR = 'blank_pages_error'
        self.ALCOAC_ERROR_TYPE_CLEAN_IMAGE_ERROR = 'clean_image_error'
        self.ALCOAC_ERROR_TYPE_DUPLICATE_DOCUMENT_ERROR = 'duplicate_document_error'
        self.ALCOAC_ERROR_TYPE_FILETYPE_ERROR = 'filetype_error'
        self.ALCOAC_ERROR_TYPE_GREYSCALE_ERROR = 'greyscale_error'
        self.ALCOAC_ERROR_TYPE_LEGIBILITY_ERROR = 'legibility_error'
        self.ALCOAC_ERROR_TYPE_MISSING_FIELDS_ERROR = 'missing_fields_error'
        self.ALCOAC_ERROR_TYPE_MISSING_PAGES_ERROR = 'missing_pages_error'
        self.ALCOAC_ERROR_TYPE_MISSING_SIGNATURES_ERROR = 'missing_signatures_error'
        self.ALCOAC_ERROR_TYPE_ORDER_PAGES_ERROR = 'order_pages_error'
        self.ALCOAC_ERROR_TYPE_PAGE_SKEW_ERROR = 'page_skew_error'
        self.ALCOAC_MESSAGE_FEATURE = 'alcoac_error_message'
        self.ALCOAC_SCORE_FEATURE = 'alcoac_error_score'
        self.UNKNOWN = 'unknown'
        self.id = str(uuid.uuid1())


class IQVKeyMapping(object):
    """
    Used to track all standard key mappings for document.
    Often used in the <a href="#IQVPageROI.Properties">IQVPageROI.Properties</a>
    """

    container = str
    """
    container for this item
    """

    description = str
    """
    Description of this key, how to use, etc.
    """

    key = str
    """
    This is the unique key string for this <a href="#IQVKeyMapping">IQVKeyMapping</a>
    and must be unique
    """

    synonyms = []
    """
    typical synonyms for this under
    <a href="#IQVKeyValueSet.key">IQVKeyValueSet.key</a> with a confidence
    specified <a href="#IQVKeyValueSet.confidence">IQVKeyValueSet.confidence</a>
    """

    value_type = str
    """
    If no value is expected with this key, value_type is blank
    Otherwise, value_type may be
    string
    int
    float
    roi_id
    """

    def __init__(self):
        self.container = ''
        self.description = ''
        self.key = ''
        self.synonyms = []
        self.value_type = ''


class IQV_KEY_STRING(object):
    """
    String constants used in IQVDocument object.
    
     UNKNOWN is to be utilized by microservice module
     when the best guess is "unknown": The module is
     quite certain that it cannot determine the
     value given the input.
    """

    KEY_AlternateContent = str
    """
    AlternateContent is found in paragraphs detected as images or textboxes
    """

    KEY_amendment_number = str
    """
    amendment_number
    i2e=amendment_number
    """

    KEY_approval_date = str
    """
    approval_date
    i2e=approval_date
    """

    KEY_arm = str
    """
    arm
    """

    KEY_blank_header = str
    """
    Default value for <a href="#IQV_KEY_STRING.KEY_LinkText">IQV_KEY_STRING.KEY_LinkText</a> when there is
    a section, but no section header

    Align paragraphs and blocks
    ParaROI is the roi id of the paragraph in <a href="#IQVDocument.DocumentParagraphs">IQVDocument.DocumentParagraphs</a>
    BlockROI is the roi id of the block in <a href="#IQVDocument.DocumentImages">IQVDocument.DocumentImages</a>
    HeaderText is the string of the immediate header
    SectionHeaderROI is the roi id of the immediate header
    BlockPrintPage is the page number (ones-based) of the block in <a href="#IQVDocument.DocumentImages">IQVDocument.DocumentImages</a>
    LinkROI is the roi of the link in <a href="#IQVDocument.DocumentLinks">IQVDocument.DocumentLinks</a>
    LinkLevel is the hierarchy level (ones-based, 1 for highest) of the link in <a href="#IQVDocument.DocumentLinks">IQVDocument.DocumentLinks</a>
    """

    KEY_blinding = str
    """
    blinding
    e.g., open-label, single-blind, double-blind,
     double-blind [sponsor unblinded], matching placebo, double-dummy
    """

    KEY_BlockInsert = str
    """
    For detecting link by font, insert link
    """

    KEY_BlockLineROIExactMatch = str
    """
    Align paragraphs and blocks
    ParaROI is the roi id of the paragraph in <a href="#IQVDocument.DocumentParagraphs">IQVDocument.DocumentParagraphs</a>
    BlockROI is the roi id of the block in <a href="#IQVDocument.DocumentImages">IQVDocument.DocumentImages</a>
    HeaderText is the string of the immediate header
    SectionHeaderROI is the roi id of the immediate header
    BlockPrintPage is the page number (ones-based) of the block in <a href="#IQVDocument.DocumentImages">IQVDocument.DocumentImages</a>
    LinkROI is the roi of the link in <a href="#IQVDocument.DocumentLinks">IQVDocument.DocumentLinks</a>
    LinkLevel is the hierarchy level (ones-based, 1 for highest) of the link in <a href="#IQVDocument.DocumentLinks">IQVDocument.DocumentLinks</a>
    """

    KEY_BlockPrintPage = str
    """
    Align paragraphs and blocks
    ParaROI is the roi id of the paragraph in <a href="#IQVDocument.DocumentParagraphs">IQVDocument.DocumentParagraphs</a>
    BlockROI is the roi id of the block in <a href="#IQVDocument.DocumentImages">IQVDocument.DocumentImages</a>
    HeaderText is the string of the immediate header
    SectionHeaderROI is the roi id of the immediate header
    BlockPrintPage is the page number (ones-based) of the block in <a href="#IQVDocument.DocumentImages">IQVDocument.DocumentImages</a>
    LinkROI is the roi of the link in <a href="#IQVDocument.DocumentLinks">IQVDocument.DocumentLinks</a>
    LinkLevel is the hierarchy level (ones-based, 1 for highest) of the link in <a href="#IQVDocument.DocumentLinks">IQVDocument.DocumentLinks</a>
    """

    KEY_BlockROI = str
    """
    Align paragraphs and blocks
    ParaROI is the roi id of the paragraph in <a href="#IQVDocument.DocumentParagraphs">IQVDocument.DocumentParagraphs</a>
    BlockROI is the roi id of the block in <a href="#IQVDocument.DocumentImages">IQVDocument.DocumentImages</a>
    HeaderText is the string of the immediate header
    SectionHeaderROI is the roi id of the immediate header
    BlockPrintPage is the page number (ones-based) of the block in <a href="#IQVDocument.DocumentImages">IQVDocument.DocumentImages</a>
    LinkROI is the roi of the link in <a href="#IQVDocument.DocumentLinks">IQVDocument.DocumentLinks</a>
    LinkLevel is the hierarchy level (ones-based, 1 for highest) of the link in <a href="#IQVDocument.DocumentLinks">IQVDocument.DocumentLinks</a>
    """

    KEY_BulletPrefix = str
    """
    For bullets and numbers, prefix that
    was manually inserted into the text, derived
    from the bullets
    """

    KEY_color = str
    """
    color from i2e
    From Linguamatics properties
    <a href="#NLP_Entity.Properties">NLP_Entity.Properties</a>
    """

    KEY_COMPARE_base_text = str
    """
    for a compare,
    LHS or baseline or DocumentA object text
    """

    KEY_COMPARE_char_roi_base_location = str
    """
    start index for this <a href="#IQVDocumentDiff">IQVDocumentDiff</a>
    within the base roi (one or more roi's per section)
    """

    KEY_COMPARE_char_roi_compare_location = str
    """
    start index for this <a href="#IQVDocumentDiff">IQVDocumentDiff</a>
    within the compare roi (one or more roi's per section)
    """

    KEY_COMPARE_char_section_location = str
    """
    start index for this <a href="#IQVDocumentDiff">IQVDocumentDiff</a>
    within this section
    """

    KEY_COMPARE_compare_text = str
    """
    for a compare,
    RHS or compare or DocumentB object text
    """

    KEY_compare_document_a = str
    """
    used in compare display
    LHS | v1 | document A
    compare_document_a
    as compared to <a href="#IQV_KEY_STRING.KEY_compare_document_b">IQV_KEY_STRING.KEY_compare_document_b</a>
    """

    KEY_compare_document_b = str
    """
    used in compare display
    RHS | v2 | document B
    compare_document_b
    as compared to <a href="#IQV_KEY_STRING.KEY_compare_document_a">IQV_KEY_STRING.KEY_compare_document_a</a>
    """

    KEY_COMPARE_summary_num_chars = str
    """
    number of individual chars from all <a href="#IQVDocumentDiff">IQVDocumentDiff</a> within a
     section element or other item
    """

    KEY_COMPARE_summary_num_diffs = str
    """
    number of individual diffs <a href="#IQVDocumentDiff">IQVDocumentDiff</a> within a
     section element or other item
    """

    KEY_compound = str
    """
    compound
    """

    KEY_ConjoinedSegments = str
    """
    multiple segments that are logically concatenated
    """

    KEY_control = str
    """
    control
    """

    KEY_CumulativeWordCount = str
    """
    CumulativeWordCount is word count in context of
    <a href="#IQVDocument.DocumentParagraphs">IQVDocument.DocumentParagraphs</a> words,
    not including headers and footers
    """

    KEY_CustomXML = str
    """
    CustomXML
    """

    KEY_decon_soa_max_x = str
    """
    For decon page, some soa may be deconstructed from scratch
    by page.
    This is tracked with this key.

    The table often has comments on the right side.
    This value helps track comments outside the table.
    """

    KEY_decon_soa_page = str
    """
    For decon page, some soa may be deconstructed from scratch
    by page.
    This is tracked with this key.
    """

    KEY_design = str
    """
    design
    """

    KEY_DiscontinuationofStudyInterventionsandParticipantWithdrawalHeader = str
    """
    For this section DiscontinuationofStudyInterventionsandParticipantWithdrawal, the value provided is the friendly display description (such as TOC text), text at top of this used to describe what section this is
    """

    KEY_DiscontinuationofStudyInterventionsandParticipantWithdrawalRefRoiId = str
    """
    For this section DiscontinuationofStudyInterventionsandParticipantWithdrawal, id of toc_element. (We do not need to store the id of current element--this is found in self.id)
    """

    KEY_document_keyword = str
    """
    for <a href="#IQVDocumentGroundTruth.XProperties">IQVDocumentGroundTruth.XProperties</a>
    to support multiple keyword assigned to a document
    """

    KEY_document_status = str
    """
    document_status found in POST under
    <a href="#IQVDocument.IQVDocumentFeedbackResultsList">IQVDocument.IQVDocumentFeedbackResultsList</a>
    such as final, draft
    """

    KEY_document_topic = str
    """
    for <a href="#IQVDocumentGroundTruth.XProperties">IQVDocumentGroundTruth.XProperties</a>
    to support multiple topics assigned to a document
    """

    KEY_document_version = str
    """
    document_version found in POST under
    <a href="#IQVDocument.IQVDocumentFeedbackResultsList">IQVDocument.IQVDocumentFeedbackResultsList</a>
    such as final, draft
    """

    KEY_DocumentPropertyKey = str
    """
    What are we comparing? the property
    """

    KEY_drug = str
    """
    drug
    """

    KEY_dts = str
    """
    date time stamp in YYYYMMDDHHMMSS UTC format 14-characters
    """

    KEY_endpoints = str
    """
    endpoints
    """

    KEY_EndpointsHeader = str
    """
    For this section Endpoints, the value provided is the friendly display description (such as TOC text), text at top of this used to describe what section this is
    """

    KEY_EndpointsRefRoiId = str
    """
    For this section Endpoints, id of toc_element. (We do not need to store the id of current element--this is found in self.id)
    """

    KEY_entities_in_assessments = str
    """
    entities_in_assessments for SOA
    i2e=entities_in_assessments
    """

    KEY_entity_key = str
    """
    entity_key key used in i2e query
    <a href="#NLP_Entity.Properties">NLP_Entity.Properties</a>
    """

    KEY_environment = str
    """
    environment found in POST under
    <a href="#IQVDocument.IQVDocumentFeedbackResultsList">IQVDocument.IQVDocumentFeedbackResultsList</a>
    """

    KEY_exclusion_section = str
    """
    exclusion_section
    i2e=exclusion_section
    """

    KEY_ExclusionCriteriaHeader = str
    """
    For this section ExclusionCriteria, the value provided is the friendly display description (such as TOC text), text at top of this used to describe what section this is
    """

    KEY_ExclusionCriteriaRefRoiId = str
    """
    For this section ExclusionCriteria, id of toc_element. (We do not need to store the id of current element--this is found in self.id)
    """

    KEY_font_bold = str
    """
    font_bold as true or false
    """

    KEY_font_size = str
    """
    font_size
    """

    KEY_font_style = str
    """
    font_style
    """

    KEY_Footnote_ = str
    """
    Align footnote to table reference
    Footnote
    element in DocumentParagraphs
    key "IsFootnote" value "footnote label" (e.g., a, b, c)
    key "FootnoteTableROI" value "ROI id of table to which this footnote applies to"
    Footnote pointer(table cell with text that references footnote)
    element in DocumentTables
    at the table cell level
    key "Footnote_i" value "footnote label" (e.g., a, b, c)
    key "FootnoteText_i" value "footnote text"
    key "FootnoteID_i" value "ROI id of paragraph that is the footnote"
    i is zero-based iterator to handle cases in which one table cell has multiple footnote references
    """

    KEY_FootnoteID_ = str
    """
    Align footnote to table reference
    Footnote
    element in DocumentParagraphs
    key "IsFootnote" value "footnote label" (e.g., a, b, c)
    key "FootnoteTableROI" value "ROI id of table to which this footnote applies to"
    Footnote pointer(table cell with text that references footnote)
    element in DocumentTables
    at the table cell level
    key "Footnote_i" value "footnote label" (e.g., a, b, c)
    key "FootnoteText_i" value "footnote text"
    key "FootnoteID_i" value "ROI id of paragraph that is the footnote"
    i is zero-based iterator to handle cases in which one table cell has multiple footnote references
    """

    KEY_FootnoteParaROI = str
    """
    Align footnote to reference in para
    This is property of footnote
    This is for footnotes at bottom of page
    Others not handled here
    end notes
    footnotes for SOA
    """

    KEY_FootnoteTableROI = str
    """
    Align footnote to table reference
    Footnote
    element in DocumentParagraphs
    key "IsFootnote" value "footnote label" (e.g., a, b, c)
    key "FootnoteTableROI" value "ROI id of table to which this footnote applies to"
    Footnote pointer(table cell with text that references footnote)
    element in DocumentTables
    at the table cell level
    key "Footnote_i" value "footnote label" (e.g., a, b, c)
    key "FootnoteText_i" value "footnote text"
    key "FootnoteID_i" value "ROI id of paragraph that is the footnote"
    i is zero-based iterator to handle cases in which one table cell has multiple footnote references
    """

    KEY_FootnoteText_ = str
    """
    Align footnote to table reference
    Footnote
    element in DocumentParagraphs
    key "IsFootnote" value "footnote label" (e.g., a, b, c)
    key "FootnoteTableROI" value "ROI id of table to which this footnote applies to"
    Footnote pointer(table cell with text that references footnote)
    element in DocumentTables
    at the table cell level
    key "Footnote_i" value "footnote label" (e.g., a, b, c)
    key "FootnoteText_i" value "footnote text"
    key "FootnoteID_i" value "ROI id of paragraph that is the footnote"
    i is zero-based iterator to handle cases in which one table cell has multiple footnote references
    """

    KEY_gridspan = str
    """
    for a table, grid span for column
    """

    KEY_HeaderNumericSection = str
    """
    for a header, the numeric TOC value as in 3.2.2
    """

    KEY_HeaderText = str
    """
    Align paragraphs and blocks
    ParaROI is the roi id of the paragraph in <a href="#IQVDocument.DocumentParagraphs">IQVDocument.DocumentParagraphs</a>
    BlockROI is the roi id of the block in <a href="#IQVDocument.DocumentImages">IQVDocument.DocumentImages</a>
    HeaderText is the string of the immediate header
    SectionHeaderROI is the roi id of the immediate header
    BlockPrintPage is the page number (ones-based) of the block in <a href="#IQVDocument.DocumentImages">IQVDocument.DocumentImages</a>
    LinkROI is the roi of the link in <a href="#IQVDocument.DocumentLinks">IQVDocument.DocumentLinks</a>
    LinkLevel is the hierarchy level (ones-based, 1 for highest) of the link in <a href="#IQVDocument.DocumentLinks">IQVDocument.DocumentLinks</a>
    """

    KEY_ilvl = str
    """
    For bullets and numbers, the unique id for the
     <a href="#IQVNumberingLevel">IQVNumberingLevel</a>
    """

    KEY_inclusion_section = str
    """
    inclusion_section
    i2e=inclusion_section
    """

    KEY_InclusionCriteriaHeader = str
    """
    For this section InclusionCriteria, the value provided is the friendly display description (such as TOC text), text at top of this used to describe what section this is
    """

    KEY_InclusionCriteriaRefRoiId = str
    """
    For this section InclusionCriteria, id of toc_element. (We do not need to store the id of current element--this is found in self.id)
    """

    KEY_indication = str
    """
    indication
    """

    KEY_InsertRectifyText = str
    """
    From rectify para-block, did we
    change the para to match the block?
    """

    KEY_intervention_form = str
    """
    intervention_form
    """

    KEY_intervention_method = str
    """
    intervention_method
    e.g., randomization, stratification, both
    """

    KEY_IntroductionHeader = str
    """
    For this section Introduction, the value provided is the friendly display description (such as TOC text), text at top of this used to describe what section this is
    """

    KEY_IntroductionRefRoiId = str
    """
    For this section Introduction, id of toc_element. (We do not need to store the id of current element--this is found in self.id)
    """

    KEY_investigator = str
    """
    investigator
    """

    KEY_iqv_standard_term = str
    """
    iqv_standard_term
    as listed in https://wiki.quintiles.net/display/PD/Standardized+Section+Headers
    <a href="#IQVPageROI.iqv_standard_term">IQVPageROI.iqv_standard_term</a> and <a href="#IQVDocumentLink.iqv_standard_term">IQVDocumentLink.iqv_standard_term</a>

    Use this as property key when the standard term is updated and want to track it
    """

    KEY_IsAmendment = str
    """
    Y or N (?)
    """

    KEY_IsAttachment = str
    """
    is-a element for footnote in section SOA
    This marks a paragraph as a footnote
    of the section SOA so it won't be duplicated
    with <a href="#IQVPageROI.Attachments">IQVPageROI.Attachments</a>
    """

    KEY_IsColumnHeader = str
    """
    for a table, is this a header
    """

    KEY_IsDiscontinuationofStudyInterventionsandParticipantWithdrawalElement = str
    """
    is-a element for section DiscontinuationofStudyInterventionsandParticipantWithdrawal
    This is the ROI that marks one element
     of the section DiscontinuationofStudyInterventionsandParticipantWithdrawal
    """

    KEY_IsDiscontinuationofStudyInterventionsandParticipantWithdrawalHeader = str
    """
    is-a header for section DiscontinuationofStudyInterventionsandParticipantWithdrawal
    This is the ROI that marks the header
     for the section DiscontinuationofStudyInterventionsandParticipantWithdrawal
    """

    KEY_IsEndpointsElement = str
    """
    is-a element for section Endpoints
    This is the ROI that marks one element
     of the section Endpoints
    """

    KEY_IsEndpointsHeader = str
    """
    is-a header for section Endpoints
    This is the ROI that marks the header
     for the section Endpoints
    """

    KEY_IsEndpointTable = str
    """
    is-a Table for section Endpoints
    This is the ROI that marks one Table
    """

    KEY_IsExclusionCriteria = str
    """
    is-a item in section ExclusionCriteria
    """

    KEY_IsExclusionCriteriaElement = str
    """
    is-a element for section ExclusionCriteria
    This is the ROI that marks one element
     of the section ExclusionCriteria
    """

    KEY_IsExclusionCriteriaHeader = str
    """
    is-a header for section ExclusionCriteria
    This is the ROI that marks the header
     for the section ExclusionCriteria
    """

    KEY_IsFootnote = str
    """
    Align footnote to table reference
    Footnote
    element in DocumentParagraphs
    key "IsFootnote" value "footnote label" (e.g., a, b, c)
    key "FootnoteTableROI" value "ROI id of table to which this footnote applies to"
    Footnote pointer(table cell with text that references footnote)
    element in DocumentTables
    at the table cell level
    key "Footnote_i" value "footnote label" (e.g., a, b, c)
    key "FootnoteText_i" value "footnote text"
    key "FootnoteID_i" value "ROI id of paragraph that is the footnote"
    i is zero-based iterator to handle cases in which one table cell has multiple footnote references
    """

    KEY_IsFootnote_ = str
    """
    Align footnote to table reference
    Footnote
    element in DocumentParagraphs
    key "IsFootnote_i" value "footnote label" (e.g., a, b, c)
    key "FootnoteTableROI" value "ROI id of table to which this footnote applies to"
    Footnote pointer(table cell with text that references footnote)
    element in DocumentTables
    at the table cell level
    key "Footnote_i" value "footnote label" (e.g., a, b, c)
    key "FootnoteText_i" value "footnote text"
    key "FootnoteID_i" value "ROI id of paragraph that is the footnote"
    i is zero-based iterator to handle cases in which one table cell has multiple footnote references
    """

    KEY_IsFootnoteText_ = str
    """
    Align footnote to table reference
    Footnote
    element in DocumentParagraphs
    key "IsFootnote_i" value "footnote label" (e.g., a, b, c)
    key "IsFootnoteText_i" value "footnote text"
    key "FootnoteTableROI" value "ROI id of table to which this footnote applies to"
    Footnote pointer(table cell with text that references footnote)
    element in DocumentTables
    at the table cell level
    key "Footnote_i" value "footnote label" (e.g., a, b, c)
    key "FootnoteText_i" value "footnote text"
    key "FootnoteID_i" value "ROI id of paragraph that is the footnote"
    i is zero-based iterator to handle cases in which one table cell has multiple footnote references
    """

    KEY_IsInclusionCriteria = str
    """
    is-a item in section InclusionCriteria
    """

    KEY_IsInclusionCriteriaElement = str
    """
    is-a element for section InclusionCriteria
    This is the ROI that marks one element
     of the section InclusionCriteria
    """

    KEY_IsInclusionCriteriaHeader = str
    """
    is-a header for section InclusionCriteria
    This is the ROI that marks the header
     for the section InclusionCriteria
    """

    KEY_IsIntroductionElement = str
    """
    is-a element for section Introduction
    This is the ROI that marks one element
     of the section Introduction
    """

    KEY_IsIntroductionHeader = str
    """
    is-a header for section Introduction
    This is the ROI that marks the header
     for the section Introduction
    """

    KEY_IsObjectivesElement = str
    """
    is-a element for section Objectives
    This is the ROI that marks one element
     of the section Objectives
    """

    KEY_IsObjectivesEndpointsElement = str
    """
    is-a element for section ObjectivesEndpoints
    This is the ROI that marks one element
     of the section ObjectivesEndpoints
    """

    KEY_IsObjectivesEndpointsHeader = str
    """
    is-a header for section ObjectivesEndpoints
    This is the ROI that marks the header
     for the section ObjectivesEndpoints
    """

    KEY_IsObjectivesHeader = str
    """
    is-a header for section Objectives
    This is the ROI that marks the header
     for the section Objectives
    """

    KEY_IsReferencesElement = str
    """
    is-a element for section References
    This is the ROI that marks one element
     of the section References
    """

    KEY_IsReferencesHeader = str
    """
    is-a header for section References
    This is the ROI that marks the header
     for the section References
    """

    KEY_IsRootElement = str
    """
    is-a root element as for <a href="#IQVDocumentDiff">IQVDocumentDiff</a>
    that has child diffs
    """

    KEY_IsSectionElement = str
    """
    IsSectionElement is-a element for section Section
    This is the ROI that marks one element
     of the section Section.
    SectionHeaderROI is roi of the immediate header
     SectionHeaderPrintPage is expected print page of roi of the immediate header
    """

    KEY_IsSectionElementDiff = str
    """
    individual diff within a section element
    """

    KEY_IsSectionHeader = str
    """
    is-a header for section Section
    This is the ROI that marks the header
     for the section Section
    """

    KEY_IsSOAAssessment = str
    """
    is-a Assessment for section SOA
    This is the ROI that marks one Assessment
     of the section SOA
    """

    KEY_IsSOAAssessmentPreferredTerm = str
    """
    is-a Assessment for section SOA
    This is the ROI that marks one Assessment
     of the section SOA
    This is the preferred term for the assessment
    """

    KEY_IsSOAElement = str
    """
    is-a element for section SOA
    This is the ROI that marks one element
     of the section SOA
    """

    KEY_IsSOAEpoch = str
    """
    is-a Column Header for section SOA
    This is the <a href="#IQVPageROI">IQVPageROI</a> or <a href="#IQVTableColumn">IQVTableColumn</a>
     that marks one Table Header
    of the section SOA
    """

    KEY_IsSOAHeader = str
    """
    is-a header for section SOA
    This is the ROI that marks the header
     for the section SOA
    """

    KEY_IsSOALink = str
    """
    is-a Table for link SOA
    This is the Link that contains SOA
    """

    KEY_IsSOATable = str
    """
    is-a Table for section SOA
    This is the ROI that marks one Table
     of the section SOA
    """

    KEY_IsSOATableColumn = str
    """
    is-a Table Column (Headers) / Timepoint for section SOA
    This is the ROI that marks one <a href="#IQVTableColumn">IQVTableColumn</a>
     of the section SOA
    """

    KEY_IsStatisticalConsiderationsElement = str
    """
    is-a element for section StatisticalConsiderations
    This is the ROI that marks one element
     of the section StatisticalConsiderations
    """

    KEY_IsStatisticalConsiderationsHeader = str
    """
    is-a header for section StatisticalConsiderations
    This is the ROI that marks the header
     for the section StatisticalConsiderations
    """

    KEY_IsStudyAssessmentsandProceduresElement = str
    """
    is-a element for section StudyAssessmentsandProcedures
    This is the ROI that marks one element
     of the section StudyAssessmentsandProcedures
    """

    KEY_IsStudyAssessmentsandProceduresHeader = str
    """
    is-a header for section StudyAssessmentsandProcedures
    This is the ROI that marks the header
     for the section StudyAssessmentsandProcedures
    """

    KEY_IsStudyDesignElement = str
    """
    is-a element for section StudyDesign
    This is the ROI that marks one element
     of the section StudyDesign
    """

    KEY_IsStudyDesignHeader = str
    """
    is-a header for section StudyDesign
    This is the ROI that marks the header
     for the section StudyDesign
    """

    KEY_IsStudyInterventionsandConcomitantTherapyElement = str
    """
    is-a element for section StudyInterventionsandConcomitantTherapy
    This is the ROI that marks one element
     of the section StudyInterventionsandConcomitantTherapy
    """

    KEY_IsStudyInterventionsandConcomitantTherapyHeader = str
    """
    is-a header for section StudyInterventionsandConcomitantTherapy
    This is the ROI that marks the header
     for the section StudyInterventionsandConcomitantTherapy
    """

    KEY_IsStudyPopulationElement = str
    """
    is-a element for section StudyPopulation
    This is the ROI that marks one element
     of the section StudyPopulation
    """

    KEY_IsStudyPopulationHeader = str
    """
    is-a header for section StudyPopulation
    This is the ROI that marks the header
     for the section StudyPopulation
    """

    KEY_IsSummaryElement = str
    """
    is-a element for section Summary
    This is the ROI that marks one element
     of the section Summary
    """

    KEY_IsSummaryHeader = str
    """
    is-a header for section Summary
    This is the ROI that marks the header
     for the section Summary
    """

    KEY_IsSupportingDocumentationElement = str
    """
    is-a element for section SupportingDocumentation
    This is the ROI that marks one element
     of the section SupportingDocumentation
    """

    KEY_IsSupportingDocumentationHeader = str
    """
    is-a header for section SupportingDocumentation
    This is the ROI that marks the header
     for the section SupportingDocumentation
    """

    KEY_IsTOAElement = str
    """
    is-a element for section TOA
    This is the ROI that marks one element
     of the section TOA
    """

    KEY_IsTOAHeader = str
    """
    is-a header for section TOA
    This is the ROI that marks the header
     for the section TOA
    """

    KEY_IsTOCElement = str
    """
    is-a element for section TOC
    This is the ROI that marks one element
     of the section TOC
    """

    KEY_IsTOCHeader = str
    """
    is-a header for section TOC
    This is the ROI that marks the header
     for the section TOC
    """

    KEY_IsTOCLink = str
    """
    is-a <a href="#IQVDocumentLink">IQVDocumentLink</a> that is found in TOC
    or is TOC-like (refers to a section in the document)
    """

    KEY_IsTOFElement = str
    """
    is-a element for section TOF
    This is the ROI that marks one element
     of the section TOF
    """

    KEY_IsTOFHeader = str
    """
    is-a header for section TOF
    This is the ROI that marks the header
     for the section TOF
    """

    KEY_IsTOTElement = str
    """
    is-a element for section TOT
    This is the ROI that marks one element
     of the section TOT
    """

    KEY_IsTOTHeader = str
    """
    is-a header for section TOT
    This is the ROI that marks the header
     for the section TOT
    """

    KEY_ItemType = str
    """
    for DocumentItem
    """

    KEY_ItemType_Endpoint = str
    """
    for DocumentItem
    """

    KEY_ItemType_EndpointType = str
    """
    for DocumentItem
    """

    KEY_ItemType_Objective = str
    """
    for DocumentItem
    """

    KEY_ItemType_ObjectiveType = str
    """
    for DocumentItem
    """

    KEY_LinkLevel = str
    """
    Align paragraphs and blocks
    ParaROI is the roi id of the paragraph in <a href="#IQVDocument.DocumentParagraphs">IQVDocument.DocumentParagraphs</a>
    BlockROI is the roi id of the block in <a href="#IQVDocument.DocumentImages">IQVDocument.DocumentImages</a>
    HeaderText is the string of the immediate header
    SectionHeaderROI is the roi id of the immediate header
    BlockPrintPage is the page number (ones-based) of the block in <a href="#IQVDocument.DocumentImages">IQVDocument.DocumentImages</a>
    LinkROI is the roi of the link in <a href="#IQVDocument.DocumentLinks">IQVDocument.DocumentLinks</a>
    LinkLevel is the hierarchy level (ones-based, 1 for highest) of the link in <a href="#IQVDocument.DocumentLinks">IQVDocument.DocumentLinks</a>
    """

    KEY_LinkPage = str
    """
    LinkROI is the roi of the link in <a href="#IQVDocument.DocumentLinks">IQVDocument.DocumentLinks</a>
    LinkLevel is the hierarchy level (ones-based, 1 for highest) of the link in <a href="#IQVDocument.DocumentLinks">IQVDocument.DocumentLinks</a>
    LinkPage is page as specified in table of contents
    LinkPrefix is numeric prefix
    """

    KEY_LinkPageLHS = str
    """
    LHS Page Number for diff of <a href="#IQVDocumentDiff.diff_category">IQVDocumentDiff.diff_category</a>==
    <a href="#IQV_KEY_STRING.KEY_IsTOCLink">IQV_KEY_STRING.KEY_IsTOCLink</a>IsTOCLink
    """

    KEY_LinkPageRHS = str
    """
    RHS Page Number for diff of <a href="#IQVDocumentDiff.diff_category">IQVDocumentDiff.diff_category</a>==
    <a href="#IQV_KEY_STRING.KEY_IsTOCLink">IQV_KEY_STRING.KEY_IsTOCLink</a>IsTOCLink
    """

    KEY_LinkPrefix = str
    """
    LinkROI is the roi of the link in <a href="#IQVDocument.DocumentLinks">IQVDocument.DocumentLinks</a>
    LinkLevel is the hierarchy level (ones-based, 1 for highest) of the link in <a href="#IQVDocument.DocumentLinks">IQVDocument.DocumentLinks</a>
    LinkPage is page as specified in table of contents
    LinkPrefix is numeric prefix
    """

    KEY_LinkROI = str
    """
    Align paragraphs and blocks
    ParaROI is the roi id of the paragraph in <a href="#IQVDocument.DocumentParagraphs">IQVDocument.DocumentParagraphs</a>
    BlockROI is the roi id of the block in <a href="#IQVDocument.DocumentImages">IQVDocument.DocumentImages</a>
    HeaderText is the string of the immediate header
    SectionHeaderROI is the roi id of the immediate header
    BlockPrintPage is the page number (ones-based) of the block in <a href="#IQVDocument.DocumentImages">IQVDocument.DocumentImages</a>
    LinkROI is the roi of the link in <a href="#IQVDocument.DocumentLinks">IQVDocument.DocumentLinks</a>
    LinkLevel is the hierarchy level (ones-based, 1 for highest) of the link in <a href="#IQVDocument.DocumentLinks">IQVDocument.DocumentLinks</a>
    """

    KEY_LinkText = str
    """
    Align paragraphs and blocks
    ParaROI is the roi id of the paragraph in <a href="#IQVDocument.DocumentParagraphs">IQVDocument.DocumentParagraphs</a>
    BlockROI is the roi id of the block in <a href="#IQVDocument.DocumentImages">IQVDocument.DocumentImages</a>
    HeaderText is the string of the immediate header
    SectionHeaderROI is the roi id of the immediate header
    BlockPrintPage is the page number (ones-based) of the block in <a href="#IQVDocument.DocumentImages">IQVDocument.DocumentImages</a>
    LinkROI is the roi of the link in <a href="#IQVDocument.DocumentLinks">IQVDocument.DocumentLinks</a>
    LinkLevel is the hierarchy level (ones-based, 1 for highest) of the link in <a href="#IQVDocument.DocumentLinks">IQVDocument.DocumentLinks</a>
    """

    KEY_ManualInsert = str
    """
    Align paragraphs and blocks
    ParaROI is the roi id of the paragraph in <a href="#IQVDocument.DocumentParagraphs">IQVDocument.DocumentParagraphs</a>
    BlockROI is the roi id of the block in <a href="#IQVDocument.DocumentImages">IQVDocument.DocumentImages</a>
    HeaderText is the string of the immediate header
    SectionHeaderROI is the roi id of the immediate header
    BlockPrintPage is the page number (ones-based) of the block in <a href="#IQVDocument.DocumentImages">IQVDocument.DocumentImages</a>
    LinkROI is the roi of the link in <a href="#IQVDocument.DocumentLinks">IQVDocument.DocumentLinks</a>
    LinkLevel is the hierarchy level (ones-based, 1 for highest) of the link in <a href="#IQVDocument.DocumentLinks">IQVDocument.DocumentLinks</a>
    ManualInsert when link is not explicitly provided
    """

    KEY_masking = str
    """
    masking
    enter all that apply (participant, care provider, investigator,
     outcomes assessor) or 'No Masking'
    """

    KEY_molecule_device = str
    """
    molecule_device found in POST under
    <a href="#IQVDocument.IQVDocumentFeedbackResultsList">IQVDocument.IQVDocumentFeedbackResultsList</a>
    """

    KEY_next = str
    """
    next from i2e
    From Linguamatics properties
    <a href="#NLP_Entity.Properties">NLP_Entity.Properties</a>
    """

    KEY_nid = str
    """
    nid from i2e
    From Linguamatics properties
    <a href="#NLP_Entity.Properties">NLP_Entity.Properties</a>
    """

    KEY_NormalizedSOA_CSVFilename = str
    """
    NormalizedSOA Output to CSV file, which
    is generated after OMOP Update as output.
    If no records are found, the value to this field is blank
    """

    KEY_NormalizedSOA_JSONFilename = str
    """
    NormalizedSOA Output to JSON file, which
    is generated after OMOP Update as output.
    If no SOA is in the protocol document, the value to this field is blank
    If no records are found, the value to this field is blank
    """

    KEY_num_entities = str
    """
    count of entities for this roi
    """

    KEY_number_of_subjects = str
    """
    number_of_subjects
    i2e=number_of_subjects
    """

    KEY_numId = str
    """
    For bullets and numbers, the unique id for the
     <a href="#IQVNumberingGroup">IQVNumberingGroup</a>
    """

    KEY_ObjectiveRefRoiId = str
    """
    for DocumentItem
    if this is an endpoint, then the link to the objective is here
    """

    KEY_objectives_section = str
    """
    objectives_section
    i2e=objectives_section
    aka primary objectives
    """

    KEY_ObjectivesEndpointsHeader = str
    """
    For this section ObjectivesEndpoints, the value provided is the friendly display description (such as TOC text), text at top of this used to describe what section this is
    """

    KEY_ObjectivesEndpointsRefRoiId = str
    """
    For this section ObjectivesEndpoints, id of toc_element. (We do not need to store the id of current element--this is found in self.id)
    """

    KEY_ObjectivesHeader = str
    """
    For this section Objectives, the value provided is the friendly display description (such as TOC text), text at top of this used to describe what section this is
    """

    KEY_ObjectivesRefRoiId = str
    """
    For this section Objectives, id of toc_element. (We do not need to store the id of current element--this is found in self.id)
    """

    KEY_observation = str
    """
    observation
    What is being examined to determine the effect from the intervention?
     Potential terms: treat, delay, confirm, predict, identify,
     reduce, correct, reverse, lower, decrease, increase or improve
    """

    KEY_ParaIndex = str
    """
    ParaIndex is index in <a href="#IQVDocument.DocumentParagraphs">IQVDocument.DocumentParagraphs</a>
    """

    KEY_ParaPrintPage = str
    """
    Align paragraphs and blocks
    ParaROI is the roi id of the paragraph in <a href="#IQVDocument.DocumentParagraphs">IQVDocument.DocumentParagraphs</a>
    BlockROI is the roi id of the block in <a href="#IQVDocument.DocumentImages">IQVDocument.DocumentImages</a>
    HeaderText is the string of the immediate header
    SectionHeaderROI is the roi id of the immediate header
    BlockPrintPage is the page number (ones-based) of the block in <a href="#IQVDocument.DocumentImages">IQVDocument.DocumentImages</a>
    ParaPrintPage is the page number (ones-based) of estimation of block location
    LinkROI is the roi of the link in <a href="#IQVDocument.DocumentLinks">IQVDocument.DocumentLinks</a>
    LinkLevel is the hierarchy level (ones-based, 1 for highest) of the link in <a href="#IQVDocument.DocumentLinks">IQVDocument.DocumentLinks</a>
    """

    KEY_ParaROI = str
    """
    Align paragraphs and blocks
    ParaROI is the roi id of the paragraph in <a href="#IQVDocument.DocumentParagraphs">IQVDocument.DocumentParagraphs</a>
    BlockROI is the roi id of the block in <a href="#IQVDocument.DocumentImages">IQVDocument.DocumentImages</a>
    HeaderText is the string of the immediate header
    SectionHeaderROI is the roi id of the immediate header
    BlockPrintPage is the page number (ones-based) of the block in <a href="#IQVDocument.DocumentImages">IQVDocument.DocumentImages</a>
    LinkROI is the roi of the link in <a href="#IQVDocument.DocumentLinks">IQVDocument.DocumentLinks</a>
    LinkLevel is the hierarchy level (ones-based, 1 for highest) of the link in <a href="#IQVDocument.DocumentLinks">IQVDocument.DocumentLinks</a>
    """

    KEY_ParaROIExactMatch = str
    """
    Align paragraphs and blocks
    ParaROI is the roi id of the paragraph in <a href="#IQVDocument.DocumentParagraphs">IQVDocument.DocumentParagraphs</a>
    BlockROI is the roi id of the block in <a href="#IQVDocument.DocumentImages">IQVDocument.DocumentImages</a>
    HeaderText is the string of the immediate header
    SectionHeaderROI is the roi id of the immediate header
    BlockPrintPage is the page number (ones-based) of the block in <a href="#IQVDocument.DocumentImages">IQVDocument.DocumentImages</a>
    LinkROI is the roi of the link in <a href="#IQVDocument.DocumentLinks">IQVDocument.DocumentLinks</a>
    LinkLevel is the hierarchy level (ones-based, 1 for highest) of the link in <a href="#IQVDocument.DocumentLinks">IQVDocument.DocumentLinks</a>
    """

    KEY_participant_age = str
    """
    participant_age
    """

    KEY_participant_sex = str
    """
    participant_sex
    """

    KEY_PB_biopsy = str
    """
    Patient Burden (PB) Variable
    Is ≥1 biopsy required DURING the trial? Choose Y or N
    """

    KEY_PB_blood_draw = str
    """
    Patient Burden (PB) Variable
    Is this assessment a blood draw?
    intermediate action
    """

    KEY_PB_caregiver = str
    """
    Patient Burden (PB) Variable
    Will the subject need a caregiver in order to participate in the trial? Choose Y or N
    """

    KEY_PB_colonoscopy = str
    """
    Patient Burden (PB) Variable
    Is ≥1 colonoscopy required in the trial? Choose Y or N
    """

    KEY_PB_diary = str
    """
    Patient Burden (PB) Variable
    Is the patient required to fill in a diary at home? Choose Y or N
    """

    KEY_PB_discontinue_treatment = str
    """
    Patient Burden (PB) Variable
    Does the subject need to discontinue current treatment for the disease? Choose Y or N
    """

    KEY_PB_endoscopy = str
    """
    Patient Burden (PB) Variable
    Is ≥1 endoscopy required in the trial? Choose Y or N
    """

    KEY_PB_freq_pro = str
    """
    Patient Burden (PB) Variable
    If there are any PROs in the trial, is ≥1 PRO required to be filled out at &gt;50% of visits?
    """

    KEY_PB_imaging_ct = str
    """
    Patient Burden (PB) Variable
    Is ≥1 CT required in the trial? Choose Y or N
    """

    KEY_PB_imaging_dexa = str
    """
    Patient Burden (PB) Variable
    Is ≥1 Dexa required in the trial? Choose Y or N
    """

    KEY_PB_imaging_mammogram = str
    """
    Patient Burden (PB) Variable
    Is ≥1 Mammogram required in the trial? Choose Y or N
    """

    KEY_PB_imaging_mri = str
    """
    Patient Burden (PB) Variable
    Is ≥1 MRI required in the trial? Choose Y or N
    """

    KEY_PB_imaging_pet = str
    """
    Patient Burden (PB) Variable
    Is ≥1 PET required in the trial? Choose Y or N
    """

    KEY_PB_imaging_xray = str
    """
    Patient Burden (PB) Variable
    Is ≥1 X-ray required in the trial? Choose Y or N
    """

    KEY_PB_IncludesPRO = str
    """
    For Patient Burden (PB) Variable
    Are there PRO assessments at this visit?
    """

    KEY_PB_injectable = str
    """
    Patient Burden (PB) Variable
    Is the study drug injectable, but SoC is not? Choose Y or N
    """

    KEY_PB_injection_gt1_visit = str
    """
    Patient Burden (PB) Variable
    If study drug is injectable, does any visit have &gt;1 injection of study drug, when SOC does not?
    """

    KEY_PB_inpatient = str
    """
    Patient Burden (PB) Variable
    Is an in-patient duration (≥ 1 overnight stay) required DUE ONLY TO the trial? Choose Y or N
    """

    KEY_PB_lumbar_puncture = str
    """
    Patient Burden (PB) Variable
    Is ≥1 lumbar puncture required in the trial? Choose Y or N
    """

    KEY_PB_median_visit_len = str
    """
    Patient Burden (PB) Variable
    What is the median visit length? Enter as number of hours
    """

    KEY_PB_novel_drug = str
    """
    Patient Burden (PB) Variable
    Is this investigational product/study drug novel and unapproved? Choose Y or N
    """

    KEY_PB_num_visits_per_month = str
    """
    Patient Burden (PB) Variable
    Calculate # visits / month
    """

    KEY_PB_pb_total_score = str
    """
    Patient Burden (PB) Variable
    Total Score
    """

    KEY_PB_percent_placebo = str
    """
    Patient Burden (PB) Variable
    What percentage of patients will experience pure placebo for some period during the trial? Enter a number 0-100%
    """

    KEY_PB_percent_visit_blood_gte1 = str
    """
    Patient Burden (PB) Variable
    What percentage of visits have ≥1 blood draw? Enter a number 0-100%
    """

    KEY_PB_pro = str
    """
    Patient Burden (PB) Variable
    Is this item a PRO?
    """

    KEY_PB_total_num_months = str
    """
    Patient Burden (PB) Variable
    What is the total length, in months, of the trial? Enter a number
    """

    KEY_PB_total_num_pro = str
    """
    Patient Burden (PB) Variable
    How many PRO assessments (subject entered) are in this trial? Enter a number
    """

    KEY_PB_total_num_site_visit = str
    """
    Patient Burden (PB) Variable
    How many total in-person visits are in the trial? Enter a number
    """

    KEY_phase = str
    """
    phase
    """

    KEY_PhysicalTableIndex = str
    """
    for a table, index of the table
    """

    KEY_population = str
    """
    population
    i2e=population
    """

    KEY_PopulationCountElement = str
    """
    This ROI contains the value of PopulationCount
    This is the ROI that marks one element
     that indicates PopulationCount
    """

    KEY_priority = str
    """
    priority found in POST under
    <a href="#IQVDocument.IQVDocumentFeedbackResultsList">IQVDocument.IQVDocumentFeedbackResultsList</a>
    """

    KEY_prob = str
    """
    prob from i2e
    From Linguamatics properties
    <a href="#NLP_Entity.Properties">NLP_Entity.Properties</a>
    """

    KEY_ProcessDateTime = str
    """
    ProcessDateTime that created the element
    for attribute listed in <a href="#IQVDocument.IQVAttributeCandidates">IQVDocument.IQVAttributeCandidates</a>
    as AttributeKey for one of the <a href="#IQVAttributeCandidate.Features">IQVAttributeCandidate.Features</a>
    using YYYYMMDDHHSSMM UTC
    """

    KEY_ProcessMachineName = str
    """
    name of server hosting the process
    """

    KEY_ProcessName = str
    """
    Process that created the element
    for attribute listed in <a href="#IQVDocument.IQVAttributeCandidates">IQVDocument.IQVAttributeCandidates</a>
    as AttributeKey for one of the <a href="#IQVAttributeCandidate.Features">IQVAttributeCandidate.Features</a>
    """

    KEY_ProcessVersion = str
    """
    ProcessVersion that created the element
    for attribute listed in <a href="#IQVDocument.IQVAttributeCandidates">IQVDocument.IQVAttributeCandidates</a>
    as AttributeKey for one of the <a href="#IQVAttributeCandidate.Features">IQVAttributeCandidate.Features</a>
    """

    KEY_project_id = str
    """
    project_id found in POST under
    <a href="#IQVDocument.IQVDocumentFeedbackResultsList">IQVDocument.IQVDocumentFeedbackResultsList</a>
    """

    KEY_ProtocolName = str
    """
    Protocol Name
    """

    KEY_ProtocolNumber = str
    """
    ProtocolNumber
    """

    KEY_ProtocolNumberElement = str
    """
    This ROI contains the value of ProtocolNumber
    This is the ROI that marks one element
     that indicates ProtocolNumber
    """

    KEY_ProtocolSponsorElement = str
    """
    This ROI contains the value of ProtocolSponsor
    This is the ROI that marks one element
     that indicates ProtocolSponsor
    """

    KEY_ProtocolTitle = str
    """
    ProtocolTitle
    i2e=title
    """

    KEY_ProtocolTitleElement = str
    """
    This ROI contains the value of ProtocolTitle
    This is the ROI that marks one element
     that indicates ProtocolTitle
    """

    KEY_ProtocolVersion = str
    """
    ProtocolVersion
    i2e=version
    """

    KEY_pt = str
    """
    pt from i2e
    From Linguamatics properties
    <a href="#NLP_Entity.Properties">NLP_Entity.Properties</a>
    """

    KEY_qcfeedback_runid = str
    """
    run id for qcfeedback run
    """

    KEY_redaction_any_address = str
    """
    redaction query
    redaction_any_address
    catch-all
    """

    KEY_redaction_any_email = str
    """
    redaction query
    redaction_any_email
    catch-all
    """

    KEY_redaction_any_organization = str
    """
    redaction query
    redaction_any_organization
    catch-all
    """

    KEY_redaction_any_telephone = str
    """
    redaction query
    redaction_any_telephone
    catch-all
    """

    KEY_redaction_category = str
    """
    Redaction category
    """

    KEY_redaction_investigator = str
    """
    redaction query
    redaction_investigator
    """

    KEY_redaction_molecule_name = str
    """
    redaction query
    redaction_molecule_name
    """

    KEY_redaction_other_person_role = str
    """
    redaction query
    redaction_other_person_role
    """

    KEY_redaction_primary_investigator = str
    """
    redaction query
    redaction_primary_investigator
    """

    KEY_redaction_profile_id = str
    """
    redaction profile
    """

    KEY_redaction_qualified_physician = str
    """
    redaction query
    redaction_qualified_physician
    """

    KEY_redaction_sponsor_address = str
    """
    redaction query
    redaction_sponsor_address
    """

    KEY_redaction_sponsor_monitor = str
    """
    redaction query
    redaction_sponsor_monitor
    """

    KEY_redaction_sponsor_name = str
    """
    redaction query
    redaction_sponsor_name
    """

    KEY_redaction_sponsor_signatory = str
    """
    redaction query
    redaction_sponsor_signatory
    """

    KEY_redaction_sponsors_medical_expert = str
    """
    redaction query
    redaction_sponsors_medical_expert
    """

    KEY_redaction_subcategory = str
    """
    Redaction subcategory
    """

    KEY_ReferencesHeader = str
    """
    For this section References, the value provided is the friendly display description (such as TOC text), text at top of this used to describe what section this is
    """

    KEY_ReferencesRefRoiId = str
    """
    For this section References, id of toc_element. (We do not need to store the id of current element--this is found in self.id)
    """

    KEY_roi_id = str
    """
    roi_id
    id of ROI which contains this entity
    <a href="#NLP_Entity.Properties">NLP_Entity.Properties</a>
    """

    KEY_roi_text = str
    """
    roi_text
    text of ROI which contains this entity
    <a href="#NLP_Entity.Properties">NLP_Entity.Properties</a>
    """

    KEY_secondary_objectives = str
    """
    secondary_objectives
    """

    KEY_SectionHeader = str
    """
    For this section Section, the value provided is the friendly display description (such as TOC text), text at top of this used to describe what section this is
    """

    KEY_SectionHeaderPrintPage = str
    """
    IsSectionElement is-a element for section Section
    This is the ROI that marks one element
     of the section Section.
    SectionHeaderROI is roi of the immediate header
     SectionHeaderPrintPage is expected print page of roi of the immediate header
    """

    KEY_SectionHeaderROI = str
    """
    Align paragraphs and blocks
    ParaROI is the roi id of the paragraph in <a href="#IQVDocument.DocumentParagraphs">IQVDocument.DocumentParagraphs</a>
    BlockROI is the roi id of the block in <a href="#IQVDocument.DocumentImages">IQVDocument.DocumentImages</a>
    HeaderText is the string of the immediate header
    SectionHeaderROI is the roi id of the immediate header
    BlockPrintPage is the page number (ones-based) of the block in <a href="#IQVDocument.DocumentImages">IQVDocument.DocumentImages</a>
    LinkROI is the roi of the link in <a href="#IQVDocument.DocumentLinks">IQVDocument.DocumentLinks</a>
    LinkLevel is the hierarchy level (ones-based, 1 for highest) of the link in <a href="#IQVDocument.DocumentLinks">IQVDocument.DocumentLinks</a>
    """

    KEY_SectionHeaderRoiId = str
    """
    For this section Section, the value provided is the friendly display description (such as TOC text), text at top of this used to describe what section this is
    """

    KEY_SectionRefRoiId = str
    """
    For this section Section, id of toc_element. (We do not need to store the id of current element--this is found in self.id)
    """

    KEY_short_title = str
    """
    short_title
    Short title should be sufficiently detailed
     to make clear to a lay reader what the study is about
     i2e=short_title
    """

    KEY_sid = str
    """
    sid from i2e
    From Linguamatics properties
    <a href="#NLP_Entity.Properties">NLP_Entity.Properties</a>
    """

    KEY_site = str
    """
    site found in POST under
    <a href="#IQVDocument.IQVDocumentFeedbackResultsList">IQVDocument.IQVDocumentFeedbackResultsList</a>
    """

    KEY_soa_days = str
    """
    soa_days
    i2e=soa_days
    """

    KEY_soa_epochs = str
    """
    soa_epochs
    i2e=soa_epochs
    """

    KEY_soa_footnotes = str
    """
    soa_footnotes
    i2e=soa_footnotes
    """

    KEY_soa_months = str
    """
    soa_months
    i2e=soa_months
    """

    KEY_soa_section_links = str
    """
    soa_section_links
    i2e=soa_section_links
    """

    KEY_soa_visit = str
    """
    soa_visit
    """

    KEY_soa_weeks = str
    """
    soa_weeks
    i2e=soa_weeks
    """

    KEY_soa_window = str
    """
    soa_window
    """

    KEY_soa_years = str
    """
    soa_years
    i2e=soa_years
    """

    KEY_SOAHeader = str
    """
    For this section SOA, the value provided is the friendly display description (such as TOC text), text at top of this used to describe what section this is
    """

    KEY_SOARefRoiId = str
    """
    For this section SOA, id of toc_element. (We do not need to store the id of current element--this is found in self.id)
    """

    KEY_SOATableFeatures = str
    """
    is-a Table for section SOA
    This is the ROI that marks one Table
     of the section SOA.
    Use the <a href="#IQVKeyValueSet.confidence">IQVKeyValueSet.confidence</a> to
    get the SOA Table Features for this table
    """

    KEY_span = str
    """
    span from i2e
    From Linguamatics properties
    <a href="#NLP_Entity.Properties">NLP_Entity.Properties</a>
    """

    KEY_sponsor = str
    """
    sponsor
    """

    KEY_sponsor_address = str
    """
    sponsor_address
    """

    KEY_standard_template_level = str
    """
    standard_template_level
    for header matched to standard template
    """

    KEY_standard_template_level_item = str
    """
    standard_template_level_item
    for element matched to standard template
    """

    KEY_standard_template_placeholder = str
    """
    standard_template_placeholder
    for header matched to standard template
    """

    KEY_standard_template_placeholder_item = str
    """
    standard_template_placeholder_item
    for element matched to standard template
    """

    KEY_standard_template_prefix = str
    """
    standard_template_prefix
    for header matched to standard template
    """

    KEY_standard_template_prefix_item = str
    """
    standard_template_prefix_item
    for element matched to standard template
    """

    KEY_standard_template_similarity_score = str
    """
    standard_template_similarity_score
    for header matched to standard template
    """

    KEY_standard_template_text = str
    """
    standard_template_text
    for header matched to standard template
    """

    KEY_StatisticalConsiderationsHeader = str
    """
    For this section StatisticalConsiderations, the value provided is the friendly display description (such as TOC text), text at top of this used to describe what section this is
    """

    KEY_StatisticalConsiderationsRefRoiId = str
    """
    For this section StatisticalConsiderations, id of toc_element. (We do not need to store the id of current element--this is found in self.id)
    """

    KEY_study_id = str
    """
    study_id
    """

    KEY_study_status = str
    """
    study_status found in POST under
    <a href="#IQVDocument.IQVDocumentFeedbackResultsList">IQVDocument.IQVDocumentFeedbackResultsList</a>
    """

    KEY_StudyAssessmentsandProceduresHeader = str
    """
    For this section StudyAssessmentsandProcedures, the value provided is the friendly display description (such as TOC text), text at top of this used to describe what section this is
    """

    KEY_StudyAssessmentsandProceduresRefRoiId = str
    """
    For this section StudyAssessmentsandProcedures, id of toc_element. (We do not need to store the id of current element--this is found in self.id)
    """

    KEY_StudyDesignHeader = str
    """
    For this section StudyDesign, the value provided is the friendly display description (such as TOC text), text at top of this used to describe what section this is
    """

    KEY_StudyDesignRefRoiId = str
    """
    For this section StudyDesign, id of toc_element. (We do not need to store the id of current element--this is found in self.id)
    """

    KEY_StudyInterventionsandConcomitantTherapyHeader = str
    """
    For this section StudyInterventionsandConcomitantTherapy, the value provided is the friendly display description (such as TOC text), text at top of this used to describe what section this is
    """

    KEY_StudyInterventionsandConcomitantTherapyRefRoiId = str
    """
    For this section StudyInterventionsandConcomitantTherapy, id of toc_element. (We do not need to store the id of current element--this is found in self.id)
    """

    KEY_StudyPopulationHeader = str
    """
    For this section StudyPopulation, the value provided is the friendly display description (such as TOC text), text at top of this used to describe what section this is
    """

    KEY_StudyPopulationRefRoiId = str
    """
    For this section StudyPopulation, id of toc_element. (We do not need to store the id of current element--this is found in self.id)
    """

    KEY_SummaryHeader = str
    """
    For this section Summary, the value provided is the friendly display description (such as TOC text), text at top of this used to describe what section this is
    """

    KEY_SummaryRefRoiId = str
    """
    For this section Summary, id of toc_element. (We do not need to store the id of current element--this is found in self.id)
    """

    KEY_SupportingDocumentationHeader = str
    """
    For this section SupportingDocumentation, the value provided is the friendly display description (such as TOC text), text at top of this used to describe what section this is
    """

    KEY_SupportingDocumentationRefRoiId = str
    """
    For this section SupportingDocumentation, id of toc_element. (We do not need to store the id of current element--this is found in self.id)
    """

    KEY_TableColumnIndex = str
    """
    Visit for section SOA
    This is the sequential index of the Visit column
    in the section SOA
    """

    KEY_TableROI = str
    """
    ROI id of the <a href="#IQVDocument.DocumentTables">IQVDocument.DocumentTables</a> table
    """

    KEY_TableRowIndex = str
    """
    Assessment for section SOA
    This is the sequential index of the Assessment
    in the section SOA
    """

    KEY_this = str
    """
    this from i2e
    From Linguamatics properties
    <a href="#NLP_Entity.Properties">NLP_Entity.Properties</a>
    """

    KEY_time_unit = str
    """
    time unit
    epoch
    sub-epoch
    year
    month
    week
    day
    visit
    window
    """

    KEY_time_unit_day = str
    """
    Aligns with Linguamatics i2e query processing as follows

    Time Unit | Coding Index | Color | Notes
    Epoch | 0 | #abf1ff |
    Sub-epoch | 1 | #ffb0b0 | cycle
    Year | 2 | #f8f87e |
    Month | 3 | #dab4ff |
    Week | 4 | #bbfc8f |
    Day | 5 | #a1c7ff |
    Visit | 6 | #ffd398 |
    Window | 7 | #66f9c2 |

    cycle = sub-epoch
    """

    KEY_time_unit_epoch = str
    """
    Aligns with Linguamatics i2e query processing as follows

    Time Unit | Coding Index | Color | Notes
    Epoch | 0 | #abf1ff |
    Sub-epoch | 1 | #ffb0b0 | cycle
    Year | 2 | #f8f87e |
    Month | 3 | #dab4ff |
    Week | 4 | #bbfc8f |
    Day | 5 | #a1c7ff |
    Visit | 6 | #ffd398 |
    Window | 7 | #66f9c2 |

    cycle = sub-epoch
    """

    KEY_time_unit_month = str
    """
    Aligns with Linguamatics i2e query processing as follows

    Time Unit | Coding Index | Color | Notes
    Epoch | 0 | #abf1ff |
    Sub-epoch | 1 | #ffb0b0 | cycle
    Year | 2 | #f8f87e |
    Month | 3 | #dab4ff |
    Week | 4 | #bbfc8f |
    Day | 5 | #a1c7ff |
    Visit | 6 | #ffd398 |
    Window | 7 | #66f9c2 |

    cycle = sub-epoch
    """

    KEY_time_unit_sub_epoch = str
    """
    Aligns with Linguamatics i2e query processing as follows

    Time Unit | Coding Index | Color | Notes
    Epoch | 0 | #abf1ff |
    Sub-epoch | 1 | #ffb0b0 | cycle
    Year | 2 | #f8f87e |
    Month | 3 | #dab4ff |
    Week | 4 | #bbfc8f |
    Day | 5 | #a1c7ff |
    Visit | 6 | #ffd398 |
    Window | 7 | #66f9c2 |

    cycle = sub-epoch
    """

    KEY_time_unit_visit = str
    """
    Aligns with Linguamatics i2e query processing as follows

    Time Unit | Coding Index | Color | Notes
    Epoch | 0 | #abf1ff |
    Sub-epoch | 1 | #ffb0b0 | cycle
    Year | 2 | #f8f87e |
    Month | 3 | #dab4ff |
    Week | 4 | #bbfc8f |
    Day | 5 | #a1c7ff |
    Visit | 6 | #ffd398 |
    Window | 7 | #66f9c2 |

    cycle = sub-epoch
    """

    KEY_time_unit_week = str
    """
    Aligns with Linguamatics i2e query processing as follows

    Time Unit | Coding Index | Color | Notes
    Epoch | 0 | #abf1ff |
    Sub-epoch | 1 | #ffb0b0 | cycle
    Year | 2 | #f8f87e |
    Month | 3 | #dab4ff |
    Week | 4 | #bbfc8f |
    Day | 5 | #a1c7ff |
    Visit | 6 | #ffd398 |
    Window | 7 | #66f9c2 |

    cycle = sub-epoch
    """

    KEY_time_unit_window = str
    """
    Aligns with Linguamatics i2e query processing as follows

    Time Unit | Coding Index | Color | Notes
    Epoch | 0 | #abf1ff |
    Sub-epoch | 1 | #ffb0b0 | cycle
    Year | 2 | #f8f87e |
    Month | 3 | #dab4ff |
    Week | 4 | #bbfc8f |
    Day | 5 | #a1c7ff |
    Visit | 6 | #ffd398 |
    Window | 7 | #66f9c2 |

    cycle = sub-epoch
    """

    KEY_time_unit_year = str
    """
    Aligns with Linguamatics i2e query processing as follows

    Time Unit | Coding Index | Color | Notes
    Epoch | 0 | #abf1ff |
    Sub-epoch | 1 | #ffb0b0 | cycle
    Year | 2 | #f8f87e |
    Month | 3 | #dab4ff |
    Week | 4 | #bbfc8f |
    Day | 5 | #a1c7ff |
    Visit | 6 | #ffd398 |
    Window | 7 | #66f9c2 |

    cycle = sub-epoch
    """

    KEY_time_value = str
    """
    value (in units of time unit)
    """

    KEY_TOAHeader = str
    """
    For this section TOA, the value provided is the friendly display description (such as TOC text), text at top of this used to describe what section this is
    """

    KEY_TOARefRoiId = str
    """
    For this section TOA, id of toc_element. (We do not need to store the id of current element--this is found in self.id)
    """

    KEY_TOCHeader = str
    """
    For this section TOC, the value provided is the friendly display description (such as TOC text), text at top of this used to describe what section this is
    """

    KEY_TOCRefRoiId = str
    """
    For this section TOC, id of toc_element. (We do not need to store the id of current element--this is found in self.id)
    """

    KEY_TOFHeader = str
    """
    For this section TOF, the value provided is the friendly display description (such as TOC text), text at top of this used to describe what section this is
    """

    KEY_TOFRefRoiId = str
    """
    For this section TOF, id of toc_element. (We do not need to store the id of current element--this is found in self.id)
    """

    KEY_TOTHeader = str
    """
    For this section TOT, the value provided is the friendly display description (such as TOC text), text at top of this used to describe what section this is
    """

    KEY_TOTRefRoiId = str
    """
    For this section TOT, id of toc_element. (We do not need to store the id of current element--this is found in self.id)
    """

    KEY_trial_type_randomized = str
    """
    trial_type_randomized
    """

    KEY_uploadDate = str
    """
    uploadDate
    """

    KEY_user_filename = str
    """
    user_filename found in POST under
    <a href="#IQVDocument.IQVDocumentFeedbackResultsList">IQVDocument.IQVDocumentFeedbackResultsList</a>
    such as final, draft
    """

    KEY_UserBusinessUnit = str
    """

    """

    KEY_version_date = str
    """
    version_date
    """

    KEY_Y = str
    """
    Y is the <a href="#IQVRectangle.Y">IQVRectangle.Y</a> spatial location
     on the page (such as <a href="#IQVDocumentLink.LinkPage">IQVDocumentLink.LinkPage</a>) and
      is used for sequential sorting

      Y is from the BlockROI

      BlockROI is the roi id of the block in <a href="#IQVDocument.DocumentImages">IQVDocument.DocumentImages</a>

     BlockPrintPage is the page number (ones-based) of the block in <a href="#IQVDocument.DocumentImages">IQVDocument.DocumentImages</a>
     LinkROI is the roi of the link in <a href="#IQVDocument.DocumentLinks">IQVDocument.DocumentLinks</a>
     LinkLevel is the hierarchy level (ones-based, 1 for highest) of the link in <a href="#IQVDocument.DocumentLinks">IQVDocument.DocumentLinks</a>
    """

    def __init__(self):
        self.KEY_AlternateContent = 'AlternateContent'
        self.KEY_amendment_number = 'amendment_number'
        self.KEY_approval_date = 'approval_date'
        self.KEY_arm = 'arm'
        self.KEY_blank_header = 'blank_header'
        self.KEY_blinding = 'blinding'
        self.KEY_BlockInsert = 'BlockInsert'
        self.KEY_BlockLineROIExactMatch = 'BlockLineROIExactMatch'
        self.KEY_BlockPrintPage = 'BlockPrintPage'
        self.KEY_BlockROI = 'BlockROI'
        self.KEY_BulletPrefix = 'BulletPrefix'
        self.KEY_color = 'color'
        self.KEY_COMPARE_base_text = 'local_text'
        self.KEY_COMPARE_char_roi_base_location = 'COMPARE_char_roi_base_location'
        self.KEY_COMPARE_char_roi_compare_location = 'COMPARE_char_roi_compare_location'
        self.KEY_COMPARE_char_section_location = 'COMPARE_char_section_location'
        self.KEY_COMPARE_compare_text = 'compare_text'
        self.KEY_compare_document_a = 'compare_document_a'
        self.KEY_compare_document_b = 'compare_document_b'
        self.KEY_COMPARE_summary_num_chars = 'COMPARE_summary_num_chars'
        self.KEY_COMPARE_summary_num_diffs = 'COMPARE_summary_num_diffs'
        self.KEY_compound = 'compound'
        self.KEY_ConjoinedSegments = 'ConjoinedSegments'
        self.KEY_control = 'control'
        self.KEY_CumulativeWordCount = 'CumulativeWordCount'
        self.KEY_CustomXML = 'CustomXML'
        self.KEY_decon_soa_max_x = 'decon_soa_page'
        self.KEY_decon_soa_page = 'decon_soa_page'
        self.KEY_design = 'design'
        self.KEY_DiscontinuationofStudyInterventionsandParticipantWithdrawalHeader = 'DiscontinuationofStudyInterventionsandParticipantWithdrawalHeader'
        self.KEY_DiscontinuationofStudyInterventionsandParticipantWithdrawalRefRoiId = 'DiscontinuationofStudyInterventionsandParticipantWithdrawalRefRoiId'
        self.KEY_document_keyword = 'keyword'
        self.KEY_document_status = 'document_status'
        self.KEY_document_topic = 'topic'
        self.KEY_document_version = 'document_version'
        self.KEY_DocumentPropertyKey = 'DocumentPropertyKey'
        self.KEY_drug = 'drug'
        self.KEY_dts = 'dts'
        self.KEY_endpoints = 'endpoints'
        self.KEY_EndpointsHeader = 'EndpointsHeader'
        self.KEY_EndpointsRefRoiId = 'EndpointsRefRoiId'
        self.KEY_entities_in_assessments = 'entities_in_assessments'
        self.KEY_entity_key = 'entity_key'
        self.KEY_environment = 'environment'
        self.KEY_exclusion_section = 'exclusion_section'
        self.KEY_ExclusionCriteriaHeader = 'ExclusionCriteriaHeader'
        self.KEY_ExclusionCriteriaRefRoiId = 'ExclusionCriteriaRefRoiId'
        self.KEY_font_bold = 'font_bold'
        self.KEY_font_size = 'font_size'
        self.KEY_font_style = 'font_style'
        self.KEY_Footnote_ = 'Footnote_'
        self.KEY_FootnoteID_ = 'FootnoteID_'
        self.KEY_FootnoteParaROI = 'FootnoteParaROI'
        self.KEY_FootnoteTableROI = 'FootnoteTableROI'
        self.KEY_FootnoteText_ = 'FootnoteText_'
        self.KEY_gridspan = 'gridspan'
        self.KEY_HeaderNumericSection = 'HeaderNumericSection'
        self.KEY_HeaderText = 'HeaderText'
        self.KEY_ilvl = 'ilvl'
        self.KEY_inclusion_section = 'inclusion_section'
        self.KEY_InclusionCriteriaHeader = 'InclusionCriteriaHeader'
        self.KEY_InclusionCriteriaRefRoiId = 'InclusionCriteriaRefRoiId'
        self.KEY_indication = 'indication'
        self.KEY_InsertRectifyText = 'InsertRectifyText'
        self.KEY_intervention_form = 'intervention_form'
        self.KEY_intervention_method = 'intervention_method'
        self.KEY_IntroductionHeader = 'IntroductionHeader'
        self.KEY_IntroductionRefRoiId = 'IntroductionRefRoiId'
        self.KEY_investigator = 'investigator'
        self.KEY_iqv_standard_term = 'iqv_standard_term'
        self.KEY_IsAmendment = 'is_amendment'
        self.KEY_IsAttachment = 'IsAttachment'
        self.KEY_IsColumnHeader = 'IsColumnHeader'
        self.KEY_IsDiscontinuationofStudyInterventionsandParticipantWithdrawalElement = 'IsDiscontinuationofStudyInterventionsandParticipantWithdrawalElement'
        self.KEY_IsDiscontinuationofStudyInterventionsandParticipantWithdrawalHeader = 'IsDiscontinuationofStudyInterventionsandParticipantWithdrawalHeader'
        self.KEY_IsEndpointsElement = 'IsEndpointsElement'
        self.KEY_IsEndpointsHeader = 'IsEndpointsHeader'
        self.KEY_IsEndpointTable = 'IsEndpointTable'
        self.KEY_IsExclusionCriteria = 'IsExclusionCriteria'
        self.KEY_IsExclusionCriteriaElement = 'IsExclusionCriteriaElement'
        self.KEY_IsExclusionCriteriaHeader = 'IsExclusionCriteriaHeader'
        self.KEY_IsFootnote = 'IsFootnote'
        self.KEY_IsFootnote_ = 'IsFootnote_'
        self.KEY_IsFootnoteText_ = 'IsFootnoteText_'
        self.KEY_IsInclusionCriteria = 'IsInclusionCriteria'
        self.KEY_IsInclusionCriteriaElement = 'IsInclusionCriteriaElement'
        self.KEY_IsInclusionCriteriaHeader = 'IsInclusionCriteriaHeader'
        self.KEY_IsIntroductionElement = 'IsIntroductionElement'
        self.KEY_IsIntroductionHeader = 'IsIntroductionHeader'
        self.KEY_IsObjectivesElement = 'IsObjectivesElement'
        self.KEY_IsObjectivesEndpointsElement = 'IsObjectivesEndpointsElement'
        self.KEY_IsObjectivesEndpointsHeader = 'IsObjectivesEndpointsHeader'
        self.KEY_IsObjectivesHeader = 'IsObjectivesHeader'
        self.KEY_IsReferencesElement = 'IsReferencesElement'
        self.KEY_IsReferencesHeader = 'IsReferencesHeader'
        self.KEY_IsRootElement = 'IsRootElement'
        self.KEY_IsSectionElement = 'IsSectionElement'
        self.KEY_IsSectionElementDiff = 'IsSectionElementDiff'
        self.KEY_IsSectionHeader = 'IsSectionHeader'
        self.KEY_IsSOAAssessment = 'IsSOAAssessment'
        self.KEY_IsSOAAssessmentPreferredTerm = 'IsSOAAssessmentPreferredTerm'
        self.KEY_IsSOAElement = 'IsSOAElement'
        self.KEY_IsSOAEpoch = 'IsSOAEpoch'
        self.KEY_IsSOAHeader = 'IsSOAHeader'
        self.KEY_IsSOALink = 'IsSOALink'
        self.KEY_IsSOATable = 'IsSOATable'
        self.KEY_IsSOATableColumn = 'IsSOATableColumn'
        self.KEY_IsStatisticalConsiderationsElement = 'IsStatisticalConsiderationsElement'
        self.KEY_IsStatisticalConsiderationsHeader = 'IsStatisticalConsiderationsHeader'
        self.KEY_IsStudyAssessmentsandProceduresElement = 'IsStudyAssessmentsandProceduresElement'
        self.KEY_IsStudyAssessmentsandProceduresHeader = 'IsStudyAssessmentsandProceduresHeader'
        self.KEY_IsStudyDesignElement = 'IsStudyDesignElement'
        self.KEY_IsStudyDesignHeader = 'IsStudyDesignHeader'
        self.KEY_IsStudyInterventionsandConcomitantTherapyElement = 'IsStudyInterventionsandConcomitantTherapyElement'
        self.KEY_IsStudyInterventionsandConcomitantTherapyHeader = 'IsStudyInterventionsandConcomitantTherapyHeader'
        self.KEY_IsStudyPopulationElement = 'IsStudyPopulationElement'
        self.KEY_IsStudyPopulationHeader = 'IsStudyPopulationHeader'
        self.KEY_IsSummaryElement = 'IsSummaryElement'
        self.KEY_IsSummaryHeader = 'IsSummaryHeader'
        self.KEY_IsSupportingDocumentationElement = 'IsSupportingDocumentationElement'
        self.KEY_IsSupportingDocumentationHeader = 'IsSupportingDocumentationHeader'
        self.KEY_IsTOAElement = 'IsTOAElement'
        self.KEY_IsTOAHeader = 'IsTOAHeader'
        self.KEY_IsTOCElement = 'IsTOCElement'
        self.KEY_IsTOCHeader = 'IsTOCHeader'
        self.KEY_IsTOCLink = 'IsTOCLink'
        self.KEY_IsTOFElement = 'IsTOFElement'
        self.KEY_IsTOFHeader = 'IsTOFHeader'
        self.KEY_IsTOTElement = 'IsTOTElement'
        self.KEY_IsTOTHeader = 'IsTOTHeader'
        self.KEY_ItemType = 'ItemType'
        self.KEY_ItemType_Endpoint = 'endpoint'
        self.KEY_ItemType_EndpointType = 'endpoint_type'
        self.KEY_ItemType_Objective = 'objective'
        self.KEY_ItemType_ObjectiveType = 'objective_type'
        self.KEY_LinkLevel = 'LinkLevel'
        self.KEY_LinkPage = 'LinkPage'
        self.KEY_LinkPageLHS = 'LinkPageLHS'
        self.KEY_LinkPageRHS = 'LinkPageRHS'
        self.KEY_LinkPrefix = 'LinkPrefix'
        self.KEY_LinkROI = 'LinkROI'
        self.KEY_LinkText = 'LinkText'
        self.KEY_ManualInsert = 'ManualInsert'
        self.KEY_masking = 'masking'
        self.KEY_molecule_device = 'molecule_device'
        self.KEY_next = 'next'
        self.KEY_nid = 'nid'
        self.KEY_NormalizedSOA_CSVFilename = 'NormalizedSOA_CSVFilename'
        self.KEY_NormalizedSOA_JSONFilename = 'NormalizedSOA_JSONFilename'
        self.KEY_num_entities = 'num_entities'
        self.KEY_number_of_subjects = 'number_of_subjects'
        self.KEY_numId = 'numId'
        self.KEY_ObjectiveRefRoiId = 'ObjectiveRefRoiId'
        self.KEY_objectives_section = 'objectives_section'
        self.KEY_ObjectivesEndpointsHeader = 'ObjectivesEndpointsHeader'
        self.KEY_ObjectivesEndpointsRefRoiId = 'ObjectivesEndpointsRefRoiId'
        self.KEY_ObjectivesHeader = 'ObjectivesHeader'
        self.KEY_ObjectivesRefRoiId = 'ObjectivesRefRoiId'
        self.KEY_observation = 'observation'
        self.KEY_ParaIndex = 'ParaIndex'
        self.KEY_ParaPrintPage = 'ParaPrintPage'
        self.KEY_ParaROI = 'ParaROI'
        self.KEY_ParaROIExactMatch = 'ParaROIExactMatch'
        self.KEY_participant_age = 'participant_age'
        self.KEY_participant_sex = 'participant_sex'
        self.KEY_PB_biopsy = 'biopsy'
        self.KEY_PB_blood_draw = 'blood_draw'
        self.KEY_PB_caregiver = 'caregiver'
        self.KEY_PB_colonoscopy = 'colonoscopy'
        self.KEY_PB_diary = 'diary'
        self.KEY_PB_discontinue_treatment = 'discontinue_treatment'
        self.KEY_PB_endoscopy = 'endoscopy'
        self.KEY_PB_freq_pro = 'freq_pro'
        self.KEY_PB_imaging_ct = 'imaging_ct'
        self.KEY_PB_imaging_dexa = 'imaging_dexa'
        self.KEY_PB_imaging_mammogram = 'imaging_mammogram'
        self.KEY_PB_imaging_mri = 'imaging_mri'
        self.KEY_PB_imaging_pet = 'imaging_pet'
        self.KEY_PB_imaging_xray = 'imaging_xray'
        self.KEY_PB_IncludesPRO = 'IncludesPRO'
        self.KEY_PB_injectable = 'injectable'
        self.KEY_PB_injection_gt1_visit = 'injection_gt1_visit'
        self.KEY_PB_inpatient = 'inpatient'
        self.KEY_PB_lumbar_puncture = 'lumbar_puncture'
        self.KEY_PB_median_visit_len = 'median_visit_len'
        self.KEY_PB_novel_drug = 'novel_drug'
        self.KEY_PB_num_visits_per_month = 'num_visits_per_month'
        self.KEY_PB_pb_total_score = 'pb_total_score'
        self.KEY_PB_percent_placebo = 'percent_placebo'
        self.KEY_PB_percent_visit_blood_gte1 = 'percent_visit_blood_gte1'
        self.KEY_PB_pro = 'pro'
        self.KEY_PB_total_num_months = 'total_num_months'
        self.KEY_PB_total_num_pro = 'total_num_pro'
        self.KEY_PB_total_num_site_visit = 'total_num_site_visit'
        self.KEY_phase = 'phase'
        self.KEY_PhysicalTableIndex = 'PhysicalTableIndex'
        self.KEY_population = 'population'
        self.KEY_PopulationCountElement = 'PopulationCountElement'
        self.KEY_priority = 'priority'
        self.KEY_prob = 'prob'
        self.KEY_ProcessDateTime = 'ProcessDateTime'
        self.KEY_ProcessMachineName = 'ProcessMachineName'
        self.KEY_ProcessName = 'ProcessName'
        self.KEY_ProcessVersion = 'ProcessVersion'
        self.KEY_project_id = 'project_id'
        self.KEY_ProtocolName = 'protocol_name'
        self.KEY_ProtocolNumber = 'ProtocolNumber'
        self.KEY_ProtocolNumberElement = 'ProtocolNumberElement'
        self.KEY_ProtocolSponsorElement = 'ProtocolSponsorElement'
        self.KEY_ProtocolTitle = 'ProtocolTitle'
        self.KEY_ProtocolTitleElement = 'ProtocolTitleElement'
        self.KEY_ProtocolVersion = 'ProtocolVersion'
        self.KEY_pt = 'pt'
        self.KEY_qcfeedback_runid = 'qcfeedback_runid'
        self.KEY_redaction_any_address = 'redaction_any_address'
        self.KEY_redaction_any_email = 'redaction_any_email'
        self.KEY_redaction_any_organization = 'redaction_any_organization'
        self.KEY_redaction_any_telephone = 'redaction_any_telephone'
        self.KEY_redaction_category = 'RedactionCategory'
        self.KEY_redaction_investigator = 'redaction_investigator'
        self.KEY_redaction_molecule_name = 'redaction_molecule_name'
        self.KEY_redaction_other_person_role = 'redaction_other_person_role'
        self.KEY_redaction_primary_investigator = 'redaction_primary_investigator'
        self.KEY_redaction_profile_id = 'redaction_profile_id'
        self.KEY_redaction_qualified_physician = 'redaction_primary_qualified_physician'
        self.KEY_redaction_sponsor_address = 'redaction_sponsor_address'
        self.KEY_redaction_sponsor_monitor = 'redaction_sponsor_monitor'
        self.KEY_redaction_sponsor_name = 'redaction_sponsor_name'
        self.KEY_redaction_sponsor_signatory = 'redaction_sponsor_signatory'
        self.KEY_redaction_sponsors_medical_expert = 'redaction_sponsors_medical_expert'
        self.KEY_redaction_subcategory = 'RedactionSubcategory'
        self.KEY_ReferencesHeader = 'ReferencesHeader'
        self.KEY_ReferencesRefRoiId = 'ReferencesRefRoiId'
        self.KEY_roi_id = 'roi_id'
        self.KEY_roi_text = 'roi_text'
        self.KEY_secondary_objectives = 'secondary_objectives'
        self.KEY_SectionHeader = 'SectionHeader'
        self.KEY_SectionHeaderPrintPage = 'SectionHeaderPrintPage'
        self.KEY_SectionHeaderROI = 'SectionHeaderROI'
        self.KEY_SectionHeaderRoiId = 'SectionHeaderRoiId'
        self.KEY_SectionRefRoiId = 'SectionRefRoiId'
        self.KEY_short_title = 'short_title'
        self.KEY_sid = 'sid'
        self.KEY_site = 'site'
        self.KEY_soa_days = 'soa_days'
        self.KEY_soa_epochs = 'soa_epochs'
        self.KEY_soa_footnotes = 'soa_footnotes'
        self.KEY_soa_months = 'soa_months'
        self.KEY_soa_section_links = 'soa_section_links'
        self.KEY_soa_visit = 'soa_visit'
        self.KEY_soa_weeks = 'soa_weeks'
        self.KEY_soa_window = 'soa_window'
        self.KEY_soa_years = 'soa_years'
        self.KEY_SOAHeader = 'SOAHeader'
        self.KEY_SOARefRoiId = 'SOARefRoiId'
        self.KEY_SOATableFeatures = 'SOATableFeatures'
        self.KEY_span = 'span'
        self.KEY_sponsor = 'sponsor'
        self.KEY_sponsor_address = 'sponsor_address'
        self.KEY_standard_template_level = 'standard_template_level'
        self.KEY_standard_template_level_item = 'standard_template_level_item'
        self.KEY_standard_template_placeholder = 'standard_template_placeholder'
        self.KEY_standard_template_placeholder_item = 'standard_template_placeholder_item'
        self.KEY_standard_template_prefix = 'standard_template_prefix'
        self.KEY_standard_template_prefix_item = 'standard_template_prefix_item'
        self.KEY_standard_template_similarity_score = 'standard_template_similarity_score'
        self.KEY_standard_template_text = 'standard_template_text'
        self.KEY_StatisticalConsiderationsHeader = 'StatisticalConsiderationsHeader'
        self.KEY_StatisticalConsiderationsRefRoiId = 'StatisticalConsiderationsRefRoiId'
        self.KEY_study_id = 'study_id'
        self.KEY_study_status = 'study_status'
        self.KEY_StudyAssessmentsandProceduresHeader = 'StudyAssessmentsandProceduresHeader'
        self.KEY_StudyAssessmentsandProceduresRefRoiId = 'StudyAssessmentsandProceduresRefRoiId'
        self.KEY_StudyDesignHeader = 'StudyDesignHeader'
        self.KEY_StudyDesignRefRoiId = 'StudyDesignRefRoiId'
        self.KEY_StudyInterventionsandConcomitantTherapyHeader = 'StudyInterventionsandConcomitantTherapyHeader'
        self.KEY_StudyInterventionsandConcomitantTherapyRefRoiId = 'StudyInterventionsandConcomitantTherapyRefRoiId'
        self.KEY_StudyPopulationHeader = 'StudyPopulationHeader'
        self.KEY_StudyPopulationRefRoiId = 'StudyPopulationRefRoiId'
        self.KEY_SummaryHeader = 'SummaryHeader'
        self.KEY_SummaryRefRoiId = 'SummaryRefRoiId'
        self.KEY_SupportingDocumentationHeader = 'SupportingDocumentationHeader'
        self.KEY_SupportingDocumentationRefRoiId = 'SupportingDocumentationRefRoiId'
        self.KEY_TableColumnIndex = 'TableColumnIndex'
        self.KEY_TableROI = 'TableROI'
        self.KEY_TableRowIndex = 'TableRowIndex'
        self.KEY_this = 'this'
        self.KEY_time_unit = 'time_unit'
        self.KEY_time_unit_day = 'Day'
        self.KEY_time_unit_epoch = 'Epoch'
        self.KEY_time_unit_month = 'Month'
        self.KEY_time_unit_sub_epoch = 'Sub-epoch'
        self.KEY_time_unit_visit = 'Visit'
        self.KEY_time_unit_week = 'Week'
        self.KEY_time_unit_window = 'Window'
        self.KEY_time_unit_year = 'Year'
        self.KEY_time_value = 'time_value'
        self.KEY_TOAHeader = 'TOAHeader'
        self.KEY_TOARefRoiId = 'TOARefRoiId'
        self.KEY_TOCHeader = 'TOCHeader'
        self.KEY_TOCRefRoiId = 'TOCRefRoiId'
        self.KEY_TOFHeader = 'TOFHeader'
        self.KEY_TOFRefRoiId = 'TOFRefRoiId'
        self.KEY_TOTHeader = 'TOTHeader'
        self.KEY_TOTRefRoiId = 'TOTRefRoiId'
        self.KEY_trial_type_randomized = 'trial_type_randomized'
        self.KEY_uploadDate = 'uploadDate'
        self.KEY_user_filename = 'user_filename'
        self.KEY_UserBusinessUnit = 'UserBusinessUnit'
        self.KEY_version_date = 'version_date'
        self.KEY_Y = 'Y'


class NLP_Entity(object):
    """
    list of entities found for a <a href="#IQVPageROI">IQVPageROI</a>
    or <a href="#IQVSubText">IQVSubText</a>
    For OMOP XML--based on https://www.ohdsi.org/data-standardization/the-common-data-model/
    Observational Medical Outcomes Partnership
    """

    confidence = float
    """
    Probability score of correctness of this label
    """

    doc_id = str
    """
    Element index
    Which document is this element in?
    Top-level id for <a href="#IQVDocument">IQVDocument</a>
    """

    dts = str
    """
    datetimestamp (YYYYMMDDHHMMSS UTC) of Process that indicated this entity
    """

    entity_class = str
    """
    condition, drug, procedure, etc.
    """

    entity_index = str
    """
    index within segment
    """

    entity_key = str
    """
    If this pt is a key-value pair or Q/A, use this key
    For instance,
     <a href="#NLP_Entity.entity_key">NLP_Entity.entity_key</a> = blinding
    <a href="#NLP_Entity.standard_entity_name">NLP_Entity.standard_entity_name</a> = OPEN LABEL
    """

    group_type = str
    """
    Element index
    Which item is this element a member of? (name of member = group_type)
    For example, for <a href="#IQVPageROI.Properties">IQVPageROI.Properties</a>, group_type = "Properties"
    Possible parents include but are not limited to
    <a href="#IQVDocument">IQVDocument</a><a href="#IQVPageROI">IQVPageROI</a><a href="#IQVDocumentLink">IQVDocumentLink</a>
    SQL code example 1 for usage of index
    <code>
    WHERE parent_id=parent_id AND group_type=group_type
    </code>
    """

    hierarchy = str
    """
    image,table,paragraph,item,header,footer,roi
    """

    id = str
    """
    unique id for this entity
    """

    iqv_standard_term = str
    """
    Element index
    If this element is a link or header, what is the standard term?
    There is 0 or 1 iqv_standard_term for each element
    """

    link_id = str
    """
    Element index
    Which [link <a href="#IQVDocumentLink">IQVDocumentLink</a>] section is this element in?
    The id for <a href="#IQVDocumentLink.LinkType">IQVDocumentLink.LinkType</a> == "toc"
    and <a href="#IQVDocumentLink.LinkLevel">IQVDocumentLink.LinkLevel</a> == 1
    """

    link_id_level2 = str
    """
    Element index
    Which [link <a href="#IQVDocumentLink">IQVDocumentLink</a>] section is this element in?
    The id for <a href="#IQVDocumentLink.LinkType">IQVDocumentLink.LinkType</a> == "toc"
    and <a href="#IQVDocumentLink.LinkLevel">IQVDocumentLink.LinkLevel</a> == 2
    """

    link_id_level3 = str
    """
    Element index
    Which [link <a href="#IQVDocumentLink">IQVDocumentLink</a>] section is this element in?
    The id for <a href="#IQVDocumentLink.LinkType">IQVDocumentLink.LinkType</a> == "toc"
    and <a href="#IQVDocumentLink.LinkLevel">IQVDocumentLink.LinkLevel</a> == 3
    """

    link_id_level4 = str
    """
    Element index
    Which [link <a href="#IQVDocumentLink">IQVDocumentLink</a>] section is this element in?
    The id for <a href="#IQVDocumentLink.LinkType">IQVDocumentLink.LinkType</a> == "toc"
    and <a href="#IQVDocumentLink.LinkLevel">IQVDocumentLink.LinkLevel</a> == 4
    """

    link_id_level5 = str
    """
    Element index
    Which [link <a href="#IQVDocumentLink">IQVDocumentLink</a>] section is this element in?
    The id for <a href="#IQVDocumentLink.LinkType">IQVDocumentLink.LinkType</a> == "toc"
    and <a href="#IQVDocumentLink.LinkLevel">IQVDocumentLink.LinkLevel</a> == 5
    """

    link_id_level6 = str
    """
    Element index
    Which [link <a href="#IQVDocumentLink">IQVDocumentLink</a>] section is this element in?
    The id for <a href="#IQVDocumentLink.LinkType">IQVDocumentLink.LinkType</a> == "toc"
    and <a href="#IQVDocumentLink.LinkLevel">IQVDocumentLink.LinkLevel</a> == 6
    """

    link_id_subsection1 = str
    """
    Element index
    Which [link <a href="#IQVDocumentLink">IQVDocumentLink</a>] section is this element in?
    The id for <a href="#IQVDocumentLink.LinkType">IQVDocumentLink.LinkType</a> == "subsection1"
    """

    link_id_subsection2 = str
    """
    Element index
    Which [link <a href="#IQVDocumentLink">IQVDocumentLink</a>] section is this element in?
    The id for <a href="#IQVDocumentLink.LinkType">IQVDocumentLink.LinkType</a> == "subsection2"
    """

    link_id_subsection3 = str
    """
    Element index
    Which [link <a href="#IQVDocumentLink">IQVDocumentLink</a>] section is this element in?
    The id for <a href="#IQVDocumentLink.LinkType">IQVDocumentLink.LinkType</a> == "subsection3"
    """

    negated = str
    """
    Default is blank; N=no, Y=yes
    """

    ontology = str
    """
    Ontology such as
     MedDRA, MMI, etc.
    """

    ontology_item_code = str
    """
    Unique item code within the <a href="#NLP_Entity.ontology">NLP_Entity.ontology</a>
    """

    ontology_version = str
    """
    Version of <a href="#NLP_Entity.ontology">NLP_Entity.ontology</a>
    """

    parent_id = str
    """
    Element index
    Which item is this element a member of?
    For example, for <a href="#IQVPageROI.Properties">IQVPageROI.Properties</a>, parent_id = <a href="#IQVPageROI.id">IQVPageROI.id</a>
    Possible parents include but are not limited to
    <a href="#IQVDocument">IQVDocument</a><a href="#IQVPageROI">IQVPageROI</a><a href="#IQVDocumentLink">IQVDocumentLink</a>
    SQL code example 1 for usage of index
    <code>
    WHERE parent_id=parent_id AND group_type=group_type
    </code>
    SQL code example 2 for usage of index
    <code>
    WHERE parent_id=parent_id
    </code>
    """

    process_source = str
    """
    Process that indicated this entity
    """

    Properties = []
    """
    Properties for this NLP_Entity as <a href="#IQVKeyValueSet">IQVKeyValueSet</a><a href="#IQVKeyValueSet.key">IQVKeyValueSet.key</a> See standardized key listing
    <a href="#IQVKeyValueSet.value">IQVKeyValueSet.value</a> See standardized key listing
    <a href="#IQVKeyValueSet.confidence">IQVKeyValueSet.confidence</a> is 0 to 1 confidence value
    """

    standard_entity_name = str
    """
    based on <a href="#NLP_Entity.ontology">NLP_Entity.ontology</a>
    pt (preferred term)
    """

    start = int
    """
    Zero-based start index within the segment.
      -1=not set
    """

    text = str
    """
    entire string that makes up this entity
    """

    text_len = int
    """
    length of inner text
    0=default
    """

    user_id = str
    """
    user id of Process that indicated this entity
    """

    def __init__(self):
        self.confidence = 0.0
        self.doc_id = ''
        self.dts = ''
        self.entity_class = ''
        self.entity_index = ''
        self.entity_key = ''
        self.group_type = ''
        self.hierarchy = ''
        self.id = ''
        self.iqv_standard_term = ''
        self.link_id = ''
        self.link_id_level2 = ''
        self.link_id_level3 = ''
        self.link_id_level4 = ''
        self.link_id_level5 = ''
        self.link_id_level6 = ''
        self.link_id_subsection1 = ''
        self.link_id_subsection2 = ''
        self.link_id_subsection3 = ''
        self.negated = ''
        self.ontology = ''
        self.ontology_item_code = ''
        self.ontology_version = ''
        self.parent_id = ''
        self.process_source = ''
        self.Properties = []
        self.standard_entity_name = ''
        self.start = -1
        self.text = ''
        self.text_len = -1
        self.user_id = ''
        self.id = str(uuid.uuid1())


class IQVConceptTerm(object):
    """
    Common Concept
    """

    cui = str
    """
    concept unique ID per the ontology
    """

    entity_class = str
    """
    keyword, timeline, reference, etc.
    """

    entity_text = str
    """
    commonly displayed text of the entity (e.g., "pulse rate")
    """

    entity_xref = str
    """
    list of synonyms
    """

    id = str
    """
    Unique index in IQV concepts list
    """

    info = str
    """
    any definitions/additional information per ontology
    """

    ontology = str
    """
    short/abbreviated name of ontology (e.g., NCI)
    """

    preferred_term = str
    """
    preferred term per ontology
    """

    def __init__(self):
        self.cui = ''
        self.entity_class = ''
        self.entity_text = ''
        self.entity_xref = ''
        self.id = ''
        self.info = ''
        self.ontology = ''
        self.preferred_term = ''
        self.id = str(uuid.uuid1())


class IQVConceptRelation(object):
    """
    Relation between 2 concepts
    """

    context_unit = str
    """
    in which context this relation is relevant
    """

    dts = str
    """
    date time stamp of creation
    """

    id = str
    """
    Unique index in IQV concept relations list
    """

    id1 = str
    """
    id of concept 1 from <a href="#IQVConceptTerm.id">IQVConceptTerm.id</a>
    """

    id2 = str
    """
    id of concept 2 from <a href="#IQVConceptTerm.id">IQVConceptTerm.id</a>
    """

    relation_type = str
    """
    hierarchy (parent-child relation, where id1 is parent, id2 is child)
    synonym
    other
    """

    user_id = str
    """
    user_id when created
    """

    weight = float
    """
    Weight of strength of relation
    from 0 to 1
    0 is weak, 1 is strong
    """

    def __init__(self):
        self.context_unit = ''
        self.dts = ''
        self.id = ''
        self.id1 = ''
        self.id2 = ''
        self.relation_type = ''
        self.user_id = ''
        self.weight = 0.0
        self.id = str(uuid.uuid1())


class NLP_Attribute(object):
    """
    For OMOP XML--based on https://www.ohdsi.org/data-standardization/the-common-data-model/
    Observational Medical Outcomes Partnership
    """

    attribute_class = str
    """
    measurements, modifier, qualifier, etc
    """

    attribute_index = str
    """
    index within segment
    """

    doc_id = str
    """
    Element index
    Which document is this element in?
    Top-level id for <a href="#IQVDocument">IQVDocument</a>
    """

    group_type = str
    """
    Element index
    Which item is this element a member of? (name of member = group_type)
    For example, for <a href="#IQVPageROI.Properties">IQVPageROI.Properties</a>, group_type = "Properties"
    Possible parents include but are not limited to
    <a href="#IQVDocument">IQVDocument</a><a href="#IQVPageROI">IQVPageROI</a><a href="#IQVDocumentLink">IQVDocumentLink</a>
    SQL code example 1 for usage of index
    <code>
    WHERE parent_id=parent_id AND group_type=group_type
    </code>
    """

    hierarchy = str
    """
    image,table,paragraph,item,header,footer,roi
    """

    id = str
    """
    unique id for this entity
    """

    iqv_standard_term = str
    """
    Element index
    If this element is a link or header, what is the standard term?
    There is 0 or 1 iqv_standard_term for each element
    """

    link_id = str
    """
    Element index
    Which [link <a href="#IQVDocumentLink">IQVDocumentLink</a>] section is this element in?
    The id for <a href="#IQVDocumentLink.LinkType">IQVDocumentLink.LinkType</a> == "toc"
    and <a href="#IQVDocumentLink.LinkLevel">IQVDocumentLink.LinkLevel</a> == 1
    """

    link_id_level2 = str
    """
    Element index
    Which [link <a href="#IQVDocumentLink">IQVDocumentLink</a>] section is this element in?
    The id for <a href="#IQVDocumentLink.LinkType">IQVDocumentLink.LinkType</a> == "toc"
    and <a href="#IQVDocumentLink.LinkLevel">IQVDocumentLink.LinkLevel</a> == 2
    """

    link_id_level3 = str
    """
    Element index
    Which [link <a href="#IQVDocumentLink">IQVDocumentLink</a>] section is this element in?
    The id for <a href="#IQVDocumentLink.LinkType">IQVDocumentLink.LinkType</a> == "toc"
    and <a href="#IQVDocumentLink.LinkLevel">IQVDocumentLink.LinkLevel</a> == 3
    """

    link_id_level4 = str
    """
    Element index
    Which [link <a href="#IQVDocumentLink">IQVDocumentLink</a>] section is this element in?
    The id for <a href="#IQVDocumentLink.LinkType">IQVDocumentLink.LinkType</a> == "toc"
    and <a href="#IQVDocumentLink.LinkLevel">IQVDocumentLink.LinkLevel</a> == 4
    """

    link_id_level5 = str
    """
    Element index
    Which [link <a href="#IQVDocumentLink">IQVDocumentLink</a>] section is this element in?
    The id for <a href="#IQVDocumentLink.LinkType">IQVDocumentLink.LinkType</a> == "toc"
    and <a href="#IQVDocumentLink.LinkLevel">IQVDocumentLink.LinkLevel</a> == 5
    """

    link_id_level6 = str
    """
    Element index
    Which [link <a href="#IQVDocumentLink">IQVDocumentLink</a>] section is this element in?
    The id for <a href="#IQVDocumentLink.LinkType">IQVDocumentLink.LinkType</a> == "toc"
    and <a href="#IQVDocumentLink.LinkLevel">IQVDocumentLink.LinkLevel</a> == 6
    """

    link_id_subsection1 = str
    """
    Element index
    Which [link <a href="#IQVDocumentLink">IQVDocumentLink</a>] section is this element in?
    The id for <a href="#IQVDocumentLink.LinkType">IQVDocumentLink.LinkType</a> == "subsection1"
    """

    link_id_subsection2 = str
    """
    Element index
    Which [link <a href="#IQVDocumentLink">IQVDocumentLink</a>] section is this element in?
    The id for <a href="#IQVDocumentLink.LinkType">IQVDocumentLink.LinkType</a> == "subsection2"
    """

    link_id_subsection3 = str
    """
    Element index
    Which [link <a href="#IQVDocumentLink">IQVDocumentLink</a>] section is this element in?
    The id for <a href="#IQVDocumentLink.LinkType">IQVDocumentLink.LinkType</a> == "subsection3"
    """

    parent_id = str
    """
    Element index
    Which item is this element a member of?
    For example, for <a href="#IQVPageROI.Properties">IQVPageROI.Properties</a>, parent_id = <a href="#IQVPageROI.id">IQVPageROI.id</a>
    Possible parents include but are not limited to
    <a href="#IQVDocument">IQVDocument</a><a href="#IQVPageROI">IQVPageROI</a><a href="#IQVDocumentLink">IQVDocumentLink</a>
    SQL code example 1 for usage of index
    <code>
    WHERE parent_id=parent_id AND group_type=group_type
    </code>
    SQL code example 2 for usage of index
    <code>
    WHERE parent_id=parent_id
    </code>
    """

    process_source = str
    """
    Process that indicated this entity
    """

    start = int
    """
    Zero-based start index within the segment.
      -1=not set
    """

    text = str
    """
    entire string that makes up this attribute
    """

    def __init__(self):
        self.attribute_class = ''
        self.attribute_index = ''
        self.doc_id = ''
        self.group_type = ''
        self.hierarchy = ''
        self.id = ''
        self.iqv_standard_term = ''
        self.link_id = ''
        self.link_id_level2 = ''
        self.link_id_level3 = ''
        self.link_id_level4 = ''
        self.link_id_level5 = ''
        self.link_id_level6 = ''
        self.link_id_subsection1 = ''
        self.link_id_subsection2 = ''
        self.link_id_subsection3 = ''
        self.parent_id = ''
        self.process_source = ''
        self.start = -1
        self.text = ''
        self.id = str(uuid.uuid1())


class NLP_Relation(object):
    """
    For OMOP XML--based on https://www.ohdsi.org/data-standardization/the-common-data-model/
    Observational Medical Outcomes Partnership
    """

    confidence = float
    """
    Probability score of correctness of this label
    """

    doc_id = str
    """
    Element index
    Which document is this element in?
    Top-level id for <a href="#IQVDocument">IQVDocument</a>
    """

    entities = []
    """
    entity list (list of entity id's)
    """

    entities_list = str
    """

    """

    group_type = str
    """
    Element index
    Which item is this element a member of? (name of member = group_type)
    For example, for <a href="#IQVPageROI.Properties">IQVPageROI.Properties</a>, group_type = "Properties"
    Possible parents include but are not limited to
    <a href="#IQVDocument">IQVDocument</a><a href="#IQVPageROI">IQVPageROI</a><a href="#IQVDocumentLink">IQVDocumentLink</a>
    SQL code example 1 for usage of index
    <code>
    WHERE parent_id=parent_id AND group_type=group_type
    </code>
    """

    hierarchy = str
    """
    image,table,paragraph,item,header,footer,roi
    """

    id = str
    """
    unique id for this entity
    """

    iqv_standard_term = str
    """
    Element index
    If this element is a link or header, what is the standard term?
    There is 0 or 1 iqv_standard_term for each element
    """

    is_bidirectional = int
    """
    0=no (default), 1=yes
    """

    is_hierarchical = int
    """
    0=no (default), 1=yes
    """

    link_id = str
    """
    Element index
    Which [link <a href="#IQVDocumentLink">IQVDocumentLink</a>] section is this element in?
    The id for <a href="#IQVDocumentLink.LinkType">IQVDocumentLink.LinkType</a> == "toc"
    and <a href="#IQVDocumentLink.LinkLevel">IQVDocumentLink.LinkLevel</a> == 1
    """

    link_id_level2 = str
    """
    Element index
    Which [link <a href="#IQVDocumentLink">IQVDocumentLink</a>] section is this element in?
    The id for <a href="#IQVDocumentLink.LinkType">IQVDocumentLink.LinkType</a> == "toc"
    and <a href="#IQVDocumentLink.LinkLevel">IQVDocumentLink.LinkLevel</a> == 2
    """

    link_id_level3 = str
    """
    Element index
    Which [link <a href="#IQVDocumentLink">IQVDocumentLink</a>] section is this element in?
    The id for <a href="#IQVDocumentLink.LinkType">IQVDocumentLink.LinkType</a> == "toc"
    and <a href="#IQVDocumentLink.LinkLevel">IQVDocumentLink.LinkLevel</a> == 3
    """

    link_id_level4 = str
    """
    Element index
    Which [link <a href="#IQVDocumentLink">IQVDocumentLink</a>] section is this element in?
    The id for <a href="#IQVDocumentLink.LinkType">IQVDocumentLink.LinkType</a> == "toc"
    and <a href="#IQVDocumentLink.LinkLevel">IQVDocumentLink.LinkLevel</a> == 4
    """

    link_id_level5 = str
    """
    Element index
    Which [link <a href="#IQVDocumentLink">IQVDocumentLink</a>] section is this element in?
    The id for <a href="#IQVDocumentLink.LinkType">IQVDocumentLink.LinkType</a> == "toc"
    and <a href="#IQVDocumentLink.LinkLevel">IQVDocumentLink.LinkLevel</a> == 5
    """

    link_id_level6 = str
    """
    Element index
    Which [link <a href="#IQVDocumentLink">IQVDocumentLink</a>] section is this element in?
    The id for <a href="#IQVDocumentLink.LinkType">IQVDocumentLink.LinkType</a> == "toc"
    and <a href="#IQVDocumentLink.LinkLevel">IQVDocumentLink.LinkLevel</a> == 6
    """

    link_id_subsection1 = str
    """
    Element index
    Which [link <a href="#IQVDocumentLink">IQVDocumentLink</a>] section is this element in?
    The id for <a href="#IQVDocumentLink.LinkType">IQVDocumentLink.LinkType</a> == "subsection1"
    """

    link_id_subsection2 = str
    """
    Element index
    Which [link <a href="#IQVDocumentLink">IQVDocumentLink</a>] section is this element in?
    The id for <a href="#IQVDocumentLink.LinkType">IQVDocumentLink.LinkType</a> == "subsection2"
    """

    link_id_subsection3 = str
    """
    Element index
    Which [link <a href="#IQVDocumentLink">IQVDocumentLink</a>] section is this element in?
    The id for <a href="#IQVDocumentLink.LinkType">IQVDocumentLink.LinkType</a> == "subsection3"
    """

    parent_id = str
    """
    Element index
    Which item is this element a member of?
    For example, for <a href="#IQVPageROI.Properties">IQVPageROI.Properties</a>, parent_id = <a href="#IQVPageROI.id">IQVPageROI.id</a>
    Possible parents include but are not limited to
    <a href="#IQVDocument">IQVDocument</a><a href="#IQVPageROI">IQVPageROI</a><a href="#IQVDocumentLink">IQVDocumentLink</a>
    SQL code example 1 for usage of index
    <code>
    WHERE parent_id=parent_id AND group_type=group_type
    </code>
    SQL code example 2 for usage of index
    <code>
    WHERE parent_id=parent_id
    </code>
    """

    process_source = str
    """
    Process that indicated this entity
    """

    relation_name = str
    """
    type of relation
    """

    relation_type = str
    """
    type of relation
    """

    def __init__(self):
        self.confidence = 0.0
        self.doc_id = ''
        self.entities = []
        self.entities_list = ''
        self.group_type = ''
        self.hierarchy = ''
        self.id = ''
        self.iqv_standard_term = ''
        self.is_bidirectional = -1
        self.is_hierarchical = -1
        self.link_id = ''
        self.link_id_level2 = ''
        self.link_id_level3 = ''
        self.link_id_level4 = ''
        self.link_id_level5 = ''
        self.link_id_level6 = ''
        self.link_id_subsection1 = ''
        self.link_id_subsection2 = ''
        self.link_id_subsection3 = ''
        self.parent_id = ''
        self.process_source = ''
        self.relation_name = ''
        self.relation_type = ''
        self.id = str(uuid.uuid1())


class NLP_Segment(object):
    """
    Extracted from <a href="#IQVPageROI">IQVPageROI</a>
    For OMOP XML--based on https://www.ohdsi.org/data-standardization/the-common-data-model/
    Observational Medical Outcomes Partnership
    """

    attributes = []
    """
    List of entities as <a href="#NLP_Attribute">NLP_Attribute</a>
    """

    doc_id = str
    """
    Element index
    Which document is this element in?
    Top-level id for <a href="#IQVDocument">IQVDocument</a>
    """

    entities = []
    """
    List of entities as <a href="#NLP_Entity">NLP_Entity</a>
    """

    group_type = str
    """
    Element index
    Which item is this element a member of? (name of member = group_type)
    For example, for <a href="#IQVPageROI.Properties">IQVPageROI.Properties</a>, group_type = "Properties"
    Possible parents include but are not limited to
    <a href="#IQVDocument">IQVDocument</a><a href="#IQVPageROI">IQVPageROI</a><a href="#IQVDocumentLink">IQVDocumentLink</a>
    SQL code example 1 for usage of index
    <code>
    WHERE parent_id=parent_id AND group_type=group_type
    </code>
    """

    hierarchy = str
    """
    image,table,paragraph,item,header,footer,roi
    """

    id = str
    """
    unique id for this NLP_Segment
    """

    iqv_standard_term = str
    """
    Element index
    If this element is a link or header, what is the standard term?
    There is 0 or 1 iqv_standard_term for each element
    """

    link_id = str
    """
    Element index
    Which [link <a href="#IQVDocumentLink">IQVDocumentLink</a>] section is this element in?
    The id for <a href="#IQVDocumentLink.LinkType">IQVDocumentLink.LinkType</a> == "toc"
    and <a href="#IQVDocumentLink.LinkLevel">IQVDocumentLink.LinkLevel</a> == 1
    """

    link_id_level2 = str
    """
    Element index
    Which [link <a href="#IQVDocumentLink">IQVDocumentLink</a>] section is this element in?
    The id for <a href="#IQVDocumentLink.LinkType">IQVDocumentLink.LinkType</a> == "toc"
    and <a href="#IQVDocumentLink.LinkLevel">IQVDocumentLink.LinkLevel</a> == 2
    """

    link_id_level3 = str
    """
    Element index
    Which [link <a href="#IQVDocumentLink">IQVDocumentLink</a>] section is this element in?
    The id for <a href="#IQVDocumentLink.LinkType">IQVDocumentLink.LinkType</a> == "toc"
    and <a href="#IQVDocumentLink.LinkLevel">IQVDocumentLink.LinkLevel</a> == 3
    """

    link_id_level4 = str
    """
    Element index
    Which [link <a href="#IQVDocumentLink">IQVDocumentLink</a>] section is this element in?
    The id for <a href="#IQVDocumentLink.LinkType">IQVDocumentLink.LinkType</a> == "toc"
    and <a href="#IQVDocumentLink.LinkLevel">IQVDocumentLink.LinkLevel</a> == 4
    """

    link_id_level5 = str
    """
    Element index
    Which [link <a href="#IQVDocumentLink">IQVDocumentLink</a>] section is this element in?
    The id for <a href="#IQVDocumentLink.LinkType">IQVDocumentLink.LinkType</a> == "toc"
    and <a href="#IQVDocumentLink.LinkLevel">IQVDocumentLink.LinkLevel</a> == 5
    """

    link_id_level6 = str
    """
    Element index
    Which [link <a href="#IQVDocumentLink">IQVDocumentLink</a>] section is this element in?
    The id for <a href="#IQVDocumentLink.LinkType">IQVDocumentLink.LinkType</a> == "toc"
    and <a href="#IQVDocumentLink.LinkLevel">IQVDocumentLink.LinkLevel</a> == 6
    """

    link_id_subsection1 = str
    """
    Element index
    Which [link <a href="#IQVDocumentLink">IQVDocumentLink</a>] section is this element in?
    The id for <a href="#IQVDocumentLink.LinkType">IQVDocumentLink.LinkType</a> == "subsection1"
    """

    link_id_subsection2 = str
    """
    Element index
    Which [link <a href="#IQVDocumentLink">IQVDocumentLink</a>] section is this element in?
    The id for <a href="#IQVDocumentLink.LinkType">IQVDocumentLink.LinkType</a> == "subsection2"
    """

    link_id_subsection3 = str
    """
    Element index
    Which [link <a href="#IQVDocumentLink">IQVDocumentLink</a>] section is this element in?
    The id for <a href="#IQVDocumentLink.LinkType">IQVDocumentLink.LinkType</a> == "subsection3"
    """

    parent_id = str
    """
    Element index
    Which item is this element a member of?
    For example, for <a href="#IQVPageROI.Properties">IQVPageROI.Properties</a>, parent_id = <a href="#IQVPageROI.id">IQVPageROI.id</a>
    Possible parents include but are not limited to
    <a href="#IQVDocument">IQVDocument</a><a href="#IQVPageROI">IQVPageROI</a><a href="#IQVDocumentLink">IQVDocumentLink</a>
    SQL code example 1 for usage of index
    <code>
    WHERE parent_id=parent_id AND group_type=group_type
    </code>
    SQL code example 2 for usage of index
    <code>
    WHERE parent_id=parent_id
    </code>
    """

    primary_section = str
    """
    primary section of the document in which text is located
    """

    Properties = []
    """
    Properties for this NLP_Entity as <a href="#IQVKeyValueSet">IQVKeyValueSet</a><a href="#IQVKeyValueSet.key">IQVKeyValueSet.key</a> See standardized key listing
    <a href="#IQVKeyValueSet.value">IQVKeyValueSet.value</a> See standardized key listing
    <a href="#IQVKeyValueSet.confidence">IQVKeyValueSet.confidence</a> is 0 to 1 confidence value
    """

    secondary_section = str
    """
    secondary section of the document in which text is located
    """

    segment_type = str
    """
    table, tr, td, section, etc.
    """

    segments = []
    """
    List of entities as <a href="#NLP_Entity">NLP_Entity</a>
    """

    text = str
    """
    segment text
    """

    text_footnotes = []
    """
    segment text footnotes
    """

    def __init__(self):
        self.attributes = []
        self.doc_id = ''
        self.entities = []
        self.group_type = ''
        self.hierarchy = ''
        self.id = ''
        self.iqv_standard_term = ''
        self.link_id = ''
        self.link_id_level2 = ''
        self.link_id_level3 = ''
        self.link_id_level4 = ''
        self.link_id_level5 = ''
        self.link_id_level6 = ''
        self.link_id_subsection1 = ''
        self.link_id_subsection2 = ''
        self.link_id_subsection3 = ''
        self.parent_id = ''
        self.primary_section = ''
        self.Properties = []
        self.secondary_section = ''
        self.segment_type = ''
        self.segments = []
        self.text = ''
        self.text_footnotes = []
        self.id = str(uuid.uuid1())


class NLP_System_Mapping(object):
    """
    NLP System such as LM
    """

    DataType = str
    """

    """

    doc_id = str
    """
    Element index
    Which document is this element in?
    Top-level id for <a href="#IQVDocument">IQVDocument</a>
    """

    EntityKey = str
    """
    Used in Property in IQV.XML
    """

    FilenameKey = str
    """

    """

    group_type = str
    """
    Element index
    Which item is this element a member of? (name of member = group_type)
    For example, for <a href="#IQVPageROI.Properties">IQVPageROI.Properties</a>, group_type = "Properties"
    Possible parents include but are not limited to
    <a href="#IQVDocument">IQVDocument</a><a href="#IQVPageROI">IQVPageROI</a><a href="#IQVDocumentLink">IQVDocumentLink</a>
    SQL code example 1 for usage of index
    <code>
    WHERE parent_id=parent_id AND group_type=group_type
    </code>
    """

    hierarchy = str
    """
    image,table,paragraph,item,header,footer,roi
    """

    id = str
    """

    """

    iqv_standard_term = str
    """
    Element index
    If this element is a link or header, what is the standard term?
    There is 0 or 1 iqv_standard_term for each element
    """

    link_id = str
    """
    Element index
    Which [link <a href="#IQVDocumentLink">IQVDocumentLink</a>] section is this element in?
    The id for <a href="#IQVDocumentLink.LinkType">IQVDocumentLink.LinkType</a> == "toc"
    and <a href="#IQVDocumentLink.LinkLevel">IQVDocumentLink.LinkLevel</a> == 1
    """

    link_id_level2 = str
    """
    Element index
    Which [link <a href="#IQVDocumentLink">IQVDocumentLink</a>] section is this element in?
    The id for <a href="#IQVDocumentLink.LinkType">IQVDocumentLink.LinkType</a> == "toc"
    and <a href="#IQVDocumentLink.LinkLevel">IQVDocumentLink.LinkLevel</a> == 2
    """

    link_id_level3 = str
    """
    Element index
    Which [link <a href="#IQVDocumentLink">IQVDocumentLink</a>] section is this element in?
    The id for <a href="#IQVDocumentLink.LinkType">IQVDocumentLink.LinkType</a> == "toc"
    and <a href="#IQVDocumentLink.LinkLevel">IQVDocumentLink.LinkLevel</a> == 3
    """

    link_id_level4 = str
    """
    Element index
    Which [link <a href="#IQVDocumentLink">IQVDocumentLink</a>] section is this element in?
    The id for <a href="#IQVDocumentLink.LinkType">IQVDocumentLink.LinkType</a> == "toc"
    and <a href="#IQVDocumentLink.LinkLevel">IQVDocumentLink.LinkLevel</a> == 4
    """

    link_id_level5 = str
    """
    Element index
    Which [link <a href="#IQVDocumentLink">IQVDocumentLink</a>] section is this element in?
    The id for <a href="#IQVDocumentLink.LinkType">IQVDocumentLink.LinkType</a> == "toc"
    and <a href="#IQVDocumentLink.LinkLevel">IQVDocumentLink.LinkLevel</a> == 5
    """

    link_id_level6 = str
    """
    Element index
    Which [link <a href="#IQVDocumentLink">IQVDocumentLink</a>] section is this element in?
    The id for <a href="#IQVDocumentLink.LinkType">IQVDocumentLink.LinkType</a> == "toc"
    and <a href="#IQVDocumentLink.LinkLevel">IQVDocumentLink.LinkLevel</a> == 6
    """

    link_id_subsection1 = str
    """
    Element index
    Which [link <a href="#IQVDocumentLink">IQVDocumentLink</a>] section is this element in?
    The id for <a href="#IQVDocumentLink.LinkType">IQVDocumentLink.LinkType</a> == "subsection1"
    """

    link_id_subsection2 = str
    """
    Element index
    Which [link <a href="#IQVDocumentLink">IQVDocumentLink</a>] section is this element in?
    The id for <a href="#IQVDocumentLink.LinkType">IQVDocumentLink.LinkType</a> == "subsection2"
    """

    link_id_subsection3 = str
    """
    Element index
    Which [link <a href="#IQVDocumentLink">IQVDocumentLink</a>] section is this element in?
    The id for <a href="#IQVDocumentLink.LinkType">IQVDocumentLink.LinkType</a> == "subsection3"
    """

    NLPSystem = str
    """

    """

    NLPSystemQueryName = str
    """

    """

    NLPSystemVersion = str
    """

    """

    parent_id = str
    """
    Element index
    Which item is this element a member of?
    For example, for <a href="#IQVPageROI.Properties">IQVPageROI.Properties</a>, parent_id = <a href="#IQVPageROI.id">IQVPageROI.id</a>
    Possible parents include but are not limited to
    <a href="#IQVDocument">IQVDocument</a><a href="#IQVPageROI">IQVPageROI</a><a href="#IQVDocumentLink">IQVDocumentLink</a>
    SQL code example 1 for usage of index
    <code>
    WHERE parent_id=parent_id AND group_type=group_type
    </code>
    SQL code example 2 for usage of index
    <code>
    WHERE parent_id=parent_id
    </code>
    """

    QCFeedbackUIKey = str
    """
    Used in qc feedback as field_name
    """

    def __init__(self):
        self.DataType = ''
        self.doc_id = ''
        self.EntityKey = ''
        self.FilenameKey = ''
        self.group_type = ''
        self.hierarchy = ''
        self.id = ''
        self.iqv_standard_term = ''
        self.link_id = ''
        self.link_id_level2 = ''
        self.link_id_level3 = ''
        self.link_id_level4 = ''
        self.link_id_level5 = ''
        self.link_id_level6 = ''
        self.link_id_subsection1 = ''
        self.link_id_subsection2 = ''
        self.link_id_subsection3 = ''
        self.NLPSystem = ''
        self.NLPSystemQueryName = ''
        self.NLPSystemVersion = ''
        self.parent_id = ''
        self.QCFeedbackUIKey = ''
        self.id = str(uuid.uuid1())


class IQVRedactionCategory(object):
    """
    Redaction Category with specification if
     redacted or not. See <a href="#IQVRedactionProfile">IQVRedactionProfile</a>
    for building a profile of a list of these
    """

    Category = str
    """
    Label for category as found in i2e results,
    IQV.XML, and JSON tags
    """

    id = str
    """

    """

    IsRedacted = int
    """
    0 or 1
    0 = Do not redact this item
    1 = Do redact this item
    """

    Query = str
    """
    i2e Query name
    """

    def __init__(self):
        self.Category = ''
        self.id = ''
        self.IsRedacted = -1
        self.Query = ''
        self.id = str(uuid.uuid1())


class IQVRedactionProfile(object):
    """
    Used to assign role-based redaction. Role should
    be assigned a profile. The profile lists all
    possible <a href="#IQVRedactionCategory">IQVRedactionCategory</a> and
    indicator whether to redact or not <a href="#IQVRedactionCategory.IsRedacted">IQVRedactionCategory.IsRedacted</a>
    """

    Categories = []
    """
    All active categories
    """

    DefaultIsRedacted = int
    """
    0 or 1
    0 = Do not redact this item
    1 = Do redact this item
    """

    id = str
    """
    Unique profile id
    """

    def __init__(self):
        self.Categories = []
        self.DefaultIsRedacted = -1
        self.id = ''
        self.id = str(uuid.uuid1())


class IQVDocumentLink(object):
    """
    Links within document, mostly to handle document-document
    link and section structure
    <a href="#IQVDocumentLink">IQVDocumentLink</a>
    """

    doc_id = str
    """
    Element index
    Which document is this element in?
    Top-level id for <a href="#IQVDocument">IQVDocument</a>
    """

    group_type = str
    """
    Element index
    Which item is this element a member of? (name of member = group_type)
    For example, for <a href="#IQVPageROI.Properties">IQVPageROI.Properties</a>, group_type = "Properties"
    Possible parents include but are not limited to
    <a href="#IQVDocument">IQVDocument</a><a href="#IQVPageROI">IQVPageROI</a><a href="#IQVDocumentLink">IQVDocumentLink</a>
    SQL code example 1 for usage of index
    <code>
    WHERE parent_id=parent_id AND group_type=group_type
    </code>
    """

    hierarchy = str
    """
    image,table,paragraph,item,header,footer,roi
    """

    id = str
    """
    Unique id for the link
    """

    iqv_standard_term = str
    """
    Element index
    If this element is a link or header, what is the standard term?
    There is 0 or 1 iqv_standard_term for each element
    """

    link_id = str
    """
    Element index
    Which [link <a href="#IQVDocumentLink">IQVDocumentLink</a>] section is this element in?
    The id for <a href="#IQVDocumentLink.LinkType">IQVDocumentLink.LinkType</a> == "toc"
    and <a href="#IQVDocumentLink.LinkLevel">IQVDocumentLink.LinkLevel</a> == 1
    """

    link_id_level2 = str
    """
    Element index
    Which [link <a href="#IQVDocumentLink">IQVDocumentLink</a>] section is this element in?
    The id for <a href="#IQVDocumentLink.LinkType">IQVDocumentLink.LinkType</a> == "toc"
    and <a href="#IQVDocumentLink.LinkLevel">IQVDocumentLink.LinkLevel</a> == 2
    """

    link_id_level3 = str
    """
    Element index
    Which [link <a href="#IQVDocumentLink">IQVDocumentLink</a>] section is this element in?
    The id for <a href="#IQVDocumentLink.LinkType">IQVDocumentLink.LinkType</a> == "toc"
    and <a href="#IQVDocumentLink.LinkLevel">IQVDocumentLink.LinkLevel</a> == 3
    """

    link_id_level4 = str
    """
    Element index
    Which [link <a href="#IQVDocumentLink">IQVDocumentLink</a>] section is this element in?
    The id for <a href="#IQVDocumentLink.LinkType">IQVDocumentLink.LinkType</a> == "toc"
    and <a href="#IQVDocumentLink.LinkLevel">IQVDocumentLink.LinkLevel</a> == 4
    """

    link_id_level5 = str
    """
    Element index
    Which [link <a href="#IQVDocumentLink">IQVDocumentLink</a>] section is this element in?
    The id for <a href="#IQVDocumentLink.LinkType">IQVDocumentLink.LinkType</a> == "toc"
    and <a href="#IQVDocumentLink.LinkLevel">IQVDocumentLink.LinkLevel</a> == 5
    """

    link_id_level6 = str
    """
    Element index
    Which [link <a href="#IQVDocumentLink">IQVDocumentLink</a>] section is this element in?
    The id for <a href="#IQVDocumentLink.LinkType">IQVDocumentLink.LinkType</a> == "toc"
    and <a href="#IQVDocumentLink.LinkLevel">IQVDocumentLink.LinkLevel</a> == 6
    """

    link_id_subsection1 = str
    """
    Element index
    Which [link <a href="#IQVDocumentLink">IQVDocumentLink</a>] section is this element in?
    The id for <a href="#IQVDocumentLink.LinkType">IQVDocumentLink.LinkType</a> == "subsection1"
    """

    link_id_subsection2 = str
    """
    Element index
    Which [link <a href="#IQVDocumentLink">IQVDocumentLink</a>] section is this element in?
    The id for <a href="#IQVDocumentLink.LinkType">IQVDocumentLink.LinkType</a> == "subsection2"
    """

    link_id_subsection3 = str
    """
    Element index
    Which [link <a href="#IQVDocumentLink">IQVDocumentLink</a>] section is this element in?
    The id for <a href="#IQVDocumentLink.LinkType">IQVDocumentLink.LinkType</a> == "subsection3"
    """

    LinkDestinations = []
    """
    Single destination, multiple pointers, page, text, location.
    Allow for a list in case of overlapping blocks, but only one is expected
    """

    LinkLevel = int
    """
    hierarchical level of the link, with 1=top most level,
    -1=not set
    """

    LinkPage = int
    """
    zero-based page index of link destination point;
    additional information on link destination may be
    found in <see cref="!:LinkDestination" />
    -1 = not set
    """

    LinkPointers = []
    """
    Single destination, multiple pointers
    """

    LinkPrefix = str
    """
    numeric prefix (section identifier), such as "7.1.1"
    """

    LinkText = str
    """
    raw text of destination
    """

    LinkType = str
    """
    type of link: internal, external, toc, tof, toa, tot
    """

    parent_id = str
    """
    Element index
    Which item is this element a member of?
    For example, for <a href="#IQVPageROI.Properties">IQVPageROI.Properties</a>, parent_id = <a href="#IQVPageROI.id">IQVPageROI.id</a>
    Possible parents include but are not limited to
    <a href="#IQVDocument">IQVDocument</a><a href="#IQVPageROI">IQVPageROI</a><a href="#IQVDocumentLink">IQVDocumentLink</a>
    SQL code example 1 for usage of index
    <code>
    WHERE parent_id=parent_id AND group_type=group_type
    </code>
    SQL code example 2 for usage of index
    <code>
    WHERE parent_id=parent_id
    </code>
    """

    Properties = []
    """
    Properties such as what section header this is a link for.
    """

    def __init__(self):
        self.doc_id = ''
        self.group_type = ''
        self.hierarchy = ''
        self.id = ''
        self.iqv_standard_term = ''
        self.link_id = ''
        self.link_id_level2 = ''
        self.link_id_level3 = ''
        self.link_id_level4 = ''
        self.link_id_level5 = ''
        self.link_id_level6 = ''
        self.link_id_subsection1 = ''
        self.link_id_subsection2 = ''
        self.link_id_subsection3 = ''
        self.LinkDestinations = []
        self.LinkLevel = -1
        self.LinkPage = -1
        self.LinkPointers = []
        self.LinkPrefix = ''
        self.LinkText = ''
        self.LinkType = ''
        self.parent_id = ''
        self.Properties = []
        self.id = str(uuid.uuid1())


class IQVDocumentVariable(object):
    """
    Assessment and visit record for an SOA
    """

    doc_id = str
    """
    Which document is this element in?
    """

    dts = str
    """
    datetimestamp in YYYYMMDDHHMMSS
    """

    id = str
    """
    Element index for this variable
    """

    run_id = str
    """
    Which run of the data?
    Note: Use <a href="#IQVDocumentVariable.variable_source">IQVDocumentVariable.variable_source</a> to track code version
    """

    source_filename = str
    """
    document content source
    use this to align GT with system output
    """

    variable_category = str
    """
    category of variable
    'pb' for patient burden
    'sb' for site burden
    """

    variable_datatype = str
    """
    datatype boolean, double, integer
    """

    variable_index = int
    """
    key, such as document_date
    """

    variable_key = str
    """
    key, such as document_date
    """

    variable_label = str
    """
    key display
    """

    variable_listing_filename = str
    """
    ground truth data filename
    """

    variable_notes = str
    """
    additional notes
    """

    variable_score = float
    """
    confidence level, probability that this is correct
    """

    variable_source = str
    """
    SME input ('GT'), AI algorithm, etc.
    Put version of algorithm build here.
    """

    variable_value = str
    """
    value of the attribute, as string
    """

    def __init__(self):
        self.doc_id = ''
        self.dts = ''
        self.id = ''
        self.run_id = ''
        self.source_filename = ''
        self.variable_category = ''
        self.variable_datatype = ''
        self.variable_index = -1
        self.variable_key = ''
        self.variable_label = ''
        self.variable_listing_filename = ''
        self.variable_notes = ''
        self.variable_score = 0.0
        self.variable_source = ''
        self.variable_value = ''
        self.id = str(uuid.uuid1())


class IQVDocumentDiff(object):
    """
    
    """

    ChildDiffs = []
    """
    one element may be made up of multiple diffs

    long string may have diffs

    element may have multiple components (eg, numeric prefix, text, page number, etc)

    all of the multiple diffs/components can be placed in single logical container
    then easier to display and manage

    if the entire element is added/deleted, this is apparent at parent level
    if individual components are added/deleted, this is apparent at <a href="#IQVDocumentDiff.ChildDiffs">IQVDocumentDiff.ChildDiffs</a>
    """

    compare_roi_id = str
    """
    id of the <a href="#IQVPageROI">IQVPageROI</a> in compare document
    alternatively, id of <a href="#IQVDocumentLink">IQVDocumentLink</a>, id of <a href="#IQVTableColumn">IQVTableColumn</a>, etc.

    Important to have this, as may be multiple diffs for a single component.
    For example, diffs of <a href="#IQVDocumentLink">IQVDocumentLink</a> might include
    1. diff of numeric prefix
    2. diff of text
    3. diff of page number

    Thus, having the "parent" id here makes it possible to compile all child diffs
    of the same parent component
    """

    confidence = float
    """
    Probability score of correctness of this diff,
    0.0 is low, 1.0 is high
    """

    diff_category = str
    """
    What category of object are we comparing?
    soa, table, attributes, etc.
    """

    diff_string = str
    """
    What is the string that is different???
    (where it is found in the big string is location)
    """

    diff_subcategory = str
    """
    What subcategory of object are we comparing?
    soa_timeline, soa_assessment, attribute key, etc.
    May be blank
    """

    diff_type = int
    """
    <a href="#IQVDocumentDiffType">IQVDocumentDiffType</a>
    0=default, no difference
    1=local only
    2=compare only
    3=modification
    4=alignment only (no comparison, used for reference)
    """

    id = str
    """
    id for this comparison
    """

    IsPreferredTermComparison = bool
    """
    Only for compare of preferred term, default is false
    """

    local_roi_id = str
    """
    id of the <a href="#IQVPageROI">IQVPageROI</a> in this document
    alternatively, id of <a href="#IQVDocumentLink">IQVDocumentLink</a>, id of <a href="#IQVTableColumn">IQVTableColumn</a>, etc.

    Important to have this, as may be multiple diffs for a single component.
    For example, diffs of <a href="#IQVDocumentLink">IQVDocumentLink</a> might include
    1. diff of numeric prefix
    2. diff of text
    3. diff of page number

    Thus, having the "parent" id here makes it possible to compile all child diffs
    of the same parent component
    """

    Properties = []
    """
    properties about this comparison
    """

    PropertiesBase = []
    """
    properties about this comparison
    """

    PropertiesCompare = []
    """
    properties about this comparison
    """

    tableColumnLHS = IQVTableColumn
    """
    if this is diff in the SOA, the table column
    with all headers (LHS)
    """

    tableColumnRHS = IQVTableColumn
    """
    if this is diff in the SOA, the table column
    with all headers
    """

    tableRowHeaderLHS = IQVPageROI
    """
    if this is diff in the SOA, the row header
     for this cell compared
    """

    tableRowHeaderRHS = IQVPageROI
    """
    if this is diff in the SOA, the row header
     for this cell compared
    """

    def __init__(self):
        self.ChildDiffs = []
        self.compare_roi_id = ''
        self.confidence = 0.0
        self.diff_category = ''
        self.diff_string = ''
        self.diff_subcategory = ''
        self.diff_type = -1
        self.id = ''
        self.IsPreferredTermComparison = False
        self.local_roi_id = ''
        self.Properties = []
        self.PropertiesBase = []
        self.PropertiesCompare = []
        self.tableColumnLHS = IQVTableColumn()
        self.tableColumnRHS = IQVTableColumn()
        self.tableRowHeaderLHS = IQVPageROI()
        self.tableRowHeaderRHS = IQVPageROI()
        self.id = str(uuid.uuid1())


class IQVDocumentCompare(object):
    """
    Comparison between 2 documents <a href="#IQVDocument">IQVDocument</a>
    """

    base_doc_id = str
    """
    base/LHS doc id
    """

    base_doc_name = str
    """
    Base/LHS document short filename
    """

    BaseDocProperties = []
    """
    properties about this base document
    """

    compare_doc_id = str
    """
    comparison/RHS doc id
    """

    compare_doc_name = str
    """
    Comparison/RHS document short filename
    """

    CompareDocProperties = []
    """
    properties about this compare document
    """

    DocumentDiffs = []
    """
    List of <a href="#IQVDocumentDiff">IQVDocumentDiff</a>
    """

    id = str
    """
    id for this comparison
    """

    Properties = []
    """
    properties about this comparison
    """

    redaction_profile_id = str
    """
    id for redaction profile used in compare
    """

    RedactionProfile = IQVRedactionProfile
    """
    copy of full redaction profile used in compare
    """

    def __init__(self):
        self.base_doc_id = ''
        self.base_doc_name = ''
        self.BaseDocProperties = []
        self.compare_doc_id = ''
        self.compare_doc_name = ''
        self.CompareDocProperties = []
        self.DocumentDiffs = []
        self.id = ''
        self.Properties = []
        self.redaction_profile_id = ''
        self.RedactionProfile = IQVRedactionProfile()
        self.id = str(uuid.uuid1())


class IQVDiffRecord(object):
    """
    
    """

    category = str
    """
    High level category
    footnote, attributes, soa, toc, pt
    """

    diff_string = str
    """
    String that is added or deleted
    """

    diff_type = str
    """
    type of diff
    ADDITION_RHSONLY
    DELETION_LHSONLY
    MODIFICATION
    NO_CHANGE
    """

    doc_id_a = str
    """
    Protocol document id
    LHS/base document
    doc_id_a
    """

    doc_id_b = str
    """
    Protocol document id
    RHS/compare document
    doc_id_b
    """

    dts = str
    """
    Date/Time Stamp
    string (YYYYMMDDHHMMSS in UTC)
    """

    id = str
    """
    id for this comparison
    """

    pname_a = str
    """
    Protocol file name
    file name ending in .pdf, .docx, etc.
    LHS/base document
    doc_id_a
    """

    pname_b = str
    """
    Protocol file name
    file name ending in .pdf, .docx, etc.
    RHS/compare document
    doc_id_b
    """

    ProcessMachineName = str
    """
    server on which protocol is processed
    """

    ProcessVersion = str
    """
    Code Version
    """

    ptdiff_string = str
    """
    diff string for preferred term
    """

    ptdiff_type = str
    """
    type of diff
    ADDITION_RHSONLY
    DELETION_LHSONLY
    MODIFICATION
    NO_CHANGE
    """

    pttext_a = str
    """
    text in protocol
    """

    pttext_b = str
    """
    text in protocol
    """

    roi_id_a = str
    """
    Protocol ROI id
    LHS/base document
    roi_id_a
    """

    roi_id_b = str
    """
    Protocol ROI id
    RHS/compare document
    roi_id_b
    """

    section = str
    """
    protocol section, from
     <a href="#IQVDocumentDiff.Properties"></see> or
    <see cref="F:IQVFileManagerDLL.IQVDocumentDiff.PropertiesBase">IQVDocumentDiff.Properties"></see> or
    <see cref="F:IQVFileManagerDLL.IQVDocumentDiff.PropertiesBase</a> or
    <a href="#IQVDocumentDiff.PropertiesCompare">IQVDocumentDiff.PropertiesCompare</a> where
    <a href="#IQV_KEY_STRING.KEY_LinkText">IQV_KEY_STRING.KEY_LinkText</a> is completed or
    <a href="#IQV_KEY_STRING.KEY_IsSectionHeader">IQV_KEY_STRING.KEY_IsSectionHeader</a> is completed or
    <a href="#IQV_KEY_STRING.KEY_IsSectionElement">IQV_KEY_STRING.KEY_IsSectionElement</a> is completed
    """

    start_index = int
    """
    diff location in text
    """

    subcategory = str
    """
    2nd-level category
    soa_timeline, soa_assessment, attribute key
    """

    table_column = str
    """
    table column identifier
    """

    table_row = str
    """
    table row identifier
    """

    text_a = str
    """
    text in protocol
    """

    text_b = str
    """
    text in protocol
    """

    text_length = int
    """
    diff text length
    """

    def __init__(self):
        self.category = ''
        self.diff_string = ''
        self.diff_type = ''
        self.doc_id_a = ''
        self.doc_id_b = ''
        self.dts = ''
        self.id = ''
        self.pname_a = ''
        self.pname_b = ''
        self.ProcessMachineName = ''
        self.ProcessVersion = ''
        self.ptdiff_string = ''
        self.ptdiff_type = ''
        self.pttext_a = ''
        self.pttext_b = ''
        self.roi_id_a = ''
        self.roi_id_b = ''
        self.section = ''
        self.start_index = -1
        self.subcategory = ''
        self.table_column = ''
        self.table_row = ''
        self.text_a = ''
        self.text_b = ''
        self.text_length = -1
        self.id = str(uuid.uuid1())


class IQVDiffRecordSOA(object):
    """
    
    """

    assessment = str
    """
    assessment
    """

    category = str
    """
    High level category
    footnote, attributes, soa, toc, pt
    """

    cycle = str
    """
    cycle/subepoch timepoint
    """

    day = str
    """
    day timepoint
    """

    diff_string = str
    """
    String that is added or deleted
    """

    diff_type = str
    """
    type of diff
    ADDITION_RHSONLY
    DELETION_LHSONLY
    MODIFICATION
    NO_CHANGE
    """

    doc_id_a = str
    """
    Protocol document id
    LHS/base document
    doc_id_a
    """

    doc_id_b = str
    """
    Protocol document id
    RHS/compare document
    doc_id_b
    """

    dts = str
    """
    Date/Time Stamp
    string (YYYYMMDDHHMMSS in UTC)
    """

    epoch = str
    """
    epoch timepoint
    """

    id = str
    """
    id for this comparison
    """

    month = str
    """
    month timepoint
    """

    pname_a = str
    """
    Protocol file name
    file name ending in .pdf, .docx, etc.
    LHS/base document
    doc_id_a
    """

    pname_b = str
    """
    Protocol file name
    file name ending in .pdf, .docx, etc.
    RHS/compare document
    doc_id_b
    """

    procedure = str
    """
    text in protocol
    """

    ProcessMachineName = str
    """
    server on which protocol is processed
    """

    ProcessVersion = str
    """
    Code Version
    """

    roi_id_a = str
    """
    Protocol ROI id
    LHS/base document
    roi_id_a
    """

    roi_id_b = str
    """
    Protocol ROI id
    RHS/compare document
    roi_id_b
    """

    section = str
    """
    protocol section, from
     <a href="#IQVDocumentDiff.Properties"></see> or
    <see cref="F:IQVFileManagerDLL.IQVDocumentDiff.PropertiesBase">IQVDocumentDiff.Properties"></see> or
    <see cref="F:IQVFileManagerDLL.IQVDocumentDiff.PropertiesBase</a> or
    <a href="#IQVDocumentDiff.PropertiesCompare">IQVDocumentDiff.PropertiesCompare</a> where
    <a href="#IQV_KEY_STRING.KEY_LinkText">IQV_KEY_STRING.KEY_LinkText</a> is completed or
    <a href="#IQV_KEY_STRING.KEY_IsSectionHeader">IQV_KEY_STRING.KEY_IsSectionHeader</a> is completed or
    <a href="#IQV_KEY_STRING.KEY_IsSectionElement">IQV_KEY_STRING.KEY_IsSectionElement</a> is completed
    """

    start_index = int
    """
    diff location in text
    """

    subcategory = str
    """
    2nd-level category
    soa_timeline, soa_assessment, attribute key
    """

    table_column = str
    """
    table column identifier
    """

    table_row = str
    """
    table row identifier
    """

    text_a = str
    """
    text in protocol
    """

    text_b = str
    """
    text in protocol
    """

    text_length = int
    """
    diff text length
    """

    visit = str
    """
    visit timepoint
    """

    week = str
    """
    week timepoint
    """

    window = str
    """
    window timepoint
    """

    year = str
    """
    year timepoint
    """

    def __init__(self):
        self.assessment = ''
        self.category = ''
        self.cycle = ''
        self.day = ''
        self.diff_string = ''
        self.diff_type = ''
        self.doc_id_a = ''
        self.doc_id_b = ''
        self.dts = ''
        self.epoch = ''
        self.id = ''
        self.month = ''
        self.pname_a = ''
        self.pname_b = ''
        self.procedure = ''
        self.ProcessMachineName = ''
        self.ProcessVersion = ''
        self.roi_id_a = ''
        self.roi_id_b = ''
        self.section = ''
        self.start_index = -1
        self.subcategory = ''
        self.table_column = ''
        self.table_row = ''
        self.text_a = ''
        self.text_b = ''
        self.text_length = -1
        self.visit = ''
        self.week = ''
        self.window = ''
        self.year = ''
        self.id = str(uuid.uuid1())


class IQVAssessmentVisitRecord(object):
    """
    Assessment and visit record for an SOA
    """

    assessment = str
    """
    Protocol ROI id
    RHS/compare document
    roi_id_b
    """

    assessment_text = str
    """
    text in protocol
    """

    cycle_timepoint = str
    """
    timeline
    """

    day_timepoint = str
    """
    timeline
    """

    doc_id = str
    """
    Protocol document id
    LHS/base document
    doc_id_a
    """

    DocumentSequenceIndex = int
    """
    Sequence for assessment within SOA table
    """

    dts = str
    """
    Date/Time Stamp
    string (YYYYMMDDHHMMSS in UTC)
    """

    epoch_timepoint = str
    """
    timeline for epoch
    """

    footnotes = []
    """
    footnote if given in content or assessment
    """

    id = str
    """
    id for this record
    """

    indicator_text = str
    """
    "X" or other indicator inside of SOA cells
    default is blank
    Can include all records even if blank
     to help identify orphaned assessments, etc.
    """

    month_timepoint = str
    """
    timeline
    """

    pname = str
    """
    Protocol file name
    file name ending in .pdf, .docx, etc.
    LHS/base document
    doc_id_a
    """

    procedure = str
    """
    text in protocol
    """

    procedure_text = str
    """
    text in protocol
    """

    ProcessMachineName = str
    """
    server on which protocol is processed
    """

    ProcessVersion = str
    """
    Code Version
    """

    roi_id = str
    """
    Protocol ROI id
    for the assessment!
    """

    run_id = str
    """
    Which run of the data?
    """

    section = str
    """
    text in protocol
    """

    study_cohort = str
    """
    cohort/arm for the table
    """

    table_column_id = str
    """
    id for the <a href="#IQVTableColumn">IQVTableColumn</a>
    """

    table_link_text = str
    """
    header for the table
    """

    table_roi_id = str
    """
    id for the table
    """

    table_sequence_index = int
    """
    id for the table
    """

    visit_timepoint = str
    """
    Visit timeline
    e.g., 1, 2, 3,...
    """

    week_timepoint = str
    """
    timeline
    """

    window_timepoint = str
    """
    timeline
    """

    year_timepoint = str
    """
    timeline
    """

    def __init__(self):
        self.assessment = ''
        self.assessment_text = ''
        self.cycle_timepoint = ''
        self.day_timepoint = ''
        self.doc_id = ''
        self.DocumentSequenceIndex = -1
        self.dts = ''
        self.epoch_timepoint = ''
        self.footnotes = []
        self.id = ''
        self.indicator_text = ''
        self.month_timepoint = ''
        self.pname = ''
        self.procedure = ''
        self.procedure_text = ''
        self.ProcessMachineName = ''
        self.ProcessVersion = ''
        self.roi_id = ''
        self.run_id = ''
        self.section = ''
        self.study_cohort = ''
        self.table_column_id = ''
        self.table_link_text = ''
        self.table_roi_id = ''
        self.table_sequence_index = -1
        self.visit_timepoint = ''
        self.week_timepoint = ''
        self.window_timepoint = ''
        self.year_timepoint = ''
        self.id = str(uuid.uuid1())


class IQVAssessmentRecord(object):
    """
    Assessment record for an SOA
    """

    assessment = str
    """
    Protocol ROI id
    RHS/compare document
    roi_id_b
    """

    assessment_text = str
    """
    text in protocol
    """

    doc_id = str
    """
    Protocol document id
    LHS/base document
    doc_id_a
    """

    DocumentSequenceIndex = int
    """
    Sequence for assessment within SOA table
    """

    dts = str
    """
    Date/Time Stamp
    string (YYYYMMDDHHMMSS in UTC)
    """

    footnotes = []
    """
    footnote if given in content or assessment
    """

    id = str
    """
    id for this record
    """

    num_visits = int
    """
    Num visits for this assessment
    """

    pname = str
    """
    Protocol file name
    file name ending in .pdf, .docx, etc.
    LHS/base document
    doc_id_a
    """

    procedure = str
    """
    text in protocol
    """

    procedure_text = str
    """
    text in protocol
    """

    ProcessMachineName = str
    """
    server on which protocol is processed
    """

    ProcessVersion = str
    """
    Code Version
    """

    roi_id = str
    """
    Protocol ROI id
    for the assessment!
    """

    run_id = str
    """
    Which run of the data?
    """

    section = str
    """
    text in protocol
    """

    study_cohort = str
    """
    cohort/arm for the table
    """

    table_column_id = str
    """
    id for the <a href="#IQVTableColumn">IQVTableColumn</a>
    """

    table_link_text = str
    """
    header for the table
    """

    table_roi_id = str
    """
    id for the table
    """

    table_sequence_index = int
    """
    id for the table
    """

    def __init__(self):
        self.assessment = ''
        self.assessment_text = ''
        self.doc_id = ''
        self.DocumentSequenceIndex = -1
        self.dts = ''
        self.footnotes = []
        self.id = ''
        self.num_visits = -1
        self.pname = ''
        self.procedure = ''
        self.procedure_text = ''
        self.ProcessMachineName = ''
        self.ProcessVersion = ''
        self.roi_id = ''
        self.run_id = ''
        self.section = ''
        self.study_cohort = ''
        self.table_column_id = ''
        self.table_link_text = ''
        self.table_roi_id = ''
        self.table_sequence_index = -1
        self.id = str(uuid.uuid1())


class IQVLabParameterRecord(object):
    """
    Lab data individual parameter
    
    1+ parameter(s) per panel/procedure
    """

    assessment = str
    """
    If known, the assessment in the SOA
    """

    doc_id = str
    """
    Protocol document id
    LHS/base document
    doc_id_a
    """

    dts = str
    """
    Date/Time Stamp
    string (YYYYMMDDHHMMSS in UTC)
    """

    id = str
    """
    id for this record
    """

    parameter = str
    """
    normalized text in protocol
    multiple parameters per procedure/panel
    """

    parameter_text = str
    """
    raw text in protocol
    multiple parameters per procedure/panel
    """

    pname = str
    """
    Protocol file name
    file name ending in .pdf, .docx, etc.
    LHS/base document
    doc_id_a
    """

    procedure_panel = str
    """
    normalized text of procedure/panel
    procedure/panel may be the same as the assessment
    """

    procedure_panel_text = str
    """
    raw text in protocol
    procedure/panel may be the same as the assessment
    """

    ProcessMachineName = str
    """
    server on which protocol is processed
    """

    ProcessVersion = str
    """
    Code Version
    """

    roi_id = str
    """
    Protocol ROI id
    for the assessment!
    """

    run_id = str
    """
    Which run of the data?
    """

    section = str
    """
    text in protocol
    """

    table_link_text = str
    """
    header for the table
    """

    table_roi_id = str
    """
    id for the table
    """

    table_sequence_index = int
    """
    id for the table
    """

    def __init__(self):
        self.assessment = ''
        self.doc_id = ''
        self.dts = ''
        self.id = ''
        self.parameter = ''
        self.parameter_text = ''
        self.pname = ''
        self.procedure_panel = ''
        self.procedure_panel_text = ''
        self.ProcessMachineName = ''
        self.ProcessVersion = ''
        self.roi_id = ''
        self.run_id = ''
        self.section = ''
        self.table_link_text = ''
        self.table_roi_id = ''
        self.table_sequence_index = -1
        self.id = str(uuid.uuid1())


class IQVVisitRecord(object):
    """
    Visit record for an SOA
    """

    cycle_timepoint = str
    """
    timeline
    """

    day_timepoint = str
    """
    timeline
    """

    doc_id = str
    """
    Protocol document id
    LHS/base document
    doc_id_a
    """

    DocumentSequenceIndex = int
    """
    Sequence for assessment within SOA table
    """

    dts = str
    """
    Date/Time Stamp
    string (YYYYMMDDHHMMSS in UTC)
    """

    epoch_timepoint = str
    """
    timeline for epoch
    """

    footnotes = []
    """
    footnote if given in content or assessment
    """

    id = str
    """
    id for this record
    """

    month_timepoint = str
    """
    timeline
    """

    num_assessments = int
    """
    Num visits for this assessment
    """

    pname = str
    """
    Protocol file name
    file name ending in .pdf, .docx, etc.
    LHS/base document
    doc_id_a
    """

    ProcessMachineName = str
    """
    server on which protocol is processed
    """

    ProcessVersion = str
    """
    Code Version
    """

    run_id = str
    """
    Which run of the data?
    """

    study_cohort = str
    """
    cohort/arm for the table
    """

    table_column_id = str
    """
    id for the <a href="#IQVTableColumn">IQVTableColumn</a>
    """

    table_link_text = str
    """
    header for the table
    """

    table_roi_id = str
    """
    id for the table
    """

    table_sequence_index = int
    """
    id for the table
    """

    visit_timepoint = str
    """
    Visit timeline
    e.g., 1, 2, 3,...
    """

    week_timepoint = str
    """
    timeline
    """

    window_timepoint = str
    """
    timeline
    """

    year_timepoint = str
    """
    timeline
    """

    def __init__(self):
        self.cycle_timepoint = ''
        self.day_timepoint = ''
        self.doc_id = ''
        self.DocumentSequenceIndex = -1
        self.dts = ''
        self.epoch_timepoint = ''
        self.footnotes = []
        self.id = ''
        self.month_timepoint = ''
        self.num_assessments = -1
        self.pname = ''
        self.ProcessMachineName = ''
        self.ProcessVersion = ''
        self.run_id = ''
        self.study_cohort = ''
        self.table_column_id = ''
        self.table_link_text = ''
        self.table_roi_id = ''
        self.table_sequence_index = -1
        self.visit_timepoint = ''
        self.week_timepoint = ''
        self.window_timepoint = ''
        self.year_timepoint = ''
        self.id = str(uuid.uuid1())


class IQVIECriteriaRecord(object):
    """
    Assessment and visit record for an SOA
    """

    doc_id = str
    """
    Protocol document id
    LHS/base document
    doc_id_a
    """

    DocumentSequenceIndex = int
    """
    Sequence for assessment within SOA table
    """

    dts = str
    """
    Date/Time Stamp
    string (YYYYMMDDHHMMSS in UTC)
    """

    footnotes = []
    """
    footnote if given in content or assessment
    """

    id = str
    """
    id for this record
    """

    ie_type = str
    """
    inclusion, exclusion, other
    """

    item_text = str
    """
    text in protocol
    """

    link_text = str
    """
    header for the table
    """

    pname = str
    """
    Protocol file name
    file name ending in .pdf, .docx, etc.
    LHS/base document
    doc_id_a
    """

    procedure = str
    """
    text in protocol
    """

    procedure_text = str
    """
    text in protocol
    """

    ProcessMachineName = str
    """
    server on which protocol is processed
    """

    ProcessVersion = str
    """
    Code Version
    """

    roi_id = str
    """
    Protocol ROI id
    for the assessment!
    """

    section = str
    """
    text in protocol
    """

    study_cohort = str
    """
    cohort/arm for the table
    """

    def __init__(self):
        self.doc_id = ''
        self.DocumentSequenceIndex = -1
        self.dts = ''
        self.footnotes = []
        self.id = ''
        self.ie_type = ''
        self.item_text = ''
        self.link_text = ''
        self.pname = ''
        self.procedure = ''
        self.procedure_text = ''
        self.ProcessMachineName = ''
        self.ProcessVersion = ''
        self.roi_id = ''
        self.section = ''
        self.study_cohort = ''
        self.id = str(uuid.uuid1())


class IQVGxPElement(object):
    """
    
    """

    code_source = str
    """
    Name of project
    """

    code_source_repo = str
    """
    Location of code repository
    """

    creator = str
    """
    Designator for creator of this element
    """

    creator_organization = str
    """
    Designator for creator organization of this element
    (IQVIA, Amazon, Google, etc.)
    """

    date_time_stamp = str
    """
    creation of GxP certificate
    14-character datetime string as YYYYMMDDHHMMSS
    default is UTC time zone
    """

    description = str
    """
    User-friendly description targeted to
    audience of user of this element
    (may be a developer, data scientist, or business user).
    For extensive technical notes, use <a href="#IQVGxPElement.technical_notes">IQVGxPElement.technical_notes</a>
    """

    element_namespace = str
    """
    Primary deployment namespace for this element
    """

    element_type = str
    """
    Type of element from standardized list
    compute_platform
    machine
    microservice
    model
    dataset (single dataset such as training, test, validation, etc.)
    datalake (may contain multiple datasets)
    data_file
    data_element
    dev_team
    """

    element_version = str
    """
    version of code
    """

    elements = []
    """
    Child elements
    """

    environment = str
    """
    dev, svt, uat, etc. or other environment settings
    """

    id = str
    """
    id for this result set
    """

    item_ids = []
    """
    Child elements, listing id only
     Use this in the case of something like a file listing
    in which location is known in <a href="#IQVGxPElement.item_ids_location">IQVGxPElement.item_ids_location</a>
    """

    item_ids_location = str
    """
    Location of <a href="#IQVGxPElement.item_ids">IQVGxPElement.item_ids</a>
    """

    label = str
    """
    Short name for this element
    """

    project_id = str
    """
    Primary project_id for original element
    """

    Properties = []
    """
    Properties for this element. If this is
     <a href="#IQVGxPElement.element_type">IQVGxPElement.element_type</a>==data_file or data_element,
    then the relevant properties are primarily determined by the
     designer of the model. For example, the language of the
     data_file may be relevant for one model and should be captured. For
    a different model, the language might be irrelevant and does not
    need to be captured.
    <a href="#IQVKeyValueSet.key">IQVKeyValueSet.key</a> See standardized key listing
    <a href="#IQVKeyValueSet.value">IQVKeyValueSet.value</a> See standardized key listing
    <a href="#IQVKeyValueSet.confidence">IQVKeyValueSet.confidence</a> is 0 to 1 confidence value
    """

    source_repo_id = str
    """
    id in the source repository, such as git hash
    """

    source_system = str
    """
    system connecting to AI
    """

    technical_notes = []
    """
    Placeholder for detailed technical notes
    relevant to this element
    """

    user_id = str
    """
    user id for submitter
    """

    def __init__(self):
        self.code_source = ''
        self.code_source_repo = ''
        self.creator = ''
        self.creator_organization = ''
        self.date_time_stamp = ''
        self.description = ''
        self.element_namespace = ''
        self.element_type = ''
        self.element_version = ''
        self.elements = []
        self.environment = ''
        self.id = ''
        self.item_ids = []
        self.item_ids_location = ''
        self.label = ''
        self.project_id = ''
        self.Properties = []
        self.source_repo_id = ''
        self.source_system = ''
        self.technical_notes = []
        self.user_id = ''
        self.id = str(uuid.uuid1())


class IQVDocumentDiffGenericDisplayCellItem(object):
    """
    
    """

    ChildItems = []
    """
    <a href="#IQVDocumentDiffGenericDisplayCellItem">IQVDocumentDiffGenericDisplayCellItem</a>
    """

    diff_types = []
    """
    actual text, broken into separate strings
    """

    id = str
    """
    guid/uuid
    """

    indent = int
    """
    zero-based; 0=no indent
    """

    item_type = str
    """
    visit, assessment, footnote, parameter, etc.
    """

    sequence = int
    """
    zero-based
    """

    strs = []
    """
    actual text, broken into separate strings
    """

    def __init__(self):
        self.ChildItems = []
        self.diff_types = []
        self.id = ''
        self.indent = -1
        self.item_type = ''
        self.sequence = -1
        self.strs = []
        self.id = str(uuid.uuid1())


class IQVDocumentDiffGenericDisplayCell(object):
    """
    Cell of information for display
    """

    cellItems = []
    """
    <a href="#IQVDocumentDiffGenericDisplayCellItem">IQVDocumentDiffGenericDisplayCellItem</a>
    """

    colIndex = int
    """
    zero-based
    """

    diff_types = []
    """
    <a href="#IQVDocumentDiffType">IQVDocumentDiffType</a>
    """

    id = str
    """
    guid/uuid
    """

    rowIndex = int
    """
    zero-based
    """

    def __init__(self):
        self.cellItems = []
        self.colIndex = -1
        self.diff_types = []
        self.id = ''
        self.rowIndex = -1
        self.id = str(uuid.uuid1())


class IQVDocumentDiffGenericDisplayRow(object):
    """
    Row of information for display
    """

    cells = []
    """
    <a href="#IQVDocumentDiffGenericDisplayCell">IQVDocumentDiffGenericDisplayCell</a>
    """

    ChildRows = []
    """
    <a href="#IQVDocumentDiffGenericDisplayRow">IQVDocumentDiffGenericDisplayRow</a>
    """

    headerType = int
    """
    1 is primary header
    """

    id = str
    """
    guid/uuid
    """

    rowIndex = int
    """
    zero-based
    """

    def __init__(self):
        self.cells = []
        self.ChildRows = []
        self.headerType = -1
        self.id = ''
        self.rowIndex = -1
        self.id = str(uuid.uuid1())


class IQVDocumentDiffGenericDisplayTable(object):
    """
    Cell of information for display
    """

    id = str
    """
    guid/uuid
    """

    rowGroups = []
    """
    <a href="#IQVDocumentDiffGenericDisplayRow">IQVDocumentDiffGenericDisplayRow</a>
    """

    rows = []
    """
    <a href="#IQVDocumentDiffGenericDisplayRow">IQVDocumentDiffGenericDisplayRow</a>
    """

    tableType = str
    """
    toc, soa, etc.
    """

    def __init__(self):
        self.id = ''
        self.rowGroups = []
        self.rows = []
        self.tableType = ''
        self.id = str(uuid.uuid1())


class IQVDocumentDiffGenericDisplayDocument(object):
    """
    
    """

    diff_table_other = IQVDocumentDiffGenericDisplayTable
    """
    other as <a href="#IQVDocumentDiffGenericDisplayTable">IQVDocumentDiffGenericDisplayTable</a>
    """

    diff_table_soa = IQVDocumentDiffGenericDisplayTable
    """
    soa as <a href="#IQVDocumentDiffGenericDisplayTable">IQVDocumentDiffGenericDisplayTable</a>
    """

    diff_table_toc = IQVDocumentDiffGenericDisplayTable
    """
    toc as <a href="#IQVDocumentDiffGenericDisplayTable">IQVDocumentDiffGenericDisplayTable</a>
    """

    id = str
    """
    guid/uuid
    """

    Properties = []
    """
    List of additional properties as <a href="#IQVKeyValueSet">IQVKeyValueSet</a><a href="#IQVKeyValueSet.key">IQVKeyValueSet.key</a> See standardized key listing
    <a href="#IQVKeyValueSet.value">IQVKeyValueSet.value</a> See standardized key listing
    <a href="#IQVKeyValueSet.confidence">IQVKeyValueSet.confidence</a> is 0 to 1 confidence value
    gridspan (for table cell)
    """

    def __init__(self):
        self.diff_table_other = IQVDocumentDiffGenericDisplayTable()
        self.diff_table_soa = IQVDocumentDiffGenericDisplayTable()
        self.diff_table_toc = IQVDocumentDiffGenericDisplayTable()
        self.id = ''
        self.Properties = []
        self.id = str(uuid.uuid1())


class IQVDocumentDataItemQC(object):
    """
    
    """

    bIsTableCell = bool
    """
    roi id if provided
    """

    childbox_id = str
    """
    roi id if provided
    """

    column_roi_id = str
    """
    roi id if provided
    """

    content = str
    """
    content
    """

    CPT_section = str
    """
    common protocol template
    """

    datacell_roi_id = str
    """
    roi id if provided
    """

    dataType = str
    """
    Text, Table
    """

    entities = []
    """
    redaction
    """

    file_section = str
    """
    TITLE for titlepage
    """

    file_section_level = int
    """
    ones-based
    """

    file_section_num = str
    """
    numeric
    """

    fontInfo = FontInfo
    """
    font info
    """

    level_1_CPT_section = str
    """
    common protocol template
    """

    para_id = str
    """
    roi id if provided
    """

    qc_change_type = str
    """
    add/modify/delete
    """

    roi_id = str
    """
    roi id if provided
    """

    row_roi_id = str
    """
    roi id if provided
    """

    section_level = str
    """

    """

    seq_num = str
    """
    seq_num as listed in <a href="#IQVDocumentDataFeedbackQC.index">IQVDocumentDataFeedbackQC.index</a>

    for table cells, this is ones-based index as column index within a row
    (row starts with seq_num=1)
    """

    subtext_id = str
    """
    roi id if provided
    """

    table_roi_id = str
    """
    roi id if provided
    """

    def __init__(self):
        self.bIsTableCell = False
        self.childbox_id = ''
        self.column_roi_id = ''
        self.content = ''
        self.CPT_section = ''
        self.datacell_roi_id = ''
        self.dataType = ''
        self.entities = []
        self.file_section = ''
        self.file_section_level = -1
        self.file_section_num = ''
        self.fontInfo = FontInfo()
        self.level_1_CPT_section = ''
        self.para_id = ''
        self.qc_change_type = ''
        self.roi_id = ''
        self.row_roi_id = ''
        self.section_level = ''
        self.seq_num = ''
        self.subtext_id = ''
        self.table_roi_id = ''
        self.id = str(uuid.uuid1())


class IQVDocumentDataFeedbackQC(object):
    """
    
    """

    columns = []
    """
    columns of items
    """

    data = []
    """
    data items
    """

    index = []
    """
    indexes of items
    """

    metadata = []
    """
    metadata items
    """

    def __init__(self):
        self.columns = []
        self.data = []
        self.index = []
        self.metadata = []
        self.id = str(uuid.uuid1())


class IQVDocumentFeedbackQC(object):
    """
    
    """

    bIsActive = bool
    """
    is active
    """

    doc_id = str
    """
    Element index
    Which document is this element in?
    Top-level id for <a href="#IQVDocument">IQVDocument</a>
    """

    documentFilePath = str
    """
    directory
    """

    fileName = str
    """
    source filename
    """

    group_type = str
    """
    Element index
    Which item is this element a member of? (name of member = group_type)
    For example, for <a href="#IQVPageROI.Properties">IQVPageROI.Properties</a>, group_type = "Properties"
    Possible parents include but are not limited to
    <a href="#IQVDocument">IQVDocument</a><a href="#IQVPageROI">IQVPageROI</a><a href="#IQVDocumentLink">IQVDocumentLink</a>
    SQL code example 1 for usage of index
    <code>
    WHERE parent_id=parent_id AND group_type=group_type
    </code>
    """

    hierarchy = str
    """
    image,table,paragraph,item,header,footer,roi
    """

    id = str
    """
    unique document id for feedback
    """

    iqv_standard_term = str
    """
    Element index
    If this element is a link or header, what is the standard term?
    There is 0 or 1 iqv_standard_term for each element
    """

    iqvdata = IQVDocumentDataFeedbackQC
    """
    data item
    """

    iqvdataSoa = IQVDocumentDataFeedbackQC
    """
    data item
    """

    iqvdataSoaStd = IQVDocumentDataFeedbackQC
    """
    data item
    """

    iqvdataSummary = IQVDocumentDataFeedbackQC
    """
    data item
    """

    iqvdataToc = IQVDocumentDataFeedbackQC
    """
    data item
    """

    link_id = str
    """
    Element index
    Which [link <a href="#IQVDocumentLink">IQVDocumentLink</a>] section is this element in?
    The id for <a href="#IQVDocumentLink.LinkType">IQVDocumentLink.LinkType</a> == "toc"
    and <a href="#IQVDocumentLink.LinkLevel">IQVDocumentLink.LinkLevel</a> == 1
    """

    link_id_level2 = str
    """
    Element index
    Which [link <a href="#IQVDocumentLink">IQVDocumentLink</a>] section is this element in?
    The id for <a href="#IQVDocumentLink.LinkType">IQVDocumentLink.LinkType</a> == "toc"
    and <a href="#IQVDocumentLink.LinkLevel">IQVDocumentLink.LinkLevel</a> == 2
    """

    link_id_level3 = str
    """
    Element index
    Which [link <a href="#IQVDocumentLink">IQVDocumentLink</a>] section is this element in?
    The id for <a href="#IQVDocumentLink.LinkType">IQVDocumentLink.LinkType</a> == "toc"
    and <a href="#IQVDocumentLink.LinkLevel">IQVDocumentLink.LinkLevel</a> == 3
    """

    link_id_level4 = str
    """
    Element index
    Which [link <a href="#IQVDocumentLink">IQVDocumentLink</a>] section is this element in?
    The id for <a href="#IQVDocumentLink.LinkType">IQVDocumentLink.LinkType</a> == "toc"
    and <a href="#IQVDocumentLink.LinkLevel">IQVDocumentLink.LinkLevel</a> == 4
    """

    link_id_level5 = str
    """
    Element index
    Which [link <a href="#IQVDocumentLink">IQVDocumentLink</a>] section is this element in?
    The id for <a href="#IQVDocumentLink.LinkType">IQVDocumentLink.LinkType</a> == "toc"
    and <a href="#IQVDocumentLink.LinkLevel">IQVDocumentLink.LinkLevel</a> == 5
    """

    link_id_level6 = str
    """
    Element index
    Which [link <a href="#IQVDocumentLink">IQVDocumentLink</a>] section is this element in?
    The id for <a href="#IQVDocumentLink.LinkType">IQVDocumentLink.LinkType</a> == "toc"
    and <a href="#IQVDocumentLink.LinkLevel">IQVDocumentLink.LinkLevel</a> == 6
    """

    link_id_subsection1 = str
    """
    Element index
    Which [link <a href="#IQVDocumentLink">IQVDocumentLink</a>] section is this element in?
    The id for <a href="#IQVDocumentLink.LinkType">IQVDocumentLink.LinkType</a> == "subsection1"
    """

    link_id_subsection2 = str
    """
    Element index
    Which [link <a href="#IQVDocumentLink">IQVDocumentLink</a>] section is this element in?
    The id for <a href="#IQVDocumentLink.LinkType">IQVDocumentLink.LinkType</a> == "subsection2"
    """

    link_id_subsection3 = str
    """
    Element index
    Which [link <a href="#IQVDocumentLink">IQVDocumentLink</a>] section is this element in?
    The id for <a href="#IQVDocumentLink.LinkType">IQVDocumentLink.LinkType</a> == "subsection3"
    """

    parent_id = str
    """
    Element index
    Which item is this element a member of?
    For example, for <a href="#IQVPageROI.Properties">IQVPageROI.Properties</a>, parent_id = <a href="#IQVPageROI.id">IQVPageROI.id</a>
    Possible parents include but are not limited to
    <a href="#IQVDocument">IQVDocument</a><a href="#IQVPageROI">IQVPageROI</a><a href="#IQVDocumentLink">IQVDocumentLink</a>
    SQL code example 1 for usage of index
    <code>
    WHERE parent_id=parent_id AND group_type=group_type
    </code>
    SQL code example 2 for usage of index
    <code>
    WHERE parent_id=parent_id
    </code>
    """

    source_system = str
    """
    LM, QC, etc.
    """

    timeCreated = str
    """
    unique document id for feedback
    """

    timeUpdated = str
    """
    unique document id for feedback
    """

    userId = str
    """
    user
    """

    def __init__(self):
        self.bIsActive = False
        self.doc_id = ''
        self.documentFilePath = ''
        self.fileName = ''
        self.group_type = ''
        self.hierarchy = ''
        self.id = ''
        self.iqv_standard_term = ''
        self.iqvdata = IQVDocumentDataFeedbackQC()
        self.iqvdataSoa = IQVDocumentDataFeedbackQC()
        self.iqvdataSoaStd = IQVDocumentDataFeedbackQC()
        self.iqvdataSummary = IQVDocumentDataFeedbackQC()
        self.iqvdataToc = IQVDocumentDataFeedbackQC()
        self.link_id = ''
        self.link_id_level2 = ''
        self.link_id_level3 = ''
        self.link_id_level4 = ''
        self.link_id_level5 = ''
        self.link_id_level6 = ''
        self.link_id_subsection1 = ''
        self.link_id_subsection2 = ''
        self.link_id_subsection3 = ''
        self.parent_id = ''
        self.source_system = ''
        self.timeCreated = ''
        self.timeUpdated = ''
        self.userId = ''
        self.id = str(uuid.uuid1())


class IQVClassifierModel(object):
    """
    Used to specify 2nd-level and other specialized models
    """

    Base_Model_Version = str
    """
    1st-level model
    """

    Country = str
    """
    If specified, model is for
     one country
    """

    Doc_Class = str
    """
    If specified, model is for one of the following
    site, country, study
    """

    Full_Classification_List = []
    """
    List of document classifications that are used
    as input to this model
    """

    id = str
    """
    id
    """

    Language = str
    """
    If specified, model is for
     one language
    """

    Model_Directory = str
    """
    Relative path where model artifacts are
    """

    Model_Index = str
    """
    Unique index within this list of models at this level
    """

    Model_Label = str
    """
    Unique label within this list of models at this level
    """

    Model_Name = str
    """
    Unique name within this list of models at this level
    """

    Model_Sequence = str
    """
    Level of model,
     2 for 2nd-level model
    """

    def __init__(self):
        self.Base_Model_Version = ''
        self.Country = ''
        self.Doc_Class = ''
        self.Full_Classification_List = []
        self.id = ''
        self.Language = ''
        self.Model_Directory = ''
        self.Model_Index = ''
        self.Model_Label = ''
        self.Model_Name = ''
        self.Model_Sequence = ''


class IQVFormularyItem(object):
    """
    
    """

    Client = str
    """
    system connecting to AI
    """

    DrugName = str
    """
    system connecting to AI
    """

    DrugSpecialCode = str
    """
    system connecting to AI
    """

    DrugTier = str
    """
    system connecting to AI
    """

    id = str
    """
    unique id
    """

    PBM = str
    """
    system connecting to AI
    """

    Properties = []
    """
    Properties for this element. If this is
     <see cref="!:element_type" />==data_file or data_element,
    then the relevant properties are primarily determined by the
     designer of the model. For example, the language of the
     data_file may be relevant for one model and should be captured. For
    a different model, the language might be irrelevant and does not
    need to be captured.
    <a href="#IQVKeyValueSet.key">IQVKeyValueSet.key</a> See standardized key listing
    <a href="#IQVKeyValueSet.value">IQVKeyValueSet.value</a> See standardized key listing
    <a href="#IQVKeyValueSet.confidence">IQVKeyValueSet.confidence</a> is 0 to 1 confidence value
    """

    Source = str
    """
    system connecting to AI
    """

    source_system = str
    """
    system connecting to AI
    """

    SourceDate = str
    """
    YYYYMMDDHHMMSS
    """

    def __init__(self):
        self.Client = ''
        self.DrugName = ''
        self.DrugSpecialCode = ''
        self.DrugTier = ''
        self.id = ''
        self.PBM = ''
        self.Properties = []
        self.Source = ''
        self.source_system = ''
        self.SourceDate = ''
        self.id = str(uuid.uuid1())
