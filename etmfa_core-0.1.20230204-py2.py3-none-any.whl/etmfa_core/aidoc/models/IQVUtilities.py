from datetime import datetime

from enum import Enum


class Constants:
    """ Misc util constants. """
    PPI_RESOLUTION = 72
    # Ratio based on letter format settings 1.5 inches / 11 inches
    RELATIVE_AREA_HEADER = 0.136


class ROI_TYPE(Enum):
    DEFAULT = -1
    """
    Not set
    """

    BOX_AREA_FULL_PAGE_DEFAULT = 0
    BOX_AREA_LEFT_MARGIN = 1
    BOX_AREA_RIGHT_MARGIN = 2
    BOX_AREA_TOP_MARGIN = 3
    BOX_AREA_BOTTOM_MARGIN = 4
    BOX_AREA_CENTER_THIRD = 5
    BOX_AREA_CENTER_1 = 6
    BOX_AREA_LEFT_TOP_1 = 7
    BOX_AREA_TOP_1 = 8
    BOX_AREA_RIGHT_TOP_1 = 9
    BOX_AREA_RIGHT_1 = 10
    BOX_AREA_RIGHT_BOTTOM_1 = 11
    BOX_AREA_BOTTOM_1 = 12
    BOX_AREA_LEFT_BOTTOM_1 = 13
    BOX_AREA_LEFT_1 = 14
    BOX_AREA_CENTER_NEGATIVE_MARGINS = 15

    IMAGE_DEFAULT = 100
    """
    Image default, needs to be processed by OCR
    """

    IMAGE_SHAPE = 101
    IMAGE_SHAPE_PARAGRAPH_TEXT = 102
    IMAGE_HEADER = 103
    IMAGE_FOOTER = 104
    IMAGE_BLOB = 105

    HEADER_DEFAULT = 200
    HEADER_w_p = 201
    HEADER_w_r = 202
    HEADER_w_t = 203

    FOOTER_DEFAULT = 300
    FOOTER_w_p = 301
    FOOTER_w_r = 302
    FOOTER_w_t = 303

    PARAGRAPH_DEFAULT = 400
    """
    Paragraph default, such as a block from digitized PDF,
    or major segment from spatial classifier
    """

    PARAGRAPH_w_p = 401
    PARAGRAPH_w_r = 402
    PARAGRAPH_w_t = 403

    PARAGRAPH_TOC_ELEMENT = 404
    PARAGRAPH_BULLETED_TEXT = 405

    PARAGRAPH_CENTERED_TEXT = 406
    PARAGRAPH_NONSTANDARD_DEFAULT = 407
    PARAGRAPH_SIGNATURE_BLOCK = 408

    PARAGRAPH_LINE = 409
    """
    Line within a paragraph
    """

    PARAGRAPH_SPAN = 410
    """
    text span within a paragraph line
    """

    TABLE = 500
    TABLE_tc = 501  # cell
    TABLE_row = 502  # row

    MESSAGE_FROM = 600
    MESSAGE_RECIPIENT = 601
    MESSAGE_SUBJECT = 602
    MESSAGE_BODY = 603
    MESSAGE_DATE = 604
    MESSAGE_ATTACHMENT = 605
    MESSAGE_RECIPIENT_CC = 606
    MESSAGE_RECIPIENT_BCC = 607

    LETTER_HEADER_LEFT_COLUMN = 700
    LETTER_HEADER_RIGHT_COLUMN = 701
    LETTER_HEADER_CENTER_COLUMN = 702
    LETTER_HEADER_STAMP = 703

    HYPERLINK = 900

    """
    For simlated_scanned_pdf, In case of a processed pdf that is not well-behaved, a
    simulated full-page scan is created
    """
    SIMULATED_SCAN = 1000



def GetDateTimeString():
    """Get the UTC date/time as 14-character string YYYYMMDDHHMMSS

    return: UTC time as 14-character string YYYYMMDDHHMMSS"""
    
    date = datetime.utcnow()
    return '{:04d}{:02d}{:02d}{:02d}{:02d}{:02d}'.format(
        date.year, date.month, date.day, date.hour, date.minute, date.second)
