from etmfa_core.aidoc.models.IQVDocument import IQVPageROI

roi_type_codes = {
    'other': 100,
    'text': 400,
    'table': 500
}


def parse_segment_as_iqv_page(segment):
    """
    Fill IQVPageROI structure with segment location, type and image location information
    :param segment: Image segment represented as a dictionary
    :return: Image segment represented as a IQVPageROI
    """
    xmin = segment.get('xmin')
    ymin = segment.get('ymin')
    xmax = segment.get('xmax')
    ymax = segment.get('ymax')

    segment_path = segment.get('path')
    if not segment_path:
        return None

    segment_type = segment.get('class')
    if not segment_type:
        return None

    type_code = roi_type_codes.get(segment_type)
    if not type_code:
        return None

    segment_roi = IQVPageROI()

    segment_roi.OutputImageFilename_FinalImageProcessingOutput = segment_path
    segment_roi.m_ROI_TYPEVal = type_code
    segment_roi.m_PARENT_ROI_TYPEVal = 0

    segment_roi.rectangle.X = xmin
    segment_roi.rectangle.Y = ymin
    segment_roi.rectangle.Width = xmax - xmin
    segment_roi.rectangle.Height = ymax - ymin

    return segment_roi
