import logging
import re
from typing import List

from etmfa_core.aidoc.models.IQVDocument import *
from etmfa_core.aidoc.models.IQVUtilities import Constants

logger = logging.getLogger('etmfa_core.aidoc')

def GetPropertyIQVKeyValueSetFromIQVDocument(iqvDocument:IQVDocument,
    key:str    
):
    """
    Get IQVKeyValueSet from the IQVDocument properties.
    Assume there is only a single match (handled in set property)
    This is from the document-level properties.

    :param iqvDocument: the document resource
    :param key: the property key
    :returns: IQVKeyValueSet where key=key
    """
    try:
        keymatch = key.lower().strip()
        for kv in iqvDocument.Properties:
            kvkey = kv.key.lower().strip()
            if kvkey == keymatch:
                return kv
    except Exception as e:
        return None


def GetPropertyFromIQVDocument(iqvDocument:IQVDocument,
    key:str    
):
    """
    Get any property from the IQVDocument.
    Assume there is only a single match (handled in set property)
    This is from the document-level properties.

    :param iqvDocument: the document resource
    :param key: the property key
    :returns: tuple (value, confidence) 
        WHERE
        str value is property value
        float confidence is confidence of correctness of value
    """
    try:
        kv = GetPropertyIQVKeyValueSetFromIQVDocument(iqvDocument, key)
        if kv is None:
            return None
        else:
            return [kv.value, kv.confidence]        
    except Exception as e:
        return None


def GetIndication(iqvDocument:IQVDocument):
    """
    Get indication property from the IQVDocument.
    This is a document-level property.

    :param iqvDocument: the document resource
    :returns: tuple (value, confidence) 
        WHERE
        str value is property value
        float confidence is confidence of correctness of value
    """
    try:
        key = IQV_KEY_STRING.KEY_indication
        return GetPropertyFromIQVDocument(iqvDocument, key)
    except Exception as e:
        return None


def GetPropertyIQVKeyValueSetFromIQVPageROI(roi:IQVPageROI,
    key:str    
):
    """
    Get IQVKeyValueSet from the IQVPageROI properties.
    Assume there is only a single match (handled in set property)
    This is from the ROI-level properties.

    :param roi: the region of interest (ROI), such as paragraph
    :param key: the property key
    :returns: IQVKeyValueSet where key=key
    """
    try:
        keymatch = key.lower().strip()
        for kv in roi.Properties:
            kvkey = kv.key.lower().strip()
            if kvkey == keymatch:
                return kv
    except Exception as e:
        return None


def GetPropertyFromIQVPageROI(roi:IQVPageROI,
    key:str    
):
    """
    Get any property from the IQVPageROI.
    Assume there is only a single match (handled in set property)
    This is from the ROI-level properties.

    :param roi: the region of interest (ROI), such as paragraph
    :param key: the property key
    :returns: tuple (value, confidence) 
        WHERE
        str value is property value
        float confidence is confidence of correctness of value
    """
    try:
        kv = GetPropertyIQVKeyValueSetFromIQVPageROI(roi, key)
        if kv is None:
            return None
        else:
            return [kv.value, kv.confidence]        
    except Exception as e:
        return None


def GetFontSize(roi:IQVPageROI):
    """
    Get font size property from the IQVPageROI.
    This is a ROI-level property.

    :param roi: the region of interest (ROI), such as paragraph
    :returns: tuple (value, confidence) 
        WHERE
        str value is property value
        float confidence is confidence of correctness of value
    """
    try:
        key = IQV_KEY_STRING.KEY_font_size
        return GetPropertyFromIQVPageROI(roi, key)
    except Exception as e:
        return None
