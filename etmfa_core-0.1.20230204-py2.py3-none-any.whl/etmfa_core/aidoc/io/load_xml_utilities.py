import logging
from ..models.IQVDocument import *
from .load_xml_db import *
import psycopg2
import operator
import math

logger = logging.getLogger('etmfa_core.aidoc')


def get_table_column_count(roi):
    """
    Assuming that input is a table,
    return max number of columns in the table rows
    :param roi:input IQVPageROI as logical table
    :returns column count
    """
    numCols = 0;
    try:
        for row in roi.ChildBoxes:
            if len(row.ChildBoxes) > numCols:
                numCols = len(row.ChildBoxes)
    except Exception as e:
        logger.exception(e)
    return numCols;

def get_property(roi, property_key):
    """
    Given property key of an object
    return value of the property
    :param roi:input IQVPageROI or object with Properties
    :param property_key:key of property as a string
    :returns property value, or empty string if not found
    """
    property_value = ''
    try:
        for prop in roi.Properties:
            if prop.key == property_key:
                property_value = prop.value
                break;
    except Exception as e:
        logger.exception(e)
    return property_value


def get_soa_links(doc):
    """
    Given document IQVDocument
    return list of SOA links
    :param doc:input IQVDocument
    :returns list of SOA links/section headers
    """
    links = []
    try:
        for link in doc.DocumentLinks:
            soa_prop = get_property(link, "IsSOALink")  # IQV_KEY_STRING.KEY_IsSOALink, thisLinkTables.Count
            if len(soa_prop)>0:
                links.append(link)
    except Exception as e:
        logger.exception(e)
    return links


def get_compiled_soa(doc):
    """
    Get the SOA as list of logical tables
    Given document IQVDocument
    :param doc:input IQVDocument
    :returns list of SOA tables
    """
    soa_list = []
    try:
        matchMin = 0.7;
        cntTables = 0;
        linkTables = [];
        allSOALinks = [];
        allNonSOALinks = [];

        # section-centric
        # block-centric

        # get links this link and next link
        maxConf = 0;
        minConf = 0.7;

        #
        # find max conf in links
        #
        soa_links = get_soa_links(doc)
        pkpd_links = []  # get_pkpd_links(doc);
        #
        # remove pkpd
        # 
        if len(soa_links)>0 and len(pkpd_links)>0:
            tmp_soa_links = [];
            for tmp_soa_link in soa_links:
                bFoundInPKPD = False
                for pkpd_link in pkpd_links:
                    if tmp_soa_link.id == pkpd_link.id:
                        bFoundInPKPD = True
                        break;
                if not bFoundInPKPD:
                    tmp_soa_links.append(tmp_soa_link)
            if len(tmp_soa_links)>0:
                soa_links.clear()
                for soa_link in tmp_soa_links:
                    soa_links.append(soa_link)
        #
        # sort links
        # add GetPropertyAsInt(IQV_KEY_STRING.KEY_Y) if necessary
        #
        sorted(soa_links, key=operator.attrgetter("LinkType","DocumentSequenceIndex","LinkPage"));
        #
        # get groups
        #
        soa_links_groups = []
        link_group = []
        link_group_page = -1
        if len(soa_links)>0:
            link_group.append(soa_links[0])
            link_group_page = soa_links[0].LinkPage
        cnt_links = 0
        for soa_link in soa_links:
            cnt_links += 1
            if cnt_links <= 1:
                continue;
            if soa_link.LinkPage == link_group_page:
                link_group.append(soa_link)
            else:
                soa_links_groups.append(link_group)
                link_group = []
                link_group.append(soa_link)
                link_group_page = soa_link.LinkPage 
        if len(link_group)>0:
            soa_links_groups.append(link_group)
        last_page = -1
        this_link_tables = []
        for link_group1 in soa_links_groups:
            this_link_tables = []
            for next_link in link_group1:
                bMatchThisLink = False;
                # nextLink2 = None;
                # nextLink2 = get_next_link(doc, next_link)
                for roi_table in doc.DocumentTables:
                    linkROI_id = get_property(roi_table, "LinkROI")  # (IQV_KEY_STRING.KEY_LinkROI);
                    if (linkROI_id != next_link.id):
                        continue;
                    #
                    # is a valid table?
                    # often footnotes are listed as a "table"
                    #
                    numcols = get_table_column_count(roi_table);
                    if numcols < 5: # <= 2:
                        continue;
                    this_link_tables.append(roi_table)
            #
            # now create compiled soa table for this link group
            #
            soa = None
            for roi in this_link_tables:   
                if soa is not None:
                    bMatchCurrentSOA = False;
                    currentSOACols = 0;
                    roiCols = 0;
                    currentRow0Text = "";
                    roiRow0Text = "";
                    if len(roi.ChildBoxes) > 0:
                        roiRow0Text = roi.ChildBoxes[0].GetFullText();
                    if len(soa.ChildBoxes) > 0:
                        currentRow0Text = soa.ChildBoxes[0].GetFullText();
                    for roiRow in roi.ChildBoxes:
                        if len(roiRow.ChildBoxes) > roiCols:
                            roiCols = len(roiRow.ChildBoxes)
                    for roiRow in soa.ChildBoxes:
                        if len(roiRow.ChildBoxes) > currentSOACols:
                            currentSOACols = len(roiRow.ChildBoxes)
                    #######################################################
                    #
                    # match to last soa in this section
                    #
                    # depends on num columns, but this is not robust in some cases (merge issues)
                    # provide some leniency on this restriction, can be off by 1 in column count
                    #  if row 1 is good match by text
                    #
                    ########################################################
                    codedText = "";
                    diff_cols = currentSOACols - roiCols
                    if diff_cols < 0:
                        diff_cols = diff_cols * -1
                    if (currentSOACols == roiCols):
                        bMatchCurrentSOA = True;
                    elif diff_cols <= 1:     #  and FuzzySearch.IsFuzzyMatch(roiRow0Text, currentRow0Text, ref codedText))
                        bMatchCurrentSOA = True;
                    if bMatchCurrentSOA:
                        for table_item in roi.ChildBoxes:
                            bSetProp = False
                            for prop in table_item.Properties:
                                if prop.key == "PhysicalTableIndex":
                                    bSetProp = True
                                    prop.value = str(cntTables)
                            if not bSetProp:
                                prop = IQVKeyValueSet()
                                prop.key = "PhysicalTableIndex"
                                prop.value = str(cntTables)
                                table_item.Properties.append(prop)
                            soa.ChildBoxes.append(tableItem);
                        #
                        # Also add attachments (footnotes)!!!!!!!!!!!!
                        #
                        for attachment in roi.Attachments:
                            soa.Attachments.append(attachment)
                    else:
                        soa_list.append(soa)
                        soa = None;
                        soa = roi
                else:
                    soa = roi
                cntTables += 1
            if soa is not None:
                soa_list.append(soa)


    except Exception as e:
        logger.exception(e);
    return soa_list;
