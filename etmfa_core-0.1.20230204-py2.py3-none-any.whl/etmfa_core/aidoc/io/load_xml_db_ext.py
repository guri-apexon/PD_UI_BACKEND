import logging

from ..models.IQVUtilities import GetDateTimeString
from ..models.IQVDocument import *
from .load_xml_db import *
import psycopg2
import operator

logger = logging.getLogger('etmfa_core.aidoc')

####################################################
#
# Document Element--all types
#
####################################################
def GetDocumentElementListFromDBByParentID_with_doc_id(
    documentelements_db_List,
    parent_id,
    table_name,
    group_type,
    hierarchy):
    """
    Given parent_id and parent group_type,
    retrieve the list of high-level object from list of elements iqvpageroi_db
    :param name="documentelements_db_List">connection already established</param>
    :param name="obj_list">object list to be instantiated</param>
    :param name="parent_id">primary key of parent object</param>
    :param name="table_name">default is iqvpageroi_db</param>
    :param name="group_type">used in where clause</param>
    :param hierarchy: para, table, etc.
    <returns>list of objects</returns>
    """
    obj_list = []
    elements = [x for x in documentelements_db_List if x.parent_id == parent_id and x.hierarchy == hierarchy]
    if len(group_type) > 0 and len(elements) > 0:
        elements = [x for x in elements if x.group_type == group_type]
    for element in elements:
        obj_list.append(element);
    if len(obj_list) > 1:
        obj1 = obj_list[0]
        if hasattr(obj1, 'DocumentSequenceIndex'):
            # sort in ASCENDING order by sequence index
            # if obj_list[0].DocumentSequenceIndex is not None:
            obj_list.sort(key=lambda x: x.DocumentSequenceIndex)
    return obj_list;


def GetDocumentElementListFromDBByTerm_with_doc_id(
    documentelements_db_List,
    parent_id,
    table_name,
    group_type,
    hierarchy,
    iqv_standard_term):
    """
    Given parent_id and parent group_type,
    retrieve the list of high-level object from list of elements iqvpageroi_db
    :param name="documentelements_db_List">connection already established</param>
    :param name="obj_list">object list to be instantiated</param>
    :param name="parent_id">primary key of parent object</param>
    :param name="table_name">default is iqvpageroi_db</param>
    :param name="group_type">used in where clause</param>
    :param hierarchy: para, table, etc.
    :param iqv_standard_term: standard term lookup as in https://wiki.quintiles.net/display/PD/Standardized+Section+Headers
    <returns>list of objects</returns>
    """
    obj_list = []
    elements = [x for x in documentelements_db_List if x.parent_id == parent_id and x.hierarchy == hierarchy and x.iqv_standard_term == iqv_standard_term]
    if len(group_type) > 0 and len(elements) > 0:
        elements = [x for x in elements if x.group_type == group_type]
    for element in elements:
        obj_list.append(element);
    if len(obj_list) > 1:
        obj1 = obj_list[0]
        if hasattr(obj1, 'DocumentSequenceIndex'):
            # sort in ASCENDING order by sequence index
            # if obj_list[0].DocumentSequenceIndex is not None:
            obj_list.sort(key=lambda x: x.DocumentSequenceIndex)
    return obj_list;


def GetDocumentElementListFromDBByParentID_with_doc_id_d1(
    dict_documentelements_db_List,
    parent_id,
    table_name,
    group_type,
    hierarchy
):
    """
    Given parent_id and parent group_type,
    retrieve the list of high-level object from dictionary

    Notes:
    Filter by
        - group_type (child member/field name)
        - hierarchy (para, image, table, etc.)
    Sort by
        - DocumentSequenceIndex

    :param dict: connection already established
    :param obj_list: object list to be instantiated
    :param parent_id: primary key of parent object
    :param table_name: default is iqvpageroi_db
    :param group_type: used in where clause
    :returns list of objects
    """
    obj_list = []
    parent_id = hierarchy + parent_id;
    if parent_id in dict_documentelements_db_List:
        obj_list = dict_documentelements_db_List[parent_id]
    if len(group_type)>0:
        final_list = [] 
        for element in obj_list:
            if element.group_type == group_type:  # and element.hierarchy == hierarchy:
                final_list.append(element)
        ##########################################
        #
        # Sort objects!
        #
        ##########################################
        if len(final_list) > 1:
            obj1 = final_list[0]
            if hasattr(obj1, 'DocumentSequenceIndex'):
                # sort in ASCENDING order by sequence index
                # if obj_list[0].DocumentSequenceIndex is not None:
                final_list.sort(key=lambda x: x.DocumentSequenceIndex)
        # sorted(final_list, key=operator.attrgetter("DocumentSequenceIndex"));
        
        return final_list
    ##########################################
    #
    # Sort objects!
    #
    ##########################################
    if len(obj_list) > 1:
        obj1 = obj_list[0]
        if hasattr(obj1, 'DocumentSequenceIndex'):
            # sort in ASCENDING order by sequence index
            # if obj_list[0].DocumentSequenceIndex is not None:
            obj_list.sort(key=lambda x: x.DocumentSequenceIndex)
    # sorted(obj_list, key=operator.attrgetter("DocumentSequenceIndex"));

    return obj_list;


#############################################
#
# IQVPageROI
#
#############################################
def GetIQVPageROIElementsFromDB_with_doc_id_d1(
    obj,
    id,
    table_name,
    hierarchy,
    Dict_documentelements_db,  # dict
    Dict_FontInfo_db,  # dict
    IQVAttributeCandidate_db_List,
    NLP_Attribute_db_List,
    Dict_iqvtablecolumn_db,  # new dict IQVTableColumn_db_List,
    Dict_iqvtablecolumnheader_db,  # new dict IQVTableColumnHeader_db_List,
    Dict_iqvqcupdatetracking_db,  # new dict IQVQCUpdateTracking_db_List,
    IQVAttribute_db_List,
    Dict_IQVKeyValueSet_db,  # dict
    Dict_IQVSubText_db,  # dict
    Dict_NLP_Entity_db  # dict
    ):
    """
    Already have the <paramref name="obj"/>, now
    fill in the children and missing elements

    :param obj: primary object being constructed
    :param id: UUID of object
    :param table_name: table name
    :param hierarchy: paragraph, table, etc.
    :param Dict_documentelements_db: lookup dictionary of objects by parent id
    :param Dict_FontInfo_db: lookup dictionary of objects by parent id
    :param IQVAttributeCandidate_db_List: listing of objects
    :param Dict_IQVSubText_db: lookup dictionary of objects by parent id
    :param IQVQCUpdateTracking_db_List: listing of objects 
    :param Dict_IQVKeyValueSet_db: lookup dictionary of objects by parent id
    :param Dict_iqvtablecolumn_db: listing of objects
    :param NLP_Attribute_db_List: listing of objects
    :param Dict_NLP_Entity_db: lookup dictionary of objects by parent id
    :param IQVAttribute_db_List: listing of objects
    :returns obj: primary object being constructed

    """
    try:

        #        ///////////////////////////////////////////
        #        //
        #        // 2. child objects
        #        //
        #        ///////////////////////////////////////////

        #        //
        #        // first get high level
        #        //
        group_type = "";
        group_type = "ChildBoxes";
        obj.ChildBoxes = GetDocumentElementListFromDBByParentID_with_doc_id_d1(
            Dict_documentelements_db,
            obj.id,
            table_name,
            group_type,
            hierarchy);
        #        //
        #        // next get recursive levels
        #        //
        for para in obj.ChildBoxes:
            para = GetIQVPageROIElementsFromDB_with_doc_id_d1(
                para,
                "",
                table_name,
                hierarchy,
                Dict_documentelements_db,  # dict
                Dict_FontInfo_db,  # dict
                IQVAttributeCandidate_db_List,
                NLP_Attribute_db_List,
                Dict_iqvtablecolumn_db,  # new dict IQVTableColumn_db_List,
                Dict_iqvtablecolumnheader_db,  # new dict IQVTableColumnHeader_db_List,
                Dict_iqvqcupdatetracking_db,  # new dict IQVQCUpdateTracking_db_List,
                IQVAttribute_db_List,
                Dict_IQVKeyValueSet_db,  # dict
                Dict_IQVSubText_db,  # dict
                Dict_NLP_Entity_db  # dict
            );


        group_type = "Attachments";
        obj.Attachments = GetDocumentElementListFromDBByParentID_with_doc_id_d1(
            Dict_documentelements_db,
            obj.id,
            table_name,
            group_type,
            hierarchy);
        #        //
        #        // next get recursive levels
        #        //
        for para in obj.Attachments:
            para = GetIQVPageROIElementsFromDB_with_doc_id_d1(
                para,
                "",
                table_name,
                hierarchy,
                Dict_documentelements_db,  # dict
                Dict_FontInfo_db,  # dict
                IQVAttributeCandidate_db_List,
                NLP_Attribute_db_List,
                Dict_iqvtablecolumn_db,  # new dict IQVTableColumn_db_List,
                Dict_iqvtablecolumnheader_db,  # new dict IQVTableColumnHeader_db_List,
                Dict_iqvqcupdatetracking_db,  # new dict IQVQCUpdateTracking_db_List,
                IQVAttribute_db_List,
                Dict_IQVKeyValueSet_db,  # dict
                Dict_IQVSubText_db,  # dict
                Dict_NLP_Entity_db  # dict
            );


        #        //
        #        // first get high level
        #        //
        group_type = "Properties";
        table_name = "";
        obj.Properties = GetDocumentElementListFromDBByParentID_with_doc_id_d1(
            Dict_IQVKeyValueSet_db,
            obj.id,
            table_name,
            group_type,
            hierarchy);
        #        //
        #        // next get recursive levels
        #        //
        for para in obj.Properties:
            para = GetIQVKeyValueSetElementsFromDB_with_doc_id_d1(
                para,
                "",
                table_name,
                hierarchy,
                Dict_documentelements_db,  # dict
                Dict_FontInfo_db,  # dict
                IQVAttributeCandidate_db_List,
                NLP_Attribute_db_List,
                Dict_iqvtablecolumn_db,  # new dict IQVTableColumn_db_List,
                Dict_iqvtablecolumnheader_db,  # new dict IQVTableColumnHeader_db_List,
                Dict_iqvqcupdatetracking_db,  # new dict IQVQCUpdateTracking_db_List,
                IQVAttribute_db_List,
                Dict_IQVKeyValueSet_db,  # dict
                Dict_IQVSubText_db,  # dict
                Dict_NLP_Entity_db  # dict
            );

        list = [];  # new List<FontInfo>();
        table_name = "";
        group_type = "";
        group_type = "fontInfo";
        list = GetDocumentElementListFromDBByParentID_with_doc_id_d1(
            Dict_FontInfo_db,
            obj.id,
            table_name,
            group_type,
            hierarchy);
        if len(list) > 0:
            obj.fontInfo = list[0]

        # // obj.IQVAttributeCandidates
        group_type = "IQVAttributeCandidates";
        obj.IQVAttributeCandidates = GetDocumentElementListFromDBByParentID_with_doc_id(
            IQVAttributeCandidate_db_List,
            obj.id,
            table_name,
            group_type,
            hierarchy);
        #        //
        #        // next get recursive levels
        #        //
        for para in obj.IQVAttributeCandidates:
            para = GetIQVAttributeCandidateElementsFromDB_with_doc_id_d1(
                para,
                "",
                table_name,
                hierarchy,
                Dict_documentelements_db,  # dict
                Dict_FontInfo_db,  # dict
                IQVAttributeCandidate_db_List,
                NLP_Attribute_db_List,
                Dict_iqvtablecolumn_db,  # new dict IQVTableColumn_db_List,
                Dict_iqvtablecolumnheader_db,  # new dict IQVTableColumnHeader_db_List,
                Dict_iqvqcupdatetracking_db,  # new dict IQVQCUpdateTracking_db_List,
                IQVAttribute_db_List,
                Dict_IQVKeyValueSet_db,  # dict
                Dict_IQVSubText_db,  # dict
                Dict_NLP_Entity_db  # dict
            );

        #        //obj.IQVSubTextList
        group_type = "IQVSubTextList";
        obj.IQVSubTextList = GetDocumentElementListFromDBByParentID_with_doc_id_d1(
            Dict_IQVSubText_db,
            obj.id,
            table_name,
            group_type,
            hierarchy);
        #        # 
        #        // next get recursive levels
        #        //
        for para in obj.IQVSubTextList:
            GetIQVSubTextElementsFromDB_with_doc_id_d1(
                para,
                "",
                table_name,
                hierarchy,
                Dict_documentelements_db,  # dict
                Dict_FontInfo_db,  # dict
                IQVAttributeCandidate_db_List,
                NLP_Attribute_db_List,
                Dict_iqvtablecolumn_db,  # new dict IQVTableColumn_db_List,
                Dict_iqvtablecolumnheader_db,  # new dict IQVTableColumnHeader_db_List,
                Dict_iqvqcupdatetracking_db,  # new dict IQVQCUpdateTracking_db_List,
                IQVAttribute_db_List,
                Dict_IQVKeyValueSet_db,  # dict
                Dict_IQVSubText_db,  # dict
                Dict_NLP_Entity_db  # dict
            );

        #        //obj.IQVSubTextListTranslated
        group_type = "IQVSubTextListTranslated";
        obj.IQVSubTextListTranslated = GetDocumentElementListFromDBByParentID_with_doc_id_d1(
            Dict_IQVSubText_db,
            obj.id,
            table_name,
            group_type,
            hierarchy);
        #        //
        #        // next get recursive levels
        #        //
        for para in obj.IQVSubTextListTranslated:
            para = GetIQVSubTextElementsFromDB_with_doc_id_d1(
                para,
                "",
                table_name,
                hierarchy,
                Dict_documentelements_db,  # dict
                Dict_FontInfo_db,  # dict
                IQVAttributeCandidate_db_List,
                NLP_Attribute_db_List,
                Dict_iqvtablecolumn_db,  # new dict IQVTableColumn_db_List,
                Dict_iqvtablecolumnheader_db,  # new dict IQVTableColumnHeader_db_List,
                Dict_iqvqcupdatetracking_db,  # new dict IQVQCUpdateTracking_db_List,
                IQVAttribute_db_List,
                Dict_IQVKeyValueSet_db,  # dict
                Dict_IQVSubText_db,  # dict
                Dict_NLP_Entity_db  # dict
            );

        #        //obj.NLP_Attributes
        group_type = "NLP_Attributes";
        obj.NLP_Attributes = GetDocumentElementListFromDBByParentID_with_doc_id(
            NLP_Attribute_db_List,
            obj.id,
            table_name,
            group_type,
            hierarchy);
        #        //
        #        // next get recursive levels
        #        //
        for para in obj.NLP_Attributes:
            para = GetNLP_AttributeElementsFromDB_with_doc_id_d1(
                para,
                "",
                table_name,
                hierarchy,
                Dict_documentelements_db,  # dict
                Dict_FontInfo_db,  # dict
                IQVAttributeCandidate_db_List,
                NLP_Attribute_db_List,
                Dict_iqvtablecolumn_db,  # new dict IQVTableColumn_db_List,
                Dict_iqvtablecolumnheader_db,  # new dict IQVTableColumnHeader_db_List,
                Dict_iqvqcupdatetracking_db,  # new dict IQVQCUpdateTracking_db_List,
                IQVAttribute_db_List,
                Dict_IQVKeyValueSet_db,  # dict
                Dict_IQVSubText_db,  # dict
                Dict_NLP_Entity_db  # dict
            );

        #        //obj.NLP_Entities
        group_type = "NLP_Entities";
        obj.NLP_Entities = GetDocumentElementListFromDBByParentID_with_doc_id_d1(
            Dict_NLP_Entity_db,
            obj.id,
            table_name,
            group_type,
            hierarchy);
        #        //
        #        // next get recursive levels
        #        //
        for para in obj.NLP_Entities:
            para = GetNLP_EntityElementsFromDB_with_doc_id_d1(
                para,
                "",
                table_name,
                hierarchy,
                Dict_documentelements_db,  # dict
                Dict_FontInfo_db,  # dict
                IQVAttributeCandidate_db_List,
                NLP_Attribute_db_List,
                Dict_iqvtablecolumn_db,  # new dict IQVTableColumn_db_List,
                Dict_iqvtablecolumnheader_db,  # new dict IQVTableColumnHeader_db_List,
                Dict_iqvqcupdatetracking_db,  # new dict IQVQCUpdateTracking_db_List,
                IQVAttribute_db_List,
                Dict_IQVKeyValueSet_db,  # dict
                Dict_IQVSubText_db,  # dict
                Dict_NLP_Entity_db  # dict
            );

        #        //obj.OriginalSubTexts
        group_type = "OriginalSubTexts";
        obj.OriginalSubTexts = GetDocumentElementListFromDBByParentID_with_doc_id_d1(
            Dict_IQVSubText_db,
            obj.id,
            table_name,
            group_type,
            hierarchy);
        #        //
        #        // next get recursive levels
        #        //
        for para in obj.OriginalSubTexts:
            para = GetIQVSubTextElementsFromDB_with_doc_id_d1(
                para,
                "",
                table_name,
                hierarchy,
                Dict_documentelements_db,  # dict
                Dict_FontInfo_db,  # dict
                IQVAttributeCandidate_db_List,
                NLP_Attribute_db_List,
                Dict_iqvtablecolumn_db,  # new dict IQVTableColumn_db_List,
                Dict_iqvtablecolumnheader_db,  # new dict IQVTableColumnHeader_db_List,
                Dict_iqvqcupdatetracking_db,  # new dict IQVQCUpdateTracking_db_List,
                IQVAttribute_db_List,
                Dict_IQVKeyValueSet_db,  # dict
                Dict_IQVSubText_db,  # dict
                Dict_NLP_Entity_db  # dict
            );

        #        //obj.tableColumn
        listtc = [];  # new List<IQVTableColumn>();
        group_type = "tableColumn";
        listtc = GetDocumentElementListFromDBByParentID_with_doc_id_d1(
            Dict_iqvtablecolumn_db,   # IQVTableColumn_db_List,
            obj.id,
            table_name,
            group_type,
            hierarchy);
        if len(listtc) > 0:
            obj.tableColumn = listtc[0]
        #        //
        #        // next get recursive levels
        #        //
        obj.tableColumn = GetIQVTableColumnElementsFromDB_with_doc_id_d1(
            obj.tableColumn,
            "",
            table_name,
            hierarchy,
            Dict_documentelements_db,  # dict
            Dict_FontInfo_db,  # dict
            IQVAttributeCandidate_db_List,
            NLP_Attribute_db_List,
            Dict_iqvtablecolumn_db,  # new dict IQVTableColumn_db_List,
            Dict_iqvtablecolumnheader_db,  # new dict IQVTableColumnHeader_db_List,
            Dict_iqvqcupdatetracking_db,  # new dict IQVQCUpdateTracking_db_List,
            IQVAttribute_db_List,
            Dict_IQVKeyValueSet_db,  # dict
            Dict_IQVSubText_db,  # dict
            Dict_NLP_Entity_db  # dict
        );

        #        //obj.TableColumns
        group_type = "TableColumns";
        obj.TableColumns = GetDocumentElementListFromDBByParentID_with_doc_id_d1(
            Dict_iqvtablecolumn_db,   # IQVTableColumn_db_List,
            obj.id,
            table_name,
            group_type,
            hierarchy);
        #        //
        #        // next get recursive levels
        #        //
        for para in obj.TableColumns:
            para = GetIQVTableColumnElementsFromDB_with_doc_id_d1(
                para,
                "",
                table_name,
                hierarchy,
                Dict_documentelements_db,  # dict
                Dict_FontInfo_db,  # dict
                IQVAttributeCandidate_db_List,
                NLP_Attribute_db_List,
                Dict_iqvtablecolumn_db,  # new dict IQVTableColumn_db_List,
                Dict_iqvtablecolumnheader_db,  # new dict IQVTableColumnHeader_db_List,
                Dict_iqvqcupdatetracking_db,  # new dict IQVQCUpdateTracking_db_List,
                IQVAttribute_db_List,
                Dict_IQVKeyValueSet_db,  # dict
                Dict_IQVSubText_db,  # dict
                Dict_NLP_Entity_db  # dict
            );

        #        //obj.QCUpdates
        group_type = "QCUpdates";
        obj.QCUpdates = GetDocumentElementListFromDBByParentID_with_doc_id_d1(
            Dict_iqvqcupdatetracking_db,            # IQVQCUpdateTracking_db_List,
            obj.id,
            table_name,
            group_type,
            hierarchy);
        #        //
        #        // next get recursive levels
        #        //
        for para in obj.QCUpdates:
            para = GetIQVQCUpdateTrackingElementsFromDB_with_doc_id_d1(
                para,
                "",
                table_name,
                hierarchy,
                Dict_documentelements_db,  # dict
                Dict_FontInfo_db,  # dict
                IQVAttributeCandidate_db_List,
                NLP_Attribute_db_List,
                Dict_iqvtablecolumn_db,  # new dict IQVTableColumn_db_List,
                Dict_iqvtablecolumnheader_db,  # new dict IQVTableColumnHeader_db_List,
                Dict_iqvqcupdatetracking_db,  # new dict IQVQCUpdateTracking_db_List,
                IQVAttribute_db_List,
                Dict_IQVKeyValueSet_db,  # dict
                Dict_IQVSubText_db,  # dict
                Dict_NLP_Entity_db  # dict
            );

        return obj;
    except psycopg2.DatabaseError as nex:
        logger.exception(nex);
        return None;
    except Exception as e:
        logger.exception(e);
        return None;


def GetIQVDocumentFeedbackResultsElementsFromDB_with_doc_id_d1(
    obj,
    id,
    table_name,
    hierarchy,
    Dict_documentelements_db,  # dict
    Dict_FontInfo_db,  # dict
    IQVAttributeCandidate_db_List,
    NLP_Attribute_db_List,
    Dict_iqvtablecolumn_db,  # new dict IQVTableColumn_db_List,
    Dict_iqvtablecolumnheader_db,  # new dict IQVTableColumnHeader_db_List,
    Dict_iqvqcupdatetracking_db,  # new dict IQVQCUpdateTracking_db_List,
    IQVAttribute_db_List,
    Dict_IQVKeyValueSet_db,  # dict
    Dict_IQVSubText_db,  # dict
    Dict_NLP_Entity_db  # dict
    ):
    """
    Already have the <paramref name="obj"/>, now
    fill in the children and missing elements

    :param obj: primary object being constructed
    :param id: UUID of object
    :param table_name: table name
    :param Dict_documentelements_db: lookup dictionary of objects by parent id
    :param Dict_FontInfo_db: lookup dictionary of objects by parent id
    :param IQVAttributeCandidate_db_List: listing of objects
    :param Dict_IQVSubText_db: lookup dictionary of objects by parent id
    :param IQVQCUpdateTracking_db_List: listing of objects 
    :param Dict_IQVKeyValueSet_db: lookup dictionary of objects by parent id
    :param Dict_iqvtablecolumn_db: listing of objects
    :param NLP_Attribute_db_List: listing of objects
    :param Dict_NLP_Entity_db: lookup dictionary of objects by parent id
    :param IQVAttribute_db_List: listing of objects
    :returns obj: primary object being constructed

    """
    try:

        #        ///////////////////////////////////////////
        #        //
        #        // 2. child objects
        #        //
        #        ///////////////////////////////////////////

        #        //
        #        // first get high level
        #        //
        group_type = "attribute_auxiliary_list";
        table_name = "";
        obj.Properties = GetDocumentElementListFromDBByParentID_with_doc_id_d1(
            Dict_IQVKeyValueSet_db,
            obj.id,
            table_name,
            group_type,
            hierarchy);
        #        //
        #        // next get recursive levels
        #        //
        for para in obj.attribute_auxiliary_list:
            para = GetIQVKeyValueSetElementsFromDB_with_doc_id_d1(
                para,
                "",
                table_name,
                hierarchy,
                Dict_documentelements_db,  # dict
                Dict_FontInfo_db,  # dict
                IQVAttributeCandidate_db_List,
                NLP_Attribute_db_List,
                Dict_iqvtablecolumn_db,  # new dict IQVTableColumn_db_List,
                Dict_iqvtablecolumnheader_db,  # new dict IQVTableColumnHeader_db_List,
                Dict_iqvqcupdatetracking_db,  # new dict IQVQCUpdateTracking_db_List,
                IQVAttribute_db_List,
                Dict_IQVKeyValueSet_db,  # dict
                Dict_IQVSubText_db,  # dict
                Dict_NLP_Entity_db  # dict
            );

        return obj;
    except psycopg2.DatabaseError as nex:
        logger.exception(nex);
        return None;
    except Exception as e:
        logger.exception(e);
        return None;




def GetIQVDocumentProcessElementsFromDB_with_doc_id_d1(
    obj,
    id,
    table_name,
    hierarchy,
    Dict_documentelements_db,  # dict
    Dict_FontInfo_db,  # dict
    IQVAttributeCandidate_db_List,
    NLP_Attribute_db_List,
    Dict_iqvtablecolumn_db,  # new dict IQVTableColumn_db_List,
    Dict_iqvtablecolumnheader_db,  # new dict IQVTableColumnHeader_db_List,
    Dict_iqvqcupdatetracking_db,  # new dict IQVQCUpdateTracking_db_List,
    IQVAttribute_db_List,
    Dict_IQVKeyValueSet_db,  # dict
    Dict_IQVSubText_db,  # dict
    Dict_NLP_Entity_db  # dict
    ):
    """
    Already have the <paramref name="obj"/>, now
    fill in the children and missing elements

    :param obj: primary object being constructed
    :param id: UUID of object
    :param table_name: table name
    :param Dict_documentelements_db: lookup dictionary of objects by parent id
    :param Dict_FontInfo_db: lookup dictionary of objects by parent id
    :param IQVAttributeCandidate_db_List: listing of objects
    :param Dict_IQVSubText_db: lookup dictionary of objects by parent id
    :param IQVQCUpdateTracking_db_List: listing of objects 
    :param Dict_IQVKeyValueSet_db: lookup dictionary of objects by parent id
    :param Dict_iqvtablecolumn_db: listing of objects
    :param NLP_Attribute_db_List: listing of objects
    :param Dict_NLP_Entity_db: lookup dictionary of objects by parent id
    :param IQVAttribute_db_List: listing of objects
    :returns obj: primary object being constructed

    """
    try:

        #        ///////////////////////////////////////////
        #        //
        #        // 2. child objects
        #        //
        #        ///////////////////////////////////////////

        #        //
        #        // first get high level
        #        //
        group_type = "KeyValues";
        table_name = "";
        obj.Properties = GetDocumentElementListFromDBByParentID_with_doc_id_d1(
            Dict_IQVKeyValueSet_db,
            obj.id,
            table_name,
            group_type,
            hierarchy);
        #        //
        #        // next get recursive levels
        #        //
        for para in obj.KeyValues:
            para = GetIQVKeyValueSetElementsFromDB_with_doc_id_d1(
                para,
                "",
                table_name,
                hierarchy,
                Dict_documentelements_db,  # dict
                Dict_FontInfo_db,  # dict
                IQVAttributeCandidate_db_List,
                NLP_Attribute_db_List,
                Dict_iqvtablecolumn_db,  # new dict IQVTableColumn_db_List,
                Dict_iqvtablecolumnheader_db,  # new dict IQVTableColumnHeader_db_List,
                Dict_iqvqcupdatetracking_db,  # new dict IQVQCUpdateTracking_db_List,
                IQVAttribute_db_List,
                Dict_IQVKeyValueSet_db,  # dict
                Dict_IQVSubText_db,  # dict
                Dict_NLP_Entity_db  # dict
            );

        return obj;
    except psycopg2.DatabaseError as nex:
        logger.exception(nex);
        return None;
    except Exception as e:
        logger.exception(e);
        return None;


#############################################
#
# IQVDocumentLink
#
#############################################
def GetIQVDocumentLinkElementsFromDB_with_doc_id_d1(
    obj,
    id,
    table_name,
    hierarchy,
    Dict_documentelements_db,  # dict
    Dict_FontInfo_db,  # dict
    IQVAttributeCandidate_db_List,
    NLP_Attribute_db_List,
    Dict_iqvtablecolumn_db,  # new dict IQVTableColumn_db_List,
    Dict_iqvtablecolumnheader_db,  # new dict IQVTableColumnHeader_db_List,
    Dict_iqvqcupdatetracking_db,  # new dict IQVQCUpdateTracking_db_List,
    IQVAttribute_db_List,
    Dict_IQVKeyValueSet_db,  # dict
    Dict_IQVSubText_db,  # dict
    Dict_NLP_Entity_db  # dict
    ):
    """
    Already have the <paramref name="obj"/>, now
    fill in the children and missing elements

    :param obj: primary object being constructed
    :param id: UUID of object
    :param table_name: table name
    :param Dict_documentelements_db: lookup dictionary of objects by parent id
    :param Dict_FontInfo_db: lookup dictionary of objects by parent id
    :param IQVAttributeCandidate_db_List: listing of objects
    :param Dict_IQVSubText_db: lookup dictionary of objects by parent id
    :param IQVQCUpdateTracking_db_List: listing of objects 
    :param Dict_IQVKeyValueSet_db: lookup dictionary of objects by parent id
    :param Dict_iqvtablecolumn_db: listing of objects
    :param NLP_Attribute_db_List: listing of objects
    :param Dict_NLP_Entity_db: lookup dictionary of objects by parent id
    :param IQVAttribute_db_List: listing of objects
    :returns obj: primary object being constructed

    """
    try:

        #        ///////////////////////////////////////////
        #        //
        #        // 2. child objects
        #        //
        #        ///////////////////////////////////////////

        #        # 
        #        // first get high level
        #        //
        group_type = "";
        group_type = "LinkDestinations";
        obj.LinkDestinations = GetDocumentElementListFromDBByParentID_with_doc_id_d1(
            Dict_documentelements_db,
            obj.id,
            table_name,
            group_type,
            hierarchy);
        #        //
        #        // next get recursive levels
        #        //
        for para in obj.LinkDestinations:
            para = GetIQVPageROIElementsFromDB_with_doc_id_d1(
                para,
                "",
                table_name,
                hierarchy,
                Dict_documentelements_db,  # dict
                Dict_FontInfo_db,  # dict
                IQVAttributeCandidate_db_List,
                NLP_Attribute_db_List,
                Dict_iqvtablecolumn_db,  # new dict IQVTableColumn_db_List,
                Dict_iqvtablecolumnheader_db,  # new dict IQVTableColumnHeader_db_List,
                Dict_iqvqcupdatetracking_db,  # new dict IQVQCUpdateTracking_db_List,
                IQVAttribute_db_List,
                Dict_IQVKeyValueSet_db,  # dict
                Dict_IQVSubText_db,  # dict
                Dict_NLP_Entity_db  # dict
            );

        #        # 
        #        // first get high level
        #        //
        group_type = "";
        group_type = "LinkPointers";
        obj.LinkPointers = GetDocumentElementListFromDBByParentID_with_doc_id_d1(
            Dict_documentelements_db,
            obj.id,
            table_name,
            group_type,
            hierarchy);
        #        //
        #        // next get recursive levels
        #        //
        for para in obj.LinkPointers:
            para = GetIQVPageROIElementsFromDB_with_doc_id_d1(
                para,
                "",
                table_name,
                hierarchy,
                Dict_documentelements_db,  # dict
                Dict_FontInfo_db,  # dict
                IQVAttributeCandidate_db_List,
                NLP_Attribute_db_List,
                Dict_iqvtablecolumn_db,  # new dict IQVTableColumn_db_List,
                Dict_iqvtablecolumnheader_db,  # new dict IQVTableColumnHeader_db_List,
                Dict_iqvqcupdatetracking_db,  # new dict IQVQCUpdateTracking_db_List,
                IQVAttribute_db_List,
                Dict_IQVKeyValueSet_db,  # dict
                Dict_IQVSubText_db,  # dict
                Dict_NLP_Entity_db  # dict
            );

        #        //
        #        // first get high level
        #        //
        group_type = "Properties";
        table_name = "";
        obj.Properties = GetDocumentElementListFromDBByParentID_with_doc_id_d1(
            Dict_IQVKeyValueSet_db,
            obj.id,
            table_name,
            group_type,
            hierarchy);
        #        //
        #        // next get recursive levels
        #        //
        for para in obj.Properties:
            para = GetIQVKeyValueSetElementsFromDB_with_doc_id_d1(
                para,
                "",
                table_name,
                hierarchy,
                Dict_documentelements_db,  # dict
                Dict_FontInfo_db,  # dict
                IQVAttributeCandidate_db_List,
                NLP_Attribute_db_List,
                Dict_iqvtablecolumn_db,  # new dict IQVTableColumn_db_List,
                Dict_iqvtablecolumnheader_db,  # new dict IQVTableColumnHeader_db_List,
                Dict_iqvqcupdatetracking_db,  # new dict IQVQCUpdateTracking_db_List,
                IQVAttribute_db_List,
                Dict_IQVKeyValueSet_db,  # dict
                Dict_IQVSubText_db,  # dict
                Dict_NLP_Entity_db  # dict
            );


        return obj;
    except psycopg2.DatabaseError as nex:
        logger.exception(nex);
        return None;
    except Exception as e:
        logger.exception(e);
        return None;


#############################################
#
# IQVKeyValueSet
#
#############################################
def GetIQVKeyValueSetElementsFromDB_with_doc_id_d1(
    obj,
    id,
    table_name,
    hierarchy,
    Dict_documentelements_db,  # dict
    Dict_FontInfo_db,  # dict
    IQVAttributeCandidate_db_List,
    NLP_Attribute_db_List,
    Dict_iqvtablecolumn_db,  # new dict IQVTableColumn_db_List,
    Dict_iqvtablecolumnheader_db,  # new dict IQVTableColumnHeader_db_List,
    Dict_iqvqcupdatetracking_db,  # new dict IQVQCUpdateTracking_db_List,
    IQVAttribute_db_List,
    Dict_IQVKeyValueSet_db,  # dict
    Dict_IQVSubText_db,  # dict
    Dict_NLP_Entity_db  # dict
    ):
    """
    Already have the <paramref name="obj"/>, now
    fill in the children and missing elements

    :param obj: primary object being constructed
    :param id: UUID of object
    :param table_name: table name
    :param hierarchy: paragraph, table, etc.
    :param Dict_documentelements_db: lookup dictionary of objects by parent id
    :param Dict_FontInfo_db: lookup dictionary of objects by parent id
    :param IQVAttributeCandidate_db_List: listing of objects
    :param Dict_IQVSubText_db: lookup dictionary of objects by parent id
    :param IQVQCUpdateTracking_db_List: listing of objects 
    :param Dict_IQVKeyValueSet_db: lookup dictionary of objects by parent id
    :param Dict_iqvtablecolumn_db: listing of objects
    :param NLP_Attribute_db_List: listing of objects
    :param Dict_NLP_Entity_db: lookup dictionary of objects by parent id
    :param IQVAttribute_db_List: listing of objects
    :returns obj: primary object being constructed

    """
    try:

        #        ///////////////////////////////////////////
        #        //
        #        // 2. child objects
        #        //
        #        ///////////////////////////////////////////

        #        //obj.NLP_Attributes
        group_type = "NLP_Attributes";
        obj.NLP_Attributes = GetDocumentElementListFromDBByParentID_with_doc_id(
            NLP_Attribute_db_List,
            obj.id,
            table_name,
            group_type,
            hierarchy);
        #        //
        #        // next get recursive levels
        #        //
        for para in obj.NLP_Attributes:
            para = GetNLP_AttributeElementsFromDB_with_doc_id_d1(
                para,
                "",
                table_name,
                hierarchy,
                Dict_documentelements_db,  # dict
                Dict_FontInfo_db,  # dict
                IQVAttributeCandidate_db_List,
                NLP_Attribute_db_List,
                Dict_iqvtablecolumn_db,  # new dict IQVTableColumn_db_List,
                Dict_iqvtablecolumnheader_db,  # new dict IQVTableColumnHeader_db_List,
                Dict_iqvqcupdatetracking_db,  # new dict IQVQCUpdateTracking_db_List,
                IQVAttribute_db_List,
                Dict_IQVKeyValueSet_db,  # dict
                Dict_IQVSubText_db,  # dict
                Dict_NLP_Entity_db  # dict
            );

        #        //obj.NLP_Entities
        group_type = "NLP_Entities";
        obj.NLP_Entities = GetDocumentElementListFromDBByParentID_with_doc_id_d1(
            Dict_NLP_Entity_db,
            obj.id,
            table_name,
            group_type,
            hierarchy);
        #        //
        #        // next get recursive levels
        #        //
        for para in obj.NLP_Entities:
            para = GetNLP_EntityElementsFromDB_with_doc_id_d1(
                para,
                "",
                table_name,
                hierarchy,
                Dict_documentelements_db,  # dict
                Dict_FontInfo_db,  # dict
                IQVAttributeCandidate_db_List,
                NLP_Attribute_db_List,
                Dict_iqvtablecolumn_db,  # new dict IQVTableColumn_db_List,
                Dict_iqvtablecolumnheader_db,  # new dict IQVTableColumnHeader_db_List,
                Dict_iqvqcupdatetracking_db,  # new dict IQVQCUpdateTracking_db_List,
                IQVAttribute_db_List,
                Dict_IQVKeyValueSet_db,  # dict
                Dict_IQVSubText_db,  # dict
                Dict_NLP_Entity_db  # dict
            );


        #        //obj.QCUpdates
        group_type = "QCUpdates";
        obj.QCUpdates = GetDocumentElementListFromDBByParentID_with_doc_id_d1(
            Dict_iqvqcupdatetracking_db,  #  IQVQCUpdateTracking_db_List,
            obj.id,
            table_name,
            group_type,
            hierarchy);
        #        //
        #        // next get recursive levels
        #        //
        for para in obj.QCUpdates:
            para = GetIQVQCUpdateTrackingElementsFromDB_with_doc_id_d1(
                para,
                "",
                table_name,
                hierarchy,
                Dict_documentelements_db,  # dict
                Dict_FontInfo_db,  # dict
                IQVAttributeCandidate_db_List,
                NLP_Attribute_db_List,
                Dict_iqvtablecolumn_db,  # new dict IQVTableColumn_db_List,
                Dict_iqvtablecolumnheader_db,  # new dict IQVTableColumnHeader_db_List,
                Dict_iqvqcupdatetracking_db,  # new dict IQVQCUpdateTracking_db_List,
                IQVAttribute_db_List,
                Dict_IQVKeyValueSet_db,  # dict
                Dict_IQVSubText_db,  # dict
                Dict_NLP_Entity_db  # dict
            );

        return obj;
    except psycopg2.DatabaseError as nex:
        logger.exception(nex);
        return None;
    except Exception as e:
        logger.exception(e);
        return None;



#############################################
#
# IQVAttributeCandidate
#
#############################################
def GetIQVAttributeCandidateElementsFromDB_with_doc_id_d1(
    obj,
    id,
    table_name,
    hierarchy,
    Dict_documentelements_db,  # dict
    Dict_FontInfo_db,  # dict
    IQVAttributeCandidate_db_List,
    NLP_Attribute_db_List,
    Dict_iqvtablecolumn_db,  # new dict IQVTableColumn_db_List,
    Dict_iqvtablecolumnheader_db,  # new dict IQVTableColumnHeader_db_List,
    Dict_iqvqcupdatetracking_db,  # new dict IQVQCUpdateTracking_db_List,
    IQVAttribute_db_List,
    Dict_IQVKeyValueSet_db,  # dict
    Dict_IQVSubText_db,  # dict
    Dict_NLP_Entity_db  # dict
    ):
    """
    Already have the <paramref name="obj"/>, now
    fill in the children and missing elements

    :param obj: primary object being constructed
    :param id: UUID of object
    :param table_name: table name
    :param Dict_documentelements_db: lookup dictionary of objects by parent id
    :param Dict_FontInfo_db: lookup dictionary of objects by parent id
    :param IQVAttributeCandidate_db_List: listing of objects
    :param Dict_IQVSubText_db: lookup dictionary of objects by parent id
    :param IQVQCUpdateTracking_db_List: listing of objects 
    :param Dict_IQVKeyValueSet_db: lookup dictionary of objects by parent id
    :param Dict_iqvtablecolumn_db: listing of objects
    :param NLP_Attribute_db_List: listing of objects
    :param Dict_NLP_Entity_db: lookup dictionary of objects by parent id
    :param IQVAttribute_db_List: listing of objects
    :returns obj: primary object being constructed

    """
    try:

        #        ///////////////////////////////////////////
        #        //
        #        // 2. child objects
        #        //
        #        ///////////////////////////////////////////

        #        # 
        #        // first get high level
        #        //
        group_type = "";

        #        //
        #        // first get high level
        #        //
        group_type = "Features";
        table_name = "";
        obj.Features = GetDocumentElementListFromDBByParentID_with_doc_id_d1(
            Dict_IQVKeyValueSet_db,
            obj.id,
            table_name,
            group_type,
            hierarchy);
        #        //
        #        // next get recursive levels
        #        //
        for para in obj.Features:
            para = GetIQVKeyValueSetElementsFromDB_with_doc_id_d1(
                para,
                "",
                table_name,
                hierarchy,
                Dict_documentelements_db,  # dict
                Dict_FontInfo_db,  # dict
                IQVAttributeCandidate_db_List,
                NLP_Attribute_db_List,
                Dict_iqvtablecolumn_db,  # new dict IQVTableColumn_db_List,
                Dict_iqvtablecolumnheader_db,  # new dict IQVTableColumnHeader_db_List,
                Dict_iqvqcupdatetracking_db,  # new dict IQVQCUpdateTracking_db_List,
                IQVAttribute_db_List,
                Dict_IQVKeyValueSet_db,  # dict
                Dict_IQVSubText_db,  # dict
                Dict_NLP_Entity_db  # dict
            );


        return obj;
    except psycopg2.DatabaseError as nex:
        logger.exception(nex);
        return None;
    except Exception as e:
        logger.exception(e);
        return None;



#############################################
#
# IQVSubText
#
#############################################
def GetIQVSubTextElementsFromDB_with_doc_id_d1(
    obj,
    id,
    table_name,
    hierarchy,
    Dict_documentelements_db,  # dict
    Dict_FontInfo_db,  # dict
    IQVAttributeCandidate_db_List,
    NLP_Attribute_db_List,
    Dict_iqvtablecolumn_db,  # new dict IQVTableColumn_db_List,
    Dict_iqvtablecolumnheader_db,  # new dict IQVTableColumnHeader_db_List,
    Dict_iqvqcupdatetracking_db,  # new dict IQVQCUpdateTracking_db_List,
    IQVAttribute_db_List,
    Dict_IQVKeyValueSet_db,  # dict
    Dict_IQVSubText_db,  # dict
    Dict_NLP_Entity_db  # dict
    ):
    """
    Already have the <paramref name="obj"/>, now
    fill in the children and missing elements

    :param obj: primary object being constructed
    :param id: UUID of object
    :param table_name: table name
    :param Dict_documentelements_db: lookup dictionary of objects by parent id
    :param Dict_FontInfo_db: lookup dictionary of objects by parent id
    :param IQVAttributeCandidate_db_List: listing of objects
    :param Dict_IQVSubText_db: lookup dictionary of objects by parent id
    :param IQVQCUpdateTracking_db_List: listing of objects 
    :param Dict_IQVKeyValueSet_db: lookup dictionary of objects by parent id
    :param Dict_iqvtablecolumn_db: listing of objects
    :param NLP_Attribute_db_List: listing of objects
    :param Dict_NLP_Entity_db: lookup dictionary of objects by parent id
    :param IQVAttribute_db_List: listing of objects
    :returns obj: primary object being constructed

    """
    try:

        #        ///////////////////////////////////////////
        #        //
        #        // 2. child objects
        #        //
        #        ///////////////////////////////////////////

        #        # 
        #        // first get high level
        #        //
        group_type = "";
        group_type = "Attributes";
        obj.Attributes = GetDocumentElementListFromDBByParentID_with_doc_id(
            IQVAttribute_db_List,
            obj.id,
            table_name,
            group_type,
            hierarchy);
        #        //
        #        // next get recursive levels
        #        //
        for para in obj.Attributes:
            para = GetIQVAttributeElementsFromDB_with_doc_id_d1(
                para,
                "",
                table_name,
                hierarchy,
                Dict_documentelements_db,  # dict
                Dict_FontInfo_db,  # dict
                IQVAttributeCandidate_db_List,
                NLP_Attribute_db_List,
                Dict_iqvtablecolumn_db,  # new dict IQVTableColumn_db_List,
                Dict_iqvtablecolumnheader_db,  # new dict IQVTableColumnHeader_db_List,
                Dict_iqvqcupdatetracking_db,  # new dict IQVQCUpdateTracking_db_List,
                IQVAttribute_db_List,
                Dict_IQVKeyValueSet_db,  # dict
                Dict_IQVSubText_db,  # dict
                Dict_NLP_Entity_db  # dict
            );

        #        //
        #        // first get high level
        #        //
        group_type = "Properties";
        table_name = "";
        obj.Properties = GetDocumentElementListFromDBByParentID_with_doc_id_d1(
            Dict_IQVKeyValueSet_db,
            obj.id,
            table_name,
            group_type,
            hierarchy);
        #        //
        #        // next get recursive levels
        #        //
        for para in obj.Properties:
            para = GetIQVKeyValueSetElementsFromDB_with_doc_id_d1(
                para,
                "",
                table_name,
                hierarchy,
                Dict_documentelements_db,  # dict
                Dict_FontInfo_db,  # dict
                IQVAttributeCandidate_db_List,
                NLP_Attribute_db_List,
                Dict_iqvtablecolumn_db,  # new dict IQVTableColumn_db_List,
                Dict_iqvtablecolumnheader_db,  # new dict IQVTableColumnHeader_db_List,
                Dict_iqvqcupdatetracking_db,  # new dict IQVQCUpdateTracking_db_List,
                IQVAttribute_db_List,
                Dict_IQVKeyValueSet_db,  # dict
                Dict_IQVSubText_db,  # dict
                Dict_NLP_Entity_db  # dict
            );

        list = [];  # new List<FontInfo>();
        table_name = "";
        group_type = "";
        group_type = "fontInfo";
        list = GetDocumentElementListFromDBByParentID_with_doc_id_d1(
            Dict_FontInfo_db,
            obj.id,
            table_name,
            group_type,
            hierarchy);
        if len(list) > 0:
            obj.fontInfo = list[0]


        #        //obj.NLP_Attributes
        group_type = "NLP_Attributes";
        obj.NLP_Attributes = GetDocumentElementListFromDBByParentID_with_doc_id(
            NLP_Attribute_db_List,
            obj.id,
            table_name,
            group_type,
            hierarchy);
        #        //
        #        // next get recursive levels
        #        //
        for para in obj.NLP_Attributes:
            para = GetNLP_AttributeElementsFromDB_with_doc_id_d1(
                para,
                "",
                table_name,
                hierarchy,
                Dict_documentelements_db,  # dict
                Dict_FontInfo_db,  # dict
                IQVAttributeCandidate_db_List,
                NLP_Attribute_db_List,
                Dict_iqvtablecolumn_db,  # new dict IQVTableColumn_db_List,
                Dict_iqvtablecolumnheader_db,  # new dict IQVTableColumnHeader_db_List,
                Dict_iqvqcupdatetracking_db,  # new dict IQVQCUpdateTracking_db_List,
                IQVAttribute_db_List,
                Dict_IQVKeyValueSet_db,  # dict
                Dict_IQVSubText_db,  # dict
                Dict_NLP_Entity_db  # dict
            );

        #        //obj.NLP_Entities
        group_type = "NLP_Entities";
        obj.NLP_Entities = GetDocumentElementListFromDBByParentID_with_doc_id_d1(
            Dict_NLP_Entity_db,
            obj.id,
            table_name,
            group_type,
            hierarchy);
        #        //
        #        // next get recursive levels
        #        //
        for para in obj.NLP_Entities:
            para = GetNLP_EntityElementsFromDB_with_doc_id_d1(
                para,
                "",
                table_name,
                hierarchy,
                Dict_documentelements_db,  # dict
                Dict_FontInfo_db,  # dict
                IQVAttributeCandidate_db_List,
                NLP_Attribute_db_List,
                Dict_iqvtablecolumn_db,  # new dict IQVTableColumn_db_List,
                Dict_iqvtablecolumnheader_db,  # new dict IQVTableColumnHeader_db_List,
                Dict_iqvqcupdatetracking_db,  # new dict IQVQCUpdateTracking_db_List,
                IQVAttribute_db_List,
                Dict_IQVKeyValueSet_db,  # dict
                Dict_IQVSubText_db,  # dict
                Dict_NLP_Entity_db  # dict
            );


        #        //obj.QCUpdates
        group_type = "QCUpdates";
        obj.QCUpdates = GetDocumentElementListFromDBByParentID_with_doc_id_d1(
            Dict_iqvqcupdatetracking_db,  #  IQVQCUpdateTracking_db_List,
            obj.id,
            table_name,
            group_type,
            hierarchy);
        #        //
        #        // next get recursive levels
        #        //
        for para in obj.QCUpdates:
            para = GetIQVQCUpdateTrackingElementsFromDB_with_doc_id_d1(
                para,
                "",
                table_name,
                hierarchy,
                Dict_documentelements_db,  # dict
                Dict_FontInfo_db,  # dict
                IQVAttributeCandidate_db_List,
                NLP_Attribute_db_List,
                Dict_iqvtablecolumn_db,  # new dict IQVTableColumn_db_List,
                Dict_iqvtablecolumnheader_db,  # new dict IQVTableColumnHeader_db_List,
                Dict_iqvqcupdatetracking_db,  # new dict IQVQCUpdateTracking_db_List,
                IQVAttribute_db_List,
                Dict_IQVKeyValueSet_db,  # dict
                Dict_IQVSubText_db,  # dict
                Dict_NLP_Entity_db  # dict
            );

        return obj;
    except psycopg2.DatabaseError as nex:
        logger.exception(nex);
        return None;
    except Exception as e:
        logger.exception(e);
        return None;


#############################################
#
# NLP_Attribute
#
#############################################
def GetNLP_AttributeElementsFromDB_with_doc_id_d1(
    obj,
    id,
    table_name,
    hierarchy,
    Dict_documentelements_db,  # dict
    Dict_FontInfo_db,  # dict
    IQVAttributeCandidate_db_List,
    NLP_Attribute_db_List,
    Dict_iqvtablecolumn_db,  # new dict IQVTableColumn_db_List,
    Dict_iqvtablecolumnheader_db,  # new dict IQVTableColumnHeader_db_List,
    Dict_iqvqcupdatetracking_db,  # new dict IQVQCUpdateTracking_db_List,
    IQVAttribute_db_List,
    Dict_IQVKeyValueSet_db,  # dict
    Dict_IQVSubText_db,  # dict
    Dict_NLP_Entity_db  # dict
    ):
    """
    Already have the <paramref name="obj"/>, now
    fill in the children and missing elements

    :param obj: primary object being constructed
    :param id: UUID of object
    :param table_name: table name
    :param Dict_documentelements_db: lookup dictionary of objects by parent id
    :param Dict_FontInfo_db: lookup dictionary of objects by parent id
    :param IQVAttributeCandidate_db_List: listing of objects
    :param Dict_IQVSubText_db: lookup dictionary of objects by parent id
    :param IQVQCUpdateTracking_db_List: listing of objects 
    :param Dict_IQVKeyValueSet_db: lookup dictionary of objects by parent id
    :param Dict_iqvtablecolumn_db: listing of objects
    :param NLP_Attribute_db_List: listing of objects
    :param Dict_NLP_Entity_db: lookup dictionary of objects by parent id
    :param IQVAttribute_db_List: listing of objects
    :returns obj: primary object being constructed

    """
    try:

        #        ///////////////////////////////////////////
        #        //
        #        // 2. child objects
        #        //
        #        ///////////////////////////////////////////

        #        # 
        #        // first get high level
        #        //
        group_type = "";

        return obj;
    except psycopg2.DatabaseError as nex:
        logger.exception(nex);
        return None;
    except Exception as e:
        logger.exception(e);
        return None;


#############################################
#
# IQVAttribute
#
#############################################
def GetIQVAttributeElementsFromDB_with_doc_id_d1(
    obj,
    id,
    table_name,
    hierarchy,
    Dict_documentelements_db,  # dict
    Dict_FontInfo_db,  # dict
    IQVAttributeCandidate_db_List,
    NLP_Attribute_db_List,
    Dict_iqvtablecolumn_db,  # new dict IQVTableColumn_db_List,
    Dict_iqvtablecolumnheader_db,  # new dict IQVTableColumnHeader_db_List,
    Dict_iqvqcupdatetracking_db,  # new dict IQVQCUpdateTracking_db_List,
    IQVAttribute_db_List,
    Dict_IQVKeyValueSet_db,  # dict
    Dict_IQVSubText_db,  # dict
    Dict_NLP_Entity_db  # dict
    ):
    """
    Already have the <paramref name="obj"/>, now
    fill in the children and missing elements

    :param obj: primary object being constructed
    :param id: UUID of object
    :param table_name: table name
    :param Dict_documentelements_db: lookup dictionary of objects by parent id
    :param Dict_FontInfo_db: lookup dictionary of objects by parent id
    :param IQVAttributeCandidate_db_List: listing of objects
    :param Dict_IQVSubText_db: lookup dictionary of objects by parent id
    :param IQVQCUpdateTracking_db_List: listing of objects 
    :param Dict_IQVKeyValueSet_db: lookup dictionary of objects by parent id
    :param Dict_iqvtablecolumn_db: listing of objects
    :param NLP_Attribute_db_List: listing of objects
    :param Dict_NLP_Entity_db: lookup dictionary of objects by parent id
    :param IQVAttribute_db_List: listing of objects
    :returns obj: primary object being constructed

    """
    try:

        #        ///////////////////////////////////////////
        #        //
        #        // 2. child objects
        #        //
        #        ///////////////////////////////////////////

        #        # 
        #        // first get high level
        #        //
        group_type = "";

        return obj;
    except psycopg2.DatabaseError as nex:
        logger.exception(nex);
        return None;
    except Exception as e:
        logger.exception(e);
        return None;



#############################################
#
# NLP_Entity
#
#############################################
def GetNLP_EntityElementsFromDB_with_doc_id_d1(
    obj,
    id,
    table_name,
    hierarchy,
    Dict_documentelements_db,  # dict
    Dict_FontInfo_db,  # dict
    IQVAttributeCandidate_db_List,
    NLP_Attribute_db_List,
    Dict_iqvtablecolumn_db,  # new dict IQVTableColumn_db_List,
    Dict_iqvtablecolumnheader_db,  # new dict IQVTableColumnHeader_db_List,
    Dict_iqvqcupdatetracking_db,  # new dict IQVQCUpdateTracking_db_List,
    IQVAttribute_db_List,
    Dict_IQVKeyValueSet_db,  # dict
    Dict_IQVSubText_db,  # dict
    Dict_NLP_Entity_db  # dict
    ):
    """
    Already have the <paramref name="obj"/>, now
    fill in the children and missing elements

    :param obj: primary object being constructed
    :param id: UUID of object
    :param table_name: table name
    :param Dict_documentelements_db: lookup dictionary of objects by parent id
    :param Dict_FontInfo_db: lookup dictionary of objects by parent id
    :param IQVAttributeCandidate_db_List: listing of objects
    :param Dict_IQVSubText_db: lookup dictionary of objects by parent id
    :param IQVQCUpdateTracking_db_List: listing of objects 
    :param Dict_IQVKeyValueSet_db: lookup dictionary of objects by parent id
    :param Dict_iqvtablecolumn_db: listing of objects
    :param NLP_Attribute_db_List: listing of objects
    :param Dict_NLP_Entity_db: lookup dictionary of objects by parent id
    :param IQVAttribute_db_List: listing of objects
    :returns obj: primary object being constructed

    """
    try:

        #        ///////////////////////////////////////////
        #        //
        #        // 2. child objects
        #        //
        #        ///////////////////////////////////////////

        #        # 
        #        // first get high level
        #        //
        group_type = "";
        #        //
        #        // first get high level
        #        //
        group_type = "Properties";
        table_name = "";
        obj.Properties = GetDocumentElementListFromDBByParentID_with_doc_id_d1(
            Dict_IQVKeyValueSet_db,
            obj.id,
            table_name,
            group_type,
            hierarchy);
        #        //
        #        // next get recursive levels
        #        //
        for para in obj.Properties:
            para = GetIQVKeyValueSetElementsFromDB_with_doc_id_d1(
                para,
                "",
                table_name,
                hierarchy,
                Dict_documentelements_db,  # dict
                Dict_FontInfo_db,  # dict
                IQVAttributeCandidate_db_List,
                NLP_Attribute_db_List,
                Dict_iqvtablecolumn_db,  # new dict IQVTableColumn_db_List,
                Dict_iqvtablecolumnheader_db,  # new dict IQVTableColumnHeader_db_List,
                Dict_iqvqcupdatetracking_db,  # new dict IQVQCUpdateTracking_db_List,
                IQVAttribute_db_List,
                Dict_IQVKeyValueSet_db,  # dict
                Dict_IQVSubText_db,  # dict
                Dict_NLP_Entity_db  # dict
            );


        return obj;
    except psycopg2.DatabaseError as nex:
        logger.exception(nex);
        return None;
    except Exception as e:
        logger.exception(e);
        return None;


#############################################
#
# IQVTableColumn
#
#############################################
def GetIQVTableColumnElementsFromDB_with_doc_id_d1(
    obj,
    id,
    table_name,
    hierarchy,
    Dict_documentelements_db,  # dict
    Dict_FontInfo_db,  # dict
    IQVAttributeCandidate_db_List,
    NLP_Attribute_db_List,
    Dict_iqvtablecolumn_db,  # new dict IQVTableColumn_db_List,
    Dict_iqvtablecolumnheader_db,  # new dict IQVTableColumnHeader_db_List,
    Dict_iqvqcupdatetracking_db,  # new dict IQVQCUpdateTracking_db_List,
    IQVAttribute_db_List,
    Dict_IQVKeyValueSet_db,  # dict
    Dict_IQVSubText_db,  # dict
    Dict_NLP_Entity_db  # dict
    ):
    """
    Already have the <paramref name="obj"/>, now
    fill in the children and missing elements

    :param obj: primary object being constructed
    :param id: UUID of object
    :param table_name: table name
    :param Dict_documentelements_db: lookup dictionary of objects by parent id
    :param Dict_FontInfo_db: lookup dictionary of objects by parent id
    :param IQVAttributeCandidate_db_List: listing of objects
    :param Dict_IQVSubText_db: lookup dictionary of objects by parent id
    :param IQVQCUpdateTracking_db_List: listing of objects 
    :param Dict_IQVKeyValueSet_db: lookup dictionary of objects by parent id
    :param Dict_iqvtablecolumn_db: listing of objects
    :param NLP_Attribute_db_List: listing of objects
    :param Dict_NLP_Entity_db: lookup dictionary of objects by parent id
    :param IQVAttribute_db_List: listing of objects
    :returns obj: primary object being constructed

    """
    try:

        #        ///////////////////////////////////////////
        #        //
        #        // 2. child objects
        #        //
        #        ///////////////////////////////////////////

        #        # 
        #        // first get high level
        #        //
        group_type = "";
        group_type = "headers";
        obj.headers = GetDocumentElementListFromDBByParentID_with_doc_id_d1(
            Dict_iqvtablecolumnheader_db,  #  IQVTableColumnHeader_db_List,
            obj.id,
            table_name,
            group_type,
            hierarchy);
        #        //
        #        // next get recursive levels
        #        //
        for para in obj.headers:
            para = GetIQVTableColumnHeaderElementsFromDB_with_doc_id_d1(
                para,
                "",
                table_name,
                hierarchy,
                Dict_documentelements_db,  # dict
                Dict_FontInfo_db,  # dict
                IQVAttributeCandidate_db_List,
                NLP_Attribute_db_List,
                Dict_iqvtablecolumn_db,  # new dict IQVTableColumn_db_List,
                Dict_iqvtablecolumnheader_db,  # new dict IQVTableColumnHeader_db_List,
                Dict_iqvqcupdatetracking_db,  # new dict IQVQCUpdateTracking_db_List,
                IQVAttribute_db_List,
                Dict_IQVKeyValueSet_db,  # dict
                Dict_IQVSubText_db,  # dict
                Dict_NLP_Entity_db  # dict
            );


        return obj;
    except psycopg2.DatabaseError as nex:
        logger.exception(nex);
        return None;
    except Exception as e:
        logger.exception(e);
        return None;



#############################################
#
# IQVQCUpdateTracking
#
#############################################
def GetIQVQCUpdateTrackingElementsFromDB_with_doc_id_d1(
    obj,
    id,
    table_name,
    hierarchy,
    Dict_documentelements_db,  # dict
    Dict_FontInfo_db,  # dict
    IQVAttributeCandidate_db_List,
    NLP_Attribute_db_List,
    Dict_iqvtablecolumn_db,  # new dict IQVTableColumn_db_List,
    Dict_iqvtablecolumnheader_db,  # new dict IQVTableColumnHeader_db_List,
    Dict_iqvqcupdatetracking_db,  # new dict IQVQCUpdateTracking_db_List,
    IQVAttribute_db_List,
    Dict_IQVKeyValueSet_db,  # dict
    Dict_IQVSubText_db,  # dict
    Dict_NLP_Entity_db  # dict
    ):
    """
    Already have the <paramref name="obj"/>, now
    fill in the children and missing elements

    :param obj: primary object being constructed
    :param id: UUID of object
    :param table_name: table name
    :param Dict_documentelements_db: lookup dictionary of objects by parent id
    :param Dict_FontInfo_db: lookup dictionary of objects by parent id
    :param IQVAttributeCandidate_db_List: listing of objects
    :param Dict_IQVSubText_db: lookup dictionary of objects by parent id
    :param IQVQCUpdateTracking_db_List: listing of objects 
    :param Dict_IQVKeyValueSet_db: lookup dictionary of objects by parent id
    :param Dict_iqvtablecolumn_db: listing of objects
    :param NLP_Attribute_db_List: listing of objects
    :param Dict_NLP_Entity_db: lookup dictionary of objects by parent id
    :param IQVAttribute_db_List: listing of objects
    :returns obj: primary object being constructed

    """
    try:

        #        ///////////////////////////////////////////
        #        //
        #        // 2. child objects
        #        //
        #        ///////////////////////////////////////////

        #        # 
        #        // first get high level
        #        //
        group_type = "";
        #        //
        #        // first get high level
        #        //
        group_type = "Properties";
        table_name = "";
        obj.Properties = GetDocumentElementListFromDBByParentID_with_doc_id_d1(
            Dict_IQVKeyValueSet_db,
            obj.id,
            table_name,
            group_type,
            hierarchy);
        #        //
        #        // next get recursive levels
        #        //
        for para in obj.Properties:
            para = GetIQVKeyValueSetElementsFromDB_with_doc_id_d1(
                para,
                "",
                table_name,
                hierarchy,
                Dict_documentelements_db,  # dict
                Dict_FontInfo_db,  # dict
                IQVAttributeCandidate_db_List,
                NLP_Attribute_db_List,
                Dict_iqvtablecolumn_db,  # new dict IQVTableColumn_db_List,
                Dict_iqvtablecolumnheader_db,  # new dict IQVTableColumnHeader_db_List,
                Dict_iqvqcupdatetracking_db,  # new dict IQVQCUpdateTracking_db_List,
                IQVAttribute_db_List,
                Dict_IQVKeyValueSet_db,  # dict
                Dict_IQVSubText_db,  # dict
                Dict_NLP_Entity_db  # dict
            );


        return obj;
    except psycopg2.DatabaseError as nex:
        logger.exception(nex);
        return None;
    except Exception as e:
        logger.exception(e);
        return None;


#############################################
#
# IQVTableColumnHeader
#
#############################################
def GetIQVTableColumnHeaderElementsFromDB_with_doc_id_d1(
    obj,
    id,
    table_name,
    hierarchy,
    Dict_documentelements_db,  # dict
    Dict_FontInfo_db,  # dict
    IQVAttributeCandidate_db_List,
    NLP_Attribute_db_List,
    Dict_iqvtablecolumn_db,  # new dict IQVTableColumn_db_List,
    Dict_iqvtablecolumnheader_db,  # new dict IQVTableColumnHeader_db_List,
    Dict_iqvqcupdatetracking_db,  # new dict IQVQCUpdateTracking_db_List,
    IQVAttribute_db_List,
    Dict_IQVKeyValueSet_db,  # dict
    Dict_IQVSubText_db,  # dict
    Dict_NLP_Entity_db  # dict
    ):
    """
    Already have the <paramref name="obj"/>, now
    fill in the children and missing elements

    :param obj: primary object being constructed
    :param id: UUID of object
    :param table_name: table name
    :param Dict_documentelements_db: lookup dictionary of objects by parent id
    :param Dict_FontInfo_db: lookup dictionary of objects by parent id
    :param IQVAttributeCandidate_db_List: listing of objects
    :param Dict_IQVSubText_db: lookup dictionary of objects by parent id
    :param IQVQCUpdateTracking_db_List: listing of objects 
    :param Dict_IQVKeyValueSet_db: lookup dictionary of objects by parent id
    :param IQVTableColumn_db_List: listing of objects
    :param NLP_Attribute_db_List: listing of objects
    :param Dict_NLP_Entity_db: lookup dictionary of objects by parent id
    :param IQVAttribute_db_List: listing of objects
    :returns obj: primary object being constructed

    """
    try:

        #        ///////////////////////////////////////////
        #        //
        #        // 2. child objects
        #        //
        #        ///////////////////////////////////////////

        #        # 
        #        // first get high level
        #        //
        group_type = "";
        #        //
        #        // first get high level
        #        //
        group_type = "Properties";
        table_name = "";
        obj.Properties = GetDocumentElementListFromDBByParentID_with_doc_id_d1(
            Dict_IQVKeyValueSet_db,
            obj.id,
            table_name,
            group_type,
            hierarchy);
        #        //
        #        // next get recursive levels
        #        //
        for para in obj.Properties:
            para = GetIQVKeyValueSetElementsFromDB_with_doc_id_d1(
                para,
                "",
                table_name,
                hierarchy,
                Dict_documentelements_db,  # dict
                Dict_FontInfo_db,  # dict
                IQVAttributeCandidate_db_List,
                NLP_Attribute_db_List,
                Dict_iqvtablecolumn_db,  # new dict IQVTableColumn_db_List,
                Dict_iqvtablecolumnheader_db,  # new dict IQVTableColumnHeader_db_List,
                Dict_iqvqcupdatetracking_db,  # new dict IQVQCUpdateTracking_db_List,
                IQVAttribute_db_List,
                Dict_IQVKeyValueSet_db,  # dict
                Dict_IQVSubText_db,  # dict
                Dict_NLP_Entity_db  # dict
            );


        return obj;
    except psycopg2.DatabaseError as nex:
        logger.exception(nex);
        return None;
    except Exception as e:
        logger.exception(e);
        return None;




##############################################
#
# Parts List
#
##############################################
def GetDocumentPartsListFromDBByParentID(
    conn,
    parent_id,
    table_name,
    group_type):
    """
    <summary>
    Given <paramref name="cmd"/> with database connection and parent_id and parent group_type,
    retrieve the list of high-level object from iqvpageroi_db
    and instantiate the <see cref="IQVPageROI"/> object
    </summary>
    <param name="cmd">connection already established</param>
    <param name="obj_list">object list to be instantiated</param>
    <param name="parent_id">primary key of document</param>
    <param name="table_name">default is iqvpageroi_db</param>
    <param name="group_type">used in where clause</param>
    <returns>list of objects obj_list</returns>
    """
    try:
        obj_list = [];
        if len(table_name) == 0:
            table_name = "documentpartslist_db";
        sql = "";
        sql = sql + "SELECT ";
        sql = sql + "\"id\",";
        sql = sql + "\"sequence_id\",";
        if sql.endswith(","):
            sql = sql[0:len(sql)-1];
        sql = sql + " FROM public." + table_name;
        sql = sql + " WHERE parent_id = '" + parent_id + "'";
        if len(group_type) > 0:
            sql = sql + " AND group_type = '" + group_type + "'";
        sql = sql + " ORDER BY sequence_id ";
        sql = sql + ";";

        if conn is None:
            conn = get_dev_connection()
        cur = conn.cursor()
        cur.execute(sql)
        records = cur.fetchall()
        if len(records) == 0:
            cur.close();
            return [];
        cntRecords = len(records);
        for rec in records:
            obj = rec[0];
            obj_list.append(obj);
        cur.close();
        logger.info('Read database items (count=' + str(cntRecords) + ') from table ' + table_name)
        return obj_list;
    except (Exception, psycopg2.DatabaseError) as error:
        logger.exception("Database Error writing log entries")
        return None;
    except Exception as e:
        logger.exception("Error writing log entries")
        return None;

def GetDictionaryFromList(db_List):
    """
    Create LUT
    
    Given a list of objects, create 
    a dictionary with the key hierarchy+parent_id

    :param db_List: list of objects
    returns: dictionary Dict_db in which key is hierarchy+parent_id
    """
    try:
        ##########################################
        #
        # Create LUT for object
        #
        ##########################################

        Dict_db = dict()
        tmp = []
        iqvkv_id = "";
        for iqvkv in db_List:
            iqvkv_key = iqvkv.hierarchy + iqvkv.parent_id;
            if iqvkv_key == iqvkv_id:
                pass
            elif len(tmp) > 0:
                if iqvkv_id in Dict_db:
                    pass
                else:
                    Dict_db[iqvkv_id] = tmp;
                tmp = []
            tmp.append(iqvkv)
            iqvkv_id = iqvkv_key;
        if len(tmp) > 0:
            if iqvkv_id in Dict_db:
                pass
            else:
                Dict_db[iqvkv_id] = tmp;
        return Dict_db
    except Exception as e:
        return None;


def GetIQVDocumentFromDB_with_doc_id(
    conn,
    id,
    link_level=-1,
    link_id=""
    ):
    """
    Get a document or document section as IQVDocument object

    For entire document, provide the doc_id

    For document section, provide doc_id and link_id/link_level

    Example for a document section 5, with new object returned as doc1:
        conn = get_dev_connection()
        doc_id = '6b13a3fc-fa0c-4dce-b20e-3dcfef843794'
        link_level=1
        link_id='522b51a2-eb6e-11ec-9ff5-005056ab6469' # 'UUID-for-section-5'
        doc1 = GetIQVDocumentFromDB_with_doc_id(
            conn,
            doc_id,
            link_level,
            link_id)

    Example for a document section 5.3, with new object returned as doc1:
        conn = get_dev_connection()
        doc_id = '6b13a3fc-fa0c-4dce-b20e-3dcfef843794'
        link_level=2 # note second level for 5.3
        link_id='UUID-for-section-5.3'
        doc1 = GetIQVDocumentFromDB_with_doc_id(
            conn,
            doc_id,
            link_level,
            link_id)

    """

    try:
        obj = IQVDocument();

        table_name = "";
        group_type = "";

        obj = GetIQVDocumentFromDB(
            conn,
            id,
            table_name,
            group_type);

        if obj is None:
            logger.exception("Failed to retrieve primary object for id = " + id)
            return None

        bUseLink = False;
        if link_level >= 1 and len(link_id) > 0:
            bUseLink = True;
        group_type = "";

        table_name = "documentparagraphs_db";
        documentparagraphs_db_List = [];
        if not bUseLink:
            documentparagraphs_db_List = GetIQVPageROI_db_All_ListFromDBByDocID(
                conn,
                id,
                table_name,
                "");
        else:
            documentparagraphs_db_List = GetIQVPageROI_db_All_ListFromDBByLinkID(
                conn,
                id,
                table_name,
                link_id,
                link_level);
        ##########################################
        #
        # Create LUT for documentparagraphs_db_List
        #
        ##########################################
        Dict_documentparagraphs_db = GetDictionaryFromList(documentparagraphs_db_List);

        table_name = "documentimages_db";
        documentimages_db_List = [];
        if not bUseLink:
            documentimages_db_List = GetIQVPageROI_db_All_ListFromDBByDocID(
                conn,
                id,
                table_name,
                "");
        else:
            documentimages_db_List = GetIQVPageROI_db_All_ListFromDBByLinkID(
                conn,
                id,
                table_name,
                link_id,
                link_level);
        ##########################################
        #
        # Create LUT for documentimages_db_List
        #
        ##########################################
        Dict_documentimages_db = GetDictionaryFromList(documentimages_db_List);

        table_name = "documenttables_db";
        documenttables_db_List = []
        if not bUseLink:
            documenttables_db_List = GetIQVPageROI_db_All_ListFromDBByDocID(
                conn,
                id,
                table_name,
                "");
        else:
            documenttables_db_List = GetIQVPageROI_db_All_ListFromDBByLinkID(
                conn,
                id,
                table_name,
                link_id,
                link_level);
        ##########################################
        #
        # Create LUT for documenttables_db_List
        #
        ##########################################
        Dict_documenttables_db = GetDictionaryFromList(documenttables_db_List);

        table_name = "documentitems_db";
        documentitems_db_List = [];
        if not bUseLink:
            documentitems_db_List = GetIQVPageROI_db_All_ListFromDBByDocID(
                conn,
                id,
                table_name,
                "");
        else:
            documentitems_db_List = GetIQVPageROI_db_All_ListFromDBByLinkID(
                conn,
                id,
                table_name,
                link_id,
                link_level);
        ##########################################
        #
        # Create LUT for documentitems_db_List
        #
        ##########################################
        Dict_documentitems_db = GetDictionaryFromList(documentitems_db_List);

        table_name = "documentheaders_db";
        documentheaders_db_List = [];
        if not bUseLink:
            documentheaders_db_List = GetIQVPageROI_db_All_ListFromDBByDocID(
                conn,
                id,
                table_name,
                "");
        else:
            documentheaders_db_List = GetIQVPageROI_db_All_ListFromDBByLinkID(
                conn,
                id,
                table_name,
                link_id,
                link_level);
        ##########################################
        #
        # Create LUT for documentheaders_db_List
        #
        ##########################################
        Dict_documentheaders_db = GetDictionaryFromList(documentheaders_db_List);

        table_name = "documentfooters_db";
        documentfooters_db_List = [];
        if not bUseLink:
            documentfooters_db_List = GetIQVPageROI_db_All_ListFromDBByDocID(
                conn,
                id,
                table_name,
                "");
        else:
            documentfooters_db_List = GetIQVPageROI_db_All_ListFromDBByLinkID(
                conn,
                id,
                table_name,
                link_id,
                link_level);
        ##########################################
        #
        # Create LUT for documentfooters_db_List
        #
        ##########################################
        Dict_documentfooters_db = GetDictionaryFromList(documentfooters_db_List);

        table_name = "documentpartslist_db";
        documentparts_db_List = [];
        # returned in sequence order by query
        obj.DocumentPartsList = GetDocumentPartsListFromDBByParentID(
            conn,
            id,
            table_name,
            "");

        table_name = "fontinfo_db";
        fontinfo_db_List = [];
        if not bUseLink:
            fontinfo_db_List = GetFontInfo_db_All_ListFromDBByDocID(
                conn,
                id,
                table_name,
                "");
        else:
            fontinfo_db_List = GetFontInfo_db_All_ListFromDBByLinkID(
                conn,
                id,
                table_name,
                link_id,
                link_level);
        ##########################################
        #
        # Create LUT for fontinfo_db_List
        #
        ##########################################
        Dict_FontInfo_db = GetDictionaryFromList(fontinfo_db_List);

        table_name = "iqvattribute_db";
        IQVAttribute_db_List = [];
        if not bUseLink:
            IQVAttribute_db_List = GetIQVAttribute_db_All_ListFromDBByDocID(
                conn,
                id,
                table_name,
                "");
        else:
            IQVAttribute_db_List = GetIQVAttribute_db_All_ListFromDBByLinkID(
                conn,
                id,
                table_name,
                link_id,
                link_level);

        table_name = "iqvattributecandidate_db";
        IQVAttributeCandidate_db_List = [];
        if not bUseLink:
            IQVAttributeCandidate_db_List = GetIQVAttributeCandidate_db_All_ListFromDBByDocID(
                conn,
                id,
                table_name,
                "");
        else:
            IQVAttributeCandidate_db_List = GetIQVAttributeCandidate_db_All_ListFromDBByLinkID(
                conn,
                id,
                table_name,
                link_id,
                link_level);

        table_name = "iqvcharacter_db";
        iqvcharacter_db_List = [];
        if not bUseLink:
            iqvcharacter_db_List = GetIQVCharacter_db_All_ListFromDBByDocID(
                conn,
                id,
                table_name,
                "");
        else:
            iqvcharacter_db_List = GetIQVCharacter_db_All_ListFromDBByLinkID(
                conn,
                id,
                table_name,
                link_id,
                link_level);

        table_name = "iqvclassifiermodel_db";
        iqvclassifiermodel_db_List = [];

        table_name = "iqvcountrymapping_db";
        iqvcountrymapping_db_List = [];

        table_name = "iqvdocumentcompare_db";
        iqvdocumentcompare_db_List = [];

        table_name = "iqvdocumentdiff_db";
        iqvdocumentdiff_db_List = [];

        table_name = "iqvdocumentfeedbackqc_db";
        iqvdocumentfeedbackqc_db_List = [];
        if not bUseLink:
            iqvdocumentfeedbackqc_db_List = GetIQVDocumentFeedbackQC_db_All_ListFromDBByDocID(
                conn,
                id,
                table_name,
                "");
        else:
            iqvdocumentfeedbackqc_db_List = GetIQVDocumentFeedbackQC_db_All_ListFromDBByLinkID(
                conn,
                id,
                table_name,
                link_id,
                link_level);


        table_name = "";
        iqvdocumentfeedbackresults_db_List = [];
        if not bUseLink:
            iqvdocumentfeedbackresults_db_List = GetIQVDocumentFeedbackResults_db_All_ListFromDBByDocID(
                conn,
                id,
                table_name,
                "");
        else:
            iqvdocumentfeedbackresults_db_List = GetIQVDocumentFeedbackResults_db_All_ListFromDBByLinkID(
                conn,
                id,
                table_name,
                link_id,
                link_level);

        iqvdocumentlink_db_List = [];
        if not bUseLink:
            iqvdocumentlink_db_List = GetIQVDocumentLink_db_All_ListFromDBByDocID(
                conn,
                id,
                table_name,
                "");
        else:
            iqvdocumentlink_db_List = GetIQVDocumentLink_db_All_ListFromDBByLinkID(
                conn,
                id,
                table_name,
                link_id,
                link_level);

        ##########################################
        #
        # Sort links
        #
        ##########################################
        sorted(iqvdocumentlink_db_List, key=operator.attrgetter("LinkType","DocumentSequenceIndex","LinkPage"));
        ##########################################
        #
        # Create LUT for iqvdocumentlink_db_List
        #
        ##########################################
        #Dict_iqvdocumentlink_db = GetDictionaryFromList(iqvdocumentlink_db_List);

        iqvdocumentmapping_db_List = [];

        iqvdocumentprocess_db_List = [];
        if not bUseLink:
            iqvdocumentprocess_db_List = GetIQVDocumentProcess_db_All_ListFromDBByDocID(
                conn,
                id,
                table_name,
                "");
        else:
            iqvdocumentprocess_db_List = GetIQVDocumentProcess_db_All_ListFromDBByLinkID(
                conn,
                id,
                table_name,
                link_id,
                link_level);

        iqvexternallinkelement_db_List = [];
        if not bUseLink:
            iqvexternallinkelement_db_List = GetIQVExternalLinkElement_db_All_ListFromDBByDocID(
                conn,
                id,
                table_name,
                "");
        else:
            iqvexternallinkelement_db_List = GetIQVExternalLinkElement_db_All_ListFromDBByLinkID(
                conn,
                id,
                table_name,
                link_id,
                link_level);

        iqvexternallink_db_List = [];
        if not bUseLink:
            iqvexternallink_db_List = GetIQVExternalLink_db_All_ListFromDBByDocID(
                conn,
                id,
                table_name,
                "");
        else:
            iqvexternallink_db_List = GetIQVExternalLink_db_All_ListFromDBByLinkID(
                conn,
                id,
                table_name,
                link_id,
                link_level);

        iqvkeyValueset_db_List = [];
        if not bUseLink:
            iqvkeyValueset_db_List = GetIQVKeyValueSet_db_All_ListFromDBByDocID(
                conn,
                id,
                table_name,
                "");
        else:
            iqvkeyValueset_db_List = GetIQVKeyValueSet_db_All_ListFromDBByLinkID(
                conn,
                id,
                table_name,
                link_id,
                link_level);

        ##########################################
        #
        # Create LUT for IQVKeyValueSet
        #
        ##########################################
        Dict_IQVKeyValueSet_db = GetDictionaryFromList(iqvkeyValueset_db_List);

        iqvlanguagemapping_db_List = []

        iqvline_db_List = [];
        if not bUseLink:
            iqvline_db_List = GetIQVLine_db_All_ListFromDBByDocID(
                conn,
                id,
                table_name,
                "");
        else:
            iqvline_db_List = GetIQVLine_db_All_ListFromDBByLinkID(
                conn,
                id,
                table_name,
                link_id,
                link_level);

        iqvnumberinggroup_db_List = []
        if not bUseLink:
            iqvnumberinggroup_db_List = GetIQVNumberingGroup_db_All_ListFromDBByDocID(
                conn,
                id,
                table_name,
                "");
        else:
            iqvnumberinggroup_db_List = GetIQVNumberingGroup_db_All_ListFromDBByLinkID(
                conn,
                id,
                table_name,
                link_id,
                link_level);

        iqvnumberinglevel_db_List = [];
        if not bUseLink:
            iqvnumberinglevel_db_List = GetIQVNumberingLevel_db_All_ListFromDBByDocID(
                conn,
                id,
                table_name,
                "");
        else:
            iqvnumberinglevel_db_List = GetIQVNumberingLevel_db_All_ListFromDBByLinkID(
                conn,
                id,
                table_name,
                link_id,
                link_level);

        iqvpageroi_db_List = [];
        if not bUseLink:
            iqvpageroi_db_List = GetIQVPageROI_db_All_ListFromDBByDocID(
                conn,
                id,
                table_name,
                "");
        else:
            iqvpageroi_db_List = GetIQVPageROI_db_All_ListFromDBByLinkID(
                conn,
                id,
                table_name,
                link_id,
                link_level);
        ##########################################
        #
        # Create LUT for iqvpageroi_db_List
        #
        ##########################################
        Dict_iqvpageroi_db = GetDictionaryFromList(iqvpageroi_db_List);

        IQVQCUpdateTracking_db_List = [];
        if not bUseLink:
            IQVQCUpdateTracking_db_List = GetIQVQCUpdateTracking_db_All_ListFromDBByDocID(
                conn,
                id,
                table_name,
                "");
        else:
            IQVQCUpdateTracking_db_List = GetIQVQCUpdateTracking_db_All_ListFromDBByLinkID(
                conn,
                id,
                table_name,
                link_id,
                link_level);

        iqvredactioncategory_db_List = [];

        iqvredactionprofile_db_List = [];

        iqvsubtext_db_List = [];
        if not bUseLink:
            iqvsubtext_db_List = GetIQVSubText_db_All_ListFromDBByDocID(
                conn,
                id,
                table_name,
                "");
        else:
            iqvsubtext_db_List = GetIQVSubText_db_All_ListFromDBByLinkID(
                conn,
                id,
                table_name,
                link_id,
                link_level);
        ##########################################
        #
        # Create LUT for iqvsubtext_db_List
        #
        ##########################################
        Dict_IQVSubText_db = GetDictionaryFromList(iqvsubtext_db_List);



        IQVTableColumnHeader_db_List = [];
        if not bUseLink:
            IQVTableColumnHeader_db_List = GetIQVTableColumnHeader_db_All_ListFromDBByDocID(
                conn,
                id,
                table_name,
                "");
        else:
            IQVTableColumnHeader_db_List = GetIQVTableColumnHeader_db_All_ListFromDBByLinkID(
                conn,
                id,
                table_name,
                link_id,
                link_level);

        IQVTableColumn_db_List = [];
        if not bUseLink:
            IQVTableColumn_db_List = GetIQVTableColumn_db_All_ListFromDBByDocID(
                conn,
                id,
                table_name,
                "");
        else:
            IQVTableColumn_db_List = GetIQVTableColumn_db_All_ListFromDBByLinkID(
                conn,
                id,
                table_name,
                link_id,
                link_level);

        iqvTableRow_db_List = [];
        if not bUseLink:
            iqvTableRow_db_List = GetIQVTableRow_db_All_ListFromDBByDocID(
                conn,
                id,
                table_name,
                "");
        else:
            iqvTableRow_db_List = GetIQVTableRow_db_All_ListFromDBByLinkID(
                conn,
                id,
                table_name,
                link_id,
                link_level);

        iqvword_db_List = [];
        if not bUseLink:
            iqvword_db_List = GetIQVWord_db_All_ListFromDBByDocID(
                conn,
                id,
                table_name,
                "");
        else:
            iqvword_db_List = GetIQVWord_db_All_ListFromDBByLinkID(
                conn,
                id,
                table_name,
                link_id,
                link_level);

        languagecode_db_List = [];

        NLP_Attribute_db_List = [];
        if not bUseLink:
            NLP_Attribute_db_List = GetNLP_Attribute_db_All_ListFromDBByDocID(
                conn,
                id,
                table_name,
                "");
        else:
            NLP_Attribute_db_List = GetNLP_Attribute_db_All_ListFromDBByLinkID(
                conn,
                id,
                table_name,
                link_id,
                link_level);

        nlp_entity_db_List = [];
        if not bUseLink:
            nlp_entity_db_List = GetNLP_Entity_db_All_ListFromDBByDocID(
                conn,
                id,
                table_name,
                "");
        else:
            nlp_entity_db_List = GetNLP_Entity_db_All_ListFromDBByLinkID(
                conn,
                id,
                table_name,
                link_id,
                link_level);
        ##########################################
        #
        # Create LUT for nlp_entity_db_List
        #
        ##########################################
        Dict_NLP_Entity_db = GetDictionaryFromList(nlp_entity_db_List);

        nLP_Relation_Dbs_List = [];
        if not bUseLink:
            nLP_Relation_Dbs_List = GetNLP_Relation_db_All_ListFromDBByDocID(
                conn,
                id,
                table_name,
                "");
        else:
            nLP_Relation_Dbs_List = GetNLP_Relation_db_All_ListFromDBByLinkID(
                conn,
                id,
                table_name,
                link_id,
                link_level);

        nLP_Segment_Dbs_List = [];
        if not bUseLink:
            nLP_Segment_Dbs_List = GetNLP_Segment_db_All_ListFromDBByDocID(
                conn,
                id,
                table_name,
                "");
        else:
            nLP_Segment_Dbs_List = GetNLP_Segment_db_All_ListFromDBByLinkID(
                conn,
                id,
                table_name,
                link_id,
                link_level);

        nLP_System_Mapping_Dbs_List = [];
        if not bUseLink:
            nLP_System_Mapping_Dbs_List = GetNLP_System_Mapping_db_All_ListFromDBByDocID(
                conn,
                id,
                table_name,
                "");
        else:
            nLP_System_Mapping_Dbs_List = GetNLP_System_Mapping_db_All_ListFromDBByLinkID(
                conn,
                id,
                table_name,
                link_id,
                link_level);

        q_EVENT_LOG_ENTRY_List = [];

        #    ///////////////////////////////////////////////////////////
        #    //
        #    // Now just re-sort and assign in correct spot
        #    //
        #    ///////////////////////////////////////////////////////////


        table_name = "documentparagraphs_db";
        group_type = "";
        hierarchy = "paragraph";
        obj.DocumentParagraphs = GetDocumentElementListFromDBByParentID_with_doc_id(
            documentparagraphs_db_List,
            obj.id,
            table_name,
            group_type,
            hierarchy);

        logger.debug("Num paras = " + str(len(obj.DocumentParagraphs)));
        for para in obj.DocumentParagraphs:
            para = GetIQVPageROIElementsFromDB_with_doc_id_d1(
                para,
                "",
                table_name,
                hierarchy,
                Dict_documentparagraphs_db,  # dict
                Dict_FontInfo_db,  # dict
                IQVAttributeCandidate_db_List,
                NLP_Attribute_db_List,
                IQVTableColumn_db_List,
                IQVTableColumnHeader_db_List,
                IQVQCUpdateTracking_db_List,
                IQVAttribute_db_List,
                Dict_IQVKeyValueSet_db,  # dict
                Dict_IQVSubText_db,  # dict
                Dict_NLP_Entity_db  # dict
            );


        table_name = "documentimages_db";
        group_type = "";
        hierarchy = "image";
        obj.DocumentImages = GetDocumentElementListFromDBByParentID_with_doc_id(
            documentimages_db_List,
            obj.id,
            table_name,
            group_type,
            hierarchy);

        logger.debug("Num images = " + str(len(obj.DocumentImages)));
        for para in obj.DocumentImages:
            para = GetIQVPageROIElementsFromDB_with_doc_id_d1(
                para,
                "",
                table_name,
                hierarchy,
                Dict_documentimages_db,  # dict
                Dict_FontInfo_db,  # dict
                IQVAttributeCandidate_db_List,
                NLP_Attribute_db_List,
                IQVTableColumn_db_List,
                IQVTableColumnHeader_db_List,
                IQVQCUpdateTracking_db_List,
                IQVAttribute_db_List,
                Dict_IQVKeyValueSet_db,  # dict
                Dict_IQVSubText_db,  # dict
                Dict_NLP_Entity_db  # dict
            );

        table_name = "documenttables_db";
        group_type = "";
        hierarchy = "table";
        obj.DocumentTables = GetDocumentElementListFromDBByParentID_with_doc_id(
            documenttables_db_List,
            obj.id,
            table_name,
            group_type,
            hierarchy);

        logger.debug("Num tables = " + str(len(obj.DocumentTables)));
        for para in obj.DocumentTables:
            para = GetIQVPageROIElementsFromDB_with_doc_id_d1(
                para,
                "",
                table_name,
                hierarchy,
                Dict_documenttables_db,  # dict
                Dict_FontInfo_db,  # dict
                IQVAttributeCandidate_db_List,
                NLP_Attribute_db_List,
                IQVTableColumn_db_List,
                IQVTableColumnHeader_db_List,
                IQVQCUpdateTracking_db_List,
                IQVAttribute_db_List,
                Dict_IQVKeyValueSet_db,  # dict
                Dict_IQVSubText_db,  # dict
                Dict_NLP_Entity_db  # dict
            );

        table_name = "documentitems_db";
        group_type = "";
        hierarchy = "item";
        obj.DocumentItems = GetDocumentElementListFromDBByParentID_with_doc_id(
            documentitems_db_List,
            obj.id,
            table_name,
            group_type,
            hierarchy);

        logger.debug("Num items = " + str(len(obj.DocumentItems)));
        for para in obj.DocumentItems:
            para = GetIQVPageROIElementsFromDB_with_doc_id_d1(
                para,
                "",
                table_name,
                hierarchy,
                Dict_documentitems_db,  # dict
                Dict_FontInfo_db,  # dict
                IQVAttributeCandidate_db_List,
                NLP_Attribute_db_List,
                IQVTableColumn_db_List,
                IQVTableColumnHeader_db_List,
                IQVQCUpdateTracking_db_List,
                IQVAttribute_db_List,
                Dict_IQVKeyValueSet_db,  # dict
                Dict_IQVSubText_db,  # dict
                Dict_NLP_Entity_db  # dict
            );

        table_name = "documentheaders_db";
        group_type = "";
        hierarchy = "header";
        obj.DocumentHeaders = GetDocumentElementListFromDBByParentID_with_doc_id(
            documentheaders_db_List,
            obj.id,
            table_name,
            group_type,
            hierarchy);

        logger.debug("Num headers = " + str(len(obj.DocumentHeaders)));
        for para in obj.DocumentHeaders:
            para = GetIQVPageROIElementsFromDB_with_doc_id_d1(
                para,
                "",
                table_name,
                hierarchy,
                Dict_documentheaders_db,  # dict
                Dict_FontInfo_db,  # dict
                IQVAttributeCandidate_db_List,
                NLP_Attribute_db_List,
                IQVTableColumn_db_List,
                IQVTableColumnHeader_db_List,
                IQVQCUpdateTracking_db_List,
                IQVAttribute_db_List,
                Dict_IQVKeyValueSet_db,  # dict
                Dict_IQVSubText_db,  # dict
                Dict_NLP_Entity_db  # dict
            );

        table_name = "documentfooters_db";
        group_type = "";
        hierarchy = "footer";
        obj.DocumentFooters = GetDocumentElementListFromDBByParentID_with_doc_id(
            documentfooters_db_List,
            obj.id,
            table_name,
            group_type,
            hierarchy);

        logger.debug("Num footers = " + str(len(obj.DocumentFooters)));
        for para in obj.DocumentFooters:
            para = GetIQVPageROIElementsFromDB_with_doc_id_d1(
                para,
                "",
                table_name,
                hierarchy,
                Dict_documentfooters_db,  # dict
                Dict_FontInfo_db,  # dict
                IQVAttributeCandidate_db_List,
                NLP_Attribute_db_List,
                IQVTableColumn_db_List,
                IQVTableColumnHeader_db_List,
                IQVQCUpdateTracking_db_List,
                IQVAttribute_db_List,
                Dict_IQVKeyValueSet_db,  # dict
                Dict_IQVSubText_db,  # dict
                Dict_NLP_Entity_db  # dict
            );

        table_name = "iqvdocumentlinks_db";
        group_type = "";
        hierarchy = "document";
        obj.DocumentLinks = GetDocumentElementListFromDBByParentID_with_doc_id(
            iqvdocumentlink_db_List,
            obj.id,
            table_name,
            group_type,
            hierarchy);

        logger.debug("Num links = " + str(len(obj.DocumentLinks)));
        for para in obj.DocumentLinks:
            para = GetIQVDocumentLinkElementsFromDB_with_doc_id_d1(
                para,
                "",
                table_name,
                hierarchy,
                Dict_iqvpageroi_db,  # dict
                Dict_FontInfo_db,  # dict
                IQVAttributeCandidate_db_List,
                NLP_Attribute_db_List,
                IQVTableColumn_db_List,
                IQVTableColumnHeader_db_List,
                IQVQCUpdateTracking_db_List,
                IQVAttribute_db_List,
                Dict_IQVKeyValueSet_db,  # dict
                Dict_IQVSubText_db,  # dict
                Dict_NLP_Entity_db  # dict
            );

        table_name = "";
        group_type = "IQVDocumentFeedbackResultsList";
        hierarchy = "document";
        obj.IQVDocumentFeedbackResultsList = GetDocumentElementListFromDBByParentID_with_doc_id(
            iqvdocumentfeedbackresults_db_List,
            obj.id,
            table_name,
            group_type,
            hierarchy);

        logger.debug("Num feedback results = " + str(len(obj.IQVDocumentFeedbackResultsList)));
        for para in obj.IQVDocumentFeedbackResultsList:
            para = GetIQVDocumentFeedbackResultsElementsFromDB_with_doc_id_d1(
                para,
                "",
                table_name,
                hierarchy,
                Dict_documentfooters_db,  # dict
                Dict_FontInfo_db,  # dict
                IQVAttributeCandidate_db_List,
                NLP_Attribute_db_List,
                IQVTableColumn_db_List,
                IQVTableColumnHeader_db_List,
                IQVQCUpdateTracking_db_List,
                IQVAttribute_db_List,
                Dict_IQVKeyValueSet_db,  # dict
                Dict_IQVSubText_db,  # dict
                Dict_NLP_Entity_db  # dict
            );

        table_name = "";
        group_type = "IQVDocumentProcesses";
        hierarchy = "document";
        obj.IQVDocumentProcesses = GetDocumentElementListFromDBByParentID_with_doc_id(
            iqvdocumentprocess_db_List,
            obj.id,
            table_name,
            group_type,
            hierarchy);

        logger.debug("Num processes = " + str(len(obj.IQVDocumentProcesses)));
        for para in obj.IQVDocumentProcesses:
            para = GetIQVDocumentProcessElementsFromDB_with_doc_id_d1(
                para,
                "",
                table_name,
                hierarchy,
                Dict_documentfooters_db,  # dict
                Dict_FontInfo_db,  # dict
                IQVAttributeCandidate_db_List,
                NLP_Attribute_db_List,
                IQVTableColumn_db_List,
                IQVTableColumnHeader_db_List,
                IQVQCUpdateTracking_db_List,
                IQVAttribute_db_List,
                Dict_IQVKeyValueSet_db,  # dict
                Dict_IQVSubText_db,  # dict
                Dict_NLP_Entity_db  # dict
            );

        #        //
        #        // first get high level
        #        //
        group_type = "Properties";
        table_name = "";
        hierarchy = "document";
        obj.Properties = GetDocumentElementListFromDBByParentID_with_doc_id_d1(
            Dict_IQVKeyValueSet_db,
            obj.id,
            table_name,
            group_type,
            hierarchy);
        #        //
        #        // next get recursive levels
        #        //
        for para in obj.Properties:
            para = GetIQVKeyValueSetElementsFromDB_with_doc_id_d1(
                para,
                "",
                table_name,
                hierarchy,
                Dict_documentparagraphs_db,  # dict
                Dict_FontInfo_db,  # dict
                IQVAttributeCandidate_db_List,
                NLP_Attribute_db_List,
                IQVTableColumn_db_List,
                IQVTableColumnHeader_db_List,
                IQVQCUpdateTracking_db_List,
                IQVAttribute_db_List,
                Dict_IQVKeyValueSet_db,  # dict
                Dict_IQVSubText_db,  # dict
                Dict_NLP_Entity_db  # dict
            );


        group_type = "NLP_Attributes";
        hierarchy = "document";
        obj.NLP_Attributes = GetDocumentElementListFromDBByParentID_with_doc_id(
            NLP_Attribute_db_List,
            obj.id,
            table_name,
            group_type,
            hierarchy);
        #        //
        #        // next get recursive levels
        #        //
        for para in obj.NLP_Attributes:
            para = GetNLP_AttributeElementsFromDB_with_doc_id_d1(
                para,
                "",
                table_name,
                hierarchy,
                Dict_documentparagraphs_db,  # dict
                Dict_FontInfo_db,  # dict
                IQVAttributeCandidate_db_List,
                NLP_Attribute_db_List,
                IQVTableColumn_db_List,
                IQVTableColumnHeader_db_List,
                IQVQCUpdateTracking_db_List,
                IQVAttribute_db_List,
                Dict_IQVKeyValueSet_db,  # dict
                Dict_IQVSubText_db,  # dict
                Dict_NLP_Entity_db  # dict
            );

        #        //obj.NLP_Entities
        group_type = "NLP_Entities";
        hierarchy = "document";
        obj.NLP_Entities = GetDocumentElementListFromDBByParentID_with_doc_id_d1(
            Dict_NLP_Entity_db,
            obj.id,
            table_name,
            group_type,
            hierarchy);
        #        //
        #        // next get recursive levels
        #        //
        for para in obj.NLP_Entities:
            para = GetNLP_EntityElementsFromDB_with_doc_id_d1(
                para,
                "",
                table_name,
                hierarchy,
                Dict_documentparagraphs_db,  # dict
                Dict_FontInfo_db,  # dict
                IQVAttributeCandidate_db_List,
                NLP_Attribute_db_List,
                IQVTableColumn_db_List,
                IQVTableColumnHeader_db_List,
                IQVQCUpdateTracking_db_List,
                IQVAttribute_db_List,
                Dict_IQVKeyValueSet_db,  # dict
                Dict_IQVSubText_db,  # dict
                Dict_NLP_Entity_db  # dict
            );

        return obj;
    except Exception as e1:
        logger.exception("Error reading document")
        return None;


def GetIQVDocumentFromDB_with_doc_id_d1(
    conn,
    id,
    headers_only = False,
    link_level = -1,
    link_id = ""
    ):
    """
    Get a document or document section as IQVDocument object

    For entire document, provide the doc_id

    For document section, provide doc_id and link_id/link_level

    Example for a document section 5, with new object returned as doc1:
        conn = get_dev_connection()
        doc_id = '6b13a3fc-fa0c-4dce-b20e-3dcfef843794'
        link_level=1
        link_id='522b51a2-eb6e-11ec-9ff5-005056ab6469' # 'UUID-for-section-5'
        doc1 = GetIQVDocumentFromDB_with_doc_id(
            conn,
            doc_id,
            link_level,
            link_id)

    Example for a document section 5.3, with new object returned as doc1:
        conn = get_dev_connection()
        doc_id = '6b13a3fc-fa0c-4dce-b20e-3dcfef843794'
        link_level=2 # note second level for 5.3
        link_id='UUID-for-section-5.3'
        doc1 = GetIQVDocumentFromDB_with_doc_id(
            conn,
            doc_id,
            link_level,
            link_id)

    """

    try:
        obj = IQVDocument();

        table_name = "";
        group_type = "";

        obj = GetIQVDocumentFromDB(
            conn,
            id,
            table_name,
            group_type);

        if obj is None:
            logger.exception("Failed to retrieve primary object for id = " + id)
            return None

        bUseLink = False;
        if link_level >= 1 and len(link_id) > 0:
            bUseLink = True;
        group_type = "";

        table_name = "documentparagraphs_db";
        documentparagraphs_db_List = [];
        if not headers_only:
            if not bUseLink:
                documentparagraphs_db_List = GetIQVPageROI_db_All_ListFromDBByDocID(
                    conn,
                    id,
                    table_name,
                    "");
            else:
                documentparagraphs_db_List = GetIQVPageROI_db_All_ListFromDBByLinkID(
                    conn,
                    id,
                    table_name,
                    link_id,
                    link_level);
        ##########################################
        #
        # Create LUT for documentparagraphs_db_List
        #
        ##########################################
        Dict_documentparagraphs_db = GetDictionaryFromList(documentparagraphs_db_List);

        table_name = "documentimages_db";
        documentimages_db_List = [];
        if not headers_only:
            if not bUseLink:
                documentimages_db_List = GetIQVPageROI_db_All_ListFromDBByDocID(
                    conn,
                    id,
                    table_name,
                    "");
            else:
                documentimages_db_List = GetIQVPageROI_db_All_ListFromDBByLinkID(
                    conn,
                    id,
                    table_name,
                    link_id,
                    link_level);
        ##########################################
        #
        # Create LUT for documentimages_db_List
        #
        ##########################################
        Dict_documentimages_db = GetDictionaryFromList(documentimages_db_List);

        table_name = "documenttables_db";
        documenttables_db_List = []
        if not headers_only:
            if not bUseLink:
                documenttables_db_List = GetIQVPageROI_db_All_ListFromDBByDocID(
                    conn,
                    id,
                    table_name,
                    "");
            else:
                documenttables_db_List = GetIQVPageROI_db_All_ListFromDBByLinkID(
                    conn,
                    id,
                    table_name,
                    link_id,
                    link_level);
        ##########################################
        #
        # Create LUT for documenttables_db_List
        #
        ##########################################
        Dict_documenttables_db = GetDictionaryFromList(documenttables_db_List);

        table_name = "documentitems_db";
        documentitems_db_List = [];
        if not headers_only:
            if not bUseLink:
                documentitems_db_List = GetIQVPageROI_db_All_ListFromDBByDocID(
                    conn,
                    id,
                    table_name,
                    "");
            else:
                documentitems_db_List = GetIQVPageROI_db_All_ListFromDBByLinkID(
                    conn,
                    id,
                    table_name,
                    link_id,
                    link_level);
        ##########################################
        #
        # Create LUT for documentitems_db_List
        #
        ##########################################
        Dict_documentitems_db = GetDictionaryFromList(documentitems_db_List);

        table_name = "documentheaders_db";
        documentheaders_db_List = [];
        if not headers_only:
            if not bUseLink:
                documentheaders_db_List = GetIQVPageROI_db_All_ListFromDBByDocID(
                    conn,
                    id,
                    table_name,
                    "");
            else:
                documentheaders_db_List = GetIQVPageROI_db_All_ListFromDBByLinkID(
                    conn,
                    id,
                    table_name,
                    link_id,
                    link_level);
        ##########################################
        #
        # Create LUT for documentheaders_db_List
        #
        ##########################################
        Dict_documentheaders_db = GetDictionaryFromList(documentheaders_db_List);

        table_name = "documentfooters_db";
        documentfooters_db_List = [];
        if not headers_only:
            if not bUseLink:
                documentfooters_db_List = GetIQVPageROI_db_All_ListFromDBByDocID(
                    conn,
                    id,
                    table_name,
                    "");
            else:
                documentfooters_db_List = GetIQVPageROI_db_All_ListFromDBByLinkID(
                    conn,
                    id,
                    table_name,
                    link_id,
                    link_level);
        ##########################################
        #
        # Create LUT for documentfooters_db_List
        #
        ##########################################
        Dict_documentfooters_db = GetDictionaryFromList(documentfooters_db_List);

        table_name = "documentpartslist_db";
        documentparts_db_List = [];
        # returned in sequence order by query
        if not headers_only:
            obj.DocumentPartsList = GetDocumentPartsListFromDBByParentID(
                conn,
                id,
                table_name,
                "");

        table_name = "fontinfo_db";
        fontinfo_db_List = [];
        if not headers_only:
            if not bUseLink:
                fontinfo_db_List = GetFontInfo_db_All_ListFromDBByDocID(
                    conn,
                    id,
                    table_name,
                    "");
            else:
                fontinfo_db_List = GetFontInfo_db_All_ListFromDBByLinkID(
                    conn,
                    id,
                    table_name,
                    link_id,
                    link_level);
        ##########################################
        #
        # Create LUT for fontinfo_db_List
        #
        ##########################################
        Dict_FontInfo_db = GetDictionaryFromList(fontinfo_db_List);

        table_name = "iqvattribute_db";
        IQVAttribute_db_List = [];
        if not headers_only:
            if not bUseLink:
                IQVAttribute_db_List = GetIQVAttribute_db_All_ListFromDBByDocID(
                    conn,
                    id,
                    table_name,
                    "");
            else:
                IQVAttribute_db_List = GetIQVAttribute_db_All_ListFromDBByLinkID(
                    conn,
                    id,
                    table_name,
                    link_id,
                    link_level);

        table_name = "iqvattributecandidate_db";
        IQVAttributeCandidate_db_List = [];
        if not headers_only:
            if not bUseLink:
                IQVAttributeCandidate_db_List = GetIQVAttributeCandidate_db_All_ListFromDBByDocID(
                    conn,
                    id,
                    table_name,
                    "");
            else:
                IQVAttributeCandidate_db_List = GetIQVAttributeCandidate_db_All_ListFromDBByLinkID(
                    conn,
                    id,
                    table_name,
                    link_id,
                    link_level);

        table_name = "iqvcharacter_db";
        iqvcharacter_db_List = [];
        if not headers_only:
            if not bUseLink:
                iqvcharacter_db_List = GetIQVCharacter_db_All_ListFromDBByDocID(
                    conn,
                    id,
                    table_name,
                    "");
            else:
                iqvcharacter_db_List = GetIQVCharacter_db_All_ListFromDBByLinkID(
                    conn,
                    id,
                    table_name,
                    link_id,
                    link_level);

        table_name = "iqvclassifiermodel_db";
        iqvclassifiermodel_db_List = [];

        table_name = "iqvcountrymapping_db";
        iqvcountrymapping_db_List = [];

        table_name = "iqvdocumentcompare_db";
        iqvdocumentcompare_db_List = [];

        table_name = "iqvdocumentdiff_db";
        iqvdocumentdiff_db_List = [];

        table_name = "iqvdocumentfeedbackqc_db";
        iqvdocumentfeedbackqc_db_List = [];
        if not headers_only:
            if not bUseLink:
                iqvdocumentfeedbackqc_db_List = GetIQVDocumentFeedbackQC_db_All_ListFromDBByDocID(
                    conn,
                    id,
                    table_name,
                    "");
            else:
                iqvdocumentfeedbackqc_db_List = GetIQVDocumentFeedbackQC_db_All_ListFromDBByLinkID(
                    conn,
                    id,
                    table_name,
                    link_id,
                    link_level);


        table_name = "";
        iqvdocumentfeedbackresults_db_List = [];
        if not headers_only:
            if not bUseLink:
                iqvdocumentfeedbackresults_db_List = GetIQVDocumentFeedbackResults_db_All_ListFromDBByDocID(
                    conn,
                    id,
                    table_name,
                    "");
            else:
                iqvdocumentfeedbackresults_db_List = GetIQVDocumentFeedbackResults_db_All_ListFromDBByLinkID(
                    conn,
                    id,
                    table_name,
                    link_id,
                    link_level);

        iqvdocumentlink_db_List = [];
        # GET FOR headers_only
        if not bUseLink:
            iqvdocumentlink_db_List = GetIQVDocumentLink_db_All_ListFromDBByDocID(
                conn,
                id,
                table_name,
                "");
        else:
            iqvdocumentlink_db_List = GetIQVDocumentLink_db_All_ListFromDBByLinkID(
                conn,
                id,
                table_name,
                link_id,
                link_level);

        ##########################################
        #
        # Sort links
        #
        ##########################################
        sorted(iqvdocumentlink_db_List, key=operator.attrgetter("LinkType","DocumentSequenceIndex","LinkPage"));
        ##########################################
        #
        # Create LUT for iqvdocumentlink_db_List
        #
        ##########################################
        #Dict_iqvdocumentlink_db = GetDictionaryFromList(iqvdocumentlink_db_List);

        iqvdocumentmapping_db_List = [];

        iqvdocumentprocess_db_List = [];
        # GET FOR headers_only:
        if not bUseLink:
            iqvdocumentprocess_db_List = GetIQVDocumentProcess_db_All_ListFromDBByDocID(
                conn,
                id,
                table_name,
                "");
        else:
            iqvdocumentprocess_db_List = GetIQVDocumentProcess_db_All_ListFromDBByLinkID(
                conn,
                id,
                table_name,
                link_id,
                link_level);

        iqvexternallinkelement_db_List = [];
        if not headers_only:
            if not bUseLink:
                iqvexternallinkelement_db_List = GetIQVExternalLinkElement_db_All_ListFromDBByDocID(
                    conn,
                    id,
                    table_name,
                    "");
            else:
                iqvexternallinkelement_db_List = GetIQVExternalLinkElement_db_All_ListFromDBByLinkID(
                    conn,
                    id,
                    table_name,
                    link_id,
                    link_level);

        iqvexternallink_db_List = [];
        if not headers_only:
            if not bUseLink:
                iqvexternallink_db_List = GetIQVExternalLink_db_All_ListFromDBByDocID(
                    conn,
                    id,
                    table_name,
                    "");
            else:
                iqvexternallink_db_List = GetIQVExternalLink_db_All_ListFromDBByLinkID(
                    conn,
                    id,
                    table_name,
                    link_id,
                    link_level);

        iqvkeyValueset_db_List = [];
        if not headers_only:
            if not bUseLink:
                iqvkeyValueset_db_List = GetIQVKeyValueSet_db_All_ListFromDBByDocID(
                    conn,
                    id,
                    table_name,
                    "");
            else:
                iqvkeyValueset_db_List = GetIQVKeyValueSet_db_All_ListFromDBByLinkID(
                    conn,
                    id,
                    table_name,
                    link_id,
                    link_level);
        else:  
            # headers_only
            # get where doc_id=doc_id AND hierarchy='document'
            # leave table_name and group_type blank!
            hierarchy = "document";
            iqvkeyValueset_db_List = GetIQVKeyValueSetListFromDBByDocID_Hierarchy(
                conn,
                id,
                hierarchy,
                "",
                "");
        ##########################################
        #
        # Create LUT for IQVKeyValueSet
        #
        ##########################################
        Dict_IQVKeyValueSet_db = GetDictionaryFromList(iqvkeyValueset_db_List);

        iqvlanguagemapping_db_List = []

        iqvline_db_List = [];
        if not headers_only:
            if not bUseLink:
                iqvline_db_List = GetIQVLine_db_All_ListFromDBByDocID(
                    conn,
                    id,
                    table_name,
                    "");
            else:
                iqvline_db_List = GetIQVLine_db_All_ListFromDBByLinkID(
                    conn,
                    id,
                    table_name,
                    link_id,
                    link_level);

        iqvnumberinggroup_db_List = []
        if not headers_only:
            if not bUseLink:
                iqvnumberinggroup_db_List = GetIQVNumberingGroup_db_All_ListFromDBByDocID(
                    conn,
                    id,
                    table_name,
                    "");
            else:
                iqvnumberinggroup_db_List = GetIQVNumberingGroup_db_All_ListFromDBByLinkID(
                    conn,
                    id,
                    table_name,
                    link_id,
                    link_level);

        iqvnumberinglevel_db_List = [];
        if not headers_only:
            if not bUseLink:
                iqvnumberinglevel_db_List = GetIQVNumberingLevel_db_All_ListFromDBByDocID(
                    conn,
                    id,
                    table_name,
                    "");
            else:
                iqvnumberinglevel_db_List = GetIQVNumberingLevel_db_All_ListFromDBByLinkID(
                    conn,
                    id,
                    table_name,
                    link_id,
                    link_level);

        iqvpageroi_db_List = [];
        # if not headers_only:
        #     if not bUseLink:
        #         iqvpageroi_db_List = GetIQVPageROI_db_All_ListFromDBByDocID(
        #             conn,
        #             id,
        #             table_name,
        #             "");
        #     else:
        #         iqvpageroi_db_List = GetIQVPageROI_db_All_ListFromDBByLinkID(
        #             conn,
        #             id,
        #             table_name,
        #             link_id,
        #             link_level);
        ##########################################
        #
        # Create LUT for iqvpageroi_db_List
        #
        ##########################################
        Dict_iqvpageroi_db = GetDictionaryFromList(iqvpageroi_db_List);

        IQVQCUpdateTracking_db_List = [];
        if not headers_only:
            if not bUseLink:
                IQVQCUpdateTracking_db_List = GetIQVQCUpdateTracking_db_All_ListFromDBByDocID(
                    conn,
                    id,
                    table_name,
                    "");
            else:
                IQVQCUpdateTracking_db_List = GetIQVQCUpdateTracking_db_All_ListFromDBByLinkID(
                    conn,
                    id,
                    table_name,
                    link_id,
                    link_level);
        else:  
            # headers_only
            # leave table_name and group_type blank!
            hierarchy = "document";
            IQVQCUpdateTracking_db_List = GetIQVQCUpdateTrackingListFromDBByDocID_Hierarchy(
                conn,
                id,
                hierarchy,
                "",
                "");
        ##########################################
        #
        # Create LUT for IQVQCUpdateTracking_db_List
        #
        ##########################################
        Dict_iqvqcupdatetracking_db = GetDictionaryFromList(IQVQCUpdateTracking_db_List);

        iqvredactioncategory_db_List = [];

        iqvredactionprofile_db_List = [];

        iqvsubtext_db_List = [];
        if not headers_only:
            if not bUseLink:
                iqvsubtext_db_List = GetIQVSubText_db_All_ListFromDBByDocID(
                    conn,
                    id,
                    table_name,
                    "");
            else:
                iqvsubtext_db_List = GetIQVSubText_db_All_ListFromDBByLinkID(
                    conn,
                    id,
                    table_name,
                    link_id,
                    link_level);
        ##########################################
        #
        # Create LUT for iqvsubtext_db_List
        #
        ##########################################
        Dict_IQVSubText_db = GetDictionaryFromList(iqvsubtext_db_List);



        IQVTableColumnHeader_db_List = [];
        if not headers_only:
            if not bUseLink:
                IQVTableColumnHeader_db_List = GetIQVTableColumnHeader_db_All_ListFromDBByDocID(
                    conn,
                    id,
                    table_name,
                    "");
            else:
                IQVTableColumnHeader_db_List = GetIQVTableColumnHeader_db_All_ListFromDBByLinkID(
                    conn,
                    id,
                    table_name,
                    link_id,
                    link_level);
        ##########################################
        #
        # Create LUT for IQVTableColumnHeader_db_List
        #
        ##########################################
        Dict_iqvtablecolumnheader_db = GetDictionaryFromList(IQVTableColumnHeader_db_List);

        IQVTableColumn_db_List = [];
        if not headers_only:
            if not bUseLink:
                IQVTableColumn_db_List = GetIQVTableColumn_db_All_ListFromDBByDocID(
                    conn,
                    id,
                    table_name,
                    "");
            else:
                IQVTableColumn_db_List = GetIQVTableColumn_db_All_ListFromDBByLinkID(
                    conn,
                    id,
                    table_name,
                    link_id,
                    link_level);
        ##########################################
        #
        # Create LUT for IQVTableColumn_db_List
        #
        ##########################################
        Dict_iqvtablecolumn_db = GetDictionaryFromList(IQVTableColumn_db_List);

        iqvTableRow_db_List = [];
        if not headers_only:
            if not bUseLink:
                iqvTableRow_db_List = GetIQVTableRow_db_All_ListFromDBByDocID(
                    conn,
                    id,
                    table_name,
                    "");
            else:
                iqvTableRow_db_List = GetIQVTableRow_db_All_ListFromDBByLinkID(
                    conn,
                    id,
                    table_name,
                    link_id,
                    link_level);

        iqvword_db_List = [];
        if not headers_only:
            if not bUseLink:
                iqvword_db_List = GetIQVWord_db_All_ListFromDBByDocID(
                    conn,
                    id,
                    table_name,
                    "");
            else:
                iqvword_db_List = GetIQVWord_db_All_ListFromDBByLinkID(
                    conn,
                    id,
                    table_name,
                    link_id,
                    link_level);

        languagecode_db_List = [];

        NLP_Attribute_db_List = [];
        if not headers_only:
            if not bUseLink:
                NLP_Attribute_db_List = GetNLP_Attribute_db_All_ListFromDBByDocID(
                    conn,
                    id,
                    table_name,
                    "");
            else:
                NLP_Attribute_db_List = GetNLP_Attribute_db_All_ListFromDBByLinkID(
                    conn,
                    id,
                    table_name,
                    link_id,
                    link_level);
        else:  
            # headers_only
            # leave table_name and group_type blank!
            hierarchy = "document";
            NLP_Attribute_db_List = GetNLP_AttributeListFromDBByDocID_Hierarchy(
                conn,
                id,
                hierarchy,
                "",
                "");

        nlp_entity_db_List = [];
        if not headers_only:
            if not bUseLink:
                nlp_entity_db_List = GetNLP_Entity_db_All_ListFromDBByDocID(
                    conn,
                    id,
                    table_name,
                    "");
            else:
                nlp_entity_db_List = GetNLP_Entity_db_All_ListFromDBByLinkID(
                    conn,
                    id,
                    table_name,
                    link_id,
                    link_level);
        else:  
            # headers_only
            # leave table_name and group_type blank!
            hierarchy = "document";
            nlp_entity_db_List = GetNLP_EntityListFromDBByDocID_Hierarchy(
                conn,
                id,
                hierarchy,
                "",
                "");

        ##########################################
        #
        # Create LUT for nlp_entity_db_List
        #
        ##########################################
        Dict_NLP_Entity_db = GetDictionaryFromList(nlp_entity_db_List);

        nLP_Relation_Dbs_List = [];
        if not headers_only:
            if not bUseLink:
                nLP_Relation_Dbs_List = GetNLP_Relation_db_All_ListFromDBByDocID(
                    conn,
                    id,
                    table_name,
                    "");
            else:
                nLP_Relation_Dbs_List = GetNLP_Relation_db_All_ListFromDBByLinkID(
                    conn,
                    id,
                    table_name,
                    link_id,
                    link_level);

        nLP_Segment_Dbs_List = [];
        if not headers_only:
            if not bUseLink:
                nLP_Segment_Dbs_List = GetNLP_Segment_db_All_ListFromDBByDocID(
                    conn,
                    id,
                    table_name,
                    "");
            else:
                nLP_Segment_Dbs_List = GetNLP_Segment_db_All_ListFromDBByLinkID(
                    conn,
                    id,
                    table_name,
                    link_id,
                    link_level);

        nLP_System_Mapping_Dbs_List = [];
        if not headers_only:
            if not bUseLink:
                nLP_System_Mapping_Dbs_List = GetNLP_System_Mapping_db_All_ListFromDBByDocID(
                    conn,
                    id,
                    table_name,
                    "");
            else:
                nLP_System_Mapping_Dbs_List = GetNLP_System_Mapping_db_All_ListFromDBByLinkID(
                    conn,
                    id,
                    table_name,
                    link_id,
                    link_level);

        q_EVENT_LOG_ENTRY_List = [];

        #    ///////////////////////////////////////////////////////////
        #    //
        #    // Now just re-sort and assign in correct spot
        #    //
        #    ///////////////////////////////////////////////////////////


        table_name = "documentparagraphs_db";
        group_type = "";
        hierarchy = "paragraph";
        obj.DocumentParagraphs = GetDocumentElementListFromDBByParentID_with_doc_id(
            documentparagraphs_db_List,
            obj.id,
            table_name,
            group_type,
            hierarchy);

        logger.debug("Num paras = " + str(len(obj.DocumentParagraphs)));
        for para in obj.DocumentParagraphs:
            para = GetIQVPageROIElementsFromDB_with_doc_id_d1(
                para,
                "",
                table_name,
                hierarchy,
                Dict_documentparagraphs_db,  # dict
                Dict_FontInfo_db,  # dict
                IQVAttributeCandidate_db_List,
                NLP_Attribute_db_List,
                Dict_iqvtablecolumn_db,  # new dict IQVTableColumn_db_List,
                Dict_iqvtablecolumnheader_db,  # new dict IQVTableColumnHeader_db_List,
                Dict_iqvqcupdatetracking_db,  # new dict IQVQCUpdateTracking_db_List,
                IQVAttribute_db_List,
                Dict_IQVKeyValueSet_db,  # dict
                Dict_IQVSubText_db,  # dict
                Dict_NLP_Entity_db  # dict
            );


        table_name = "documentimages_db";
        group_type = "";
        hierarchy = "image";
        obj.DocumentImages = GetDocumentElementListFromDBByParentID_with_doc_id(
            documentimages_db_List,
            obj.id,
            table_name,
            group_type,
            hierarchy);

        logger.debug("Num images = " + str(len(obj.DocumentImages)));
        for para in obj.DocumentImages:
            para = GetIQVPageROIElementsFromDB_with_doc_id_d1(
                para,
                "",
                table_name,
                hierarchy,
                Dict_documentimages_db,  # dict
                Dict_FontInfo_db,  # dict
                IQVAttributeCandidate_db_List,
                NLP_Attribute_db_List,
                Dict_iqvtablecolumn_db,  # new dict IQVTableColumn_db_List,
                Dict_iqvtablecolumnheader_db,  # new dict IQVTableColumnHeader_db_List,
                Dict_iqvqcupdatetracking_db,  # new dict IQVQCUpdateTracking_db_List,
                IQVAttribute_db_List,
                Dict_IQVKeyValueSet_db,  # dict
                Dict_IQVSubText_db,  # dict
                Dict_NLP_Entity_db  # dict
            );

        table_name = "documenttables_db";
        group_type = "";
        hierarchy = "table";
        obj.DocumentTables = GetDocumentElementListFromDBByParentID_with_doc_id(
            documenttables_db_List,
            obj.id,
            table_name,
            group_type,
            hierarchy);

        logger.debug("Num tables = " + str(len(obj.DocumentTables)));
        for para in obj.DocumentTables:
            para = GetIQVPageROIElementsFromDB_with_doc_id_d1(
                para,
                "",
                table_name,
                hierarchy,
                Dict_documenttables_db,  # dict
                Dict_FontInfo_db,  # dict
                IQVAttributeCandidate_db_List,
                NLP_Attribute_db_List,
                Dict_iqvtablecolumn_db,  # new dict IQVTableColumn_db_List,
                Dict_iqvtablecolumnheader_db,  # new dict IQVTableColumnHeader_db_List,
                Dict_iqvqcupdatetracking_db,  # new dict IQVQCUpdateTracking_db_List,
                IQVAttribute_db_List,
                Dict_IQVKeyValueSet_db,  # dict
                Dict_IQVSubText_db,  # dict
                Dict_NLP_Entity_db  # dict
            );

        table_name = "documentitems_db";
        group_type = "";
        hierarchy = "item";
        obj.DocumentItems = GetDocumentElementListFromDBByParentID_with_doc_id(
            documentitems_db_List,
            obj.id,
            table_name,
            group_type,
            hierarchy);

        logger.debug("Num items = " + str(len(obj.DocumentItems)));
        for para in obj.DocumentItems:
            para = GetIQVPageROIElementsFromDB_with_doc_id_d1(
                para,
                "",
                table_name,
                hierarchy,
                Dict_documentitems_db,  # dict
                Dict_FontInfo_db,  # dict
                IQVAttributeCandidate_db_List,
                NLP_Attribute_db_List,
                Dict_iqvtablecolumn_db,  # new dict IQVTableColumn_db_List,
                Dict_iqvtablecolumnheader_db,  # new dict IQVTableColumnHeader_db_List,
                Dict_iqvqcupdatetracking_db,  # new dict IQVQCUpdateTracking_db_List,
                IQVAttribute_db_List,
                Dict_IQVKeyValueSet_db,  # dict
                Dict_IQVSubText_db,  # dict
                Dict_NLP_Entity_db  # dict
            );

        table_name = "documentheaders_db";
        group_type = "";
        hierarchy = "header";
        obj.DocumentHeaders = GetDocumentElementListFromDBByParentID_with_doc_id(
            documentheaders_db_List,
            obj.id,
            table_name,
            group_type,
            hierarchy);

        logger.debug("Num headers = " + str(len(obj.DocumentHeaders)));
        for para in obj.DocumentHeaders:
            para = GetIQVPageROIElementsFromDB_with_doc_id_d1(
                para,
                "",
                table_name,
                hierarchy,
                Dict_documentheaders_db,  # dict
                Dict_FontInfo_db,  # dict
                IQVAttributeCandidate_db_List,
                NLP_Attribute_db_List,
                Dict_iqvtablecolumn_db,  # new dict IQVTableColumn_db_List,
                Dict_iqvtablecolumnheader_db,  # new dict IQVTableColumnHeader_db_List,
                Dict_iqvqcupdatetracking_db,  # new dict IQVQCUpdateTracking_db_List,
                IQVAttribute_db_List,
                Dict_IQVKeyValueSet_db,  # dict
                Dict_IQVSubText_db,  # dict
                Dict_NLP_Entity_db  # dict
            );

        table_name = "documentfooters_db";
        group_type = "";
        hierarchy = "footer";
        obj.DocumentFooters = GetDocumentElementListFromDBByParentID_with_doc_id(
            documentfooters_db_List,
            obj.id,
            table_name,
            group_type,
            hierarchy);

        logger.debug("Num footers = " + str(len(obj.DocumentFooters)));
        for para in obj.DocumentFooters:
            para = GetIQVPageROIElementsFromDB_with_doc_id_d1(
                para,
                "",
                table_name,
                hierarchy,
                Dict_documentfooters_db,  # dict
                Dict_FontInfo_db,  # dict
                IQVAttributeCandidate_db_List,
                NLP_Attribute_db_List,
                Dict_iqvtablecolumn_db,  # new dict IQVTableColumn_db_List,
                Dict_iqvtablecolumnheader_db,  # new dict IQVTableColumnHeader_db_List,
                Dict_iqvqcupdatetracking_db,  # new dict IQVQCUpdateTracking_db_List,
                IQVAttribute_db_List,
                Dict_IQVKeyValueSet_db,  # dict
                Dict_IQVSubText_db,  # dict
                Dict_NLP_Entity_db  # dict
            );

        table_name = "iqvdocumentlinks_db";
        group_type = "";
        hierarchy = "document";
        obj.DocumentLinks = GetDocumentElementListFromDBByParentID_with_doc_id(
            iqvdocumentlink_db_List,
            obj.id,
            table_name,
            group_type,
            hierarchy);

        logger.debug("Num links = " + str(len(obj.DocumentLinks)));
        for para in obj.DocumentLinks:
            para = GetIQVDocumentLinkElementsFromDB_with_doc_id_d1(
                para,
                "",
                table_name,
                hierarchy,
                Dict_iqvpageroi_db,  # dict
                Dict_FontInfo_db,  # dict
                IQVAttributeCandidate_db_List,
                NLP_Attribute_db_List,
                Dict_iqvtablecolumn_db,  # new dict IQVTableColumn_db_List,
                Dict_iqvtablecolumnheader_db,  # new dict IQVTableColumnHeader_db_List,
                Dict_iqvqcupdatetracking_db,  # new dict IQVQCUpdateTracking_db_List,
                IQVAttribute_db_List,
                Dict_IQVKeyValueSet_db,  # dict
                Dict_IQVSubText_db,  # dict
                Dict_NLP_Entity_db  # dict
            );

        table_name = "";
        group_type = "IQVDocumentFeedbackResultsList";
        hierarchy = "document";
        obj.IQVDocumentFeedbackResultsList = GetDocumentElementListFromDBByParentID_with_doc_id(
            iqvdocumentfeedbackresults_db_List,
            obj.id,
            table_name,
            group_type,
            hierarchy);

        logger.debug("Num feedback results = " + str(len(obj.IQVDocumentFeedbackResultsList)));
        for para in obj.IQVDocumentFeedbackResultsList:
            para = GetIQVDocumentFeedbackResultsElementsFromDB_with_doc_id_d1(
                para,
                "",
                table_name,
                hierarchy,
                Dict_documentfooters_db,  # dict
                Dict_FontInfo_db,  # dict
                IQVAttributeCandidate_db_List,
                NLP_Attribute_db_List,
                Dict_iqvtablecolumn_db,  # new dict IQVTableColumn_db_List,
                Dict_iqvtablecolumnheader_db,  # new dict IQVTableColumnHeader_db_List,
                Dict_iqvqcupdatetracking_db,  # new dict IQVQCUpdateTracking_db_List,
                IQVAttribute_db_List,
                Dict_IQVKeyValueSet_db,  # dict
                Dict_IQVSubText_db,  # dict
                Dict_NLP_Entity_db  # dict
            );

        table_name = "";
        group_type = "IQVDocumentProcesses";
        hierarchy = "document";
        obj.IQVDocumentProcesses = GetDocumentElementListFromDBByParentID_with_doc_id(
            iqvdocumentprocess_db_List,
            obj.id,
            table_name,
            group_type,
            hierarchy);

        logger.debug("Num processes = " + str(len(obj.IQVDocumentProcesses)));
        for para in obj.IQVDocumentProcesses:
            para = GetIQVDocumentProcessElementsFromDB_with_doc_id_d1(
                para,
                "",
                table_name,
                hierarchy,
                Dict_documentfooters_db,  # dict
                Dict_FontInfo_db,  # dict
                IQVAttributeCandidate_db_List,
                NLP_Attribute_db_List,
                Dict_iqvtablecolumn_db,  # new dict IQVTableColumn_db_List,
                Dict_iqvtablecolumnheader_db,  # new dict IQVTableColumnHeader_db_List,
                Dict_iqvqcupdatetracking_db,  # new dict IQVQCUpdateTracking_db_List,
                IQVAttribute_db_List,
                Dict_IQVKeyValueSet_db,  # dict
                Dict_IQVSubText_db,  # dict
                Dict_NLP_Entity_db  # dict
            );

        #        //
        #        // first get high level
        #        //
        group_type = "Properties";
        table_name = "";
        hierarchy = "document";
        obj.Properties = GetDocumentElementListFromDBByParentID_with_doc_id_d1(
            Dict_IQVKeyValueSet_db,
            obj.id,
            table_name,
            group_type,
            hierarchy);
        #        //
        #        // next get recursive levels
        #        //
        for para in obj.Properties:
            para = GetIQVKeyValueSetElementsFromDB_with_doc_id_d1(
                para,
                "",
                table_name,
                hierarchy,
                Dict_documentparagraphs_db,  # dict
                Dict_FontInfo_db,  # dict
                IQVAttributeCandidate_db_List,
                NLP_Attribute_db_List,
                Dict_iqvtablecolumn_db,  # new dict IQVTableColumn_db_List,
                Dict_iqvtablecolumnheader_db,  # new dict IQVTableColumnHeader_db_List,
                Dict_iqvqcupdatetracking_db,  # new dict IQVQCUpdateTracking_db_List,
                IQVAttribute_db_List,
                Dict_IQVKeyValueSet_db,  # dict
                Dict_IQVSubText_db,  # dict
                Dict_NLP_Entity_db  # dict
            );


        group_type = "NLP_Attributes";
        hierarchy = "document";
        obj.NLP_Attributes = GetDocumentElementListFromDBByParentID_with_doc_id(
            NLP_Attribute_db_List,
            obj.id,
            table_name,
            group_type,
            hierarchy);
        #        //
        #        // next get recursive levels
        #        //
        for para in obj.NLP_Attributes:
            para = GetNLP_AttributeElementsFromDB_with_doc_id_d1(
                para,
                "",
                table_name,
                hierarchy,
                Dict_documentparagraphs_db,  # dict
                Dict_FontInfo_db,  # dict
                IQVAttributeCandidate_db_List,
                NLP_Attribute_db_List,
                Dict_iqvtablecolumn_db,  # new dict IQVTableColumn_db_List,
                Dict_iqvtablecolumnheader_db,  # new dict IQVTableColumnHeader_db_List,
                Dict_iqvqcupdatetracking_db,  # new dict IQVQCUpdateTracking_db_List,
                IQVAttribute_db_List,
                Dict_IQVKeyValueSet_db,  # dict
                Dict_IQVSubText_db,  # dict
                Dict_NLP_Entity_db  # dict
            );

        #        //obj.NLP_Entities
        group_type = "NLP_Entities";
        hierarchy = "document";
        obj.NLP_Entities = GetDocumentElementListFromDBByParentID_with_doc_id_d1(
            Dict_NLP_Entity_db,
            obj.id,
            table_name,
            group_type,
            hierarchy);
        #        //
        #        // next get recursive levels
        #        //
        for para in obj.NLP_Entities:
            para = GetNLP_EntityElementsFromDB_with_doc_id_d1(
                para,
                "",
                table_name,
                hierarchy,
                Dict_documentparagraphs_db,  # dict
                Dict_FontInfo_db,  # dict
                IQVAttributeCandidate_db_List,
                NLP_Attribute_db_List,
                Dict_iqvtablecolumn_db,  # new dict IQVTableColumn_db_List,
                Dict_iqvtablecolumnheader_db,  # new dict IQVTableColumnHeader_db_List,
                Dict_iqvqcupdatetracking_db,  # new dict IQVQCUpdateTracking_db_List,
                IQVAttribute_db_List,
                Dict_IQVKeyValueSet_db,  # dict
                Dict_IQVSubText_db,  # dict
                Dict_NLP_Entity_db  # dict
            );

        return obj;
    except Exception as e1:
        logger.exception("Error reading document")
        return None;


def GetIQVDocumentFromDB_tables_by_term_d1(
    conn,
    id,
    iqv_standard_term,
    headers_only = False,
    link_level = -1,
    link_id = ""
    ):
    """
    Get a document or document section as IQVDocument object
    For this process, get only tables in the document that match the iqv_standard_term

    For entire document, provide the doc_id

    For document section, provide doc_id and link_id/link_level

    """

    try:
        obj = IQVDocument();

        table_name = "";
        group_type = "";

        obj = GetIQVDocumentFromDB(
            conn,
            id,
            table_name,
            group_type);

        if obj is None:
            logger.exception("Failed to retrieve primary object for id = " + id)
            return None

        bUseLink = False;
        if link_level >= 1 and len(link_id) > 0:
            bUseLink = True;
        group_type = "";

        table_name = "documentparagraphs_db";
        documentparagraphs_db_List = [];
        ##########################################
        #
        # Create LUT for documentparagraphs_db_List
        #
        ##########################################
        Dict_documentparagraphs_db = GetDictionaryFromList(documentparagraphs_db_List);

        table_name = "documentimages_db";
        documentimages_db_List = [];
        ##########################################
        #
        # Create LUT for documentimages_db_List
        #
        ##########################################
        Dict_documentimages_db = GetDictionaryFromList(documentimages_db_List);

        table_name = "documenttables_db";
        documenttables_db_List = []
        if not headers_only:
            if not bUseLink:
                documenttables_db_List = GetIQVPageROI_db_All_ListFromDBByDocID(
                    conn,
                    id,
                    table_name,
                    "");
            else:
                documenttables_db_List = GetIQVPageROI_db_All_ListFromDBByLinkID(
                    conn,
                    id,
                    table_name,
                    link_id,
                    link_level);
        ##########################################
        #
        # Create LUT for documenttables_db_List
        #
        ##########################################
        Dict_documenttables_db = GetDictionaryFromList(documenttables_db_List);

        table_name = "documentitems_db";
        documentitems_db_List = [];
        ##########################################
        #
        # Create LUT for documentitems_db_List
        #
        ##########################################
        Dict_documentitems_db = GetDictionaryFromList(documentitems_db_List);

        table_name = "documentheaders_db";
        documentheaders_db_List = [];
        ##########################################
        #
        # Create LUT for documentheaders_db_List
        #
        ##########################################
        Dict_documentheaders_db = GetDictionaryFromList(documentheaders_db_List);

        table_name = "documentfooters_db";
        documentfooters_db_List = [];
        ##########################################
        #
        # Create LUT for documentfooters_db_List
        #
        ##########################################
        Dict_documentfooters_db = GetDictionaryFromList(documentfooters_db_List);

        table_name = "documentpartslist_db";
        documentparts_db_List = [];
        # returned in sequence order by query
        if not headers_only:
            obj.DocumentPartsList = GetDocumentPartsListFromDBByParentID(
                conn,
                id,
                table_name,
                "");

        table_name = "fontinfo_db";
        fontinfo_db_List = [];
        if not headers_only:
            if not bUseLink:
                fontinfo_db_List = GetFontInfo_db_All_ListFromDBByDocID(
                    conn,
                    id,
                    table_name,
                    "");
            else:
                fontinfo_db_List = GetFontInfo_db_All_ListFromDBByLinkID(
                    conn,
                    id,
                    table_name,
                    link_id,
                    link_level);
        ##########################################
        #
        # Create LUT for fontinfo_db_List
        #
        ##########################################
        Dict_FontInfo_db = GetDictionaryFromList(fontinfo_db_List);

        table_name = "iqvattribute_db";
        IQVAttribute_db_List = [];
        if not headers_only:
            if not bUseLink:
                IQVAttribute_db_List = GetIQVAttribute_db_All_ListFromDBByDocID(
                    conn,
                    id,
                    table_name,
                    "");
            else:
                IQVAttribute_db_List = GetIQVAttribute_db_All_ListFromDBByLinkID(
                    conn,
                    id,
                    table_name,
                    link_id,
                    link_level);

        table_name = "iqvattributecandidate_db";
        IQVAttributeCandidate_db_List = [];
        if not headers_only:
            if not bUseLink:
                IQVAttributeCandidate_db_List = GetIQVAttributeCandidate_db_All_ListFromDBByDocID(
                    conn,
                    id,
                    table_name,
                    "");
            else:
                IQVAttributeCandidate_db_List = GetIQVAttributeCandidate_db_All_ListFromDBByLinkID(
                    conn,
                    id,
                    table_name,
                    link_id,
                    link_level);

        table_name = "iqvcharacter_db";
        iqvcharacter_db_List = [];
        if not headers_only:
            if not bUseLink:
                iqvcharacter_db_List = GetIQVCharacter_db_All_ListFromDBByDocID(
                    conn,
                    id,
                    table_name,
                    "");
            else:
                iqvcharacter_db_List = GetIQVCharacter_db_All_ListFromDBByLinkID(
                    conn,
                    id,
                    table_name,
                    link_id,
                    link_level);

        table_name = "iqvclassifiermodel_db";
        iqvclassifiermodel_db_List = [];

        table_name = "iqvcountrymapping_db";
        iqvcountrymapping_db_List = [];

        table_name = "iqvdocumentcompare_db";
        iqvdocumentcompare_db_List = [];

        table_name = "iqvdocumentdiff_db";
        iqvdocumentdiff_db_List = [];

        table_name = "iqvdocumentfeedbackqc_db";
        iqvdocumentfeedbackqc_db_List = [];
        if not headers_only:
            if not bUseLink:
                iqvdocumentfeedbackqc_db_List = GetIQVDocumentFeedbackQC_db_All_ListFromDBByDocID(
                    conn,
                    id,
                    table_name,
                    "");
            else:
                iqvdocumentfeedbackqc_db_List = GetIQVDocumentFeedbackQC_db_All_ListFromDBByLinkID(
                    conn,
                    id,
                    table_name,
                    link_id,
                    link_level);


        table_name = "";
        iqvdocumentfeedbackresults_db_List = [];
        if not headers_only:
            if not bUseLink:
                iqvdocumentfeedbackresults_db_List = GetIQVDocumentFeedbackResults_db_All_ListFromDBByDocID(
                    conn,
                    id,
                    table_name,
                    "");
            else:
                iqvdocumentfeedbackresults_db_List = GetIQVDocumentFeedbackResults_db_All_ListFromDBByLinkID(
                    conn,
                    id,
                    table_name,
                    link_id,
                    link_level);

        iqvdocumentlink_db_List = [];
        # GET FOR headers_only
        if not bUseLink:
            iqvdocumentlink_db_List = GetIQVDocumentLink_db_All_ListFromDBByDocID(
                conn,
                id,
                table_name,
                "");
        else:
            iqvdocumentlink_db_List = GetIQVDocumentLink_db_All_ListFromDBByLinkID(
                conn,
                id,
                table_name,
                link_id,
                link_level);

        ##########################################
        #
        # Sort links
        #
        ##########################################
        sorted(iqvdocumentlink_db_List, key=operator.attrgetter("LinkType","DocumentSequenceIndex","LinkPage"));
        ##########################################
        #
        # Create LUT for iqvdocumentlink_db_List
        #
        ##########################################
        #Dict_iqvdocumentlink_db = GetDictionaryFromList(iqvdocumentlink_db_List);

        iqvdocumentmapping_db_List = [];

        iqvdocumentprocess_db_List = [];
        # GET FOR headers_only:
        if not bUseLink:
            iqvdocumentprocess_db_List = GetIQVDocumentProcess_db_All_ListFromDBByDocID(
                conn,
                id,
                table_name,
                "");
        else:
            iqvdocumentprocess_db_List = GetIQVDocumentProcess_db_All_ListFromDBByLinkID(
                conn,
                id,
                table_name,
                link_id,
                link_level);

        iqvexternallinkelement_db_List = [];
        if not headers_only:
            if not bUseLink:
                iqvexternallinkelement_db_List = GetIQVExternalLinkElement_db_All_ListFromDBByDocID(
                    conn,
                    id,
                    table_name,
                    "");
            else:
                iqvexternallinkelement_db_List = GetIQVExternalLinkElement_db_All_ListFromDBByLinkID(
                    conn,
                    id,
                    table_name,
                    link_id,
                    link_level);

        iqvexternallink_db_List = [];
        if not headers_only:
            if not bUseLink:
                iqvexternallink_db_List = GetIQVExternalLink_db_All_ListFromDBByDocID(
                    conn,
                    id,
                    table_name,
                    "");
            else:
                iqvexternallink_db_List = GetIQVExternalLink_db_All_ListFromDBByLinkID(
                    conn,
                    id,
                    table_name,
                    link_id,
                    link_level);

        iqvkeyValueset_db_List = [];
        if not headers_only:
            if not bUseLink:
                iqvkeyValueset_db_List = GetIQVKeyValueSet_db_All_ListFromDBByDocID(
                    conn,
                    id,
                    table_name,
                    "");
            else:
                iqvkeyValueset_db_List = GetIQVKeyValueSet_db_All_ListFromDBByLinkID(
                    conn,
                    id,
                    table_name,
                    link_id,
                    link_level);
        else:  
            # headers_only
            # get where doc_id=doc_id AND hierarchy='document'
            # leave table_name and group_type blank!
            hierarchy = "document";
            iqvkeyValueset_db_List = GetIQVKeyValueSetListFromDBByDocID_Hierarchy(
                conn,
                id,
                hierarchy,
                "",
                "");
        ##########################################
        #
        # Create LUT for IQVKeyValueSet
        #
        ##########################################
        Dict_IQVKeyValueSet_db = GetDictionaryFromList(iqvkeyValueset_db_List);

        iqvlanguagemapping_db_List = []

        iqvline_db_List = [];
        if not headers_only:
            if not bUseLink:
                iqvline_db_List = GetIQVLine_db_All_ListFromDBByDocID(
                    conn,
                    id,
                    table_name,
                    "");
            else:
                iqvline_db_List = GetIQVLine_db_All_ListFromDBByLinkID(
                    conn,
                    id,
                    table_name,
                    link_id,
                    link_level);

        iqvnumberinggroup_db_List = []
        if not headers_only:
            if not bUseLink:
                iqvnumberinggroup_db_List = GetIQVNumberingGroup_db_All_ListFromDBByDocID(
                    conn,
                    id,
                    table_name,
                    "");
            else:
                iqvnumberinggroup_db_List = GetIQVNumberingGroup_db_All_ListFromDBByLinkID(
                    conn,
                    id,
                    table_name,
                    link_id,
                    link_level);

        iqvnumberinglevel_db_List = [];
        if not headers_only:
            if not bUseLink:
                iqvnumberinglevel_db_List = GetIQVNumberingLevel_db_All_ListFromDBByDocID(
                    conn,
                    id,
                    table_name,
                    "");
            else:
                iqvnumberinglevel_db_List = GetIQVNumberingLevel_db_All_ListFromDBByLinkID(
                    conn,
                    id,
                    table_name,
                    link_id,
                    link_level);

        iqvpageroi_db_List = [];
        # if not headers_only:
        #     if not bUseLink:
        #         iqvpageroi_db_List = GetIQVPageROI_db_All_ListFromDBByDocID(
        #             conn,
        #             id,
        #             table_name,
        #             "");
        #     else:
        #         iqvpageroi_db_List = GetIQVPageROI_db_All_ListFromDBByLinkID(
        #             conn,
        #             id,
        #             table_name,
        #             link_id,
        #             link_level);
        ##########################################
        #
        # Create LUT for iqvpageroi_db_List
        #
        ##########################################
        Dict_iqvpageroi_db = GetDictionaryFromList(iqvpageroi_db_List);

        IQVQCUpdateTracking_db_List = [];
        if not headers_only:
            if not bUseLink:
                IQVQCUpdateTracking_db_List = GetIQVQCUpdateTracking_db_All_ListFromDBByDocID(
                    conn,
                    id,
                    table_name,
                    "");
            else:
                IQVQCUpdateTracking_db_List = GetIQVQCUpdateTracking_db_All_ListFromDBByLinkID(
                    conn,
                    id,
                    table_name,
                    link_id,
                    link_level);
        else:  
            # headers_only
            # leave table_name and group_type blank!
            hierarchy = "document";
            IQVQCUpdateTracking_db_List = GetIQVQCUpdateTrackingListFromDBByDocID_Hierarchy(
                conn,
                id,
                hierarchy,
                "",
                "");
        ##########################################
        #
        # Create LUT for IQVQCUpdateTracking_db_List
        #
        ##########################################
        Dict_iqvqcupdatetracking_db = GetDictionaryFromList(IQVQCUpdateTracking_db_List);

        iqvredactioncategory_db_List = [];

        iqvredactionprofile_db_List = [];

        iqvsubtext_db_List = [];
        if not headers_only:
            if not bUseLink:
                iqvsubtext_db_List = GetIQVSubText_db_All_ListFromDBByDocID(
                    conn,
                    id,
                    table_name,
                    "");
            else:
                iqvsubtext_db_List = GetIQVSubText_db_All_ListFromDBByLinkID(
                    conn,
                    id,
                    table_name,
                    link_id,
                    link_level);
        ##########################################
        #
        # Create LUT for iqvsubtext_db_List
        #
        ##########################################
        Dict_IQVSubText_db = GetDictionaryFromList(iqvsubtext_db_List);



        IQVTableColumnHeader_db_List = [];
        if not headers_only:
            if not bUseLink:
                IQVTableColumnHeader_db_List = GetIQVTableColumnHeader_db_All_ListFromDBByDocID(
                    conn,
                    id,
                    table_name,
                    "");
            else:
                IQVTableColumnHeader_db_List = GetIQVTableColumnHeader_db_All_ListFromDBByLinkID(
                    conn,
                    id,
                    table_name,
                    link_id,
                    link_level);
        ##########################################
        #
        # Create LUT for IQVTableColumnHeader_db_List
        #
        ##########################################
        Dict_iqvtablecolumnheader_db = GetDictionaryFromList(IQVTableColumnHeader_db_List);

        IQVTableColumn_db_List = [];
        if not headers_only:
            if not bUseLink:
                IQVTableColumn_db_List = GetIQVTableColumn_db_All_ListFromDBByDocID(
                    conn,
                    id,
                    table_name,
                    "");
            else:
                IQVTableColumn_db_List = GetIQVTableColumn_db_All_ListFromDBByLinkID(
                    conn,
                    id,
                    table_name,
                    link_id,
                    link_level);
        ##########################################
        #
        # Create LUT for IQVTableColumn_db_List
        #
        ##########################################
        Dict_iqvtablecolumn_db = GetDictionaryFromList(IQVTableColumn_db_List);

        iqvTableRow_db_List = [];
        if not headers_only:
            if not bUseLink:
                iqvTableRow_db_List = GetIQVTableRow_db_All_ListFromDBByDocID(
                    conn,
                    id,
                    table_name,
                    "");
            else:
                iqvTableRow_db_List = GetIQVTableRow_db_All_ListFromDBByLinkID(
                    conn,
                    id,
                    table_name,
                    link_id,
                    link_level);

        iqvword_db_List = [];
        if not headers_only:
            if not bUseLink:
                iqvword_db_List = GetIQVWord_db_All_ListFromDBByDocID(
                    conn,
                    id,
                    table_name,
                    "");
            else:
                iqvword_db_List = GetIQVWord_db_All_ListFromDBByLinkID(
                    conn,
                    id,
                    table_name,
                    link_id,
                    link_level);

        languagecode_db_List = [];

        NLP_Attribute_db_List = [];
        if not headers_only:
            if not bUseLink:
                NLP_Attribute_db_List = GetNLP_Attribute_db_All_ListFromDBByDocID(
                    conn,
                    id,
                    table_name,
                    "");
            else:
                NLP_Attribute_db_List = GetNLP_Attribute_db_All_ListFromDBByLinkID(
                    conn,
                    id,
                    table_name,
                    link_id,
                    link_level);
        else:  
            # headers_only
            # leave table_name and group_type blank!
            hierarchy = "document";
            NLP_Attribute_db_List = GetNLP_AttributeListFromDBByDocID_Hierarchy(
                conn,
                id,
                hierarchy,
                "",
                "");

        nlp_entity_db_List = [];
        if not headers_only:
            if not bUseLink:
                nlp_entity_db_List = GetNLP_Entity_db_All_ListFromDBByDocID(
                    conn,
                    id,
                    table_name,
                    "");
            else:
                nlp_entity_db_List = GetNLP_Entity_db_All_ListFromDBByLinkID(
                    conn,
                    id,
                    table_name,
                    link_id,
                    link_level);
        else:  
            # headers_only
            # leave table_name and group_type blank!
            hierarchy = "document";
            nlp_entity_db_List = GetNLP_EntityListFromDBByDocID_Hierarchy(
                conn,
                id,
                hierarchy,
                "",
                "");

        ##########################################
        #
        # Create LUT for nlp_entity_db_List
        #
        ##########################################
        Dict_NLP_Entity_db = GetDictionaryFromList(nlp_entity_db_List);

        nLP_Relation_Dbs_List = [];
        if not headers_only:
            if not bUseLink:
                nLP_Relation_Dbs_List = GetNLP_Relation_db_All_ListFromDBByDocID(
                    conn,
                    id,
                    table_name,
                    "");
            else:
                nLP_Relation_Dbs_List = GetNLP_Relation_db_All_ListFromDBByLinkID(
                    conn,
                    id,
                    table_name,
                    link_id,
                    link_level);

        nLP_Segment_Dbs_List = [];
        if not headers_only:
            if not bUseLink:
                nLP_Segment_Dbs_List = GetNLP_Segment_db_All_ListFromDBByDocID(
                    conn,
                    id,
                    table_name,
                    "");
            else:
                nLP_Segment_Dbs_List = GetNLP_Segment_db_All_ListFromDBByLinkID(
                    conn,
                    id,
                    table_name,
                    link_id,
                    link_level);

        nLP_System_Mapping_Dbs_List = [];
        if not headers_only:
            if not bUseLink:
                nLP_System_Mapping_Dbs_List = GetNLP_System_Mapping_db_All_ListFromDBByDocID(
                    conn,
                    id,
                    table_name,
                    "");
            else:
                nLP_System_Mapping_Dbs_List = GetNLP_System_Mapping_db_All_ListFromDBByLinkID(
                    conn,
                    id,
                    table_name,
                    link_id,
                    link_level);

        q_EVENT_LOG_ENTRY_List = [];

        #    ///////////////////////////////////////////////////////////
        #    //
        #    // Now just re-sort and assign in correct spot
        #    //
        #    ///////////////////////////////////////////////////////////


        table_name = "documentparagraphs_db";
        group_type = "";
        hierarchy = "paragraph";

        table_name = "documentimages_db";
        group_type = "";
        hierarchy = "image";

        table_name = "documenttables_db";
        group_type = "";
        hierarchy = "table";
        obj.DocumentTables = GetDocumentElementListFromDBByTerm_with_doc_id(
            documenttables_db_List,
            obj.id,
            table_name,
            group_type,
            hierarchy,
            iqv_standard_term);

        logger.debug("Num tables = " + str(len(obj.DocumentTables)));
        for para in obj.DocumentTables:
            para = GetIQVPageROIElementsFromDB_with_doc_id_d1(
                para,
                "",
                table_name,
                hierarchy,
                Dict_documenttables_db,  # dict
                Dict_FontInfo_db,  # dict
                IQVAttributeCandidate_db_List,
                NLP_Attribute_db_List,
                Dict_iqvtablecolumn_db,  # new dict IQVTableColumn_db_List,
                Dict_iqvtablecolumnheader_db,  # new dict IQVTableColumnHeader_db_List,
                Dict_iqvqcupdatetracking_db,  # new dict IQVQCUpdateTracking_db_List,
                IQVAttribute_db_List,
                Dict_IQVKeyValueSet_db,  # dict
                Dict_IQVSubText_db,  # dict
                Dict_NLP_Entity_db  # dict
            );

        table_name = "documentitems_db";
        group_type = "";
        hierarchy = "item";

        table_name = "documentheaders_db";
        group_type = "";
        hierarchy = "header";

        table_name = "documentfooters_db";
        group_type = "";
        hierarchy = "footer";

        table_name = "iqvdocumentlinks_db";
        group_type = "";
        hierarchy = "document";
        obj.DocumentLinks = GetDocumentElementListFromDBByParentID_with_doc_id(
            iqvdocumentlink_db_List,
            obj.id,
            table_name,
            group_type,
            hierarchy);

        logger.debug("Num links = " + str(len(obj.DocumentLinks)));
        for para in obj.DocumentLinks:
            para = GetIQVDocumentLinkElementsFromDB_with_doc_id_d1(
                para,
                "",
                table_name,
                hierarchy,
                Dict_iqvpageroi_db,  # dict
                Dict_FontInfo_db,  # dict
                IQVAttributeCandidate_db_List,
                NLP_Attribute_db_List,
                Dict_iqvtablecolumn_db,  # new dict IQVTableColumn_db_List,
                Dict_iqvtablecolumnheader_db,  # new dict IQVTableColumnHeader_db_List,
                Dict_iqvqcupdatetracking_db,  # new dict IQVQCUpdateTracking_db_List,
                IQVAttribute_db_List,
                Dict_IQVKeyValueSet_db,  # dict
                Dict_IQVSubText_db,  # dict
                Dict_NLP_Entity_db  # dict
            );

        table_name = "";
        group_type = "IQVDocumentFeedbackResultsList";
        hierarchy = "document";
        obj.IQVDocumentFeedbackResultsList = GetDocumentElementListFromDBByParentID_with_doc_id(
            iqvdocumentfeedbackresults_db_List,
            obj.id,
            table_name,
            group_type,
            hierarchy);

        logger.debug("Num feedback results = " + str(len(obj.IQVDocumentFeedbackResultsList)));
        for para in obj.IQVDocumentFeedbackResultsList:
            para = GetIQVDocumentFeedbackResultsElementsFromDB_with_doc_id_d1(
                para,
                "",
                table_name,
                hierarchy,
                Dict_documentfooters_db,  # dict
                Dict_FontInfo_db,  # dict
                IQVAttributeCandidate_db_List,
                NLP_Attribute_db_List,
                Dict_iqvtablecolumn_db,  # new dict IQVTableColumn_db_List,
                Dict_iqvtablecolumnheader_db,  # new dict IQVTableColumnHeader_db_List,
                Dict_iqvqcupdatetracking_db,  # new dict IQVQCUpdateTracking_db_List,
                IQVAttribute_db_List,
                Dict_IQVKeyValueSet_db,  # dict
                Dict_IQVSubText_db,  # dict
                Dict_NLP_Entity_db  # dict
            );

        table_name = "";
        group_type = "IQVDocumentProcesses";
        hierarchy = "document";
        obj.IQVDocumentProcesses = GetDocumentElementListFromDBByParentID_with_doc_id(
            iqvdocumentprocess_db_List,
            obj.id,
            table_name,
            group_type,
            hierarchy);

        logger.debug("Num processes = " + str(len(obj.IQVDocumentProcesses)));
        for para in obj.IQVDocumentProcesses:
            para = GetIQVDocumentProcessElementsFromDB_with_doc_id_d1(
                para,
                "",
                table_name,
                hierarchy,
                Dict_documentfooters_db,  # dict
                Dict_FontInfo_db,  # dict
                IQVAttributeCandidate_db_List,
                NLP_Attribute_db_List,
                Dict_iqvtablecolumn_db,  # new dict IQVTableColumn_db_List,
                Dict_iqvtablecolumnheader_db,  # new dict IQVTableColumnHeader_db_List,
                Dict_iqvqcupdatetracking_db,  # new dict IQVQCUpdateTracking_db_List,
                IQVAttribute_db_List,
                Dict_IQVKeyValueSet_db,  # dict
                Dict_IQVSubText_db,  # dict
                Dict_NLP_Entity_db  # dict
            );

        #        //
        #        // first get high level
        #        //
        group_type = "Properties";
        table_name = "";
        hierarchy = "document";
        obj.Properties = GetDocumentElementListFromDBByParentID_with_doc_id_d1(
            Dict_IQVKeyValueSet_db,
            obj.id,
            table_name,
            group_type,
            hierarchy);
        #        //
        #        // next get recursive levels
        #        //
        for para in obj.Properties:
            para = GetIQVKeyValueSetElementsFromDB_with_doc_id_d1(
                para,
                "",
                table_name,
                hierarchy,
                Dict_documentparagraphs_db,  # dict
                Dict_FontInfo_db,  # dict
                IQVAttributeCandidate_db_List,
                NLP_Attribute_db_List,
                Dict_iqvtablecolumn_db,  # new dict IQVTableColumn_db_List,
                Dict_iqvtablecolumnheader_db,  # new dict IQVTableColumnHeader_db_List,
                Dict_iqvqcupdatetracking_db,  # new dict IQVQCUpdateTracking_db_List,
                IQVAttribute_db_List,
                Dict_IQVKeyValueSet_db,  # dict
                Dict_IQVSubText_db,  # dict
                Dict_NLP_Entity_db  # dict
            );


        group_type = "NLP_Attributes";
        hierarchy = "document";
        obj.NLP_Attributes = GetDocumentElementListFromDBByParentID_with_doc_id(
            NLP_Attribute_db_List,
            obj.id,
            table_name,
            group_type,
            hierarchy);
        #        //
        #        // next get recursive levels
        #        //
        for para in obj.NLP_Attributes:
            para = GetNLP_AttributeElementsFromDB_with_doc_id_d1(
                para,
                "",
                table_name,
                hierarchy,
                Dict_documentparagraphs_db,  # dict
                Dict_FontInfo_db,  # dict
                IQVAttributeCandidate_db_List,
                NLP_Attribute_db_List,
                Dict_iqvtablecolumn_db,  # new dict IQVTableColumn_db_List,
                Dict_iqvtablecolumnheader_db,  # new dict IQVTableColumnHeader_db_List,
                Dict_iqvqcupdatetracking_db,  # new dict IQVQCUpdateTracking_db_List,
                IQVAttribute_db_List,
                Dict_IQVKeyValueSet_db,  # dict
                Dict_IQVSubText_db,  # dict
                Dict_NLP_Entity_db  # dict
            );

        #        //obj.NLP_Entities
        group_type = "NLP_Entities";
        hierarchy = "document";
        obj.NLP_Entities = GetDocumentElementListFromDBByParentID_with_doc_id_d1(
            Dict_NLP_Entity_db,
            obj.id,
            table_name,
            group_type,
            hierarchy);
        #        //
        #        // next get recursive levels
        #        //
        for para in obj.NLP_Entities:
            para = GetNLP_EntityElementsFromDB_with_doc_id_d1(
                para,
                "",
                table_name,
                hierarchy,
                Dict_documentparagraphs_db,  # dict
                Dict_FontInfo_db,  # dict
                IQVAttributeCandidate_db_List,
                NLP_Attribute_db_List,
                Dict_iqvtablecolumn_db,  # new dict IQVTableColumn_db_List,
                Dict_iqvtablecolumnheader_db,  # new dict IQVTableColumnHeader_db_List,
                Dict_iqvqcupdatetracking_db,  # new dict IQVQCUpdateTracking_db_List,
                IQVAttribute_db_List,
                Dict_IQVKeyValueSet_db,  # dict
                Dict_IQVSubText_db,  # dict
                Dict_NLP_Entity_db  # dict
            );

        return obj;
    except Exception as e1:
        logger.exception("Error reading document")
        return None;



def GetIQVDocumentSection_d1(
    conn,
    id,
    cpt_section_key):
    """
    Get a document as IQVDocument object

    To retrieve a specific section from a document, 
    you may utilize the function GetIQVDocumentSection_d1.
    With a handle to the document object and to the database connection, 
    provide the section key that you want to retrieve. 
    The section keys are listed in Standardized Section Headers
    https://wiki.quintiles.net/display/PD/Standardized+Section+Headers.

    :param conn: database connection
    :param id: id of document
    :param cpt_section_key: standardized key for section as in https://wiki.quintiles.net/display/PD/Standardized+Section+Headers
    :returns IQVDocument object
    """
    try:
        bIncludeMetadata = False
        doch = GetIQVDocumentFromDB_headers(
            conn,
            id,
            bIncludeMetadata
        );

        link_id = ''
        link_level = 1
        for link in doch.DocumentLinks:
            if link.iqv_standard_term == cpt_section_key:
                link_id = link.id
                link_level = link.LinkLevel
                break

        headers_only = False
        if len(link_id)>0:
            doc1 = GetIQVDocumentFromDB_with_doc_id_d1(
                conn,
                id,
                headers_only,
                link_level,
                link_id
            )
            return doc1;
        else:
            return None;

    except Exception as e1:
        logger.exception("Error retrieving document section")
        return None


def GetIQVDocumentFromDB_headers(
    conn,
    id,
    bIncludeMetadata=False
    ):
    """
    Get a document as IQVDocument object, containing headers as IQVDocumentLink
    Optionally, include document metadata/properties

    """

    try:
        obj = IQVDocument();

        #obj = GetIQVDocumentFromDB(
        #        conn,
        #        id,
        #        "",
        #        "");

        headers_only = True
        bIncludeMetadata = True
        obj = GetIQVDocumentFromDB_with_doc_id_d1(
            conn,
            id,
            headers_only);
        return obj;

        table_name = "";
        group_type = "";

        bUseLink = False;
        group_type = "";


        table_name = "";
        iqvattributecandidate_db_List = [];
        if bIncludeMetadata:
            iqvattributecandidate_db_List = GetIQVAttributeCandidate_db_All_ListFromDBByDocID(
                conn,
                id,
                table_name,
                "");

        table_name = "";
        iqvdocumentlink_db_List = [];
        iqvdocumentlink_db_List = GetIQVDocumentLink_db_All_ListFromDBByDocID(
            conn,
            id,
            table_name,
            "");

        iqvdocumentprocess_db_List = [];
        if bIncludeMetadata:
            iqvdocumentprocess_db_List = GetIQVDocumentProcess_db_All_ListFromDBByDocID(
                conn,
                id,
                table_name,
                "");


        iqvkeyValueset_db_List = [];
        if bIncludeMetadata:
            iqvkeyValueset_db_List = GetIQVKeyValueSet_db_All_ListFromDBByDocID(
                conn,
                id,
                table_name,
                "");

        ##########################################
        #
        # Create LUT
        #
        ##########################################

        # Dictionary<string,List<IQVKeyValueSet_db>> Dict_IQVKeyValueSet_db = new Dictionary<string,List<IQVKeyValueSet_db>>();
        Dict_IQVKeyValueSet_db = dict()
        # List<IQVKeyValueSet_db> tmp = new List<IQVKeyValueSet_db>();
        tmp = []
        iqvkv_id = "";
        for iqvkv in iqvkeyValueset_db_List:
            if iqvkv.parent_id == iqvkv_id:
                pass
            elif len(tmp) > 0:
                if iqvkv_id in Dict_IQVKeyValueSet_db:
                    pass
                else:
                    Dict_IQVKeyValueSet_db[iqvkv_id] = tmp;
                tmp = []
            tmp.append(iqvkv)
            iqvkv_id = iqvkv.parent_id;
        if len(tmp) > 0:
            if iqvkv_id in Dict_IQVKeyValueSet_db:
                pass
            else:
                Dict_IQVKeyValueSet_db[iqvkv_id] = tmp;



        nlp_attribute_db_List = [];
        if not bUseLink:
            nlp_attribute_db_List = GetNLP_Attribute_db_All_ListFromDBByDocID(
                conn,
                id,
                table_name,
                "");
        else:
            nlp_attribute_db_List = GetNLP_Attribute_db_All_ListFromDBByLinkID(
                conn,
                id,
                table_name,
                link_id,
                link_level);

        nlp_entity_db_List = [];
        if not bUseLink:
            nlp_entity_db_List = GetNLP_Entity_db_All_ListFromDBByDocID(
                conn,
                id,
                table_name,
                "");
        else:
            nlp_entity_db_List = GetNLP_Entity_db_All_ListFromDBByLinkID(
                conn,
                id,
                table_name,
                link_id,
                link_level);

        q_EVENT_LOG_ENTRY_List = [];


        documentparagraphs_db_List = [];
        fontinfo_db_List = [];
        iqvattributecandidate_db_List = [];
        iqvsubtext_db_List = [];
        nlp_attribute_db_List = [];
        nlp_entity_db_List = [];
        iqvTableColumn_db_List = [];
        iqvTableColumnHeader_db_List = [];
        iqvQCUpdateTracking_db_List = [];
        iqvattribute_db_List = [];


        #    ///////////////////////////////////////////////////////////
        #    //
        #    // Now just re-sort and assign in correct spot
        #    //
        #    ///////////////////////////////////////////////////////////


        table_name = "iqvkeyvalueset_db";
        group_type = "";
        hierarchy = 'document'
        obj.Properties = GetDocumentElementListFromDBByParentID_with_doc_id_d1(
            Dict_IQVKeyValueSet_db,
            obj.id,
            table_name,
            group_type,
            hierarchy);

        logger.debug("Num paras = " + str(len(obj.Properties)));
        for para in obj.Properties:
            para = GetIQVKeyValueSetElementsFromDB_with_doc_id(
                para,
                "",
                table_name,
                documentparagraphs_db_List,
                iqvkeyValueset_db_List,
                fontinfo_db_List,
                iqvattributecandidate_db_List,
                iqvsubtext_db_List,
                nlp_attribute_db_List,
                nlp_entity_db_List,
                iqvTableColumn_db_List,
                iqvTableColumnHeader_db_List,
                iqvQCUpdateTracking_db_List,
                iqvattribute_db_List,
                Dict_IQVKeyValueSet_db);



        table_name = "iqvdocumentlinks_db";
        group_type = "";
        obj.DocumentLinks = GetDocumentElementListFromDBByParentID_with_doc_id(
            iqvdocumentlink_db_List,
            obj.id,
            table_name,
            group_type,
            hierarchy);

        logger.debug("Num links = " + str(len(obj.DocumentLinks)));
        for para in obj.DocumentLinks:
            para = GetIQVDocumentLinkElementsFromDB_with_doc_id(
                para,
                "",
                table_name,
                documentparagraphs_db_List,
                iqvkeyValueset_db_List,
                fontinfo_db_List,
                iqvattributecandidate_db_List,
                iqvsubtext_db_List,
                nlp_attribute_db_List,
                nlp_entity_db_List,
                iqvTableColumn_db_List,
                iqvTableColumnHeader_db_List,
                iqvQCUpdateTracking_db_List,
                iqvattribute_db_List,
                Dict_IQVKeyValueSet_db);


        return obj;
    except Exception as e1:
        logger.exception("Error reading document")
        return None;


def CreateIQVKeyValueSetForIQVPageROI(
    roi:IQVPageROI,
    key:str,
    value:str
):
    """
    Given the correlated parent <paramref name="roi"/> with flattened hierarchical information,
    copy this hierarchical information to <see cref="IQVKeyValueSet"/> element
    and assign the <paramref name="key"/> and <paramref name="value"/>
    :param roi
    :param key
    :param value
    :returns obj created
    """
    try:
        obj = IQVKeyValueSet();
        obj.link_id = roi.link_id;
        obj.link_id_level2 = roi.link_id_level2;
        obj.link_id_level3 = roi.link_id_level3;
        obj.link_id_level4 = roi.link_id_level4;
        obj.link_id_level5 = roi.link_id_level5;
        obj.link_id_level6 = roi.link_id_level6;
        obj.link_id_subsection1 = roi.link_id_subsection1;
        obj.link_id_subsection2 = roi.link_id_subsection2;
        obj.link_id_subsection3 = roi.link_id_subsection3;
        obj.hierarchy = roi.hierarchy;
        obj.doc_id = roi.doc_id;
        obj.group_type = "Properties";

        obj.parent_id = roi.id;

        obj.key = key;
        obj.value = value;

        return obj;
    except Exception as e:
        logger.exception("Failed to create object")
        return None;


def CreateIQVKeyValueSetForIQVDocumentLink(
    roi:IQVDocumentLink,
    key:str,
    value:str
):
    """
    Given the correlated parent <paramref name="roi"/> with flattened hierarchical information,
    copy this hierarchical information to <see cref="IQVKeyValueSet"/> element
    and assign the <paramref name="key"/> and <paramref name="value"/>
    :param roi
    :param key
    :param value
    :returns obj created
    """
    try:
        obj = IQVKeyValueSet();
        obj.link_id = roi.link_id;
        obj.link_id_level2 = roi.link_id_level2;
        obj.link_id_level3 = roi.link_id_level3;
        obj.link_id_level4 = roi.link_id_level4;
        obj.link_id_level5 = roi.link_id_level5;
        obj.link_id_level6 = roi.link_id_level6;
        obj.link_id_subsection1 = roi.link_id_subsection1;
        obj.link_id_subsection2 = roi.link_id_subsection2;
        obj.link_id_subsection3 = roi.link_id_subsection3;
        obj.hierarchy = roi.hierarchy;
        obj.doc_id = roi.doc_id;
        obj.group_type = "Properties";

        obj.parent_id = roi.id;

        obj.key = key;
        obj.value = value;

        return obj;
    except Exception as e:
        logger.exception("Failed to create object")
        return None;


def CreateIQVQCUpdateTrackingForIQVKeyValueSet(
    roi:IQVKeyValueSet,
    original_value:str,
    updated_value:str,
    source_system:str,
    user_id
):
    """
    Given the correlated parent <paramref name="roi"/> of type IQVKeyValueSet
    with flattened hierarchical information,
    copy this hierarchical information to <see cref="IQVQCUpdateTracking"/> element
    and assign the <paramref name="OriginalText"/> and <paramref name="UpdatedText"/>
    :param roi:parent object IQVKeyValueSet (property)
    :param original_value:current value
    :param updated_value: updated value
    :param source_system: algorithm or human generating value
    :param user_id: id of human or algorithm
    :returns obj created as IQVQCUpdateTracking
    """
    try:
        obj = IQVQCUpdateTracking();
        obj.link_id = roi.link_id;
        obj.link_id_level2 = roi.link_id_level2;
        obj.link_id_level3 = roi.link_id_level3;
        obj.link_id_level4 = roi.link_id_level4;
        obj.link_id_level5 = roi.link_id_level5;
        obj.link_id_level6 = roi.link_id_level6;
        obj.link_id_subsection1 = roi.link_id_subsection1;
        obj.link_id_subsection2 = roi.link_id_subsection2;
        obj.link_id_subsection3 = roi.link_id_subsection3;
        obj.hierarchy = roi.hierarchy;
        obj.doc_id = roi.doc_id;
        obj.group_type = "QCUpdates";

        obj.parent_id = roi.id;

        obj.dts = GetDateTimeString();
        obj.OriginalText = original_value;
        obj.QCType = 'modify'
        obj.roi_id = obj.parent_id
        obj.source_system = source_system;
        obj.user_id = '';
        obj.UpdatedText = updated_value;

        return obj;
    except Exception as e:
        logger.exception("Failed to create object")
        return None;


def CommitDBChanges(
    conn
):
    """
    After Updates or inserts, commit all transactions

    :param conn: connection object
    """
    try:
        conn.commit();
        return True
    except Exception as e:
        logger.exception("Failed to commit changes to database")
        return False

def SetIQVPageROIProperty(
    property_key:str,
    property_value:str,
    parent_roi:IQVPageROI,
    conn
):
    """
    Update or insert this element to database
    "Set" == ADD or UPDATE, depending if it exists
    
    Assume the <paramref name="parent_roi"/> is already created
    Now we want to add a property to this <paramref name="parent_roi"/>
    
    If the <paramref name="property_key"/> already exists, it will be updated
    If it does not exist, a new <see cref="IQVKeyValueSet"/> property will be created

    :param property_key: key of property, see <see cref="IQV_KEY_STRING"/> for common keys</param>
    :param property_value: value of property as a string</param>
    :param parent_roi: parent that has this key-value pair as its own property
        Note that the hierarchy value must be populated here!
    :param conn: connection object
    :returns 2-d tuple [bool,int] such that [True if update successful, num_updated_rows:int]
    """
    table_name = "";
    group_type = "";
    if len(table_name) == 0:
        table_name = "iqvkeyvalueset_db";
    if len(group_type) == 0:
        group_type = "Properties";
    sql = "";
    try:
        parent_id = parent_roi.id;

        #        /////////////////////////////////////////////
        #        //
        #        // primary lookup to rebuild data structure
        #        //  parent_id--id of parent 
        #        //  group_type--member field of parent
        #        // if these are not yet set, set them now
        #        //
        #        //////////////////////////////////////////////

        #        # //////////////////////////////////////////////
        #        //
        #        // First find out what is in database
        #        //
        #        ////////////////////////////////////////////////
        #        //
        #        // first get for tables, paragraphs
        #        //
        existingPropertiesInDB = [];
        table_name = "";
        hierarchy = parent_roi.hierarchy
        existingPropertiesInDB = GetIQVKeyValueSetListFromDBByParentID_Hierarchy(
            conn,
            parent_id,
            hierarchy,
            table_name,
            group_type);

        #        ///////////////////////////////////////////
        #        //
        #        // See if match
        #        //
        #        ///////////////////////////////////////////
        bFoundMatch = False;
        idMatch = "";
        bMatchValue = False;
        obj = IQVKeyValueSet();
        
        if existingPropertiesInDB is not None:
            for kv in existingPropertiesInDB:
                if kv.key == property_key:
                    bFoundMatch = True;
                    obj = kv;
                    idMatch = kv.id;
                    if kv.value == property_value:
                        bMatchValue = True;
                        break;

        if bFoundMatch and bMatchValue:
            logger.debug("Key-value already exists for \nkey = '" + \
                obj.key + "' \nvalue = '" + \
                obj.value + "' \nid = '" + \
                obj.id + "' \nparent_id = '" + \
                parent_id);
            return [True, 0];

        if bFoundMatch:
            # // use existing property with new value
            obj.value = property_value;
            sql = GetUpdate_IQVKeyValueSet(obj, table_name);

            cur = conn.cursor()
            cur.execute(sql, ())
            num_updated_rows = cur.rowcount
            # Commit the changes to the database
            conn.commit()
            cur.close()
            return [True, num_updated_rows];
        # // create new IQVKeyValueSet appropriately!
        obj = CreateIQVKeyValueSetForIQVPageROI(
            parent_roi,
            property_key,
            property_value);
        sql = GetInsert_IQVKeyValueSet_with_doc_id(
            obj, 
            obj.doc_id, 
            parent_id, 
            table_name, 
            group_type);
        cur = conn.cursor()
        cur.execute(sql, ())
        num_updated_rows = cur.rowcount
        # Commit the changes to the database
        conn.commit()
        cur.close()
        return [True, num_updated_rows];
    except Exception as ex:
        logger.error("sql = " + sql)
        logger.exception(ex);
        conn.rollback();
        return [False, 0];


def SetIQVDocumentLinkProperty(
    conn,
    property_key:str,
    property_value:str,
    roi:IQVDocumentLink,
    doc_id:str,
    source_system:str,
    user_id:str=''
):
    """
    Update or insert this element to database
    "Set" == ADD or UPDATE, depending if it exists
    
    Assume the <paramref name="roi"/> is already created
    Now we want to add a property to this <paramref name="roi"/>
    
    If the <paramref name="property_key"/> already exists, it will be updated
    If it does not exist, a new <see cref="IQVKeyValueSet"/> property will be created

    :param property_key: key of property, see <see cref="IQV_KEY_STRING"/> for common keys</param>
    :param property_value: value of property as a string</param>
    :param roi: parent that has this key-value pair as its own property
        Note that the hierarchy value must be populated here!
    :param conn: connection object
    :returns 2-d tuple [bool,int] such that [True if update successful, num_updated_rows:int]
    """
    table_name = "";
    group_type = "";
    if len(table_name) == 0:
        table_name = "iqvkeyvalueset_db";
    if len(group_type) == 0:
        group_type = "Properties";
    sql = "";
    try:
        parent_id = roi.id;

        #        /////////////////////////////////////////////
        #        //
        #        // primary lookup to rebuild data structure
        #        //  parent_id--id of parent 
        #        //  group_type--member field of parent
        #        // if these are not yet set, set them now
        #        //
        #        //////////////////////////////////////////////

        #        # //////////////////////////////////////////////
        #        //
        #        // First find out what is in database
        #        //
        #        ////////////////////////////////////////////////
        #        //
        #        // first get for tables, paragraphs
        #        //
        existingPropertiesInDB = [];
        table_name = "";
        # 
        # for LINK use 'document'
        #
        hierarchy = "document"
        existingPropertiesInDB = GetIQVKeyValueSetListFromDBByParentID_Hierarchy(
            conn,
            parent_id,
            hierarchy,
            table_name,
            group_type);

        #        ///////////////////////////////////////////
        #        //
        #        // See if match
        #        //
        #        ///////////////////////////////////////////

        # parent_id 

        bFoundMatch = False;
        idMatch = "";
        bMatchValue = False;
        original_value = ''

        obj = IQVKeyValueSet();
        
        if existingPropertiesInDB is not None:
            for kv in existingPropertiesInDB:
                if kv.key == property_key:
                    bFoundMatch = True;
                    original_value = kv.value
                    obj = kv;
                    idMatch = kv.id;
                    if kv.value == property_value:
                        bMatchValue = True;
                        break;

        if bFoundMatch and bMatchValue:
            logger.debug("Key-value already exists for \nkey = '" + \
                obj.key + "' \nvalue = '" + \
                obj.value + "' \nid = '" + \
                obj.id + "' \nparent_id = '" + \
                parent_id);
            # Add QC Tracking
            # show duplicate entry
            tracking = CreateIQVQCUpdateTrackingForIQVKeyValueSet(
                obj,
                original_value,
                property_value,
                source_system,
                user_id)
            AddIQVQCUpdateTrackingToDB_with_doc_id(
                tracking,
                doc_id,
                obj.id,
                conn,
                '',
                '');
            return [True, 0];

        if bFoundMatch:
            # // use existing property with new value
            obj.value = property_value;
            sql = GetUpdate_IQVKeyValueSet(obj, table_name);

            cur = conn.cursor()
            cur.execute(sql, ())
            num_updated_rows = cur.rowcount
            # Commit the changes to the database

            # Add QC Tracking
            # show duplicate entry
            tracking = CreateIQVQCUpdateTrackingForIQVKeyValueSet(
                obj,
                original_value,
                property_value,
                source_system,
                user_id)
            AddIQVQCUpdateTrackingToDB_with_doc_id(
                tracking,
                doc_id,
                obj.id,
                conn,
                '',
                '');

            conn.commit()
            cur.close()
            return [True, num_updated_rows];
        # // create new IQVKeyValueSet appropriately!
        obj = CreateIQVKeyValueSetForIQVDocumentLink(
            roi,
            property_key,
            property_value);
        sql = GetInsert_IQVKeyValueSet_with_doc_id(
            obj, 
            obj.doc_id, 
            parent_id, 
            table_name, 
            group_type);
        cur = conn.cursor()
        cur.execute(sql, ())
        num_updated_rows = cur.rowcount

        # Add QC Tracking
        # show duplicate entry
        tracking = CreateIQVQCUpdateTrackingForIQVKeyValueSet(
            obj,
            original_value,
            property_value,
            source_system,
            user_id)
        AddIQVQCUpdateTrackingToDB_with_doc_id(
            tracking,
            doc_id,
            obj.id,
            conn,
            '',
            '');

        # Commit the changes to the database
        conn.commit()
        cur.close()
        return [True, num_updated_rows];
    except Exception as ex:
        logger.error("sql = " + sql)
        logger.exception(ex);
        conn.rollback();
        return [False, 0];


def SetIQVDocumentLink_StandardTerm(
    standard_term:str,
    link_id:str,
    doc_id:str,
    conn
):
    """
    Update this element to database
    "Set" == UPDATE, 
    Assume that the link exists

    :param standard_term: standard term
    :param link_id: id of object
    :param doc_id: parent 
    :param conn: connection object
    :returns 2-d tuple [bool,int] such that [True if update successful, num_updated_rows:int]
    """
    table_name = "";
    group_type = "";


    sql = "";
    try:

        if len(table_name) == 0:
            table_name = "iqvdocumentlink_db";

        sqlWhere = "";
        sqlWhere = sqlWhere + " WHERE id = '";
        sqlWhere = sqlWhere + link_id;
        sqlWhere = sqlWhere + "'";

        sql = "";

        sql = sql + "UPDATE public." + table_name;
        sql = sql + " SET ";

        sql = sql + "\"iqv_standard_term\" = " + "'" + standard_term.replace("'","''").replace("%","%%") + "',";

        if sql.endswith(","):
            sql = sql[0:len(sql)-1];
        sql = sql + sqlWhere;

        cur = conn.cursor()
        cur.execute(sql, ())
        num_updated_rows = cur.rowcount
        # Commit the changes to the database
        conn.commit()
        cur.close()
        return [True, num_updated_rows];
    except Exception as ex:
        logger.error("sql = " + sql)
        logger.exception(ex);
        conn.rollback();
        return [False, 0];


def SetIQVPageROI_StandardTerm(
    standard_term:str,
    id:str,
    table_name:str,
    doc_id:str,
    conn
):
    """
    Update this element to database
    "Set" == UPDATE, 
    Assume that the link exists

    :param standard_term: standard term
    :param id: id of object
    :param table_name: name of database table
    :param doc_id: parent 
    :param conn: connection object
    :returns 2-d tuple [bool,int] such that [True if update successful, num_updated_rows:int]
    """
    group_type = "";


    sql = "";
    try:

        if len(table_name) == 0:
            table_name = "documentparagraphs_db";

        sqlWhere = "";
        sqlWhere = sqlWhere + " WHERE id = '";
        sqlWhere = sqlWhere + id;
        sqlWhere = sqlWhere + "'";

        sql = "";

        sql = sql + "UPDATE public." + table_name;
        sql = sql + " SET ";

        sql = sql + "\"iqv_standard_term\" = " + "'" + standard_term.replace("'","''").replace("%","%%") + "',";

        if sql.endswith(","):
            sql = sql[0:len(sql)-1];
        sql = sql + sqlWhere;

        cur = conn.cursor()
        cur.execute(sql, ())
        num_updated_rows = cur.rowcount
        # Commit the changes to the database
        conn.commit()
        cur.close()
        return [True, num_updated_rows];
    except Exception as ex:
        logger.error("sql = " + sql)
        logger.exception(ex);
        conn.rollback();
        return [False, 0];


def set_IQVPageROI_property_with_roi_id(
    property_key:str,
    property_value:str,
    parent_roi_id:str,
    hierarchy:str,
    cmd
):
    """
    Update or insert this element to database
    "Set" == ADD or UPDATE, depending if it exists
    
    Assume the <paramref name="parent_roi"/> is already created
    Now we want to add a property to this <paramref name="parent_roi"/>
    
    If the <paramref name="property_key"/> already exists, it will be updated
    If it does not exist, a new <see cref="IQVKeyValueSet"/> property will be created

    :param property_key: key of property to be updated/added
    :param property_value: value of property to be updated/added (always str)
    :param parent_roi_id: id of roi that contains the property
    :param hierarchy: hierarchy of roi that contains the property (table, paragraph, image, etc.)
    :param conn: database connection

    #####################################
    #    Sample usage
    #####################################
    # To update single property item (key-value pair)
    # parent_id is id of ROI that the property pertains to
    parent_id = "ac5fcd5c-a46c-4ad7-a1c6-9888d221e78b";
    hierarchy = "table"
    # key is property key
    key = "SectionHeaderPrintPage";
    # val is property value
    val = "1003";
    # conn is database connection
    ret1 = set_IQVPageROI_property_with_roi_id(
        key,
        val,
        parent_id,
        hierarchy,
        conn);

    :param property_key: key of property, see <see cref="IQV_KEY_STRING"/> for common keys</param>
    :param property_value: value of property as a string</param>
    :param parent_roi: parent that has this key-value pair as its own property</param>
    :param cmd: connection object
    :returns true if update successful
    """
    table_name = "";
    group_type = "";
    if len(table_name) == 0:
        table_name = "iqvkeyvalueset_db";
    if len(group_type) == 0:
        group_type = "Properties";
    sql = "";
    try:
        if hierarchy == "paragraph":  
            table_name = "documentparagraphs_db";
        elif hierarchy == "table":  
            table_name = "documenttables_db";
        elif hierarchy == "image":  
            table_name = "documentimages_db";
        elif hierarchy == "header":  
            table_name = "documentheaders_db";
        elif hierarchy == "footer":  
            table_name = "documentfooters_db";
        elif hierarchy == "item":  
            table_name = "documentitems_db";

        roi = None;

        roi = GetIQVPageROIFromDB(
            cmd,
            parent_roi_id,
            table_name,
            "");

        if roi is None:
            logger.exception("ROI not found in database id = " + parent_roi_id + " in SetIQVPageROIProperty");
            return False;

        return SetIQVPageROIProperty(
            property_key,
            property_value,
            roi,
            cmd);

    except Exception as ex:
        logger.exception("Error updating property")
        return False;


def set_IQVDocumentLink_standardterm_with_id(
    standard_term:str,
    link_id:str,
    doc_id:str,
    source_system:str,
    cmd
):
    """
    Update standard term for link (section header)
    "Set" == UPDATE
    
    Assume the IQVDocumentLink is already created

    :param doc_id: IQVDocument
    :param standard_term: value of standard term as in https://wiki.quintiles.net/display/PD/Standardized+Section+Headers
    :param link_id: id of IQVDocumentLink 
    :param source_system: algorithm (or human user) that determined the standard term
    :param conn: database connection

    #####################################
    #    Sample usage
    #####################################
    # To update standard term

    :returns true if update successful
    """
    table_name = "";
    group_type = "";
    if len(table_name) == 0:
        table_name = "iqvdocumentlink_db";
    if len(group_type) == 0:
        group_type = "DocumentLinks";
    sql = "";
    try:

        obj = GetIQVDocumentLinkFromDB(
                cmd,
                link_id,
                table_name,
                group_type);
        if obj is None:
            logger.exception("Error updating--could not retrieve object id = " + link_id)
            return False

        b_updated_std_term = False
        num_updated_rows = 0
        [b_updated_std_term, num_updated_rows] = SetIQVDocumentLink_StandardTerm(
            standard_term,
            link_id,
            doc_id,
            cmd);
        if b_updated_std_term:
            logger.info('Update iqv_standard_term = ' + standard_term + ' for IQVDocumentLink id = ' + link_id)
        else:
            logger.exception("Error updating iqv_standard_term for IQVDocumentLink id = " + link_id)

        property_key = 'iqv_standard_term'
        property_value = standard_term
        b_updated_properties = SetIQVDocumentLinkProperty(
            cmd,
            property_key,
            property_value,
            obj,
            doc_id,
            source_system);
        if b_updated_properties:
            logger.info('Update property for IQVDocumentLink id = ' + link_id)
        else:
            logger.exception("Error updating property for IQVDocumentLink id = " + link_id)

        if b_updated_std_term and b_updated_properties:
            return True
        else:
            return False

    except Exception as ex:
        logger.exception("Error updating property")
        return False;


def set_IQVPageROI_standardterm_with_id(
    standard_term:str,
    roi_id:str,
    hierarchy:str,
    doc_id:str,
    source_system:str,
    cmd
):
    """
    Update standard term for link (section header)
    "Set" == UPDATE
    
    Assume the IQVDocumentLink is already created

    :param doc_id: IQVDocument
    :param standard_term: value of standard term as in https://wiki.quintiles.net/display/PD/Standardized+Section+Headers
    :param roi_id: id of IQVPageROI
    :param hierarchy: hierarchy of roi that contains the property (table, paragraph, image, header, footer, item)
        default is table
    :param source_system: algorithm (or human user) that determined the standard term
    :param conn: database connection

    #####################################
    #    Sample usage
    #####################################
    # To update standard term

    :returns true if update successful
    """
    table_name = "";
    group_type = "";
    if len(hierarchy) == 0:
        hierarchy = "table";
    sql = "";
    try:
        if hierarchy == "paragraph":  
            table_name = "documentparagraphs_db";
            group_type = "DocumentParagraphs"
        elif hierarchy == "table":  
            table_name = "documenttables_db";
            group_type = "DocumentTables"
        elif hierarchy == "image":  
            table_name = "documentimages_db";
            group_type = "DocumentImages"
        elif hierarchy == "header":  
            table_name = "documentheaders_db";
            group_type = "DocumentHeaders"
        elif hierarchy == "footer":  
            table_name = "documentfooters_db";
            group_type = "DocumentFooters"
        elif hierarchy == "item":  
            table_name = "documentitems_db";
            group_type = "DocumentItems"

        obj = GetIQVPageROIFromDB(
                cmd,
                roi_id,
                table_name,
                group_type);
        if obj is None:
            logger.exception("Error updating--could not retrieve object id = " + roi_id)
            return False

        b_updated_std_term = False
        num_updated_rows = 0
        [b_updated_std_term, num_updated_rows] = SetIQVPageROI_StandardTerm(
            standard_term,
            roi_id,
            table_name,
            doc_id,
            cmd);
        if b_updated_std_term:
            logger.info('Update iqv_standard_term = ' + standard_term + ' for ' + hierarchy + ' id = ' + roi_id)
        else:
            logger.exception('Error updating iqv_standard_term for ' + hierarchy + ' id = ' + roi_id)

        property_key = 'iqv_standard_term'
        property_value = standard_term
        [b_updated_properties, num_updated_rows] = SetIQVPageROIProperty(
            property_key,
            property_value,
            obj,
            cmd);
            # doc_id,
            # source_system);
        if b_updated_properties:
            logger.info('Update property for IQVPageROI id = ' + roi_id)
        else:
            logger.exception("Error updating property for IQVPageROI id = " + roi_id)

        if b_updated_std_term and b_updated_properties:
            return True
        else:
            return False

    except Exception as ex:
        logger.exception("Error updating property")
        return False;


def set_externallink_with_id(
    conn,
    doc_id:str,
    destination_link_id:str,
    destination_link_text:str,
    destination_link_prefix:str,
    destination_url:str,
    source_roi_id:str,
    source_text:str='',
    source_start_index:str=-1,
    source_length:str=0,
    connection_type:str='internal',
    hierarchy:str='paragraph',
    source_system:str=''
):
    """
    Link from one place in document (source) to
    either another place in document (internal destination)
    or a URL (external destination)
    
    For internal destination, assume the IQVDocumentLink is already created

    :param doc_id: IQVDocument
    :param destination_link_id: id of IQVDocumentLink of internal destination (UUID)
    :param destination_link_text: text of IQVDocumentLink of internal destination (section header)
    :param destination_link_prefix: TOC prefix of IQVDocumentLink of internal destination, such as '6.2'
    :param destination_link_url: URL of external destination (internet URL)
    :param source_roi_id: id of IQVPageROI of source/pointer
    :param source_text: substring of IQVPageROI of source/pointer that has link embedded
    :param source_start_index: start (zero-based) index of substring of IQVPageROI of source/pointer that has link embedded
    :param source_start_index: char length of substring of IQVPageROI of source/pointer that has link embedded
    :param hierarchy: hierarchy of source roi (table, paragraph, image, header, footer, item)
        default is paragraph
    :param connection: internal for same document, external for URL
    :param source_system: algorithm (or human user) that determined the standard term
    :param conn: database connection

    :returns true if update successful
    """
    table_name = "";
    group_type = "";
    if len(hierarchy) == 0:
        hierarchy = "paragraph";
    sql = "";
    try:
        if hierarchy == "paragraph":  
            table_name = "documentparagraphs_db";
            group_type = "DocumentParagraphs"
        elif hierarchy == "table":  
            table_name = "documenttables_db";
            group_type = "DocumentTables"
        elif hierarchy == "image":  
            table_name = "documentimages_db";
            group_type = "DocumentImages"
        elif hierarchy == "header":  
            table_name = "documentheaders_db";
            group_type = "DocumentHeaders"
        elif hierarchy == "footer":  
            table_name = "documentfooters_db";
            group_type = "DocumentFooters"
        elif hierarchy == "item":  
            table_name = "documentitems_db";
            group_type = "DocumentItems"

        obj = GetIQVPageROIFromDB(
                conn,
                source_roi_id,
                table_name,
                group_type);
        if obj is None:
            logger.exception("Error updating--could not retrieve object id = " + source_roi_id + " from table " + table_name)
            return False

        external_link = IQVExternalLink()
        external_link.group_type = "ExternalLinks"
        external_link.connection_type = connection_type;
        external_link.destination_link_id = destination_link_id;
        external_link.destination_link_prefix = destination_link_prefix;
        external_link.destination_link_text = destination_link_text;
        external_link.destination_url = destination_url;
        external_link.doc_id = doc_id;
        external_link.hierarchy = hierarchy;
        external_link.length = source_length;
        external_link.link_id = obj.link_id;
        external_link.link_id_level2 = obj.link_id_level2;
        external_link.link_id_level3 = obj.link_id_level3;
        external_link.link_id_level4 = obj.link_id_level4;
        external_link.link_id_level5 = obj.link_id_level5;
        external_link.link_id_level6 = obj.link_id_level6;
        external_link.link_id_subsection1 = obj.link_id_subsection1;
        external_link.link_id_subsection2 = obj.link_id_subsection2;
        external_link.link_id_subsection3 = obj.link_id_subsection3;
        external_link.link_text = destination_link_prefix;
        external_link.parent_id = obj.id;
        external_link.source_text = source_text;
        external_link.startIndex = source_start_index;

        link_table_name = "iqvexternallink_db";
        link_group_type = "ExternalLinks"
        sql = GetInsert_IQVExternalLink(
            external_link,
            source_roi_id,
            link_table_name,
            link_group_type
        );

        cur = conn.cursor()
        cur.execute(sql, ())
        num_updated_rows = cur.rowcount
        # Commit the changes to the database
        conn.commit()
        cur.close()
        logger.info('Update external link = ' + external_link.destination_link_text + ' for ' + hierarchy + ' id = ' + source_roi_id)
        return [True, num_updated_rows];

    except Exception as ex:
        logger.error("sql = " + sql)
        logger.exception(ex);
        conn.rollback();
        return [False, 0];


#################################################
#
#region AddIQVToDB_with_doc_id
#
#################################################
def AddIQVQCUpdateTrackingToDB_with_doc_id(
    obj:IQVQCUpdateTracking,
    doc_id:str,
    parent_id:str,
    conn,
    table_name:str,
    group_type:str
):
    """
    Add this element to database
    :param obj: element to be added
    :param doc_id: top-level id of <see cref="IQVDocument"/></param>
    :param parent_id:
    :param conn:
    :param table_name:
    :param group_type:
    :returns True if successful
    """
    try:
        # ///////////////////////////////////////////
        # 
        #  primary lookup to rebuild data structure
        #   parent_id--id of parent 
        #   group_type--member field of parent
        #  if these are not yet set, set them now
        # 
        # ////////////////////////////////////////////
        if len(group_type) > 0:
            obj.group_type = group_type;
                
        if len(parent_id) > 0:
            obj.parent_id = parent_id;
                
        sql = GetInsert_IQVQCUpdateTracking_with_doc_id(
            obj, 
            doc_id,
            parent_id, 
            table_name,
            group_type);
        cur = conn.cursor()
        cur.execute(sql, ())
        num_updated_rows = cur.rowcount
        # Commit the changes to the database
        conn.commit()
        cur.close()

        tmp_table_name = ""; # // "iqvqcupdatetracking_db";
        tmp_group_type = table_name; # // "";
        for kv in obj.Properties:
            AddIQVKeyValueSetToDB_with_doc_id(
                kv, 
                doc_id, 
                obj.id, 
                conn, 
                tmp_table_name, 
                group_type);
        return True        
    except Exception as ex:
        logger.exception("Error adding element to database")
        # rollback the previous transaction before starting another
        conn.rollback()
        return False;


def AddNLP_AttributeToDB_with_doc_id(
    obj:NLP_Attribute,
    doc_id:str,
    parent_id:str,
    conn,
    table_name:str,
    group_type:str
):
    """
    Add this element to database
    :param obj: element to be added
    :param doc_id: top-level id of <see cref="IQVDocument"/></param>
    :param parent_id:
    :param conn:
    :param table_name:
    :param group_type:
    :returns True if successful
    """
    try:
        # ///////////////////////////////////////////
        # 
        #  primary lookup to rebuild data structure
        #   parent_id--id of parent 
        #   group_type--member field of parent
        #  if these are not yet set, set them now
        # 
        # ////////////////////////////////////////////
        if len(group_type) > 0:
            obj.group_type = group_type;
                
        if len(parent_id) > 0:
            obj.parent_id = parent_id;
                
        sql = GetInsert_NLP_Attribute_with_doc_id(
            obj, 
            doc_id,
            parent_id, 
            table_name,
            group_type);
        cur = conn.cursor()
        cur.execute(sql, ())
        num_updated_rows = cur.rowcount
        # Commit the changes to the database
        conn.commit()
        cur.close()

        return True        
    except Exception as ex:
        logger.exception("Error adding element to database")
        # rollback the previous transaction before starting another
        conn.rollback()
        return False;


def AddNLP_EntityToDB_with_doc_id(
    obj:NLP_Entity,
    doc_id:str,
    parent_id:str,
    conn,
    table_name:str,
    group_type:str
):
    """
    Add this element to database
    :param obj: element to be added
    :param doc_id: top-level id of <see cref="IQVDocument"/></param>
    :param parent_id:
    :param conn:
    :param table_name:
    :param group_type:
    :returns True if successful
    """
    try:
        # ///////////////////////////////////////////
        # 
        #  primary lookup to rebuild data structure
        #   parent_id--id of parent 
        #   group_type--member field of parent
        #  if these are not yet set, set them now
        # 
        # ////////////////////////////////////////////
        if len(group_type) > 0:
            obj.group_type = group_type;
                
        if len(parent_id) > 0:
            obj.parent_id = parent_id;
                
        sql = GetInsert_NLP_Entity_with_doc_id(
            obj, 
            doc_id,
            parent_id, 
            table_name,
            group_type);
        cur = conn.cursor()
        cur.execute(sql, ())
        num_updated_rows = cur.rowcount
        # Commit the changes to the database
        conn.commit()
        cur.close()

        tmp_table_name = ""; # // "iqvqcupdatetracking_db";
        tmp_group_type = table_name; # // "";
        for kv in obj.Properties:
            AddIQVKeyValueSetToDB_with_doc_id(
                kv, 
                doc_id, 
                obj.id, 
                conn, 
                tmp_table_name, 
                group_type);
        return True        
    except Exception as ex:
        logger.exception("Error adding element to database")
        # rollback the previous transaction before starting another
        conn.rollback()
        return False;


def AddNLP_RelationToDB_with_doc_id(
    obj:NLP_Relation,
    doc_id:str,
    parent_id:str,
    conn,
    table_name:str,
    group_type:str
):
    """
    Add this element to database
    :param obj: element to be added
    :param doc_id: top-level id of <see cref="IQVDocument"/></param>
    :param parent_id:
    :param conn:
    :param table_name:
    :param group_type:
    :returns True if successful
    """
    try:
        # ///////////////////////////////////////////
        # 
        #  primary lookup to rebuild data structure
        #   parent_id--id of parent 
        #   group_type--member field of parent
        #  if these are not yet set, set them now
        # 
        # ////////////////////////////////////////////
        if len(group_type) > 0:
            obj.group_type = group_type;
                
        if len(parent_id) > 0:
            obj.parent_id = parent_id;
                
        sql = GetInsert_NLP_Relation_with_doc_id(
            obj, 
            doc_id,
            parent_id, 
            table_name,
            group_type);
        cur = conn.cursor()
        cur.execute(sql, ())
        num_updated_rows = cur.rowcount
        # Commit the changes to the database
        conn.commit()
        cur.close()

        return True        
    except Exception as ex:
        logger.exception("Error adding element to database")
        # rollback the previous transaction before starting another
        conn.rollback()
        return False;


def AddNLP_SegmentToDB_with_doc_id(
    obj:NLP_Segment,
    doc_id:str,
    parent_id:str,
    conn,
    table_name:str,
    group_type:str
):
    """
    Add this element to database
    :param obj: element to be added
    :param doc_id: top-level id of <see cref="IQVDocument"/></param>
    :param parent_id:
    :param conn:
    :param table_name:
    :param group_type:
    :returns True if successful
    """
    try:
        # ///////////////////////////////////////////
        # 
        #  primary lookup to rebuild data structure
        #   parent_id--id of parent 
        #   group_type--member field of parent
        #  if these are not yet set, set them now
        # 
        # ////////////////////////////////////////////
        if len(group_type) > 0:
            obj.group_type = group_type;
                
        if len(parent_id) > 0:
            obj.parent_id = parent_id;
                
        sql = GetInsert_NLP_Segment_with_doc_id(
            obj, 
            doc_id,
            parent_id, 
            table_name,
            group_type);
        cur = conn.cursor()
        cur.execute(sql, ())
        num_updated_rows = cur.rowcount
        # Commit the changes to the database
        conn.commit()
        cur.close()

        tmp_table_name = ""; # // "iqvqcupdatetracking_db";
        tmp_group_type = table_name; # // "";
        group_type = "Properties"
        for kv in obj.Properties:
            AddIQVKeyValueSetToDB_with_doc_id(
                kv, 
                doc_id, 
                obj.id, 
                conn, 
                tmp_table_name, 
                group_type);
        group_type = "entities"
        for kv in obj.entities:
            AddNLP_EntityToDB_with_doc_id(
                kv, 
                doc_id, 
                obj.id, 
                conn, 
                tmp_table_name, 
                group_type);
        group_type = "attributes"
        for kv in obj.attributes:
            AddNLP_AttributeToDB_with_doc_id(
                kv, 
                doc_id, 
                obj.id, 
                conn, 
                tmp_table_name, 
                group_type);
        group_type = "segments"
        for kv in obj.segments:
            AddNLP_SegmentToDB_with_doc_id(
                kv, 
                doc_id, 
                obj.id, 
                conn, 
                tmp_table_name, 
                group_type);

        return True        
    except Exception as ex:
        logger.exception("Error adding element to database")
        # rollback the previous transaction before starting another
        conn.rollback()
        return False;

def AddNLP_System_MappingToDB_with_doc_id(
    obj:NLP_System_Mapping,
    doc_id:str,
    parent_id:str,
    conn,
    table_name:str,
    group_type:str
):
    """
    Add this element to database
    :param obj: element to be added
    :param doc_id: top-level id of <see cref="IQVDocument"/></param>
    :param parent_id:
    :param conn:
    :param table_name:
    :param group_type:
    :returns True if successful
    """
    try:
        # ///////////////////////////////////////////
        # 
        #  primary lookup to rebuild data structure
        #   parent_id--id of parent 
        #   group_type--member field of parent
        #  if these are not yet set, set them now
        # 
        # ////////////////////////////////////////////
        if len(group_type) > 0:
            obj.group_type = group_type;
                
        if len(parent_id) > 0:
            obj.parent_id = parent_id;
                
        sql = GetInsert_NLP_System_Mapping_with_doc_id(
            obj, 
            doc_id,
            parent_id, 
            table_name,
            group_type);
        cur = conn.cursor()
        cur.execute(sql, ())
        num_updated_rows = cur.rowcount
        # Commit the changes to the database
        conn.commit()
        cur.close()

        return True        
    except Exception as ex:
        logger.exception("Error adding element to database")
        # rollback the previous transaction before starting another
        conn.rollback()
        return False;

def AddIQVSubTextToDB_with_doc_id(
    obj:IQVSubText,
    doc_id:str,
    parent_id:str,
    conn,
    table_name:str,
    group_type:str
):
    """
    Add this element to database
    :param obj: element to be added
    :param doc_id: top-level id of <see cref="IQVDocument"/></param>
    :param parent_id:
    :param conn:
    :param table_name:
    :param group_type:
    :returns True if successful
    """
    try:
        # ///////////////////////////////////////////
        # 
        #  primary lookup to rebuild data structure
        #   parent_id--id of parent 
        #   group_type--member field of parent
        #  if these are not yet set, set them now
        # 
        # ////////////////////////////////////////////
        if len(group_type) > 0:
            obj.group_type = group_type;
                
        if len(parent_id) > 0:
            obj.parent_id = parent_id;
                
        sql = GetInsert_IQVSubText_with_doc_id(
            obj, 
            doc_id,
            parent_id, 
            table_name,
            group_type);
        cur = conn.cursor()
        cur.execute(sql, ())
        num_updated_rows = cur.rowcount
        # Commit the changes to the database
        conn.commit()
        cur.close()

        AddFontInfoToDB_with_doc_id(
            obj.fontInfo,
            doc_id,
            obj.id,
            conn,
            "",
            "fontInfo");

        tmp_table_name = ""; # // "iqvqcupdatetracking_db";
        group_type = "QCUpdates"
        for kv in obj.QCUpdates:
            AddIQVQCUpdateTrackingToDB_with_doc_id(
                kv, 
                doc_id, 
                obj.id, 
                conn, 
                tmp_table_name, 
                group_type);

        tmp_table_name = ""; # // "iqvqcupdatetracking_db";
        tmp_group_type = table_name; # // "";
        group_type = "Properties"
        for kv in obj.Properties:
            AddIQVKeyValueSetToDB_with_doc_id(
                kv, 
                doc_id, 
                obj.id, 
                conn, 
                tmp_table_name, 
                group_type);
        group_type = "entities"
        for kv in obj.entities:
            AddNLP_EntityToDB_with_doc_id(
                kv, 
                doc_id, 
                obj.id, 
                conn, 
                tmp_table_name, 
                group_type);
        group_type = "attributes"
        for kv in obj.attributes:
            AddNLP_AttributeToDB_with_doc_id(
                kv, 
                doc_id, 
                obj.id, 
                conn, 
                tmp_table_name, 
                group_type);

        return True        
    except Exception as ex:
        logger.exception("Error adding element to database")
        # rollback the previous transaction before starting another
        conn.rollback()
        return False;


def AddIQVKeyValueSetToDB_with_doc_id(
    obj:IQVKeyValueSet,
    doc_id:str,
    parent_id:str,
    conn,
    table_name:str,
    group_type:str
):
    """
    Add this element to database
    :param obj: element to be added
    :param doc_id: top-level id of <see cref="IQVDocument"/></param>
    :param parent_id:
    :param conn:
    :param table_name:
    :param group_type:
    :returns True if successful
    """
    try:
        # ///////////////////////////////////////////
        # 
        #  primary lookup to rebuild data structure
        #   parent_id--id of parent 
        #   group_type--member field of parent
        #  if these are not yet set, set them now
        # 
        # ////////////////////////////////////////////
        if len(group_type) > 0:
            obj.group_type = group_type;
                
        if len(parent_id) > 0:
            obj.parent_id = parent_id;
                
        sql = GetInsert_IQVKeyValueSet_with_doc_id(
            obj, 
            doc_id,
            parent_id, 
            table_name,
            group_type);
        cur = conn.cursor()
        cur.execute(sql, ())
        num_updated_rows = cur.rowcount
        # Commit the changes to the database
        conn.commit()
        cur.close()

        tmp_table_name = ""; # // "iqvqcupdatetracking_db";
        group_type = "QCUpdates"
        for kv in obj.QCUpdates:
            AddIQVQCUpdateTrackingToDB_with_doc_id(
                kv, 
                doc_id, 
                obj.id, 
                conn, 
                tmp_table_name, 
                group_type);

        group_type = "NLP_Entities"
        for kv in obj.NLP_Entities:
            AddNLP_EntityToDB_with_doc_id(
                kv, 
                doc_id, 
                obj.id, 
                conn, 
                tmp_table_name, 
                group_type);
        group_type = "NLP_Entities"
        for kv in obj.NLP_Entities:
            AddNLP_AttributeToDB_with_doc_id(
                kv, 
                doc_id, 
                obj.id, 
                conn, 
                tmp_table_name, 
                group_type);

        return True        
    except Exception as ex:
        logger.exception("Error adding element to database")
        # rollback the previous transaction before starting another
        conn.rollback()
        return False;


def AddConfigToDB_with_doc_id(
    obj:Config,
    doc_id:str,
    parent_id:str,
    conn,
    table_name:str,
    group_type:str
):
    """
    Add this element to database
    :param obj: element to be added
    :param doc_id: top-level id of <see cref="IQVDocument"/></param>
    :param parent_id:
    :param conn:
    :param table_name:
    :param group_type:
    :returns True if successful
    """
    try:
        # ///////////////////////////////////////////
        # 
        #  primary lookup to rebuild data structure
        #   parent_id--id of parent 
        #   group_type--member field of parent
        #  if these are not yet set, set them now
        # 
        # ////////////////////////////////////////////
        if len(group_type) > 0:
            obj.group_type = group_type;
                
        if len(parent_id) > 0:
            obj.parent_id = parent_id;
                
        sql = GetInsert_Config_with_doc_id(
            obj, 
            doc_id,
            parent_id, 
            table_name,
            group_type);
        cur = conn.cursor()
        cur.execute(sql, ())
        num_updated_rows = cur.rowcount
        # Commit the changes to the database
        conn.commit()
        cur.close()
        return True        
    except Exception as ex:
        logger.exception("Error adding element to database")
        # rollback the previous transaction before starting another
        conn.rollback()
        return False;

def AddFontInfoToDB_with_doc_id(
    obj:FontInfo,
    doc_id:str,
    parent_id:str,
    conn,
    table_name:str,
    group_type:str
):
    """
    Add this element to database
    :param obj: element to be added
    :param doc_id: top-level id of <see cref="IQVDocument"/></param>
    :param parent_id:
    :param conn:
    :param table_name:
    :param group_type:
    :returns True if successful
    """
    try:
        # ///////////////////////////////////////////
        # 
        #  primary lookup to rebuild data structure
        #   parent_id--id of parent 
        #   group_type--member field of parent
        #  if these are not yet set, set them now
        # 
        # ////////////////////////////////////////////
        if len(group_type) > 0:
            obj.group_type = group_type;
                
        if len(parent_id) > 0:
            obj.parent_id = parent_id;
                
        sql = GetInsert_FontInfo_with_doc_id(
            obj, 
            doc_id,
            parent_id, 
            table_name,
            group_type);
        cur = conn.cursor()
        cur.execute(sql, ())
        num_updated_rows = cur.rowcount
        # Commit the changes to the database
        conn.commit()
        cur.close()
        return True        
    except Exception as ex:
        logger.exception("Error adding element to database")
        # rollback the previous transaction before starting another
        conn.rollback()
        return False;

def AddIQVCountryMappingToDB_with_doc_id(
    obj:IQVCountryMapping,
    doc_id:str,
    parent_id:str,
    conn,
    table_name:str,
    group_type:str
):
    """
    Add this element to database
    :param obj: element to be added
    :param doc_id: top-level id of <see cref="IQVDocument"/></param>
    :param parent_id:
    :param conn:
    :param table_name:
    :param group_type:
    :returns True if successful
    """
    try:
        # ///////////////////////////////////////////
        # 
        #  primary lookup to rebuild data structure
        #   parent_id--id of parent 
        #   group_type--member field of parent
        #  if these are not yet set, set them now
        # 
        # ////////////////////////////////////////////
        if len(group_type) > 0:
            obj.group_type = group_type;
                
        if len(parent_id) > 0:
            obj.parent_id = parent_id;
                
        sql = GetInsert_IQVCountryMapping_with_doc_id(
            obj, 
            doc_id,
            parent_id, 
            table_name,
            group_type);
        cur = conn.cursor()
        cur.execute(sql, ())
        num_updated_rows = cur.rowcount
        # Commit the changes to the database
        conn.commit()
        cur.close()

        tmp_table_name = ""; # // "iqvqcupdatetracking_db";
        group_type = "iqvLanguageMappings"
        for kv in obj.iqvLanguageMappings:
            AddIQVLanguageMappingToDB_with_doc_id(
                kv, 
                doc_id, 
                obj.id, 
                conn, 
                tmp_table_name, 
                group_type);


        return True        
    except Exception as ex:
        logger.exception("Error adding element to database")
        # rollback the previous transaction before starting another
        conn.rollback()
        return False;

def AddIQVLanguageMappingToDB_with_doc_id(
    obj:IQVLanguageMapping,
    doc_id:str,
    parent_id:str,
    conn,
    table_name:str,
    group_type:str
):
    """
    Add this element to database
    :param obj: element to be added
    :param doc_id: top-level id of <see cref="IQVDocument"/></param>
    :param parent_id:
    :param conn:
    :param table_name:
    :param group_type:
    :returns True if successful
    """
    try:
        # ///////////////////////////////////////////
        # 
        #  primary lookup to rebuild data structure
        #   parent_id--id of parent 
        #   group_type--member field of parent
        #  if these are not yet set, set them now
        # 
        # ////////////////////////////////////////////
        if len(group_type) > 0:
            obj.group_type = group_type;
                
        if len(parent_id) > 0:
            obj.parent_id = parent_id;
                
        sql = GetInsert_IQVLanguageMapping_with_doc_id(
            obj, 
            doc_id,
            parent_id, 
            table_name,
            group_type);
        cur = conn.cursor()
        cur.execute(sql, ())
        num_updated_rows = cur.rowcount
        # Commit the changes to the database
        conn.commit()
        cur.close()

        return True        
    except Exception as ex:
        logger.exception("Error adding element to database")
        # rollback the previous transaction before starting another
        conn.rollback()
        return False;


def AddIQVDocumentCompareToDB_with_doc_id(
    obj:IQVDocumentCompare,
    doc_id:str,
    parent_id:str,
    conn,
    table_name:str,
    group_type:str
):
    """
    Add this element to database
    :param obj: element to be added
    :param doc_id: top-level id of <see cref="IQVDocument"/></param>
    :param parent_id:
    :param conn:
    :param table_name:
    :param group_type:
    :returns True if successful
    """
    try:
        # ///////////////////////////////////////////
        # 
        #  primary lookup to rebuild data structure
        #   parent_id--id of parent 
        #   group_type--member field of parent
        #  if these are not yet set, set them now
        # 
        # ////////////////////////////////////////////
        if len(group_type) > 0:
            obj.group_type = group_type;
                
        if len(parent_id) > 0:
            obj.parent_id = parent_id;
                
        sql = GetInsert_IQVDocumentCompare_with_doc_id(
            obj, 
            doc_id,
            parent_id, 
            table_name,
            group_type);
        cur = conn.cursor()
        cur.execute(sql, ())
        num_updated_rows = cur.rowcount
        # Commit the changes to the database
        conn.commit()
        cur.close()

        tmp_table_name = ""; # // "iqvqcupdatetracking_db";
        tmp_group_type = table_name; # // "";
        group_type = "Properties"
        for kv in obj.Properties:
            AddIQVKeyValueSetToDB_with_doc_id(
                kv, 
                doc_id, 
                obj.id, 
                conn, 
                tmp_table_name, 
                group_type);
        tmp_table_name = ""; # // "iqvqcupdatetracking_db";
        tmp_group_type = table_name; # // "";
        group_type = "BaseDocProperties"
        for kv in obj.BaseDocProperties:
            AddIQVKeyValueSetToDB_with_doc_id(
                kv, 
                doc_id, 
                obj.id, 
                conn, 
                tmp_table_name, 
                group_type);

        group_type = "CompareDocProperties"
        for kv in obj.CompareDocProperties:
            AddIQVKeyValueSetToDB_with_doc_id(
                kv, 
                doc_id, 
                obj.id, 
                conn, 
                tmp_table_name, 
                group_type);

        group_type = "DocumentDiffs"
        for kv in obj.DocumentDiffs:
            AddIQVDocumentDiffToDB_with_doc_id(
                kv, 
                doc_id, 
                obj.id, 
                conn, 
                tmp_table_name, 
                group_type);


        AddIQVRedactionProfileToDB_with_doc_id(
            obj.RedactionProfile,
            doc_id,
            obj.id,
            conn,
            "",
            "RedactionProfile");


        return True        
    except Exception as ex:
        logger.exception("Error adding element to database")
        # rollback the previous transaction before starting another
        conn.rollback()
        return False;
        
def AddIQVDocumentDiffToDB_with_doc_id(
    obj:IQVDocumentDiff,
    doc_id:str,
    parent_id:str,
    conn,
    table_name:str,
    group_type:str
):
    """
    Add this element to database
    :param obj: element to be added
    :param doc_id: top-level id of <see cref="IQVDocument"/></param>
    :param parent_id:
    :param conn:
    :param table_name:
    :param group_type:
    :returns True if successful
    """
    try:
        # ///////////////////////////////////////////
        # 
        #  primary lookup to rebuild data structure
        #   parent_id--id of parent 
        #   group_type--member field of parent
        #  if these are not yet set, set them now
        # 
        # ////////////////////////////////////////////
        if len(group_type) > 0:
            obj.group_type = group_type;
                
        if len(parent_id) > 0:
            obj.parent_id = parent_id;
                
        sql = GetInsert_IQVDocumentDiff_with_doc_id(
            obj, 
            doc_id,
            parent_id, 
            table_name,
            group_type);
        cur = conn.cursor()
        cur.execute(sql, ())
        num_updated_rows = cur.rowcount
        # Commit the changes to the database
        conn.commit()
        cur.close()

        tmp_table_name = ""; # // "iqvqcupdatetracking_db";
        tmp_group_type = table_name; # // "";
        group_type = "Properties"
        for kv in obj.Properties:
            AddIQVKeyValueSetToDB_with_doc_id(
                kv, 
                doc_id, 
                obj.id, 
                conn, 
                tmp_table_name, 
                group_type);
        tmp_table_name = ""; # // "iqvqcupdatetracking_db";
        tmp_group_type = table_name; # // "";
        group_type = "PropertiesBase"
        for kv in obj.PropertiesBase:
            AddIQVKeyValueSetToDB_with_doc_id(
                kv, 
                doc_id, 
                obj.id, 
                conn, 
                tmp_table_name, 
                group_type);

        group_type = "PropertiesCompare"
        for kv in obj.PropertiesCompare:
            AddIQVKeyValueSetToDB_with_doc_id(
                kv, 
                doc_id, 
                obj.id, 
                conn, 
                tmp_table_name, 
                group_type);

        group_type = "ChildDiffs"
        for kv in obj.ChildDiffs:
            AddIQVDocumentDiffToDB_with_doc_id(
                kv, 
                doc_id, 
                obj.id, 
                conn, 
                tmp_table_name, 
                group_type);


        AddIQVTableColumnToDB_with_doc_id(
            obj.tableColumnLHS,
            doc_id,
            obj.id,
            conn,
            "",
            "tableColumnLHS");
        AddIQVTableColumnToDB_with_doc_id(
            obj.tableColumnRHS,
            doc_id,
            obj.id,
            conn,
            "",
            "tableColumnRHS");
        AddIQVPageROIToDB_with_doc_id(
            obj.tableRowHeaderLHS,
            doc_id,
            obj.id,
            conn,
            "",
            "tableRowHeaderLHS");
        AddIQVPageROIToDB_with_doc_id(
            obj.tableRowHeaderRHS,
            doc_id,
            obj.id,
            conn,
            "",
            "tableRowHeaderRHS");

        return True        
    except Exception as ex:
        logger.exception("Error adding element to database")
        # rollback the previous transaction before starting another
        conn.rollback()
        return False;


def AddIQVTableRowToDB_with_doc_id(
    obj:IQVTableRow,
    doc_id:str,
    parent_id:str,
    conn,
    table_name:str,
    group_type:str
):
    """
    Add this element to database
    :param obj: element to be added
    :param doc_id: top-level id of <see cref="IQVDocument"/></param>
    :param parent_id:
    :param conn:
    :param table_name:
    :param group_type:
    :returns True if successful
    """
    try:
        # ///////////////////////////////////////////
        # 
        #  primary lookup to rebuild data structure
        #   parent_id--id of parent 
        #   group_type--member field of parent
        #  if these are not yet set, set them now
        # 
        # ////////////////////////////////////////////
        if len(group_type) > 0:
            obj.group_type = group_type;
                
        if len(parent_id) > 0:
            obj.parent_id = parent_id;
                
        sql = GetInsert_IQVTableRow_with_doc_id(
            obj, 
            doc_id,
            parent_id, 
            table_name,
            group_type);
        cur = conn.cursor()
        cur.execute(sql, ())
        num_updated_rows = cur.rowcount
        # Commit the changes to the database
        conn.commit()
        cur.close()

        return True        
    except Exception as ex:
        logger.exception("Error adding element to database")
        # rollback the previous transaction before starting another
        conn.rollback()
        return False;

def AddIQVTableColumnToDB_with_doc_id(
    obj:IQVTableColumn,
    doc_id:str,
    parent_id:str,
    conn,
    table_name:str,
    group_type:str
):
    """
    Add this element to database
    :param obj: element to be added
    :param doc_id: top-level id of <see cref="IQVDocument"/></param>
    :param parent_id:
    :param conn:
    :param table_name:
    :param group_type:
    :returns True if successful
    """
    try:
        # ///////////////////////////////////////////
        # 
        #  primary lookup to rebuild data structure
        #   parent_id--id of parent 
        #   group_type--member field of parent
        #  if these are not yet set, set them now
        # 
        # ////////////////////////////////////////////
        if len(group_type) > 0:
            obj.group_type = group_type;
                
        if len(parent_id) > 0:
            obj.parent_id = parent_id;
                
        sql = GetInsert_IQVTableColumn_with_doc_id(
            obj, 
            doc_id,
            parent_id, 
            table_name,
            group_type);
        cur = conn.cursor()
        cur.execute(sql, ())
        num_updated_rows = cur.rowcount
        # Commit the changes to the database
        conn.commit()
        cur.close()

        tmp_table_name = ""; # // "iqvqcupdatetracking_db";
        tmp_group_type = table_name; # // "";
        group_type = "headers"
        for kv in obj.headers:
            AddIQVTableColumnHeaderToDB_with_doc_id(
                kv, 
                doc_id, 
                obj.id, 
                conn, 
                tmp_table_name, 
                group_type);

        return True        
    except Exception as ex:
        logger.exception("Error adding element to database")
        # rollback the previous transaction before starting another
        conn.rollback()
        return False;


def AddIQVTableColumnHeaderToDB_with_doc_id(
    obj:IQVTableColumnHeader,
    doc_id:str,
    parent_id:str,
    conn,
    table_name:str,
    group_type:str
):
    """
    Add this element to database
    :param obj: element to be added
    :param doc_id: top-level id of <see cref="IQVDocument"/></param>
    :param parent_id:
    :param conn:
    :param table_name:
    :param group_type:
    :returns True if successful
    """
    try:
        # ///////////////////////////////////////////
        # 
        #  primary lookup to rebuild data structure
        #   parent_id--id of parent 
        #   group_type--member field of parent
        #  if these are not yet set, set them now
        # 
        # ////////////////////////////////////////////
        if len(group_type) > 0:
            obj.group_type = group_type;
                
        if len(parent_id) > 0:
            obj.parent_id = parent_id;
                
        sql = GetInsert_IQVTableColumnHeader_with_doc_id(
            obj, 
            doc_id,
            parent_id, 
            table_name,
            group_type);
        cur = conn.cursor()
        cur.execute(sql, ())
        num_updated_rows = cur.rowcount
        # Commit the changes to the database
        conn.commit()
        cur.close()

        tmp_table_name = ""; # // "iqvqcupdatetracking_db";
        tmp_group_type = table_name; # // "";
        group_type = "Properties"
        for kv in obj.Properties:
            AddIQVKeyValueSetToDB_with_doc_id(
                kv, 
                doc_id, 
                obj.id, 
                conn, 
                tmp_table_name, 
                group_type);

        return True        
    except Exception as ex:
        logger.exception("Error adding element to database")
        # rollback the previous transaction before starting another
        conn.rollback()
        return False;



def AddIQVRedactionCategoryToDB_with_doc_id(
    obj:IQVRedactionCategory,
    doc_id:str,
    parent_id:str,
    conn,
    table_name:str,
    group_type:str
):
    """
    Add this element to database
    :param obj: element to be added
    :param doc_id: top-level id of <see cref="IQVDocument"/></param>
    :param parent_id:
    :param conn:
    :param table_name:
    :param group_type:
    :returns True if successful
    """
    try:
        # ///////////////////////////////////////////
        # 
        #  primary lookup to rebuild data structure
        #   parent_id--id of parent 
        #   group_type--member field of parent
        #  if these are not yet set, set them now
        # 
        # ////////////////////////////////////////////
        if len(group_type) > 0:
            obj.group_type = group_type;
                
        if len(parent_id) > 0:
            obj.parent_id = parent_id;

        sql = GetInsert_IQVRedactionCategory_with_doc_id(
            obj, 
            doc_id,
            parent_id, 
            table_name,
            group_type);
        cur = conn.cursor()
        cur.execute(sql, ())
        num_updated_rows = cur.rowcount
        # Commit the changes to the database
        conn.commit()
        cur.close()

        return True        
    except Exception as ex:
        logger.exception("Error adding element to database")
        # rollback the previous transaction before starting another
        conn.rollback()
        return False;


def AddIQVRedactionProfileToDB_with_doc_id(
    obj:IQVRedactionProfile,
    doc_id:str,
    parent_id:str,
    conn,
    table_name:str,
    group_type:str
):
    """
    Add this element to database
    :param obj: element to be added
    :param doc_id: top-level id of <see cref="IQVDocument"/></param>
    :param parent_id:
    :param conn:
    :param table_name:
    :param group_type:
    :returns True if successful
    """
    try:
        # ///////////////////////////////////////////
        # 
        #  primary lookup to rebuild data structure
        #   parent_id--id of parent 
        #   group_type--member field of parent
        #  if these are not yet set, set them now
        # 
        # ////////////////////////////////////////////
        if len(group_type) > 0:
            obj.group_type = group_type;
                
        if len(parent_id) > 0:
            obj.parent_id = parent_id;

        sql = GetInsert_IQVRedactionProfile_with_doc_id(
            obj, 
            doc_id,
            parent_id, 
            table_name,
            group_type);
        cur = conn.cursor()
        cur.execute(sql, ())
        num_updated_rows = cur.rowcount
        # Commit the changes to the database
        conn.commit()
        cur.close()

        tmp_table_name = ""; # // "iqvqcupdatetracking_db";
        tmp_group_type = table_name; # // "";
        group_type = "Categories"
        for kv in obj.Categories:
            AddIQVRedactionCategoryToDB_with_doc_id(
                kv, 
                doc_id, 
                obj.id, 
                conn, 
                tmp_table_name, 
                group_type);

        return True        
    except Exception as ex:
        logger.exception("Error adding element to database")
        # rollback the previous transaction before starting another
        conn.rollback()
        return False;


def AddIQVDocumentFeedbackQCToDB_with_doc_id(
    obj:IQVDocumentFeedbackQC,
    doc_id:str,
    parent_id:str,
    conn,
    table_name:str,
    group_type:str
):
    """
    Add this element to database
    :param obj: element to be added
    :param doc_id: top-level id of <see cref="IQVDocument"/></param>
    :param parent_id:
    :param conn:
    :param table_name:
    :param group_type:
    :returns True if successful
    """
    try:
        # ///////////////////////////////////////////
        # 
        #  primary lookup to rebuild data structure
        #   parent_id--id of parent 
        #   group_type--member field of parent
        #  if these are not yet set, set them now
        # 
        # ////////////////////////////////////////////
        if len(group_type) > 0:
            obj.group_type = group_type;
                
        if len(parent_id) > 0:
            obj.parent_id = parent_id;

        sql = GetInsert_IQVDocumentFeedbackQC_with_doc_id(
            obj, 
            doc_id,
            parent_id, 
            table_name,
            group_type);
        cur = conn.cursor()
        cur.execute(sql, ())
        num_updated_rows = cur.rowcount
        # Commit the changes to the database
        conn.commit()
        cur.close()

        return True        
    except Exception as ex:
        logger.exception("Error adding element to database")
        # rollback the previous transaction before starting another
        conn.rollback()
        return False;
        
def AddIQVDocumentFeedbackResultsToDB_with_doc_id(
    obj:IQVDocumentFeedbackResults,
    doc_id:str,
    parent_id:str,
    conn,
    table_name:str,
    group_type:str
):
    """
    Add this element to database
    :param obj: element to be added
    :param doc_id: top-level id of <see cref="IQVDocument"/></param>
    :param parent_id:
    :param conn:
    :param table_name:
    :param group_type:
    :returns True if successful
    """
    try:
        # ///////////////////////////////////////////
        # 
        #  primary lookup to rebuild data structure
        #   parent_id--id of parent 
        #   group_type--member field of parent
        #  if these are not yet set, set them now
        # 
        # ////////////////////////////////////////////
        if len(group_type) > 0:
            obj.group_type = group_type;
                
        if len(parent_id) > 0:
            obj.parent_id = parent_id;

        sql = GetInsert_IQVDocumentFeedbackResults_with_doc_id(
            obj, 
            doc_id,
            parent_id, 
            table_name,
            group_type);
        cur = conn.cursor()
        cur.execute(sql, ())
        num_updated_rows = cur.rowcount
        # Commit the changes to the database
        conn.commit()
        cur.close()

        tmp_table_name = ""

        group_type = "alcoac_check_error"
        for kv in obj.alcoac_check_error:
            AddIQVAttributeCandidateToDB_with_doc_id(
                kv, 
                doc_id, 
                obj.id, 
                conn, 
                tmp_table_name, 
                group_type);

        group_type = "attribute_auxiliary_list"
        for kv in obj.attribute_auxiliary_list:
            AddIQVKeyValueSetToDB_with_doc_id(
                kv, 
                doc_id, 
                obj.id, 
                conn, 
                tmp_table_name, 
                group_type);

        return True        
    except Exception as ex:
        logger.exception("Error adding element to database")
        # rollback the previous transaction before starting another
        conn.rollback()
        return False;


def AddIQVClassifierModelToDB_with_doc_id(
    obj:IQVClassifierModel,
    doc_id:str,
    parent_id:str,
    conn,
    table_name:str,
    group_type:str
):
    """
    Add this element to database
    :param obj: element to be added
    :param doc_id: top-level id of <see cref="IQVDocument"/></param>
    :param parent_id:
    :param conn:
    :param table_name:
    :param group_type:
    :returns True if successful
    """
    try:
        # ///////////////////////////////////////////
        # 
        #  primary lookup to rebuild data structure
        #   parent_id--id of parent 
        #   group_type--member field of parent
        #  if these are not yet set, set them now
        # 
        # ////////////////////////////////////////////
        if len(group_type) > 0:
            obj.group_type = group_type;
                
        if len(parent_id) > 0:
            obj.parent_id = parent_id;

        sql = GetInsert_IQVClassifierModel_with_doc_id(
            obj, 
            doc_id,
            parent_id, 
            table_name,
            group_type);
        cur = conn.cursor()
        cur.execute(sql, ())
        num_updated_rows = cur.rowcount
        # Commit the changes to the database
        conn.commit()
        cur.close()


        return True        
    except Exception as ex:
        logger.exception("Error adding element to database")
        # rollback the previous transaction before starting another
        conn.rollback()
        return False;

def AddIQVCharacterToDB_with_doc_id(
    obj:IQVCharacter,
    doc_id:str,
    parent_id:str,
    conn,
    table_name:str,
    group_type:str
):
    """
    Add this element to database
    :param obj: element to be added
    :param doc_id: top-level id of <see cref="IQVDocument"/></param>
    :param parent_id:
    :param conn:
    :param table_name:
    :param group_type:
    :returns True if successful
    """
    try:
        # ///////////////////////////////////////////
        # 
        #  primary lookup to rebuild data structure
        #   parent_id--id of parent 
        #   group_type--member field of parent
        #  if these are not yet set, set them now
        # 
        # ////////////////////////////////////////////
        if len(group_type) > 0:
            obj.group_type = group_type;
                
        if len(parent_id) > 0:
            obj.parent_id = parent_id;

        sql = GetInsert_IQVCharacter_with_doc_id(
            obj, 
            doc_id,
            parent_id, 
            table_name,
            group_type);
        cur = conn.cursor()
        cur.execute(sql, ())
        num_updated_rows = cur.rowcount
        # Commit the changes to the database
        conn.commit()
        cur.close()


        return True        
    except Exception as ex:
        logger.exception("Error adding element to database")
        # rollback the previous transaction before starting another
        conn.rollback()
        return False;

def AddLanguageCodeToDB_with_doc_id(
    obj:LanguageCode,
    doc_id:str,
    parent_id:str,
    conn,
    table_name:str,
    group_type:str
):
    """
    Add this element to database
    :param obj: element to be added
    :param doc_id: top-level id of <see cref="IQVDocument"/></param>
    :param parent_id:
    :param conn:
    :param table_name:
    :param group_type:
    :returns True if successful
    """
    try:
        # ///////////////////////////////////////////
        # 
        #  primary lookup to rebuild data structure
        #   parent_id--id of parent 
        #   group_type--member field of parent
        #  if these are not yet set, set them now
        # 
        # ////////////////////////////////////////////
        if len(group_type) > 0:
            obj.group_type = group_type;
                
        if len(parent_id) > 0:
            obj.parent_id = parent_id;

        sql = GetInsert_LanguageCode_with_doc_id(
            obj, 
            doc_id,
            parent_id, 
            table_name,
            group_type);
        cur = conn.cursor()
        cur.execute(sql, ())
        num_updated_rows = cur.rowcount
        # Commit the changes to the database
        conn.commit()
        cur.close()


        return True        
    except Exception as ex:
        logger.exception("Error adding element to database")
        # rollback the previous transaction before starting another
        conn.rollback()
        return False;

def AddIQVWordToDB_with_doc_id(
    obj:IQVWord,
    doc_id:str,
    parent_id:str,
    conn,
    table_name:str,
    group_type:str
):
    """
    Add this element to database
    :param obj: element to be added
    :param doc_id: top-level id of <see cref="IQVDocument"/></param>
    :param parent_id:
    :param conn:
    :param table_name:
    :param group_type:
    :returns True if successful
    """
    try:
        # ///////////////////////////////////////////
        # 
        #  primary lookup to rebuild data structure
        #   parent_id--id of parent 
        #   group_type--member field of parent
        #  if these are not yet set, set them now
        # 
        # ////////////////////////////////////////////
        if len(group_type) > 0:
            obj.group_type = group_type;
                
        if len(parent_id) > 0:
            obj.parent_id = parent_id;

        sql = GetInsert_IQVWord_with_doc_id(
            obj, 
            doc_id,
            parent_id, 
            table_name,
            group_type);
        cur = conn.cursor()
        cur.execute(sql, ())
        num_updated_rows = cur.rowcount
        # Commit the changes to the database
        conn.commit()
        cur.close()


        return True        
    except Exception as ex:
        logger.exception("Error adding element to database")
        # rollback the previous transaction before starting another
        conn.rollback()
        return False;


def AddIQVAttributeCandidateToDB_with_doc_id(
    obj:IQVAttributeCandidate,
    doc_id:str,
    parent_id:str,
    conn,
    table_name:str,
    group_type:str
):
    """
    Add this element to database
    :param obj: element to be added
    :param doc_id: top-level id of <see cref="IQVDocument"/></param>
    :param parent_id:
    :param conn:
    :param table_name:
    :param group_type:
    :returns True if successful
    """
    try:
        # ///////////////////////////////////////////
        # 
        #  primary lookup to rebuild data structure
        #   parent_id--id of parent 
        #   group_type--member field of parent
        #  if these are not yet set, set them now
        # 
        # ////////////////////////////////////////////
        if len(group_type) > 0:
            obj.group_type = group_type;
                
        if len(parent_id) > 0:
            obj.parent_id = parent_id;

        sql = GetInsert_IQVAttributeCandidate_with_doc_id(
            obj, 
            doc_id,
            parent_id, 
            table_name,
            group_type);
        cur = conn.cursor()
        cur.execute(sql, ())
        num_updated_rows = cur.rowcount
        # Commit the changes to the database
        conn.commit()
        cur.close()

        tmp_table_name = ""

        group_type = "Features"
        for kv in obj.Features:
            AddIQVKeyValueSetToDB_with_doc_id(
                kv, 
                doc_id, 
                obj.id, 
                conn, 
                tmp_table_name, 
                group_type);

        return True        
    except Exception as ex:
        logger.exception("Error adding element to database")
        # rollback the previous transaction before starting another
        conn.rollback()
        return False;

        

def AddIQVAttributeToDB_with_doc_id(
    obj:IQVAttribute,
    doc_id:str,
    parent_id:str,
    conn,
    table_name:str,
    group_type:str
):
    """
    Add this element to database
    :param obj: element to be added
    :param doc_id: top-level id of <see cref="IQVDocument"/></param>
    :param parent_id:
    :param conn:
    :param table_name:
    :param group_type:
    :returns True if successful
    """
    try:
        # ///////////////////////////////////////////
        # 
        #  primary lookup to rebuild data structure
        #   parent_id--id of parent 
        #   group_type--member field of parent
        #  if these are not yet set, set them now
        # 
        # ////////////////////////////////////////////
        if len(group_type) > 0:
            obj.group_type = group_type;
                
        if len(parent_id) > 0:
            obj.parent_id = parent_id;

        sql = GetInsert_IQVAttribute_with_doc_id(
            obj, 
            doc_id,
            parent_id, 
            table_name,
            group_type);
        cur = conn.cursor()
        cur.execute(sql, ())
        num_updated_rows = cur.rowcount
        # Commit the changes to the database
        conn.commit()
        cur.close()

        return True        
    except Exception as ex:
        logger.exception("Error adding element to database")
        # rollback the previous transaction before starting another
        conn.rollback()
        return False;

def GetInsert_DocumentPartsString_with_doc_id(
    obj:str,
    parent_id:str,
    table_name:str,
    group_type:str,
    sequence_id:int
):
    """
    Get SQL for inserting an object
    of type <see cref="IQVPageROI"/>
    into table <paramref name="table_name"/>,
    LINK to parent object using <paramref name="parent_id"/>
    AND <paramref name="group_type"/>
    Note: To INSERT a string, be sure to use .Replace("'","''")
        as apostrophe is special character that must be escaped

    :param obj: object being inserted into db</param>
    :param parent_id: link to parent object which is top-level <see cref="IQVDocument"/></param>
    :param table_name: object inserted into this table, default = iqvpageroi_db</param>
    :param sequence_id: in order id</param>
    :param group_type: link to parent object</param>
    <returns></returns>
    """
    if len(table_name) == 0:
        table_name = "documentpartslist_db";
    sql = "";

    sql = sql + "INSERT INTO public." + table_name;
    sql = sql + "(";

    sql = sql + "\"id\",";
    sql = sql + "\"parent_id\",";
    sql = sql + "\"group_type\",";
    sql = sql + "\"sequence_id\",";
    
    if sql.endswith(","):
        sql = sql[0:len(sql)-1];

    sql = sql + ")";
    sql = sql + "VALUES";
    sql = sql + "(";

    sql = sql + "'" + obj + "',";
    sql = sql + "'" + parent_id + "',";
    sql = sql + "'" + group_type + "',";
    sql = sql + str(sequence_id) + ",";
    if sql.endswith(","):
        sql = sql[0:len(sql)-1];
    sql = sql + ")";

    return sql;

def AddDocumentPartsStringToDB_with_doc_id(
    obj:str,
    doc_id:str,
    parent_id:str,
    conn,
    table_name:str,
    group_type:str,
    sequence:int
):
    """
    Add this element to database
    :param obj: element to be added
    :param doc_id: top-level id of <see cref="IQVDocument"/></param>
    :param parent_id:
    :param conn:
    :param table_name:
    :param group_type:
    :returns True if successful
    """
    try:
        # ///////////////////////////////////////////
        # 
        #  primary lookup to rebuild data structure
        #   parent_id--id of parent 
        #   group_type--member field of parent
        #  if these are not yet set, set them now
        # 
        # ////////////////////////////////////////////
        #if len(group_type) > 0:
        #    obj.group_type = group_type;
                
        #if len(parent_id) > 0:
        #    obj.parent_id = parent_id;

        sql = GetInsert_DocumentPartsString_with_doc_id(
            obj, 
            doc_id,
            table_name,
            group_type,
            sequence);
        cur = conn.cursor()
        cur.execute(sql, ())
        num_updated_rows = cur.rowcount
        # Commit the changes to the database
        conn.commit()
        cur.close()

        return True        
    except Exception as ex:
        logger.exception("Error adding element to database")
        # rollback the previous transaction before starting another
        conn.rollback()
        return False;


def AddIQVPageROIToDB_with_doc_id(
    obj:IQVPageROI,
    doc_id:str,
    parent_id:str,
    conn,
    table_name:str,
    group_type:str
):
    """
    Add this element to database
    :param obj: element to be added
    :param doc_id: top-level id of <see cref="IQVDocument"/></param>
    :param parent_id:
    :param conn:
    :param table_name:
    :param group_type:
    :returns True if successful
    """
    try:
        # ///////////////////////////////////////////
        # 
        #  primary lookup to rebuild data structure
        #   parent_id--id of parent 
        #   group_type--member field of parent
        #  if these are not yet set, set them now
        # 
        # ////////////////////////////////////////////
        if len(group_type) > 0:
            obj.group_type = group_type;
                
        if len(parent_id) > 0:
            obj.parent_id = parent_id;

        obj.rectangle_x = obj.rectangle.X;
        obj.rectangle_y = obj.rectangle.Y;
        obj.rectangle_width = obj.rectangle.Width;
        obj.rectangle_height = obj.rectangle.Height;
        obj.parentrectangle_x = obj.parentRectangle.X;
        obj.parentrectangle_y = obj.parentRectangle.Y;
        obj.parentrectangle_width = obj.parentRectangle.Width;
        obj.parentrectangle_height = obj.parentRectangle.Height;
        obj.rectangleGlobalLocationOnPage_x = obj.rectangleGlobalLocationOnPage.X;
        obj.rectangleGlobalLocationOnPage_y = obj.rectangleGlobalLocationOnPage.Y;
        obj.rectangleGlobalLocationOnPage_width = obj.rectangleGlobalLocationOnPage.Width;
        obj.rectangleGlobalLocationOnPage_height = obj.rectangleGlobalLocationOnPage.Height;
        obj.strText = "";
        if len(obj.strTexts) > 0:
            obj.strText = obj.strTexts[0];
        obj.strTextTranslated = "";
        if len(obj.strTextsTranslated) > 0:
            obj.strTextTranslated = obj.strTextsTranslated[0];

        sql = GetInsert_IQVPageROI_with_doc_id(
            obj, 
            doc_id,
            parent_id, 
            table_name,
            group_type);
        cur = conn.cursor()
        cur.execute(sql, ())
        num_updated_rows = cur.rowcount
        # Commit the changes to the database
        conn.commit()
        cur.close()

        tmp_table_name = ""

        group_type = "Properties"
        for kv in obj.Properties:
            AddIQVKeyValueSetToDB_with_doc_id(
                kv, 
                doc_id, 
                obj.id, 
                conn, 
                tmp_table_name, 
                group_type);

        group_type = "Attachments"
        for kv in obj.Attachments:
            AddIQVPageROIToDB_with_doc_id(
                kv, 
                doc_id, 
                obj.id, 
                conn, 
                tmp_table_name, 
                group_type);

        group_type = "ChildBoxes"
        for kv in obj.ChildBoxes:
            AddIQVPageROIToDB_with_doc_id(
                kv, 
                doc_id, 
                obj.id, 
                conn, 
                tmp_table_name, 
                group_type);

        group_type = "NLP_Attributes"
        for kv in obj.NLP_Attributes:
            AddNLP_AttributeToDB_with_doc_id(
                kv, 
                doc_id, 
                obj.id, 
                conn, 
                tmp_table_name, 
                group_type);

        group_type = "NLP_Entities"
        for kv in obj.NLP_Entities:
            AddNLP_EntityToDB_with_doc_id(
                kv, 
                doc_id, 
                obj.id, 
                conn, 
                tmp_table_name, 
                group_type);
        AddFontInfoToDB_with_doc_id(
            obj.fontInfo,
            doc_id,
            obj.id,
            conn,
            tmp_table_name,
            "fontInfo");
        group_type = "QCUpdates"
        for kv in obj.QCUpdates:
            AddIQVQCUpdateTrackingToDB_with_doc_id(
                kv, 
                doc_id, 
                obj.id, 
                conn, 
                tmp_table_name, 
                group_type);
        group_type = "IQVSubTextList"
        for kv in obj.IQVSubTextList:
            AddIQVSubTextToDB_with_doc_id(
                kv, 
                doc_id, 
                obj.id, 
                conn, 
                tmp_table_name, 
                group_type);

        return True        
    except Exception as ex:
        logger.exception("Error adding element to database")
        # rollback the previous transaction before starting another
        conn.rollback()
        return False;


def AddIQVNumberingLevelToDB_with_doc_id(
    obj:IQVNumberingLevel,
    doc_id:str,
    parent_id:str,
    conn,
    table_name:str,
    group_type:str
):
    """
    Add this element to database
    :param obj: element to be added
    :param doc_id: top-level id of <see cref="IQVDocument"/></param>
    :param parent_id:
    :param conn:
    :param table_name:
    :param group_type:
    :returns True if successful
    """
    try:
        # ///////////////////////////////////////////
        # 
        #  primary lookup to rebuild data structure
        #   parent_id--id of parent 
        #   group_type--member field of parent
        #  if these are not yet set, set them now
        # 
        # ////////////////////////////////////////////
        if len(group_type) > 0:
            obj.group_type = group_type;
                
        if len(parent_id) > 0:
            obj.parent_id = parent_id;

        sql = GetInsert_IQVNumberingLevel_with_doc_id(
            obj, 
            doc_id,
            parent_id, 
            table_name,
            group_type);
        cur = conn.cursor()
        cur.execute(sql, ())
        num_updated_rows = cur.rowcount
        # Commit the changes to the database
        conn.commit()
        cur.close()

        return True        
    except Exception as ex:
        logger.exception("Error adding element to database")
        # rollback the previous transaction before starting another
        conn.rollback()
        return False;


def AddIQVNumberingGroupToDB_with_doc_id(
    obj:IQVNumberingGroup,
    doc_id:str,
    parent_id:str,
    conn,
    table_name:str,
    group_type:str
):
    """
    Add this element to database
    :param obj: element to be added
    :param doc_id: top-level id of <see cref="IQVDocument"/></param>
    :param parent_id:
    :param conn:
    :param table_name:
    :param group_type:
    :returns True if successful
    """
    try:
        # ///////////////////////////////////////////
        # 
        #  primary lookup to rebuild data structure
        #   parent_id--id of parent 
        #   group_type--member field of parent
        #  if these are not yet set, set them now
        # 
        # ////////////////////////////////////////////
        if len(group_type) > 0:
            obj.group_type = group_type;
                
        if len(parent_id) > 0:
            obj.parent_id = parent_id;

        sql = GetInsert_IQVNumberingGroup_with_doc_id(
            obj, 
            doc_id,
            parent_id, 
            table_name,
            group_type);
        cur = conn.cursor()
        cur.execute(sql, ())
        num_updated_rows = cur.rowcount
        # Commit the changes to the database
        conn.commit()
        cur.close()

        tmp_table_name = ""

        group_type = "numberingLevels"
        for kv in obj.numberingLevels:
            AddIQVNumberingLevelToDB_with_doc_id(
                kv, 
                doc_id, 
                obj.id, 
                conn, 
                tmp_table_name, 
                group_type);


        return True        
    except Exception as ex:
        logger.exception("Error adding element to database")
        # rollback the previous transaction before starting another
        conn.rollback()
        return False;


def AddIQVLineToDB_with_doc_id(
    obj:IQVLine,
    doc_id:str,
    parent_id:str,
    conn,
    table_name:str,
    group_type:str
):
    """
    Add this element to database
    :param obj: element to be added
    :param doc_id: top-level id of <see cref="IQVDocument"/></param>
    :param parent_id:
    :param conn:
    :param table_name:
    :param group_type:
    :returns True if successful
    """
    try:
        # ///////////////////////////////////////////
        # 
        #  primary lookup to rebuild data structure
        #   parent_id--id of parent 
        #   group_type--member field of parent
        #  if these are not yet set, set them now
        # 
        # ////////////////////////////////////////////
        if len(group_type) > 0:
            obj.group_type = group_type;
                
        if len(parent_id) > 0:
            obj.parent_id = parent_id;

        sql = GetInsert_IQVLine_with_doc_id(
            obj, 
            doc_id,
            parent_id, 
            table_name,
            group_type);
        cur = conn.cursor()
        cur.execute(sql, ())
        num_updated_rows = cur.rowcount
        # Commit the changes to the database
        conn.commit()
        cur.close()

        return True        
    except Exception as ex:
        logger.exception("Error adding element to database")
        # rollback the previous transaction before starting another
        conn.rollback()
        return False;


def AddIQVDocumentLinkToDB_with_doc_id(
    obj:IQVDocumentLink,
    doc_id:str,
    parent_id:str,
    conn,
    table_name:str,
    group_type:str
):
    """
    Add this element to database
    :param obj: element to be added
    :param doc_id: top-level id of <see cref="IQVDocument"/></param>
    :param parent_id:
    :param conn:
    :param table_name:
    :param group_type:
    :returns True if successful
    """
    try:
        # ///////////////////////////////////////////
        # 
        #  primary lookup to rebuild data structure
        #   parent_id--id of parent 
        #   group_type--member field of parent
        #  if these are not yet set, set them now
        # 
        # ////////////////////////////////////////////
        if len(group_type) > 0:
            obj.group_type = group_type;
                
        if len(parent_id) > 0:
            obj.parent_id = parent_id;

        sql = GetInsert_IQVDocumentLink_with_doc_id(
            obj, 
            doc_id,
            parent_id, 
            table_name,
            group_type);
        cur = conn.cursor()
        cur.execute(sql, ())
        num_updated_rows = cur.rowcount
        # Commit the changes to the database
        conn.commit()
        cur.close()

        tmp_table_name = ""

        group_type = "Properties"
        for kv in obj.Properties:
            AddIQVKeyValueSetToDB_with_doc_id(
                kv, 
                doc_id, 
                obj.id, 
                conn, 
                tmp_table_name, 
                group_type);

        group_type = "LinkPointers"
        for kv in obj.LinkPointers:
            AddIQVPageROIToDB_with_doc_id(
                kv, 
                doc_id, 
                obj.id, 
                conn, 
                tmp_table_name, 
                group_type);

        group_type = "LinkDestinations"
        for kv in obj.LinkDestinations:
            AddIQVPageROIToDB_with_doc_id(
                kv, 
                doc_id, 
                obj.id, 
                conn, 
                tmp_table_name, 
                group_type);

        return True        
    except Exception as ex:
        logger.exception("Error adding element to database")
        # rollback the previous transaction before starting another
        conn.rollback()
        return False;


def AddIQVDocumentProcessToDB_with_doc_id(
    obj:IQVDocumentProcess,
    doc_id:str,
    parent_id:str,
    conn,
    table_name:str,
    group_type:str
):
    """
    Add this element to database
    :param obj: element to be added
    :param doc_id: top-level id of <see cref="IQVDocument"/></param>
    :param parent_id:
    :param conn:
    :param table_name:
    :param group_type:
    :returns True if successful
    """
    try:
        # ///////////////////////////////////////////
        # 
        #  primary lookup to rebuild data structure
        #   parent_id--id of parent 
        #   group_type--member field of parent
        #  if these are not yet set, set them now
        # 
        # ////////////////////////////////////////////
        if len(group_type) > 0:
            obj.group_type = group_type;
                
        if len(parent_id) > 0:
            obj.parent_id = parent_id;

        sql = GetInsert_IQVDocumentProcess_with_doc_id(
            obj, 
            doc_id,
            parent_id, 
            table_name,
            group_type);
        cur = conn.cursor()
        cur.execute(sql, ())
        num_updated_rows = cur.rowcount
        # Commit the changes to the database
        conn.commit()
        cur.close()

        tmp_table_name = ""

        group_type = "KeyValues"
        for kv in obj.KeyValues:
            AddIQVKeyValueSetToDB_with_doc_id(
                kv, 
                doc_id, 
                obj.id, 
                conn, 
                tmp_table_name, 
                group_type);

        return True        
    except Exception as ex:
        logger.exception("Error adding element to database")
        # rollback the previous transaction before starting another
        conn.rollback()
        return False;

def AddIQVDocumentProcessToDB_with_doc_id(
    obj:IQVDocumentProcess,
    doc_id:str,
    parent_id:str,
    conn,
    table_name:str,
    group_type:str
):
    """
    Add this element to database
    :param obj: element to be added
    :param doc_id: top-level id of <see cref="IQVDocument"/></param>
    :param parent_id:
    :param conn:
    :param table_name:
    :param group_type:
    :returns True if successful
    """
    try:
        # ///////////////////////////////////////////
        # 
        #  primary lookup to rebuild data structure
        #   parent_id--id of parent 
        #   group_type--member field of parent
        #  if these are not yet set, set them now
        # 
        # ////////////////////////////////////////////
        if len(group_type) > 0:
            obj.group_type = group_type;
                
        if len(parent_id) > 0:
            obj.parent_id = parent_id;

        sql = GetInsert_IQVDocumentProcess_with_doc_id(
            obj, 
            doc_id,
            parent_id, 
            table_name,
            group_type);
        cur = conn.cursor()
        cur.execute(sql, ())
        num_updated_rows = cur.rowcount
        # Commit the changes to the database
        conn.commit()
        cur.close()

        tmp_table_name = ""

        group_type = "KeyValues"
        for kv in obj.KeyValues:
            AddIQVKeyValueSetToDB_with_doc_id(
                kv, 
                doc_id, 
                obj.id, 
                conn, 
                tmp_table_name, 
                group_type);

        return True        
    except Exception as ex:
        logger.exception("Error adding element to database")
        # rollback the previous transaction before starting another
        conn.rollback()
        return False;

def AddIQVExternalLinkElementToDB_with_doc_id(
    obj:IQVExternalLinkElement,
    doc_id:str,
    parent_id:str,
    conn,
    table_name:str,
    group_type:str
):
    """
    Add this element to database
    :param obj: element to be added
    :param doc_id: top-level id of <see cref="IQVDocument"/></param>
    :param parent_id:
    :param conn:
    :param table_name:
    :param group_type:
    :returns True if successful
    """
    try:
        # ///////////////////////////////////////////
        # 
        #  primary lookup to rebuild data structure
        #   parent_id--id of parent 
        #   group_type--member field of parent
        #  if these are not yet set, set them now
        # 
        # ////////////////////////////////////////////
        if len(group_type) > 0:
            obj.group_type = group_type;
                
        if len(parent_id) > 0:
            obj.parent_id = parent_id;

        sql = GetInsert_IQVExternalLinkElement_with_doc_id(
            obj, 
            doc_id,
            parent_id, 
            table_name,
            group_type);
        cur = conn.cursor()
        cur.execute(sql, ())
        num_updated_rows = cur.rowcount
        # Commit the changes to the database
        conn.commit()
        cur.close()

        tmp_table_name = ""

        group_type = "NLP_Entities"
        for kv in obj.NLP_Entities:
            AddNLP_EntityToDB_with_doc_id(
                kv, 
                doc_id, 
                obj.id, 
                conn, 
                tmp_table_name, 
                group_type);

        return True        
    except Exception as ex:
        logger.exception("Error adding element to database")
        # rollback the previous transaction before starting another
        conn.rollback()
        return False;


def AddIQVExternalLinkToDB_with_doc_id(
    obj:IQVExternalLink,
    doc_id:str,
    parent_id:str,
    conn,
    table_name:str,
    group_type:str
):
    """
    Add this element to database
    :param obj: element to be added
    :param doc_id: top-level id of <see cref="IQVDocument"/></param>
    :param parent_id:
    :param conn:
    :param table_name:
    :param group_type:
    :returns True if successful
    """
    try:
        # ///////////////////////////////////////////
        # 
        #  primary lookup to rebuild data structure
        #   parent_id--id of parent 
        #   group_type--member field of parent
        #  if these are not yet set, set them now
        # 
        # ////////////////////////////////////////////
        if len(group_type) > 0:
            obj.group_type = group_type;
                
        if len(parent_id) > 0:
            obj.parent_id = parent_id;

        sql = GetInsert_IQVExternalLink_with_doc_id(
            obj, 
            doc_id,
            parent_id, 
            table_name,
            group_type);
        cur = conn.cursor()
        cur.execute(sql, ())
        num_updated_rows = cur.rowcount
        # Commit the changes to the database
        conn.commit()
        cur.close()

        tmp_table_name = ""

        group_type = "Properties"
        for kv in obj.Properties:
            AddIQVKeyValueSetToDB_with_doc_id(
                kv, 
                doc_id, 
                obj.id, 
                conn, 
                tmp_table_name, 
                group_type);

        group_type = "Elements"
        for kv in obj.Elements:
            AddIQVExternalLinkElementToDB_with_doc_id(
                kv, 
                doc_id, 
                obj.id, 
                conn, 
                tmp_table_name, 
                group_type);

        return True        
    except Exception as ex:
        logger.exception("Error adding element to database")
        # rollback the previous transaction before starting another
        conn.rollback()
        return False;


def AddIQVDocumentMappingToDB_with_doc_id(
    obj:IQVDocumentMapping,
    doc_id:str,
    parent_id:str,
    conn,
    table_name:str,
    group_type:str
):
    """
    Add this element to database
    :param obj: element to be added
    :param doc_id: top-level id of <see cref="IQVDocument"/></param>
    :param parent_id:
    :param conn:
    :param table_name:
    :param group_type:
    :returns True if successful
    """
    try:
        # ///////////////////////////////////////////
        # 
        #  primary lookup to rebuild data structure
        #   parent_id--id of parent 
        #   group_type--member field of parent
        #  if these are not yet set, set them now
        # 
        # ////////////////////////////////////////////
        if len(group_type) > 0:
            obj.group_type = group_type;
                
        if len(parent_id) > 0:
            obj.parent_id = parent_id;

        sql = GetInsert_IQVDocumentMapping_with_doc_id(
            obj, 
            doc_id,
            parent_id, 
            table_name,
            group_type);
        cur = conn.cursor()
        cur.execute(sql, ())
        num_updated_rows = cur.rowcount
        # Commit the changes to the database
        conn.commit()
        cur.close()

        tmp_table_name = ""

        group_type = "AdditionalAttributesList"
        for kv in obj.AdditionalAttributesList:
            AddIQVKeyValueSetToDB_with_doc_id(
                kv, 
                doc_id, 
                obj.id, 
                conn, 
                tmp_table_name, 
                group_type);

        group_type = "AdditionalInstructionsList"
        for kv in obj.AdditionalInstructionsList:
            AddIQVKeyValueSetToDB_with_doc_id(
                kv, 
                doc_id, 
                obj.id, 
                conn, 
                tmp_table_name, 
                group_type);

        group_type = "DerivedMappings"
        for kv in obj.DerivedMappings:
            AddIQVDocumentMappingToDB_with_doc_id(
                kv, 
                doc_id, 
                obj.id, 
                conn, 
                tmp_table_name, 
                group_type);

        return True        
    except Exception as ex:
        logger.exception("Error adding element to database")
        # rollback the previous transaction before starting another
        conn.rollback()
        return False;


def AddIQVDocumentToDB_with_doc_id(
    obj:IQVDocument,
    doc_id:str,
    parent_id:str,
    conn,
    table_name:str,
    group_type:str
):
    """
    Add this element to database
    :param obj: element to be added
    :param doc_id: top-level id of <see cref="IQVDocument"/></param>
    :param parent_id:
    :param conn:
    :param table_name:
    :param group_type:
    :returns True if successful
    """
    try:
        # ///////////////////////////////////////////
        # 
        #  primary lookup to rebuild data structure
        #   parent_id--id of parent 
        #   group_type--member field of parent
        #  if these are not yet set, set them now
        # 
        # ////////////////////////////////////////////
        if len(group_type) > 0:
            obj.group_type = group_type;
                
        if len(parent_id) > 0:
            obj.parent_id = parent_id;

        sql = GetInsert_IQVDocument_with_doc_id(
            obj, 
            doc_id,
            parent_id, 
            table_name,
            group_type);
        cur = conn.cursor()
        cur.execute(sql, ())
        num_updated_rows = cur.rowcount
        # Commit the changes to the database
        conn.commit()
        cur.close()

        tmp_table_name = ""

        group_type = "Properties"
        for kv in obj.Properties:
            AddIQVKeyValueSetToDB_with_doc_id(
                kv, 
                doc_id, 
                obj.id, 
                conn, 
                tmp_table_name, 
                group_type);

        group_type = "DocumentParagraphs"
        for kv in obj.DocumentParagraphs:
            AddIQVPageROIToDB_with_doc_id(
                kv, 
                doc_id, 
                obj.id, 
                conn, 
                tmp_table_name, 
                group_type);

        group_type = "DocumentImages"
        for kv in obj.DocumentImages:
            AddIQVPageROIToDB_with_doc_id(
                kv, 
                doc_id, 
                obj.id, 
                conn, 
                tmp_table_name, 
                group_type);

        group_type = "DocumentTables"
        for kv in obj.DocumentTables:
            AddIQVPageROIToDB_with_doc_id(
                kv, 
                doc_id, 
                obj.id, 
                conn, 
                tmp_table_name, 
                group_type);

        group_type = "DocumentItems"
        for kv in obj.DocumentItems:
            AddIQVPageROIToDB_with_doc_id(
                kv, 
                doc_id, 
                obj.id, 
                conn, 
                tmp_table_name, 
                group_type);

        group_type = "DocumentHeaders"
        for kv in obj.DocumentHeaders:
            AddIQVPageROIToDB_with_doc_id(
                kv, 
                doc_id, 
                obj.id, 
                conn, 
                tmp_table_name, 
                group_type);

        group_type = "DocumentFooters"
        for kv in obj.DocumentFooters:
            AddIQVPageROIToDB_with_doc_id(
                kv, 
                doc_id, 
                obj.id, 
                conn, 
                tmp_table_name, 
                group_type);

        group_type = "DocumentPartsList"
        dpi = 0
        for kv in obj.DocumentPartsList:
            AddDocumentPartsStringToDB_with_doc_id(
                kv, 
                doc_id, 
                obj.id, 
                conn, 
                tmp_table_name, 
                group_type,
                dpi);
            dpi = dpi + 1;

        group_type = "DocumentLinks"
        for kv in obj.DocumentLinks:
            AddIQVDocumentLinkToDB_with_doc_id(
                kv, 
                doc_id, 
                obj.id, 
                conn, 
                tmp_table_name, 
                group_type);
            
        group_type = "IQVDocumentProcesses"
        for kv in obj.IQVDocumentProcesses:
            AddIQVDocumentProcessToDB_with_doc_id(
                kv, 
                doc_id, 
                obj.id, 
                conn, 
                tmp_table_name, 
                group_type);

        return True        
    except Exception as ex:
        logger.exception("Error adding element to database")
        # rollback the previous transaction before starting another
        conn.rollback()
        return False;



