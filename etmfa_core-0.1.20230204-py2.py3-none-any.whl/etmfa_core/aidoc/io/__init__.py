from xml import etree
import os
import shutil
import logging
import zipfile
import uuid
import gzip
import ntpath

import xml.etree.ElementTree as ET

from etmfa_core.aidoc.models.IQVDocument import IQVDocument
from etmfa_core.aidoc.models.IQVDocument import IQVPageROI

from .load_xml import (_writeToXmlFromIQVDocument,
                       _writeToXmlFromIQVPageROI,
                       _write_ET_to_file,
                       _readFromXmlToIQVDocument,
                       _readFromXmlToIQVPageROI,
                       _readFromXmlToConfig,
                       _readFromXmlToIQVDocumentGroundTruth,
                       _readFromXmlToIQVDocumentGroundTruthList,
                       _readFromXmlToIQVTM_PDFDocumentList,
                       _readFromXmlToIQVBigramList,
                       _readFromXmlToIQVDocumentMappingList,
                       _readFromXmlToIQVConfidenceTrackerList,
                       _readFromXmlToIQVCountryMappingList
                       )
from .load_xml_db import *
from .load_xml_db_ext import *
from .load_xml_utilities import *

logger = logging.getLogger('etmfa_core.aidoc')


def write_iqv_xml(filename: str, db: IQVDocument, remove_non_printable_chars: bool = False):
    """
    Write an IQVDocument object to file.

    Args:
        filename (str): The output file path.
        db (IQVDocument): The IQV Document to write.
    """
    if filename.lower().endswith('zip'):
        write_iqv_xml_set(filename, db, remove_non_printable_chars)
        logger.info(f'Output IQVDocument to {filename}')
    else:    
        root = _writeToXmlFromIQVDocument(db)
        _write_ET_to_file(filename, root, remove_non_printable_chars)
        logger.info(f'Output IQVDocument to {filename}')


def write_roi(filename:str, db: IQVPageROI, remove_non_printable_chars: bool = False):
    try:
        root = _writeToXmlFromIQVPageROI(db)
        _write_ET_to_file(filename, root, remove_non_printable_chars)
        pass
    except Exception as e:
        print(str(e))


def write_iqv_xml_set(filename: str, db: IQVDocument, remove_non_printable_chars: bool = False):
    """
    Write an IQVDocument object to file.

    Args:
        filename (str): The output file path.
        db (IQVDocument): The IQV Document to write.
    """

    try:
        filenames = []
        tmp_dir = str(uuid.uuid1())
        dir_local = os.getcwd()
        dir_local = os.path.join(dir_local, 'tmp')
        tmp_dir = os.path.join(dir_local, tmp_dir)

        if not os.path.exists(tmp_dir):
            os.makedirs(tmp_dir)

        cnt = 0
        for roi in db.DocumentParagraphs:
            cnt_str = f"{cnt:010d}"
            roi_str = 'p.' + cnt_str + '.' + roi.id + '.xml'
            roi_filename = os.path.join(tmp_dir, roi_str) 
            write_roi(roi_filename, roi, remove_non_printable_chars)
            filenames.append(roi_filename)
            cnt += 1
        for roi in db.DocumentImages:
            cnt_str = f"{cnt:010d}"
            roi_str = 'i.' + cnt_str + '.' + roi.id + '.xml'
            roi_filename = os.path.join(tmp_dir, roi_str) 
            write_roi(roi_filename, roi, remove_non_printable_chars)
            filenames.append(roi_filename)
            cnt += 1
        for roi in db.DocumentTables:
            cnt_str = f"{cnt:010d}"
            roi_str = 't.' + cnt_str + '.' + roi.id + '.xml'
            roi_filename = os.path.join(tmp_dir, roi_str) 
            write_roi(roi_filename, roi, remove_non_printable_chars)
            filenames.append(roi_filename)
            cnt += 1
        
        db.DocumentParagraphs.clear()
        db.DocumentImages.clear()
        db.DocumentTables.clear()

        cnt_str = f"{cnt:010d}"
        iqv_str = 'q.' + cnt_str + '.' + db.id + '.xml'
        iqv_filename = os.path.join(tmp_dir, iqv_str) 
        root = _writeToXmlFromIQVDocument(db)
        _write_ET_to_file(iqv_filename, root, remove_non_printable_chars)
        filenames.append(iqv_filename)
        logger.info(f'Output IQVDocument to {filename}')

        # Select the compression mode ZIP_DEFLATED for compression
        # or zipfile.ZIP_STORED to just store the file
        compression = zipfile.ZIP_DEFLATED

        zf = zipfile.ZipFile(filename, mode="w")
        for f1 in filenames:
            f1dir, f1name = ntpath.split(f1)
            zip_filename = f1  # os.path.join(tmp_dir, f1name) 
            zf.write(zip_filename, f1name, compress_type=compression)
        zf.close()

        try:
            # delete temp file
            if tmp_dir is not None:
                shutil.rmtree(tmp_dir, ignore_errors=True)
        except Exception as e:
            print(str(e))

    except Exception as e:
        print(str(e))

def read_iqv_xml(xmlfilename):
    """Import from XML a supported datatype, including IQVDocument, IQVPageROI

    Args:
        xmlfilename (str): name of input file to be processed

    Returns:
        IQVDocument or IQVPageROI: IQVDocument or IQVPageROI depending on xml root tag

    Raises:
        AttributeError: Parsed tag is of unrecognized type.
        FileNotFoundError: IQV XML was not found
    """
    parser = ET.XMLParser(encoding="utf-8")

    delete_tmp_dir = None
    parse_filename = xmlfilename
    # create element tree object
    if xmlfilename.endswith(".zip"):

        iqv = read_iqv_xml_set(xmlfilename)
        if iqv is not None:
            return iqv
        #
        # else this is not IQVDocument, so proceed...
        #
        zip_ref = zipfile.ZipFile(xmlfilename)

        if len(zip_ref.filelist) == 0:
            logger.exception("zip archive is empty")
            return None

        tmp_dir = str(uuid.uuid1())
        dir_local = os.getcwd()
        dir_local = os.path.join(dir_local, 'tmp')
        tmp_dir = os.path.join(dir_local, tmp_dir)

        if not os.path.exists(tmp_dir):
            os.makedirs(tmp_dir)

        zip_ref.extractall(tmp_dir)
        delete_tmp_dir = tmp_dir
        unzipped_files = zip_ref.filelist
        zip_ref.close()

        xml_file = unzipped_files[0].filename
        parse_filename = os.path.join(tmp_dir, xml_file)

        if not os.path.isfile(parse_filename):
            logger.exception("No files found in zip archive")
            shutil.rmtree(delete_tmp_dir, ignore_errors=True)
            return None

    if xmlfilename.endswith(".gz"):
        try:
            input = gzip.open(xmlfilename, 'r')
            tree = ET.parse(input)
        except Exception as e:
            logger.exception("Error reading gzip file")
            return None
 
    else:
        try:
            tree = ET.parse(parse_filename, parser=parser)
        except FileNotFoundError as e:
            raise FileNotFoundError(f'IQV XML was not found at path: {parse_filename}.') from e

    # get root element
    root = tree.getroot()

    # delete temp file
    if delete_tmp_dir is not None:
        shutil.rmtree(delete_tmp_dir, ignore_errors=True)

    if root.tag == 'IQVDocument':
        return _readFromXmlToIQVDocument(root)
    elif root.tag == 'IQVPageROI':
        return _readFromXmlToIQVPageROI(root)
    elif root.tag == 'Config':
        return _readFromXmlToConfig(root)
    elif root.tag == 'IQVDocumentGroundTruth':
        return _readFromXmlToIQVDocumentGroundTruth(root)
    elif root.tag == 'ArrayOfIQVDocumentGroundTruth':
        return _readFromXmlToIQVDocumentGroundTruthList(root)
    elif root.tag == 'ArrayOfIQVTM_PDFDocument':
        return _readFromXmlToIQVTM_PDFDocumentList(root)
    elif root.tag == 'ArrayOfIQVBigram':
        return _readFromXmlToIQVBigramList(root)
    elif root.tag == 'ArrayOfIQVDocumentMapping':
        return _readFromXmlToIQVDocumentMappingList(root)
    elif root.tag == 'ArrayOfIQVConfidenceTracker':
        return _readFromXmlToIQVConfidenceTrackerList(root)
    elif root.tag == 'ArrayOfIQVCountryMapping':
        return _readFromXmlToIQVCountryMappingList(root)

    logger.error(f'Root tag {str(root.tag)} is unrecognized type. {xmlfilename}')
    raise AttributeError(f'Root tag {str(root.tag)} is unrecognized type.')


def read_roi(xmlfilename):
    """
    Read ROI from a file
    """
    parser = ET.XMLParser(encoding="utf-8")

    delete_tmp_dir = None
    parse_filename = xmlfilename

    roi = None

    try:
        tree_para = ET.parse(parse_filename, parser=parser)
        # get root element
        root_para = tree_para.getroot()
        if root_para.tag == 'IQVPageROI':
            roi = _readFromXmlToIQVPageROI(root_para)
            # iqv.DocumentParagraphs.append(roi)
            tree_para = None
            parser = None
    except Exception as e:
        print(str(e))
    return roi
    
def read_iqv_xml_set(xmlfilename):
    """Import from XML IQVDocument only. Assumed to be a ZIP file!
    This is invoked from read_iqv_xml when a zip file is passed in

    Args:
        xmlfilename (str): name of input file to be processed

    Returns:
        IQVDocument or IQVPageROI: IQVDocument or IQVPageROI depending on xml root tag

    Raises:
        AttributeError: Parsed tag is of unrecognized type.
        FileNotFoundError: IQV XML was not found
    """
    parser = ET.XMLParser(encoding="utf-8")

    delete_tmp_dir = None
    parse_filename = xmlfilename
    # create element tree object
    if xmlfilename.endswith(".zip"):
        zip_ref = zipfile.ZipFile(xmlfilename)

        if len(zip_ref.filelist) == 0:
            logger.exception("zip archive is empty")
            return None

        tmp_dir = str(uuid.uuid1())
        dir_local = os.getcwd()
        dir_local = os.path.join(dir_local, 'tmp')
        tmp_dir = os.path.join(dir_local, tmp_dir)

        if not os.path.exists(tmp_dir):
            os.makedirs(tmp_dir)

        zip_ref.extractall(tmp_dir)
        delete_tmp_dir = tmp_dir
        unzipped_files = zip_ref.filelist
        zip_ref.close()

        fileListTmp = os.listdir(tmp_dir)
        fileList = sorted(fileListTmp)
        source = tmp_dir
        cntFiles = 0
        iqv = IQVDocument()

        for file1 in fileList:
            if len(fileList) == 1 or file1.startswith('q.'):
                try:
                    filename_iqv = os.path.join(source,file1)
                    tree = ET.parse(filename_iqv, parser=parser)
                    root = tree.getroot()
                    if root.tag == 'IQVDocument':
                        iqv = _readFromXmlToIQVDocument(root)
                    tree = None
                    parser = None
                    break
                except FileNotFoundError as ex:
                    raise FileNotFoundError(f'IQV XML was not found at path: {parse_filename}.') from ex
                except Exception as e:
                    print(str(e))
        for file1 in fileList:
            if file1.startswith('p.'):
                try:
                    filename_para = os.path.join(source,file1)
                    roi = read_roi(filename_para)
                    if roi is not None:
                        iqv.DocumentParagraphs.append(roi)
                except Exception as e:
                    print(str(e))
            elif file1.startswith('i.'):
                try:
                    filename_para = os.path.join(source,file1)
                    roi = read_roi(filename_para)
                    if roi is not None:
                        iqv.DocumentImages.append(roi)
                except Exception as e:
                    print(str(e))
            elif file1.startswith('t.'):
                try:
                    filename_para = os.path.join(source,file1)
                    roi = read_roi(filename_para)
                    if roi is not None:
                        iqv.DocumentTables.append(roi)
                except Exception as e:
                    print(str(e))

    try:
        # delete temp file
        if delete_tmp_dir is not None:
            shutil.rmtree(delete_tmp_dir, ignore_errors=True)
    except Exception as e:
        print(str(e))

    return iqv

