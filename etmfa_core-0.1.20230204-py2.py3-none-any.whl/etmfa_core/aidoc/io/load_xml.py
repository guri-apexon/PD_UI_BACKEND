import codecs
import logging
import ntpath
import os
import shutil
import uuid
import xml.etree.ElementTree as ET
import zipfile
from ..models.IQVDocument import *
from xml.dom import minidom
import re
import itertools

logger = logging.getLogger('etmfa_core.aidoc')

# https://www.compart.com/en/unicode/category/Cc
# https://gist.github.com/lawlesst/4110923
control_chars = ''.join(map(chr, itertools.chain(range(0x00, 0x09),  # we want to keep \t (x09)
                                                 range(0x0B, 0x20),
                                                 range(0x7F, 0x85),  # we want to keep \n (x85)
                                                 range(0x86, 0xA0),
                                                 range(0xD800, 0xE000),
                                                 range(0xFDD0, 0xFDE0),
                                                 range(0xFFFE, 0x10000),
                                                 range(0x1FFFE, 0x20000),
                                                 range(0x2FFFE, 0x30000),
                                                 range(0x3FFFE, 0x40000),
                                                 range(0x4FFFE, 0x50000),
                                                 range(0x5FFFE, 0x60000),
                                                 range(0x6FFFE, 0x70000),
                                                 range(0x7FFFE, 0x80000),
                                                 range(0x8FFFE, 0x90000),
                                                 range(0x9FFFE, 0xA0000),
                                                 range(0xAFFFE, 0xB0000),
                                                 range(0xBFFFE, 0xC0000),
                                                 range(0xCFFFE, 0xD0000),
                                                 range(0xDFFFE, 0xE0000),
                                                 range(0xEFFFE, 0xF0000),
                                                 range(0xFFFFE, 0x100000),
                                                 range(0x10FFFE, 0x110000)
                                                 )))

control_char_re = re.compile('[%s]' % re.escape(control_chars))


def _remove_control_chars(s):
    return control_char_re.sub('', s)


def writeXmlFileFromIQVDocument(filename: str, db: IQVDocument):
    """
    Write to file from an IQVDocument object
    """
    root = _writeToXmlFromIQVDocument(db)
    writeXML(filename, root)
    logger.info('Output IQVDocument to ' + filename)


def writeXmlFileFromLogEntries(filename: str, db):
    try:
        root = ET.Element("ArrayOfQ_EVENT_LOG_ENTRY")
        try:
            for xelm in db:
                root.append(_writeToXmlFromQ_EVENT_LOG_ENTRY(xelm))
        except Exception as e:
            logger.info('Failed to export fields ')
        writeXML(filename, root)
        logger.info('Output Log entries to ' + filename)
    except Exception as e:
        logger.exception("Error writing log entries")


def writeXmlFileFromIQVDocumentMappingList(filename: str, db):
    try:
        root = ET.Element("ArrayOfIQVDocumentMapping")
        try:
            for xelm in db:
                root.append(_writeToXmlFromIQVDocumentMapping(xelm))
        except Exception as e:
            logger.info('Failed to export fields ')
        writeXML(filename, root)
        logger.info('Output Log entries to ' + filename)
    except Exception as e:
        logger.exception("Error writing log entries")


def writeXmlFileFromIQVFormularyItems(filename: str, db):
    try:
        root = ET.Element("ArrayOfIQVFormularyItem")
        try:
            for xelm in db:
                root.append(_writeToXmlFromIQVFormularyItem(xelm))
        except Exception as e:
            logger.info('Failed to export fields ')
        writeXML(filename, root)
        logger.info('Output IQVFormularyItems to ' + filename)
    except Exception as e:
        logger.exception("Error writing log entries")


def writeXML(filename: str, root: ET.Element):
    """
    Write to XML file any ElementTree Element
    :param filename: output filename
    :param root: ET.Element
    This is done (rather than compress a string) so that anyone (e.g., SVT) can 
    extract the XML and view it as a file
    """
    xmlstr = minidom.parseString(ET.tostring(root)).toprettyxml(indent="   ")
    # tree = ET.ElementTree()
    # tree._setroot(root)
    try:
        if filename.endswith(".zip"):
            len1 = len(filename) - 4
            tmpFilename = filename[0:len1]
            with codecs.open(tmpFilename, 'w', encoding='utf-8') as f:
                f.write(xmlstr)
            with zipfile.ZipFile(filename, 'w') as zip_ref:
                zip_ref.write(tmpFilename, os.path.basename(tmpFilename), zipfile.ZIP_DEFLATED)
            os.remove(tmpFilename)

            ## Debugging info
            # with zipfile.ZipFile(filename, 'r') as zip:
            #    for info in zip.infolist(): 
            #        print(info.filename) 
            #        print('	Modified:	' + str(datetime.datetime(*info.date_time))) 
            #        print('	System:		' + str(info.create_system) + '(0 = Windows, 3 = Unix)') 
            #        print('	ZIP version:	' + str(info.create_version)) 
            #        print('	Compressed:	' + str(info.compress_size) + ' bytes') 
            #        print('	Uncompressed:	' + str(info.file_size) + ' bytes') 
        else:
            with codecs.open(filename, 'w', encoding='utf-8') as f:
                f.write(xmlstr)
    except Exception as e:
        logger.exception("Write XML File Failed")


def writeXMLToZip(filename: str, root: ET.Element):
    """
    Write to XML file any ElementTree Element
    :param filename: output filename
    :param root: ET.Element
    """
    xmlstr = minidom.parseString(ET.tostring(root)).toprettyxml(indent="   ")
    try:
        xmlfilename = filename
        if filename.endswith(".zip"):
            xmlfilename = filename[0:len(filename) - 4]

        with codecs.open(filename, 'w', encoding='utf-8') as f:
            f.write(xmlstr)

        if filename.endswith(".zip"):
            with zipfile.ZipFile(filename, 'w') as zip:
                zip.write(xmlfilename)
    except Exception as e:
        logger.exception("Write XML File Failed")


def readXML(xmlfilename):
    """Import from XML a supported datatype, including IQVDocument, IQVPageROI

    :param xmlfilename: name of input file to be processed
    :return: IQVDocument or IQVPageROI depending on xml root tag
    """

    parser = ET.XMLParser(encoding="utf-8")

    deleteTmpDir = ""
    parseFilename = xmlfilename
    # create element tree object
    if xmlfilename.endswith(".zip"):
        zip_ref = zipfile.ZipFile(xmlfilename)
        dir, shortname = ntpath.split(xmlfilename)
        endIndex = len(shortname) - 4
        tmpDir = str(uuid.uuid1())
        tmpDir = os.path.join(dir, tmpDir)
        if not os.path.exists(tmpDir):
            os.makedirs(tmpDir)
        zip_ref.extractall(tmpDir)
        zip_ref.close()
        deleteTmpDir = tmpDir
        unzippedFiles = os.listdir(tmpDir)
        if len(unzippedFiles) > 1:
            msg = ""
            for fx in unzippedFiles:
                msg = msg + fx + ","
            logger.exception("More than one file found in zip archive. Only extracting first file. " + str(
                    len(unzippedFiles)) + " files found: " + msg)
        if len(unzippedFiles) == 0:
            logger.exception("No files found in zip archive")
            shutil.rmtree(deleteTmpDir)
            return None
        fx = unzippedFiles[0]
        parseFilename = os.path.join(tmpDir, fx)
    tree = ET.parse(parseFilename, parser=parser)
    # tree = ET.parse(xmlfilename, parser = parser)

    # get root element
    root = tree.getroot()

    # delete temp file
    if len(deleteTmpDir) > 0:
        try:
            shutil.rmtree(deleteTmpDir)
        except Exception as e:
            logger.exception('Error deleting temp folder: ' + deleteTmpDir)

    iqvDocument = IQVDocument()
    if root.tag == 'IQVDocument':
        iqvDocument = _readFromXmlToIQVDocument(root)
        return iqvDocument
    elif root.tag == 'IQVPageROI':
        iqvPageROI = _readFromXmlToIQVPageROI(root)
        return iqvPageROI
    elif root.tag == 'Config':
        db = _readFromXmlToConfig(root)
        return db
    elif root.tag == 'IQVDocumentGroundTruth':
        gt = _readFromXmlToIQVDocumentGroundTruth(root)
        return gt
    elif root.tag == 'ArrayOfIQVDocumentGroundTruth':
        gt = _readFromXmlToIQVDocumentGroundTruthList(root)
        return gt
    elif root.tag == 'ArrayOfIQVDocumentMapping':
        gt = _readFromXmlToIQVDocumentMappingList(root)
        return gt
    elif root.tag == 'ArrayOfIQVCountryMapping':
        gt = _readFromXmlToIQVCountryMappingList(root)
        return gt
    elif root.tag == 'ArrayOfIQVTM_PDFDocument':
        list = _readFromXmlToIQVTM_PDFDocumentList(root)
        return list
    elif root.tag == 'ArrayOfIQVBigram':
        list = _readFromXmlToIQVBigramList(root)
        return list
    elif root.tag == 'ArrayOfQ_EVENT_LOG_ENTRY':
        list = _readFromXmlToQ_EVENT_LOG_ENTRYList(root)
        return list
    else:
        logger.error('Failed to import file ' + xmlfilename)

    return 0


def _str2bool(str):
    """Used in import from XML: transform 'true' to True and 'false' to False;
    Default is false"""
    if str == 'true':
        return True
    elif str == 'false':
        return False
    else:
        return False


def _bool2str(bVal):
    """Used in export to XML: transform True to 'true' and False to 'false';
    Default is false"""
    str = 'false'
    if bVal == True:
        str = 'true'
    elif bVal == False:
        str = 'false'
    return str


def _write_ET_to_file(filename: str, root: ET.Element, remove_non_printable_chars: bool):
    """
    Write an ElementTree Element to an XML file
    This is done (rather than compress a string) so that anyone (e.g., SVT) can 
    extract the XML and view it as a file

    Args:
        filename (str): output filename
        root (ET.Element): element root to write
    """
    if remove_non_printable_chars:
        xml_text = ET.tostring(root, encoding='unicode')
        raw_len = len(xml_text)
        xml_text = _remove_control_chars(xml_text)

        if raw_len != len(xml_text):
            logging.warning(f'IQVDocument contain non-printable characters: {filename}')
    else:
        xml_text = ET.tostring(root)

    xmlstr = minidom.parseString(xml_text).toprettyxml(indent="   ")

    if filename.endswith(".zip"):
        len1 = len(filename) - 4
        tmpFilename = filename[0:len1]
        with codecs.open(tmpFilename, 'w', encoding='utf-8') as f:
            f.write(xmlstr)
        with zipfile.ZipFile(filename, 'w') as zip_ref:
            zip_ref.write(tmpFilename, os.path.basename(tmpFilename), zipfile.ZIP_DEFLATED)
        os.remove(tmpFilename)
    else:
        with codecs.open(filename, 'w', encoding='utf-8') as f:
            f.write(xmlstr)


def _readFromXmlToDoubleList(branch: ET.ElementTree):
    root = branch
    ret = []
    for child in root:
        if (child.tag == 'double') or (child.tag == 'float'):
            try:
                ret.append(float(child.text))
            except Exception as e:
                # log
                logger.info('Failed to export field ' + child.tag)
    return ret


def _readFromXmlToIQVDocumentGroundTruthList(branch: ET.ElementTree):
    root = branch
    ret = []
    for child in root:
        if (child.tag == 'IQVDocumentGroundTruth'):
            try:
                ret.append(_readFromXmlToIQVDocumentGroundTruth(child))
            except Exception as e:
                # log
                logger.info('Failed to export field ' + child.tag)
    return ret


def _readFromXmlToIntList(branch: ET.ElementTree):
    root = branch
    ret = []
    for child in root:
        if child.tag == 'int':
            try:
                ret.append(int(child.text))
            except Exception as e:
                # log
                logger.info('Failed to export field ' + child.tag)
    return ret


def _readFromXmlToStringList(branch: ET.ElementTree):
    root = branch
    ret = []
    for child in root:
        if child.tag == 'string':
            try:
                # Handle None gracefully
                if child.text is None:
                    ret.append('')
                else:
                    ret.append(str(child.text))
            except Exception as e:
                # log
                logger.info('Failed to export field ' + child.tag)
    return ret


def _writeToXmlFromString(val: str):
    """Get the single ET Element string with value"""
    try:
        root = ET.Element('string')
        root.text = str(val)
        return root
    except Exception as e:
        logger.info('Failed to export string')


def _writeToXmlFromFloat(val: int):
    """Get the single ET Element float, 'cast' as double with value"""
    try:
        root = ET.Element('double')
        root.text = str(val)
        return root
    except Exception as e:
        logger.info('Failed to export int ' + str(e))


def _writeToXmlFromDouble(val: int):
    """Get the single ET Element float, 'cast' as double with value"""
    try:
        root = ET.Element('double')
        root.text = str(val)
        return root
    except Exception as e:
        logger.info('Failed to export int ' + str(e))


def _writeToXmlFromInt(val: int):
    """Get the single ET Element int with value"""
    try:
        root = ET.Element('int')
        root.text = str(val)
        return root
    except Exception as e:
        logger.info('Failed to export int ' + str(e))


def _readFromXmlToRectangle(branch):
    """
    Read from XML and load memory object
    """

    # get root element
    root = branch

    # initialize Rectangle
    ret = Rectangle()

    fieldName = 'Height'
    try:
        item = root.find(fieldName)
        if item is not None:
            if item.text is not None:
                ret.Height = int(item.text)
            else:
                pass
        else:
            pass
    except Exception as e:
        logger.info('Failed to import field ' + fieldName)

    fieldName = 'Width'
    try:
        item = root.find(fieldName)
        if item is not None:
            if item.text is not None:
                ret.Width = int(item.text)
            else:
                pass
        else:
            pass
    except Exception as e:
        logger.info('Failed to import field ' + fieldName)

    fieldName = 'X'
    try:
        item = root.find(fieldName)
        if item is not None:
            if item.text is not None:
                ret.X = int(item.text)
            else:
                pass
        else:
            pass
    except Exception as e:
        logger.info('Failed to import field ' + fieldName)

    fieldName = 'Y'
    try:
        item = root.find(fieldName)
        if item is not None:
            if item.text is not None:
                ret.Y = int(item.text)
            else:
                pass
        else:
            pass
    except Exception as e:
        logger.info('Failed to import field ' + fieldName)
    return ret


def _write_attribute(root, field_name: str, field_value):
    try:
        ET.SubElement(root, field_name).text = field_value
    except Exception as e:
        logger.info('Failed to export field ' + field_name)


def _extract_attribute(root, field_name: str, convert_function, default_value):
    """
    Generic function to load XML into specific memory object
    """
    try:
        item = root.find(field_name)
        if item is not None and item.text is not None:
            return convert_function(item.text)
    except Exception as e:
        logger.info('Failed to import field ' + field_name)

    return default_value


def _extract_attribute_list(root, field_name: str, convert_function, default_value):
    """
    Generic function to load XML into specific memory object
    """
    try:
        item = root.find(field_name)
        if item is not None:
            return convert_function(item)
    except Exception as e:
        logger.info('Failed to import field ' + field_name)

    return default_value


def _writeToXmlFromRectangle(db: Rectangle):
    """
    Get the ET Element RectangleD with all of its subelements
    """
    try:
        root = ET.Element("Rectangle")
        ##############################################################
        #
        # Start of fields
        #
        ##############################################################
        fieldName = 'Height'
        try:
            fieldVal = str(db.Height)
            ET.SubElement(root, fieldName).text = fieldVal
        except:
            logger.info('Failed to export field ' + fieldName)
        fieldName = 'Width'
        try:
            fieldVal = str(db.Width)
            ET.SubElement(root, fieldName).text = fieldVal
        except:
            logger.info('Failed to export field ' + fieldName)
        fieldName = 'X'
        try:
            fieldVal = str(db.X)
            ET.SubElement(root, fieldName).text = fieldVal
        except:
            logger.info('Failed to export field ' + fieldName)
        fieldName = 'Y'
        try:
            fieldVal = str(db.Y)
            ET.SubElement(root, fieldName).text = fieldVal
        except:
            logger.info('Failed to export field ' + fieldName)
        ##############################################################
        #
        # End of fields
        #
        ##############################################################
        return root
    except Exception as e:
        logger.error('Failed to write RectangleD to root')


def _readFromXmlToLanguageCode(branch):
    """
    Read from XML and load memory object
    """

    # get root element
    root = branch

    # initialize LanguageCode
    ret = LanguageCode()

    ret.code = _extract_attribute(root, 'code', str, ret.code)

    ret.description = _extract_attribute(root, 'description', str, ret.description)

    ret.eTMFCode = _extract_attribute(root, 'eTMFCode', str, ret.eTMFCode)

    ret.fourLetterCode = _extract_attribute(root, 'fourLetterCode', str, ret.fourLetterCode)

    ret.id = _extract_attribute(root, 'id', str, ret.id)

    ret.ReleaseVersionAvailability = _extract_attribute(root, 'ReleaseVersionAvailability', int,
                                                        ret.ReleaseVersionAvailability)

    ret.tesseractCode = _extract_attribute(root, 'tesseractCode', str, ret.tesseractCode)
    return ret


def _readFromXmlToLanguageCodeList(branch: ET.ElementTree):
    """
    Read from XML and load memory object, for list of objects
    """
    root = branch
    ret = []
    for child in root:
        if (child.tag == 'LanguageCode'):
            try:
                ret.append(_readFromXmlToLanguageCode(child))
            except Exception as e:
                # log
                logger.info('Failed to import field ' + child.tag)
    return ret


def _readFromXmlToIQVDocumentMapping(branch):
    """
    Read from XML and load memory object
    """

    # get root element
    root = branch

    # initialize IQVDocumentMapping
    ret = IQVDocumentMapping()

    ret.Additional_instructions = _extract_attribute(root, 'Additional_instructions', str, ret.Additional_instructions)

    ret.AdditionalAttributesList = _extract_attribute_list(root, 'AdditionalAttributesList',
                                                           _readFromXmlToIQVKeyValueSetList, ret.AdditionalAttributesList)

    ret.AdditionalInstructionsList = _extract_attribute_list(root, 'AdditionalInstructionsList',
                                                             _readFromXmlToIQVKeyValueSetList,
                                                             ret.AdditionalInstructionsList)

    ret.CONTENT_TYPE = _extract_attribute(root, 'CONTENT_TYPE', str, ret.CONTENT_TYPE)

    ret.DateGuidance = _extract_attribute(root, 'DateGuidance', str, ret.DateGuidance)

    ret.DateGuidanceSecondary = _extract_attribute(root, 'DateGuidanceSecondary', str, ret.DateGuidanceSecondary)

    ret.DerivedMappings = _extract_attribute_list(root, 'DerivedMappings', _readFromXmlToIQVDocumentMappingList,
                                                  ret.DerivedMappings)

    ret.DIA_KEY = _extract_attribute(root, 'DIA_KEY', str, ret.DIA_KEY)

    ret.DOC_ABBREVIATION = _extract_attribute(root, 'DOC_ABBREVIATION', str, ret.DOC_ABBREVIATION)

    ret.DOC_ARTIFACT = _extract_attribute(root, 'DOC_ARTIFACT', str, ret.DOC_ARTIFACT)

    ret.DOC_CLASS = _extract_attribute(root, 'DOC_CLASS', str, ret.DOC_CLASS)

    ret.DOC_COUNT = _extract_attribute(root, 'DOC_COUNT', int, ret.DOC_COUNT)

    ret.DOC_COUNT_CURRENT = _extract_attribute(root, 'DOC_COUNT_CURRENT', int, ret.DOC_COUNT_CURRENT)

    ret.DOC_SECTION = _extract_attribute(root, 'DOC_SECTION', str, ret.DOC_SECTION)

    ret.DOC_ZONE = _extract_attribute(root, 'DOC_ZONE', str, ret.DOC_ZONE)

    ret.Document_Description = _extract_attribute(root, 'Document_Description', str, ret.Document_Description)

    ret.ExpirationDateExpected = _extract_attribute(root, 'ExpirationDateExpected', int, ret.ExpirationDateExpected)

    ret.Full_Classification_Historical = _extract_attribute(root, 'Full_Classification_Historical', str,
                                                            ret.Full_Classification_Historical)

    ret.Full_Classification_Wingspan = _extract_attribute(root, 'Full_Classification_Wingspan', str,
                                                          ret.Full_Classification_Wingspan)

    ret.id = _extract_attribute(root, 'id', str, ret.id)

    ret.MLClassificationGroup = _extract_attribute(root, 'MLClassificationGroup', str, ret.MLClassificationGroup)

    ret.MLClassificationRole = _extract_attribute(root, 'MLClassificationRole', str, ret.MLClassificationRole)

    ret.MLConfusionCluster = _extract_attribute(root, 'MLConfusionCluster', str, ret.MLConfusionCluster)

    ret.Subject = _extract_attribute(root, 'Subject', str, ret.Subject)

    ret.Subtype = _extract_attribute(root, 'Subtype', str, ret.Subtype)

    ret.TargetSystemName = _extract_attribute(root, 'TargetSystemName', str, ret.TargetSystemName)

    ret.TargetSystemVersion = _extract_attribute(root, 'TargetSystemVersion', str, ret.TargetSystemVersion)

    ret.Wingspan_DIA = _extract_attribute(root, 'Wingspan_DIA', str, ret.Wingspan_DIA)

    ret.Wingspan_Doc_ID = _extract_attribute(root, 'Wingspan_Doc_ID', str, ret.Wingspan_Doc_ID)

    ret.Wingspan_doc_type = _extract_attribute(root, 'Wingspan_doc_type', str, ret.Wingspan_doc_type)
    return ret


def _readFromXmlToIQVDocumentMappingList(branch: ET.ElementTree):
    """
    Read from XML and load memory object, for list of objects
    """
    root = branch
    ret = []
    for child in root:
        if (child.tag == 'IQVDocumentMapping'):
            try:
                ret.append(_readFromXmlToIQVDocumentMapping(child))
            except Exception as e:
                # log
                logger.info('Failed to import field ' + child.tag)
    return ret


def _readFromXmlToIQVDocumentProcess(branch):
    """
    Read from XML and load memory object
    """

    # get root element
    root = branch

    # initialize IQVDocumentProcess
    ret = IQVDocumentProcess()

    ret.bProcessRequired = _extract_attribute(root, 'bProcessRequired', _str2bool, ret.bProcessRequired)

    ret.doc_id = _extract_attribute(root, 'doc_id', str, ret.doc_id)

    ret.group_type = _extract_attribute(root, 'group_type', str, ret.group_type)

    ret.hierarchy = _extract_attribute(root, 'hierarchy', str, ret.hierarchy)

    ret.id = _extract_attribute(root, 'id', str, ret.id)

    ret.iqv_standard_term = _extract_attribute(root, 'iqv_standard_term', str, ret.iqv_standard_term)

    ret.KeyValues = _extract_attribute_list(root, 'KeyValues', _readFromXmlToIQVKeyValueSetList, ret.KeyValues)

    ret.link_id = _extract_attribute(root, 'link_id', str, ret.link_id)

    ret.link_id_level2 = _extract_attribute(root, 'link_id_level2', str, ret.link_id_level2)

    ret.link_id_level3 = _extract_attribute(root, 'link_id_level3', str, ret.link_id_level3)

    ret.link_id_level4 = _extract_attribute(root, 'link_id_level4', str, ret.link_id_level4)

    ret.link_id_level5 = _extract_attribute(root, 'link_id_level5', str, ret.link_id_level5)

    ret.link_id_level6 = _extract_attribute(root, 'link_id_level6', str, ret.link_id_level6)

    ret.link_id_subsection1 = _extract_attribute(root, 'link_id_subsection1', str, ret.link_id_subsection1)

    ret.link_id_subsection2 = _extract_attribute(root, 'link_id_subsection2', str, ret.link_id_subsection2)

    ret.link_id_subsection3 = _extract_attribute(root, 'link_id_subsection3', str, ret.link_id_subsection3)

    ret.parent_id = _extract_attribute(root, 'parent_id', str, ret.parent_id)

    ret.ProcessEnvironment = _extract_attribute(root, 'ProcessEnvironment', str, ret.ProcessEnvironment)

    ret.ProcessFinishTime = _extract_attribute(root, 'ProcessFinishTime', str, ret.ProcessFinishTime)

    ret.ProcessMachineName = _extract_attribute(root, 'ProcessMachineName', str, ret.ProcessMachineName)

    ret.ProcessName = _extract_attribute(root, 'ProcessName', str, ret.ProcessName)

    ret.ProcessStartTime = _extract_attribute(root, 'ProcessStartTime', str, ret.ProcessStartTime)

    ret.ProcessType = _extract_attribute(root, 'ProcessType', str, ret.ProcessType)

    ret.ProcessUserID = _extract_attribute(root, 'ProcessUserID', str, ret.ProcessUserID)

    ret.ProcessVersion = _extract_attribute(root, 'ProcessVersion', str, ret.ProcessVersion)

    ret.ProcessVersionHash = _extract_attribute(root, 'ProcessVersionHash', str, ret.ProcessVersionHash)
    return ret


def _readFromXmlToIQVDocumentProcessList(branch: ET.ElementTree):
    """
    Read from XML and load memory object, for list of objects
    """
    root = branch
    ret = []
    for child in root:
        if (child.tag == 'IQVDocumentProcess'):
            try:
                ret.append(_readFromXmlToIQVDocumentProcess(child))
            except Exception as e:
                # log
                logger.info('Failed to import field ' + child.tag)
    return ret


def _readFromXmlToIQVQCUpdateTracking(branch):
    """
    Read from XML and load memory object
    """

    # get root element
    root = branch

    # initialize IQVQCUpdateTracking
    ret = IQVQCUpdateTracking()

    ret.doc_id = _extract_attribute(root, 'doc_id', str, ret.doc_id)

    ret.dts = _extract_attribute(root, 'dts', str, ret.dts)

    ret.group_type = _extract_attribute(root, 'group_type', str, ret.group_type)

    ret.hierarchy = _extract_attribute(root, 'hierarchy', str, ret.hierarchy)

    ret.id = _extract_attribute(root, 'id', str, ret.id)

    ret.iqv_standard_term = _extract_attribute(root, 'iqv_standard_term', str, ret.iqv_standard_term)

    ret.ItemDataType = _extract_attribute(root, 'ItemDataType', str, ret.ItemDataType)

    ret.link_id = _extract_attribute(root, 'link_id', str, ret.link_id)

    ret.link_id_level2 = _extract_attribute(root, 'link_id_level2', str, ret.link_id_level2)

    ret.link_id_level3 = _extract_attribute(root, 'link_id_level3', str, ret.link_id_level3)

    ret.link_id_level4 = _extract_attribute(root, 'link_id_level4', str, ret.link_id_level4)

    ret.link_id_level5 = _extract_attribute(root, 'link_id_level5', str, ret.link_id_level5)

    ret.link_id_level6 = _extract_attribute(root, 'link_id_level6', str, ret.link_id_level6)

    ret.link_id_subsection1 = _extract_attribute(root, 'link_id_subsection1', str, ret.link_id_subsection1)

    ret.link_id_subsection2 = _extract_attribute(root, 'link_id_subsection2', str, ret.link_id_subsection2)

    ret.link_id_subsection3 = _extract_attribute(root, 'link_id_subsection3', str, ret.link_id_subsection3)

    ret.OriginalText = _extract_attribute(root, 'OriginalText', str, ret.OriginalText)

    ret.parent_id = _extract_attribute(root, 'parent_id', str, ret.parent_id)

    ret.Properties = _extract_attribute_list(root, 'Properties', _readFromXmlToIQVKeyValueSetList, ret.Properties)

    ret.QC_id = _extract_attribute(root, 'QC_id', str, ret.QC_id)

    ret.QCType = _extract_attribute(root, 'QCType', str, ret.QCType)

    ret.roi_id = _extract_attribute(root, 'roi_id', str, ret.roi_id)

    ret.seq_num = _extract_attribute(root, 'seq_num', int, ret.seq_num)

    ret.source_system = _extract_attribute(root, 'source_system', str, ret.source_system)

    ret.UpdatedText = _extract_attribute(root, 'UpdatedText', str, ret.UpdatedText)

    ret.user_id = _extract_attribute(root, 'user_id', str, ret.user_id)
    return ret


def _readFromXmlToIQVQCUpdateTrackingList(branch: ET.ElementTree):
    """
    Read from XML and load memory object, for list of objects
    """
    root = branch
    ret = []
    for child in root:
        if (child.tag == 'IQVQCUpdateTracking'):
            try:
                ret.append(_readFromXmlToIQVQCUpdateTracking(child))
            except Exception as e:
                # log
                logger.info('Failed to import field ' + child.tag)
    return ret


def _readFromXmlToIQVTM_DocClassLite(branch):
    """
    Read from XML and load memory object
    """

    # get root element
    root = branch

    # initialize IQVTM_DocClassLite
    ret = IQVTM_DocClassLite()

    ret.DocumentCount = _extract_attribute(root, 'DocumentCount', int, ret.DocumentCount)

    ret.Index = _extract_attribute(root, 'Index', int, ret.Index)
    return ret


def _readFromXmlToIQVTM_DocClassLiteList(branch: ET.ElementTree):
    """
    Read from XML and load memory object, for list of objects
    """
    root = branch
    ret = []
    for child in root:
        if (child.tag == 'IQVTM_DocClassLite'):
            try:
                ret.append(_readFromXmlToIQVTM_DocClassLite(child))
            except Exception as e:
                # log
                logger.info('Failed to import field ' + child.tag)
    return ret


def _readFromXmlToIQVTableColumnHeader(branch):
    """
    Read from XML and load memory object
    """

    # get root element
    root = branch

    # initialize IQVTableColumnHeader
    ret = IQVTableColumnHeader()

    ret.doc_id = _extract_attribute(root, 'doc_id', str, ret.doc_id)

    ret.group_type = _extract_attribute(root, 'group_type', str, ret.group_type)

    ret.hierarchy = _extract_attribute(root, 'hierarchy', str, ret.hierarchy)

    ret.id = _extract_attribute(root, 'id', str, ret.id)

    ret.iqv_standard_term = _extract_attribute(root, 'iqv_standard_term', str, ret.iqv_standard_term)

    ret.link_id = _extract_attribute(root, 'link_id', str, ret.link_id)

    ret.link_id_level2 = _extract_attribute(root, 'link_id_level2', str, ret.link_id_level2)

    ret.link_id_level3 = _extract_attribute(root, 'link_id_level3', str, ret.link_id_level3)

    ret.link_id_level4 = _extract_attribute(root, 'link_id_level4', str, ret.link_id_level4)

    ret.link_id_level5 = _extract_attribute(root, 'link_id_level5', str, ret.link_id_level5)

    ret.link_id_level6 = _extract_attribute(root, 'link_id_level6', str, ret.link_id_level6)

    ret.link_id_subsection1 = _extract_attribute(root, 'link_id_subsection1', str, ret.link_id_subsection1)

    ret.link_id_subsection2 = _extract_attribute(root, 'link_id_subsection2', str, ret.link_id_subsection2)

    ret.link_id_subsection3 = _extract_attribute(root, 'link_id_subsection3', str, ret.link_id_subsection3)

    ret.OriginalText = _extract_attribute(root, 'OriginalText', str, ret.OriginalText)

    ret.parent_id = _extract_attribute(root, 'parent_id', str, ret.parent_id)

    ret.Properties = _extract_attribute_list(root, 'Properties', _readFromXmlToIQVKeyValueSetList, ret.Properties)

    ret.roi_id = _extract_attribute(root, 'roi_id', str, ret.roi_id)

    ret.rowIndex = _extract_attribute(root, 'rowIndex', int, ret.rowIndex)

    ret.rowRef = _extract_attribute(root, 'rowRef', str, ret.rowRef)
    return ret


def _readFromXmlToIQVTableColumnHeaderList(branch: ET.ElementTree):
    """
    Read from XML and load memory object, for list of objects
    """
    root = branch
    ret = []
    for child in root:
        if (child.tag == 'IQVTableColumnHeader'):
            try:
                ret.append(_readFromXmlToIQVTableColumnHeader(child))
            except Exception as e:
                # log
                logger.info('Failed to import field ' + child.tag)
    return ret


def _readFromXmlToIQVTableColumn(branch):
    """
    Read from XML and load memory object
    """

    # get root element
    root = branch

    # initialize IQVTableColumn
    ret = IQVTableColumn()

    ret.doc_id = _extract_attribute(root, 'doc_id', str, ret.doc_id)

    ret.group_type = _extract_attribute(root, 'group_type', str, ret.group_type)

    ret.headers = _extract_attribute_list(root, 'headers', _readFromXmlToIQVTableColumnHeaderList, ret.headers)

    ret.hierarchy = _extract_attribute(root, 'hierarchy', str, ret.hierarchy)

    ret.id = _extract_attribute(root, 'id', str, ret.id)

    ret.iqv_standard_term = _extract_attribute(root, 'iqv_standard_term', str, ret.iqv_standard_term)

    ret.link_id = _extract_attribute(root, 'link_id', str, ret.link_id)

    ret.link_id_level2 = _extract_attribute(root, 'link_id_level2', str, ret.link_id_level2)

    ret.link_id_level3 = _extract_attribute(root, 'link_id_level3', str, ret.link_id_level3)

    ret.link_id_level4 = _extract_attribute(root, 'link_id_level4', str, ret.link_id_level4)

    ret.link_id_level5 = _extract_attribute(root, 'link_id_level5', str, ret.link_id_level5)

    ret.link_id_level6 = _extract_attribute(root, 'link_id_level6', str, ret.link_id_level6)

    ret.link_id_subsection1 = _extract_attribute(root, 'link_id_subsection1', str, ret.link_id_subsection1)

    ret.link_id_subsection2 = _extract_attribute(root, 'link_id_subsection2', str, ret.link_id_subsection2)

    ret.link_id_subsection3 = _extract_attribute(root, 'link_id_subsection3', str, ret.link_id_subsection3)

    ret.maxX = _extract_attribute(root, 'maxX', int, ret.maxX)

    ret.minX = _extract_attribute(root, 'minX', int, ret.minX)

    ret.parent_id = _extract_attribute(root, 'parent_id', str, ret.parent_id)

    ret.Properties = _extract_attribute_list(root, 'Properties', _readFromXmlToIQVKeyValueSetList, ret.Properties)

    ret.table_roi_id = _extract_attribute(root, 'table_roi_id', str, ret.table_roi_id)

    ret.tableColumnIndex = _extract_attribute(root, 'tableColumnIndex', int, ret.tableColumnIndex)

    ret.tableColumnRef = _extract_attribute(root, 'tableColumnRef', str, ret.tableColumnRef)

    ret.tableIndex = _extract_attribute(root, 'tableIndex', int, ret.tableIndex)
    return ret


def _readFromXmlToIQVTableColumnList(branch: ET.ElementTree):
    """
    Read from XML and load memory object, for list of objects
    """
    root = branch
    ret = []
    for child in root:
        if (child.tag == 'IQVTableColumn'):
            try:
                ret.append(_readFromXmlToIQVTableColumn(child))
            except Exception as e:
                # log
                logger.info('Failed to import field ' + child.tag)
    return ret


def _readFromXmlToIQVTableRow(branch):
    """
    Read from XML and load memory object
    """

    # get root element
    root = branch

    # initialize IQVTableRow
    ret = IQVTableRow()

    ret.doc_id = _extract_attribute(root, 'doc_id', str, ret.doc_id)

    ret.group_type = _extract_attribute(root, 'group_type', str, ret.group_type)

    ret.header = _extract_attribute(root, 'header', str, ret.header)

    ret.hierarchy = _extract_attribute(root, 'hierarchy', str, ret.hierarchy)

    ret.id = _extract_attribute(root, 'id', str, ret.id)

    ret.iqv_standard_term = _extract_attribute(root, 'iqv_standard_term', str, ret.iqv_standard_term)

    ret.link_id = _extract_attribute(root, 'link_id', str, ret.link_id)

    ret.link_id_level2 = _extract_attribute(root, 'link_id_level2', str, ret.link_id_level2)

    ret.link_id_level3 = _extract_attribute(root, 'link_id_level3', str, ret.link_id_level3)

    ret.link_id_level4 = _extract_attribute(root, 'link_id_level4', str, ret.link_id_level4)

    ret.link_id_level5 = _extract_attribute(root, 'link_id_level5', str, ret.link_id_level5)

    ret.link_id_level6 = _extract_attribute(root, 'link_id_level6', str, ret.link_id_level6)

    ret.link_id_subsection1 = _extract_attribute(root, 'link_id_subsection1', str, ret.link_id_subsection1)

    ret.link_id_subsection2 = _extract_attribute(root, 'link_id_subsection2', str, ret.link_id_subsection2)

    ret.link_id_subsection3 = _extract_attribute(root, 'link_id_subsection3', str, ret.link_id_subsection3)

    ret.maxY = _extract_attribute(root, 'maxY', int, ret.maxY)

    ret.minY = _extract_attribute(root, 'minY', int, ret.minY)

    ret.parent_id = _extract_attribute(root, 'parent_id', str, ret.parent_id)

    ret.tableIndex = _extract_attribute(root, 'tableIndex', int, ret.tableIndex)

    ret.tableRowIndex = _extract_attribute(root, 'tableRowIndex', int, ret.tableRowIndex)

    ret.tableRowRef = _extract_attribute(root, 'tableRowRef', str, ret.tableRowRef)
    return ret


def _readFromXmlToIQVTableRowList(branch: ET.ElementTree):
    """
    Read from XML and load memory object, for list of objects
    """
    root = branch
    ret = []
    for child in root:
        if (child.tag == 'IQVTableRow'):
            try:
                ret.append(_readFromXmlToIQVTableRow(child))
            except Exception as e:
                # log
                logger.info('Failed to import field ' + child.tag)
    return ret


def _readFromXmlToIQVExternalLink(branch):
    """
    Read from XML and load memory object
    """

    # get root element
    root = branch

    # initialize IQVExternalLink
    ret = IQVExternalLink()

    ret.connection_type = _extract_attribute(root, 'connection_type', str, ret.connection_type)

    ret.destination_link_id = _extract_attribute(root, 'destination_link_id', str, ret.destination_link_id)

    ret.destination_link_prefix = _extract_attribute(root, 'destination_link_prefix', str, ret.destination_link_prefix)

    ret.destination_link_text = _extract_attribute(root, 'destination_link_text', str, ret.destination_link_text)

    ret.destination_url = _extract_attribute(root, 'destination_url', str, ret.destination_url)

    ret.doc_id = _extract_attribute(root, 'doc_id', str, ret.doc_id)

    ret.Elements = _extract_attribute_list(root, 'Elements', _readFromXmlToIQVExternalLinkElementList, ret.Elements)

    ret.group_type = _extract_attribute(root, 'group_type', str, ret.group_type)

    ret.hierarchy = _extract_attribute(root, 'hierarchy', str, ret.hierarchy)

    ret.id = _extract_attribute(root, 'id', str, ret.id)

    ret.iqv_standard_term = _extract_attribute(root, 'iqv_standard_term', str, ret.iqv_standard_term)

    ret.length = _extract_attribute(root, 'length', int, ret.length)

    ret.link_id = _extract_attribute(root, 'link_id', str, ret.link_id)

    ret.link_id_level2 = _extract_attribute(root, 'link_id_level2', str, ret.link_id_level2)

    ret.link_id_level3 = _extract_attribute(root, 'link_id_level3', str, ret.link_id_level3)

    ret.link_id_level4 = _extract_attribute(root, 'link_id_level4', str, ret.link_id_level4)

    ret.link_id_level5 = _extract_attribute(root, 'link_id_level5', str, ret.link_id_level5)

    ret.link_id_level6 = _extract_attribute(root, 'link_id_level6', str, ret.link_id_level6)

    ret.link_id_subsection1 = _extract_attribute(root, 'link_id_subsection1', str, ret.link_id_subsection1)

    ret.link_id_subsection2 = _extract_attribute(root, 'link_id_subsection2', str, ret.link_id_subsection2)

    ret.link_id_subsection3 = _extract_attribute(root, 'link_id_subsection3', str, ret.link_id_subsection3)

    ret.link_text = _extract_attribute(root, 'link_text', str, ret.link_text)

    ret.parent_id = _extract_attribute(root, 'parent_id', str, ret.parent_id)

    ret.Properties = _extract_attribute_list(root, 'Properties', _readFromXmlToIQVKeyValueSetList, ret.Properties)

    ret.source_text = _extract_attribute(root, 'source_text', str, ret.source_text)

    ret.startIndex = _extract_attribute(root, 'startIndex', int, ret.startIndex)
    return ret


def _readFromXmlToIQVExternalLinkList(branch: ET.ElementTree):
    """
    Read from XML and load memory object, for list of objects
    """
    root = branch
    ret = []
    for child in root:
        if (child.tag == 'IQVExternalLink'):
            try:
                ret.append(_readFromXmlToIQVExternalLink(child))
            except Exception as e:
                # log
                logger.info('Failed to import field ' + child.tag)
    return ret


def _readFromXmlToIQVExternalLinkElement(branch):
    """
    Read from XML and load memory object
    """

    # get root element
    root = branch

    # initialize IQVExternalLinkElement
    ret = IQVExternalLinkElement()

    ret.doc_id = _extract_attribute(root, 'doc_id', str, ret.doc_id)

    ret.group_type = _extract_attribute(root, 'group_type', str, ret.group_type)

    ret.hierarchy = _extract_attribute(root, 'hierarchy', str, ret.hierarchy)

    ret.id = _extract_attribute(root, 'id', str, ret.id)

    ret.iqv_standard_term = _extract_attribute(root, 'iqv_standard_term', str, ret.iqv_standard_term)

    ret.length = _extract_attribute(root, 'length', int, ret.length)

    ret.link_id = _extract_attribute(root, 'link_id', str, ret.link_id)

    ret.link_id_level2 = _extract_attribute(root, 'link_id_level2', str, ret.link_id_level2)

    ret.link_id_level3 = _extract_attribute(root, 'link_id_level3', str, ret.link_id_level3)

    ret.link_id_level4 = _extract_attribute(root, 'link_id_level4', str, ret.link_id_level4)

    ret.link_id_level5 = _extract_attribute(root, 'link_id_level5', str, ret.link_id_level5)

    ret.link_id_level6 = _extract_attribute(root, 'link_id_level6', str, ret.link_id_level6)

    ret.link_id_subsection1 = _extract_attribute(root, 'link_id_subsection1', str, ret.link_id_subsection1)

    ret.link_id_subsection2 = _extract_attribute(root, 'link_id_subsection2', str, ret.link_id_subsection2)

    ret.link_id_subsection3 = _extract_attribute(root, 'link_id_subsection3', str, ret.link_id_subsection3)

    ret.NLP_Entities = _extract_attribute_list(root, 'NLP_Entities', _readFromXmlToNLP_EntityList, ret.NLP_Entities)

    ret.parent_id = _extract_attribute(root, 'parent_id', str, ret.parent_id)

    ret.startIndex = _extract_attribute(root, 'startIndex', int, ret.startIndex)

    ret.text = _extract_attribute(root, 'text', str, ret.text)
    return ret


def _readFromXmlToIQVExternalLinkElementList(branch: ET.ElementTree):
    """
    Read from XML and load memory object, for list of objects
    """
    root = branch
    ret = []
    for child in root:
        if (child.tag == 'IQVExternalLinkElement'):
            try:
                ret.append(_readFromXmlToIQVExternalLinkElement(child))
            except Exception as e:
                # log
                logger.info('Failed to import field ' + child.tag)
    return ret


def _readFromXmlToIQVNumberingGroup(branch):
    """
    Read from XML and load memory object
    """

    # get root element
    root = branch

    # initialize IQVNumberingGroup
    ret = IQVNumberingGroup()

    ret.abstractNumId = _extract_attribute(root, 'abstractNumId', int, ret.abstractNumId)

    ret.countItems = _extract_attribute(root, 'countItems', int, ret.countItems)

    ret.doc_id = _extract_attribute(root, 'doc_id', str, ret.doc_id)

    ret.group_type = _extract_attribute(root, 'group_type', str, ret.group_type)

    ret.hierarchy = _extract_attribute(root, 'hierarchy', str, ret.hierarchy)

    ret.id = _extract_attribute(root, 'id', str, ret.id)

    ret.iqv_standard_term = _extract_attribute(root, 'iqv_standard_term', str, ret.iqv_standard_term)

    ret.link_id = _extract_attribute(root, 'link_id', str, ret.link_id)

    ret.link_id_level2 = _extract_attribute(root, 'link_id_level2', str, ret.link_id_level2)

    ret.link_id_level3 = _extract_attribute(root, 'link_id_level3', str, ret.link_id_level3)

    ret.link_id_level4 = _extract_attribute(root, 'link_id_level4', str, ret.link_id_level4)

    ret.link_id_level5 = _extract_attribute(root, 'link_id_level5', str, ret.link_id_level5)

    ret.link_id_level6 = _extract_attribute(root, 'link_id_level6', str, ret.link_id_level6)

    ret.link_id_subsection1 = _extract_attribute(root, 'link_id_subsection1', str, ret.link_id_subsection1)

    ret.link_id_subsection2 = _extract_attribute(root, 'link_id_subsection2', str, ret.link_id_subsection2)

    ret.link_id_subsection3 = _extract_attribute(root, 'link_id_subsection3', str, ret.link_id_subsection3)

    ret.numberingLevels = _extract_attribute_list(root, 'numberingLevels', _readFromXmlToIQVNumberingLevelList,
                                                  ret.numberingLevels)

    ret.numId = _extract_attribute(root, 'numId', int, ret.numId)

    ret.paraEndIndex = _extract_attribute(root, 'paraEndIndex', int, ret.paraEndIndex)

    ret.paraIds = _extract_attribute_list(root, 'paraIds', _readFromXmlToStringList, ret.paraIds)

    ret.paraIds_list = _extract_attribute(root, 'paraIds_list', str, ret.paraIds_list)

    ret.paraStartIndex = _extract_attribute(root, 'paraStartIndex', int, ret.paraStartIndex)

    ret.parent_id = _extract_attribute(root, 'parent_id', str, ret.parent_id)
    return ret


def _readFromXmlToIQVNumberingGroupList(branch: ET.ElementTree):
    """
    Read from XML and load memory object, for list of objects
    """
    root = branch
    ret = []
    for child in root:
        if (child.tag == 'IQVNumberingGroup'):
            try:
                ret.append(_readFromXmlToIQVNumberingGroup(child))
            except Exception as e:
                # log
                logger.info('Failed to import field ' + child.tag)
    return ret


def _readFromXmlToIQVNumberingLevel(branch):
    """
    Read from XML and load memory object
    """

    # get root element
    root = branch

    # initialize IQVNumberingLevel
    ret = IQVNumberingLevel()

    ret.doc_id = _extract_attribute(root, 'doc_id', str, ret.doc_id)

    ret.group_type = _extract_attribute(root, 'group_type', str, ret.group_type)

    ret.hierarchy = _extract_attribute(root, 'hierarchy', str, ret.hierarchy)

    ret.id = _extract_attribute(root, 'id', str, ret.id)

    ret.ilvl = _extract_attribute(root, 'ilvl', int, ret.ilvl)

    ret.iqv_standard_term = _extract_attribute(root, 'iqv_standard_term', str, ret.iqv_standard_term)

    ret.link_id = _extract_attribute(root, 'link_id', str, ret.link_id)

    ret.link_id_level2 = _extract_attribute(root, 'link_id_level2', str, ret.link_id_level2)

    ret.link_id_level3 = _extract_attribute(root, 'link_id_level3', str, ret.link_id_level3)

    ret.link_id_level4 = _extract_attribute(root, 'link_id_level4', str, ret.link_id_level4)

    ret.link_id_level5 = _extract_attribute(root, 'link_id_level5', str, ret.link_id_level5)

    ret.link_id_level6 = _extract_attribute(root, 'link_id_level6', str, ret.link_id_level6)

    ret.link_id_subsection1 = _extract_attribute(root, 'link_id_subsection1', str, ret.link_id_subsection1)

    ret.link_id_subsection2 = _extract_attribute(root, 'link_id_subsection2', str, ret.link_id_subsection2)

    ret.link_id_subsection3 = _extract_attribute(root, 'link_id_subsection3', str, ret.link_id_subsection3)

    ret.lvlText = _extract_attribute(root, 'lvlText', str, ret.lvlText)

    ret.numFmt = _extract_attribute(root, 'numFmt', str, ret.numFmt)

    ret.parent_id = _extract_attribute(root, 'parent_id', str, ret.parent_id)

    ret.start = _extract_attribute(root, 'start', str, ret.start)
    return ret


def _readFromXmlToIQVNumberingLevelList(branch: ET.ElementTree):
    """
    Read from XML and load memory object, for list of objects
    """
    root = branch
    ret = []
    for child in root:
        if (child.tag == 'IQVNumberingLevel'):
            try:
                ret.append(_readFromXmlToIQVNumberingLevel(child))
            except Exception as e:
                # log
                logger.info('Failed to import field ' + child.tag)
    return ret


def _readFromXmlToPredictedItem(branch):
    """
    Read from XML and load memory object
    """

    # get root element
    root = branch

    # initialize PredictedItem
    ret = PredictedItem()

    ret.AttributeKey = _extract_attribute(root, 'AttributeKey', str, ret.AttributeKey)

    ret.DocumentType = _extract_attribute(root, 'DocumentType', int, ret.DocumentType)

    ret.Full_Classification_Historical = _extract_attribute(root, 'Full_Classification_Historical', str,
                                                            ret.Full_Classification_Historical)

    ret.Predicted_TestConfidence = _extract_attribute(root, 'Predicted_TestConfidence', float,
                                                      ret.Predicted_TestConfidence)

    ret.Predicted_TestCorrect = _extract_attribute(root, 'Predicted_TestCorrect', int, ret.Predicted_TestCorrect)

    ret.PredictedItem_RawScore = _extract_attribute(root, 'PredictedItem_RawScore', float, ret.PredictedItem_RawScore)

    ret.PredictedItem_TestCount = _extract_attribute(root, 'PredictedItem_TestCount', int, ret.PredictedItem_TestCount)
    return ret


def _readFromXmlToPredictedItemList(branch: ET.ElementTree):
    """
    Read from XML and load memory object, for list of objects
    """
    root = branch
    ret = []
    for child in root:
        if (child.tag == 'PredictedItem'):
            try:
                ret.append(_readFromXmlToPredictedItem(child))
            except Exception as e:
                # log
                logger.info('Failed to import field ' + child.tag)
    return ret


def _readFromXmlToIQVConfidenceTracker(branch):
    """
    Read from XML and load memory object
    """

    # get root element
    root = branch

    # initialize IQVConfidenceTracker
    ret = IQVConfidenceTracker()

    ret.AttributeKey = _extract_attribute(root, 'AttributeKey', str, ret.AttributeKey)

    ret.PredictedItems = _extract_attribute_list(root, 'PredictedItems', _readFromXmlToPredictedItemList,
                                                 ret.PredictedItems)
    return ret


def _readFromXmlToIQVConfidenceTrackerList(branch: ET.ElementTree):
    """
    Read from XML and load memory object, for list of objects
    """
    root = branch
    ret = []
    for child in root:
        if (child.tag == 'IQVConfidenceTracker'):
            try:
                ret.append(_readFromXmlToIQVConfidenceTracker(child))
            except Exception as e:
                # log
                logger.info('Failed to import field ' + child.tag)
    return ret


def _readFromXmlToIQVLanguageMapping(branch):
    """
    Read from XML and load memory object
    """

    # get root element
    root = branch

    # initialize IQVLanguageMapping
    ret = IQVLanguageMapping()

    ret.HistoricalCount = _extract_attribute(root, 'HistoricalCount', int, ret.HistoricalCount)

    ret.HistoricalCountWeight = _extract_attribute(root, 'HistoricalCountWeight', float, ret.HistoricalCountWeight)

    ret.id = _extract_attribute(root, 'id', str, ret.id)

    fieldName = 'languageCode'
    try:
        item = root.find(fieldName)
        if item is not None:
            subbranch = item
            ret.languageCode = _readFromXmlToLanguageCode(subbranch)
        else:
            pass
    except Exception as e:
        logger.info('Failed to import field ' + fieldName)

    ret.script_list = _extract_attribute(root, 'script_list', str, ret.script_list)

    ret.scripts = _extract_attribute_list(root, 'scripts', _readFromXmlToStringList, ret.scripts)
    return ret


def _readFromXmlToIQVLanguageMappingList(branch: ET.ElementTree):
    """
    Read from XML and load memory object, for list of objects
    """
    root = branch
    ret = []
    for child in root:
        if (child.tag == 'IQVLanguageMapping'):
            try:
                ret.append(_readFromXmlToIQVLanguageMapping(child))
            except Exception as e:
                # log
                logger.info('Failed to import field ' + child.tag)
    return ret


def _readFromXmlToIQVCountryMapping(branch):
    """
    Read from XML and load memory object
    """

    # get root element
    root = branch

    # initialize IQVCountryMapping
    ret = IQVCountryMapping()

    ret.Country = _extract_attribute(root, 'Country', str, ret.Country)

    ret.DateFormats = _extract_attribute_list(root, 'DateFormats', _readFromXmlToStringList, ret.DateFormats)

    ret.id = _extract_attribute(root, 'id', str, ret.id)

    ret.iqvLanguageMappings = _extract_attribute_list(root, 'iqvLanguageMappings',
                                                      _readFromXmlToIQVLanguageMappingList, ret.iqvLanguageMappings)
    return ret


def _readFromXmlToIQVCountryMappingList(branch: ET.ElementTree):
    """
    Read from XML and load memory object, for list of objects
    """
    root = branch
    ret = []
    for child in root:
        if (child.tag == 'IQVCountryMapping'):
            try:
                ret.append(_readFromXmlToIQVCountryMapping(child))
            except Exception as e:
                # log
                logger.info('Failed to import field ' + child.tag)
    return ret


def _readFromXmlToIQVAttributeCandidate(branch):
    """
    Read from XML and load memory object
    """

    # get root element
    root = branch

    # initialize IQVAttributeCandidate
    ret = IQVAttributeCandidate()

    ret.AttributeKey = _extract_attribute(root, 'AttributeKey', str, ret.AttributeKey)

    ret.AttributeValue = _extract_attribute(root, 'AttributeValue', str, ret.AttributeValue)

    ret.CandidateSelected = _extract_attribute(root, 'CandidateSelected', int, ret.CandidateSelected)

    ret.doc_id = _extract_attribute(root, 'doc_id', str, ret.doc_id)

    ret.Features = _extract_attribute_list(root, 'Features', _readFromXmlToIQVKeyValueSetList, ret.Features)

    ret.group_type = _extract_attribute(root, 'group_type', str, ret.group_type)

    ret.hierarchy = _extract_attribute(root, 'hierarchy', str, ret.hierarchy)

    ret.id = _extract_attribute(root, 'id', str, ret.id)

    ret.iqv_standard_term = _extract_attribute(root, 'iqv_standard_term', str, ret.iqv_standard_term)

    ret.link_id = _extract_attribute(root, 'link_id', str, ret.link_id)

    ret.link_id_level2 = _extract_attribute(root, 'link_id_level2', str, ret.link_id_level2)

    ret.link_id_level3 = _extract_attribute(root, 'link_id_level3', str, ret.link_id_level3)

    ret.link_id_level4 = _extract_attribute(root, 'link_id_level4', str, ret.link_id_level4)

    ret.link_id_level5 = _extract_attribute(root, 'link_id_level5', str, ret.link_id_level5)

    ret.link_id_level6 = _extract_attribute(root, 'link_id_level6', str, ret.link_id_level6)

    ret.link_id_subsection1 = _extract_attribute(root, 'link_id_subsection1', str, ret.link_id_subsection1)

    ret.link_id_subsection2 = _extract_attribute(root, 'link_id_subsection2', str, ret.link_id_subsection2)

    ret.link_id_subsection3 = _extract_attribute(root, 'link_id_subsection3', str, ret.link_id_subsection3)

    ret.parent_id = _extract_attribute(root, 'parent_id', str, ret.parent_id)

    ret.RawProbabilitiyScore = _extract_attribute(root, 'RawProbabilitiyScore', float, ret.RawProbabilitiyScore)

    ret.roi_id = _extract_attribute(root, 'roi_id', str, ret.roi_id)
    return ret


def _readFromXmlToIQVAttributeCandidateList(branch: ET.ElementTree):
    """
    Read from XML and load memory object, for list of objects
    """
    root = branch
    ret = []
    for child in root:
        if (child.tag == 'IQVAttributeCandidate'):
            try:
                ret.append(_readFromXmlToIQVAttributeCandidate(child))
            except Exception as e:
                # log
                logger.info('Failed to import field ' + child.tag)
    return ret


def _readFromXmlToIQVBigram(branch):
    """
    Read from XML and load memory object
    """

    # get root element
    root = branch

    # initialize IQVBigram
    ret = IQVBigram()

    ret.bDutch = _extract_attribute(root, 'bDutch', _str2bool, ret.bDutch)

    ret.bEnglish = _extract_attribute(root, 'bEnglish', _str2bool, ret.bEnglish)

    ret.bFrench = _extract_attribute(root, 'bFrench', _str2bool, ret.bFrench)

    ret.bGerman = _extract_attribute(root, 'bGerman', _str2bool, ret.bGerman)

    ret.bSpanish = _extract_attribute(root, 'bSpanish', _str2bool, ret.bSpanish)

    ret.languageCode = _extract_attribute(root, 'languageCode', str, ret.languageCode)

    ret.s1 = _extract_attribute(root, 's1', str, ret.s1)

    ret.s2 = _extract_attribute(root, 's2', str, ret.s2)
    return ret


def _readFromXmlToIQVBigramList(branch: ET.ElementTree):
    """
    Read from XML and load memory object, for list of objects
    """
    root = branch
    ret = []
    for child in root:
        if (child.tag == 'IQVBigram'):
            try:
                ret.append(_readFromXmlToIQVBigram(child))
            except Exception as e:
                # log
                logger.info('Failed to import field ' + child.tag)
    return ret


def _readFromXmlToRectangleD(branch):
    """
    Read from XML and load memory object
    """

    # get root element
    root = branch

    # initialize RectangleD
    ret = RectangleD()

    ret.Height = _extract_attribute(root, 'Height', float, ret.Height)

    ret.Width = _extract_attribute(root, 'Width', float, ret.Width)

    ret.X = _extract_attribute(root, 'X', float, ret.X)

    ret.Y = _extract_attribute(root, 'Y', float, ret.Y)
    return ret


def _readFromXmlToRectangleDList(branch: ET.ElementTree):
    """
    Read from XML and load memory object, for list of objects
    """
    root = branch
    ret = []
    for child in root:
        if (child.tag == 'RectangleD'):
            try:
                ret.append(_readFromXmlToRectangleD(child))
            except Exception as e:
                # log
                logger.info('Failed to import field ' + child.tag)
    return ret


def _readFromXmlToFontInfo(branch):
    """
    Read from XML and load memory object
    """

    # get root element
    root = branch

    # initialize FontInfo
    ret = FontInfo()

    ret.Bold = _extract_attribute(root, 'Bold', _str2bool, ret.Bold)

    ret.Caps = _extract_attribute(root, 'Caps', _str2bool, ret.Caps)

    ret.ColorRGB = _extract_attribute(root, 'ColorRGB', int, ret.ColorRGB)

    ret.doc_id = _extract_attribute(root, 'doc_id', str, ret.doc_id)

    ret.DStrike = _extract_attribute(root, 'DStrike', _str2bool, ret.DStrike)

    ret.Emboss = _extract_attribute(root, 'Emboss', _str2bool, ret.Emboss)

    ret.group_type = _extract_attribute(root, 'group_type', str, ret.group_type)

    ret.hierarchy = _extract_attribute(root, 'hierarchy', str, ret.hierarchy)

    ret.Highlight = _extract_attribute(root, 'Highlight', str, ret.Highlight)

    ret.id = _extract_attribute(root, 'id', str, ret.id)

    ret.Imprint = _extract_attribute(root, 'Imprint', _str2bool, ret.Imprint)

    ret.iqv_standard_term = _extract_attribute(root, 'iqv_standard_term', str, ret.iqv_standard_term)

    ret.Italics = _extract_attribute(root, 'Italics', _str2bool, ret.Italics)

    ret.link_id = _extract_attribute(root, 'link_id', str, ret.link_id)

    ret.link_id_level2 = _extract_attribute(root, 'link_id_level2', str, ret.link_id_level2)

    ret.link_id_level3 = _extract_attribute(root, 'link_id_level3', str, ret.link_id_level3)

    ret.link_id_level4 = _extract_attribute(root, 'link_id_level4', str, ret.link_id_level4)

    ret.link_id_level5 = _extract_attribute(root, 'link_id_level5', str, ret.link_id_level5)

    ret.link_id_level6 = _extract_attribute(root, 'link_id_level6', str, ret.link_id_level6)

    ret.link_id_subsection1 = _extract_attribute(root, 'link_id_subsection1', str, ret.link_id_subsection1)

    ret.link_id_subsection2 = _extract_attribute(root, 'link_id_subsection2', str, ret.link_id_subsection2)

    ret.link_id_subsection3 = _extract_attribute(root, 'link_id_subsection3', str, ret.link_id_subsection3)

    ret.Outline = _extract_attribute(root, 'Outline', _str2bool, ret.Outline)

    ret.parent_id = _extract_attribute(root, 'parent_id', str, ret.parent_id)

    ret.rFonts = _extract_attribute(root, 'rFonts', str, ret.rFonts)

    ret.rStyle = _extract_attribute(root, 'rStyle', str, ret.rStyle)

    ret.Shadow = _extract_attribute(root, 'Shadow', _str2bool, ret.Shadow)

    ret.Size = _extract_attribute(root, 'Size', int, ret.Size)

    ret.SmallCaps = _extract_attribute(root, 'SmallCaps', _str2bool, ret.SmallCaps)

    ret.Strike = _extract_attribute(root, 'Strike', _str2bool, ret.Strike)

    ret.Underline = _extract_attribute(root, 'Underline', str, ret.Underline)

    ret.Vanish = _extract_attribute(root, 'Vanish', _str2bool, ret.Vanish)

    ret.VertAlign = _extract_attribute(root, 'VertAlign', str, ret.VertAlign)
    return ret


def _readFromXmlToFontInfoList(branch: ET.ElementTree):
    """
    Read from XML and load memory object, for list of objects
    """
    root = branch
    ret = []
    for child in root:
        if (child.tag == 'FontInfo'):
            try:
                ret.append(_readFromXmlToFontInfo(child))
            except Exception as e:
                # log
                logger.info('Failed to import field ' + child.tag)
    return ret


def _readFromXmlToConfig(branch):
    """
    Read from XML and load memory object
    """

    # get root element
    root = branch

    # initialize Config
    ret = Config()

    ret.AIDocQueue_IsAdmin = _extract_attribute(root, 'AIDocQueue_IsAdmin', int, ret.AIDocQueue_IsAdmin)

    ret.AIDocQueue_IsWorker = _extract_attribute(root, 'AIDocQueue_IsWorker', int, ret.AIDocQueue_IsWorker)

    ret.AIDocQueue_NumWorkers = _extract_attribute(root, 'AIDocQueue_NumWorkers', int, ret.AIDocQueue_NumWorkers)

    ret.API_Endpoint = _extract_attribute(root, 'API_Endpoint', str, ret.API_Endpoint)

    ret.API_Key = _extract_attribute(root, 'API_Key', str, ret.API_Key)

    ret.bClearWorkingDirectory = _extract_attribute(root, 'bClearWorkingDirectory', int, ret.bClearWorkingDirectory)

    ret.bCorrectRotation = _extract_attribute(root, 'bCorrectRotation', int, ret.bCorrectRotation)

    ret.bDeleteAllFilesExceptFinalizerOutputFile = _extract_attribute(root,
                                                                      'bDeleteAllFilesExceptFinalizerOutputFile',
                                                                      _str2bool,
                                                                      ret.bDeleteAllFilesExceptFinalizerOutputFile)

    ret.bDeleteInputSourceFile = _extract_attribute(root, 'bDeleteInputSourceFile', _str2bool,
                                                    ret.bDeleteInputSourceFile)

    ret.bDeleteWorkingTempDirOnSuccessComplete = _extract_attribute(root, 'bDeleteWorkingTempDirOnSuccessComplete',
                                                                    int, ret.bDeleteWorkingTempDirOnSuccessComplete)

    ret.bDictionaryBernoulliSingleCounts = _extract_attribute(root, 'bDictionaryBernoulliSingleCounts', int,
                                                              ret.bDictionaryBernoulliSingleCounts)

    ret.bDocumentManagerEXE_CloseAfterProcessDocument = _extract_attribute(root,
                                                                           'bDocumentManagerEXE_CloseAfterProcessDocument',
                                                                           int,
                                                                           ret.bDocumentManagerEXE_CloseAfterProcessDocument)

    ret.bELK_EnableLogging = _extract_attribute(root, 'bELK_EnableLogging', int, ret.bELK_EnableLogging)

    ret.bMSG_EnableMessaging = _extract_attribute(root, 'bMSG_EnableMessaging', int, ret.bMSG_EnableMessaging)

    ret.bMSG_EnableMessaging_CompareProcessing = _extract_attribute(root, 'bMSG_EnableMessaging_CompareProcessing',
                                                                    int, ret.bMSG_EnableMessaging_CompareProcessing)

    ret.bMSG_EnableMessaging_Digitizer2Processing = _extract_attribute(root,
                                                                       'bMSG_EnableMessaging_Digitizer2Processing',
                                                                       int,
                                                                       ret.bMSG_EnableMessaging_Digitizer2Processing)

    ret.bMSG_EnableMessaging_NormSOAGenerate = _extract_attribute(root, 'bMSG_EnableMessaging_NormSOAGenerate', int,
                                                                  ret.bMSG_EnableMessaging_NormSOAGenerate)

    ret.bMSG_EnableMessaging_OMOPGenerate = _extract_attribute(root, 'bMSG_EnableMessaging_OMOPGenerate', int,
                                                               ret.bMSG_EnableMessaging_OMOPGenerate)

    ret.bMSG_EnableMessaging_OMOPProcessing = _extract_attribute(root, 'bMSG_EnableMessaging_OMOPProcessing', int,
                                                                 ret.bMSG_EnableMessaging_OMOPProcessing)

    ret.bMSG_EnableMessaging_QCFeedbackProcessing = _extract_attribute(root,
                                                                       'bMSG_EnableMessaging_QCFeedbackProcessing',
                                                                       int,
                                                                       ret.bMSG_EnableMessaging_QCFeedbackProcessing)

    ret.bNoiseGenGreyscale = _extract_attribute(root, 'bNoiseGenGreyscale', _str2bool, ret.bNoiseGenGreyscale)

    ret.bNoiseGenLegibility = _extract_attribute(root, 'bNoiseGenLegibility', _str2bool, ret.bNoiseGenLegibility)

    ret.bNoiseGenPageBlanks = _extract_attribute(root, 'bNoiseGenPageBlanks', _str2bool, ret.bNoiseGenPageBlanks)

    ret.bNoiseGenPageOrientation = _extract_attribute(root, 'bNoiseGenPageOrientation', _str2bool,
                                                      ret.bNoiseGenPageOrientation)

    ret.bNoiseGenPageSequence = _extract_attribute(root, 'bNoiseGenPageSequence', _str2bool, ret.bNoiseGenPageSequence)

    ret.bOCRRaiseErrorIfScan = _extract_attribute(root, 'bOCRRaiseErrorIfScan', int, ret.bOCRRaiseErrorIfScan)

    ret.bOutput_OmopPrefixText = _extract_attribute(root, 'bOutput_OmopPrefixText', int, ret.bOutput_OmopPrefixText)

    ret.bOutput_PrefixText = _extract_attribute(root, 'bOutput_PrefixText', int, ret.bOutput_PrefixText)

    ret.bOutput_QCFeedbackPrefixText = _extract_attribute(root, 'bOutput_QCFeedbackPrefixText', int,
                                                          ret.bOutput_QCFeedbackPrefixText)

    ret.bOutput_ToMetricsDir = _extract_attribute(root, 'bOutput_ToMetricsDir', int, ret.bOutput_ToMetricsDir)

    ret.bProvideRemoteService = _extract_attribute(root, 'bProvideRemoteService', int, ret.bProvideRemoteService)

    ret.bRunInternalOCRProcesses = _extract_attribute(root, 'bRunInternalOCRProcesses', int,
                                                      ret.bRunInternalOCRProcesses)

    ret.bRunPyIPOCRProcesses = _extract_attribute(root, 'bRunPyIPOCRProcesses', int, ret.bRunPyIPOCRProcesses)

    ret.bTMFGTOutputConstrained = _extract_attribute(root, 'bTMFGTOutputConstrained', _str2bool,
                                                     ret.bTMFGTOutputConstrained)

    ret.bUseDBConnection = _extract_attribute(root, 'bUseDBConnection', int, ret.bUseDBConnection)

    ret.bUseMTServer = _extract_attribute(root, 'bUseMTServer', int, ret.bUseMTServer)

    ret.bUseSegServer = _extract_attribute(root, 'bUseSegServer', int, ret.bUseSegServer)

    ret.bWatchLog_EnableWebserverRequests = _extract_attribute(root, 'bWatchLog_EnableWebserverRequests', int,
                                                               ret.bWatchLog_EnableWebserverRequests)

    ret.ClfCodePathFilename = _extract_attribute(root, 'ClfCodePathFilename', str, ret.ClfCodePathFilename)

    ret.ConfigFilename = _extract_attribute(root, 'ConfigFilename', str, ret.ConfigFilename)

    ret.CorpusLevel = _extract_attribute(root, 'CorpusLevel', int, ret.CorpusLevel)

    ret.CorrectRotation_RotationIncrementDegrees = _extract_attribute(root,
                                                                      'CorrectRotation_RotationIncrementDegrees',
                                                                      float,
                                                                      ret.CorrectRotation_RotationIncrementDegrees)

    ret.CorrectRotation_RotationRangeDegrees = _extract_attribute(root, 'CorrectRotation_RotationRangeDegrees', float,
                                                                  ret.CorrectRotation_RotationRangeDegrees)

    ret.Country = _extract_attribute(root, 'Country', str, ret.Country)

    ret.CountryMappingFilename = _extract_attribute(root, 'CountryMappingFilename', str, ret.CountryMappingFilename)

    ret.CustomHostName = _extract_attribute(root, 'CustomHostName', str, ret.CustomHostName)

    ret.DataSplit_TestPercent = _extract_attribute(root, 'DataSplit_TestPercent', int, ret.DataSplit_TestPercent)

    ret.DataSplit_TrainingPercent = _extract_attribute(root, 'DataSplit_TrainingPercent', int,
                                                       ret.DataSplit_TrainingPercent)

    ret.DBConn_Database = _extract_attribute(root, 'DBConn_Database', str, ret.DBConn_Database)

    ret.DBConn_Login = _extract_attribute(root, 'DBConn_Login', str, ret.DBConn_Login)

    ret.DBConn_Password = _extract_attribute(root, 'DBConn_Password', str, ret.DBConn_Password)

    ret.DBConn_Server = _extract_attribute(root, 'DBConn_Server', str, ret.DBConn_Server)

    ret.DebugMode = _extract_attribute(root, 'DebugMode', int, ret.DebugMode)

    ret.DebugType = _extract_attribute(root, 'DebugType', int, ret.DebugType)

    ret.DefaultRotation = _extract_attribute(root, 'DefaultRotation', float, ret.DefaultRotation)

    ret.DictionarybRemoveCommonTerms = _extract_attribute(root, 'DictionarybRemoveCommonTerms', int,
                                                          ret.DictionarybRemoveCommonTerms)

    ret.DictionarybRemoveSparseTerms = _extract_attribute(root, 'DictionarybRemoveSparseTerms', int,
                                                          ret.DictionarybRemoveSparseTerms)

    ret.DictionaryIncludeAdditionalFeatures = _extract_attribute(root, 'DictionaryIncludeAdditionalFeatures', int,
                                                                 ret.DictionaryIncludeAdditionalFeatures)

    ret.DictionaryIncludeBigrams = _extract_attribute(root, 'DictionaryIncludeBigrams', int,
                                                      ret.DictionaryIncludeBigrams)

    ret.DictionaryIncludeLines = _extract_attribute(root, 'DictionaryIncludeLines', int, ret.DictionaryIncludeLines)

    ret.DictionaryIncludeStopWords = _extract_attribute(root, 'DictionaryIncludeStopWords', int,
                                                        ret.DictionaryIncludeStopWords)

    ret.DictionaryIncludeTrigrams = _extract_attribute(root, 'DictionaryIncludeTrigrams', int,
                                                       ret.DictionaryIncludeTrigrams)

    ret.DictionaryRemoveCommonTerms_MaxDocCount = _extract_attribute(root, 'DictionaryRemoveCommonTerms_MaxDocCount',
                                                                     int, ret.DictionaryRemoveCommonTerms_MaxDocCount)

    ret.DictionaryRemoveSparseTerms_MinDocCount = _extract_attribute(root, 'DictionaryRemoveSparseTerms_MinDocCount',
                                                                     int, ret.DictionaryRemoveSparseTerms_MinDocCount)

    ret.Dig1CodePathFilename = _extract_attribute(root, 'Dig1CodePathFilename', str, ret.Dig1CodePathFilename)

    ret.Dig1DocID = _extract_attribute(root, 'Dig1DocID', str, ret.Dig1DocID)

    ret.DisplayLabel = _extract_attribute(root, 'DisplayLabel', str, ret.DisplayLabel)

    ret.doc_id = _extract_attribute(root, 'doc_id', str, ret.doc_id)

    ret.DOCANALYSIS_TrainedNaiveBayesLibFilename = _extract_attribute(root,
                                                                      'DOCANALYSIS_TrainedNaiveBayesLibFilename',
                                                                      str,
                                                                      ret.DOCANALYSIS_TrainedNaiveBayesLibFilename)

    ret.DocID = _extract_attribute(root, 'DocID', str, ret.DocID)

    ret.DocID1 = _extract_attribute(root, 'DocID1', str, ret.DocID1)

    ret.DocID2 = _extract_attribute(root, 'DocID2', str, ret.DocID2)

    ret.DocumentManagerEXE = _extract_attribute(root, 'DocumentManagerEXE', str, ret.DocumentManagerEXE)

    ret.DocumentManagerVersion = _extract_attribute(root, 'DocumentManagerVersion', str, ret.DocumentManagerVersion)

    ret.DropBox1Dir = _extract_attribute(root, 'DropBox1Dir', str, ret.DropBox1Dir)

    ret.DropBoxWebUI = _extract_attribute(root, 'DropBoxWebUI', str, ret.DropBoxWebUI)

    ret.ELK_HostName = _extract_attribute(root, 'ELK_HostName', str, ret.ELK_HostName)

    ret.ELK_Port = _extract_attribute(root, 'ELK_Port', int, ret.ELK_Port)

    ret.ETMFDocumentSource = _extract_attribute(root, 'ETMFDocumentSource', str, ret.ETMFDocumentSource)

    ret.ETMFOutputDir = _extract_attribute(root, 'ETMFOutputDir', str, ret.ETMFOutputDir)

    ret.ExcelTemplate_SOA = _extract_attribute(root, 'ExcelTemplate_SOA', str, ret.ExcelTemplate_SOA)

    ret.EXE_CompareRunner = _extract_attribute(root, 'EXE_CompareRunner', str, ret.EXE_CompareRunner)

    ret.EXE_FeedbackUpdate = _extract_attribute(root, 'EXE_FeedbackUpdate', str, ret.EXE_FeedbackUpdate)

    ret.EXE_NormSOA = _extract_attribute(root, 'EXE_NormSOA', str, ret.EXE_NormSOA)

    ret.EXE_OMOPGenerate = _extract_attribute(root, 'EXE_OMOPGenerate', str, ret.EXE_OMOPGenerate)

    ret.EXE_OMOPIngester = _extract_attribute(root, 'EXE_OMOPIngester', str, ret.EXE_OMOPIngester)

    ret.FileDownloadStartIndex = _extract_attribute(root, 'FileDownloadStartIndex', int, ret.FileDownloadStartIndex)

    ret.flow_id = _extract_attribute(root, 'flow_id', str, ret.flow_id)

    ret.flow_name = _extract_attribute(root, 'flow_name', str, ret.flow_name)

    ret.GenerateNoise = _extract_attribute(root, 'GenerateNoise', int, ret.GenerateNoise)

    ret.GhostscriptEXEFilename = _extract_attribute(root, 'GhostscriptEXEFilename', str, ret.GhostscriptEXEFilename)

    ret.GroundTruthMasterFilename = _extract_attribute(root, 'GroundTruthMasterFilename', str,
                                                       ret.GroundTruthMasterFilename)

    ret.GroundTruthOutputDirectory = _extract_attribute(root, 'GroundTruthOutputDirectory', str,
                                                        ret.GroundTruthOutputDirectory)

    ret.id = _extract_attribute(root, 'id', str, ret.id)

    ret.ImageProc_BulletImagesDir = _extract_attribute(root, 'ImageProc_BulletImagesDir', str,
                                                       ret.ImageProc_BulletImagesDir)

    ret.ImageQC_GreyscaleThreshold = _extract_attribute(root, 'ImageQC_GreyscaleThreshold', float,
                                                        ret.ImageQC_GreyscaleThreshold)

    ret.ImageQC_LegibilityThreshold = _extract_attribute(root, 'ImageQC_LegibilityThreshold', float,
                                                         ret.ImageQC_LegibilityThreshold)

    ret.ImagesDirectory = _extract_attribute(root, 'ImagesDirectory', str, ret.ImagesDirectory)

    ret.InputDataDirectory = _extract_attribute(root, 'InputDataDirectory', str, ret.InputDataDirectory)

    ret.InputImageFilename = _extract_attribute(root, 'InputImageFilename', str, ret.InputImageFilename)

    ret.InputRawFilename = _extract_attribute(root, 'InputRawFilename', str, ret.InputRawFilename)

    ret.InputSourceMasterFilename = _extract_attribute(root, 'InputSourceMasterFilename', str,
                                                       ret.InputSourceMasterFilename)

    ret.InputWorkingMasterFilename = _extract_attribute(root, 'InputWorkingMasterFilename', str,
                                                        ret.InputWorkingMasterFilename)

    ret.IQVDocumentMappingFilename = _extract_attribute(root, 'IQVDocumentMappingFilename', str,
                                                        ret.IQVDocumentMappingFilename)

    ret.IQVEnvironment = _extract_attribute(root, 'IQVEnvironment', str, ret.IQVEnvironment)

    ret.IQVMeasurementProcedureLUTFilename = _extract_attribute(root, 'IQVMeasurementProcedureLUTFilename', str,
                                                                ret.IQVMeasurementProcedureLUTFilename)

    ret.IQVXML_DBConn_bUseDBConnection = _extract_attribute(root, 'IQVXML_DBConn_bUseDBConnection', int,
                                                            ret.IQVXML_DBConn_bUseDBConnection)

    ret.IQVXML_DBConn_bUseDBConnection_PostDig2 = _extract_attribute(root, 'IQVXML_DBConn_bUseDBConnection_PostDig2',
                                                                     int, ret.IQVXML_DBConn_bUseDBConnection_PostDig2)

    ret.IQVXML_DBConn_bUseDBConnection_PostOU = _extract_attribute(root, 'IQVXML_DBConn_bUseDBConnection_PostOU', int,
                                                                   ret.IQVXML_DBConn_bUseDBConnection_PostOU)

    ret.IQVXML_DBConn_Database = _extract_attribute(root, 'IQVXML_DBConn_Database', str, ret.IQVXML_DBConn_Database)

    ret.IQVXML_DBConn_Login = _extract_attribute(root, 'IQVXML_DBConn_Login', str, ret.IQVXML_DBConn_Login)

    ret.IQVXML_DBConn_Password = _extract_attribute(root, 'IQVXML_DBConn_Password', str, ret.IQVXML_DBConn_Password)

    ret.IQVXML_DBConn_Port = _extract_attribute(root, 'IQVXML_DBConn_Port', int, ret.IQVXML_DBConn_Port)

    ret.IQVXML_DBConn_Server = _extract_attribute(root, 'IQVXML_DBConn_Server', str, ret.IQVXML_DBConn_Server)

    ret.IQVXMLInputFilename = _extract_attribute(root, 'IQVXMLInputFilename', str, ret.IQVXMLInputFilename)

    ret.IQVXMLInputFilename2 = _extract_attribute(root, 'IQVXMLInputFilename2', str, ret.IQVXMLInputFilename2)

    ret.LanguageAnalysisLib = _extract_attribute(root, 'LanguageAnalysisLib', str, ret.LanguageAnalysisLib)

    ret.LocalTopLevelDataDir = _extract_attribute(root, 'LocalTopLevelDataDir', str, ret.LocalTopLevelDataDir)

    ret.LogDirectory = _extract_attribute(root, 'LogDirectory', str, ret.LogDirectory)

    ret.LogFilename = _extract_attribute(root, 'LogFilename', str, ret.LogFilename)

    ret.MasterFile = _extract_attribute(root, 'MasterFile', int, ret.MasterFile)

    ret.MasterIQVDocumentListFilename = _extract_attribute(root, 'MasterIQVDocumentListFilename', str,
                                                           ret.MasterIQVDocumentListFilename)

    ret.MatrixFile = _extract_attribute(root, 'MatrixFile', str, ret.MatrixFile)

    ret.MaxCellsPerPage = _extract_attribute(root, 'MaxCellsPerPage', int, ret.MaxCellsPerPage)

    ret.MaxNumDocsToProcess = _extract_attribute(root, 'MaxNumDocsToProcess', int, ret.MaxNumDocsToProcess)

    ret.MaxPagesCoreProcessing_BackSection = _extract_attribute(root, 'MaxPagesCoreProcessing_BackSection', int,
                                                                ret.MaxPagesCoreProcessing_BackSection)

    ret.MaxPagesCoreProcessing_FrontSection = _extract_attribute(root, 'MaxPagesCoreProcessing_FrontSection', int,
                                                                 ret.MaxPagesCoreProcessing_FrontSection)

    ret.MaxPagesToProcess = _extract_attribute(root, 'MaxPagesToProcess', int, ret.MaxPagesToProcess)

    ret.MaxPagesToProcessIQVTM = _extract_attribute(root, 'MaxPagesToProcessIQVTM', int, ret.MaxPagesToProcessIQVTM)

    ret.MaxTimeMinutesPerPage = _extract_attribute(root, 'MaxTimeMinutesPerPage', int, ret.MaxTimeMinutesPerPage)

    ret.MinPixelHeightForOCR = _extract_attribute(root, 'MinPixelHeightForOCR', int, ret.MinPixelHeightForOCR)

    ret.MinPixelHeightForValidImage = _extract_attribute(root, 'MinPixelHeightForValidImage', int,
                                                         ret.MinPixelHeightForValidImage)

    ret.MinPixelWidthForOCR = _extract_attribute(root, 'MinPixelWidthForOCR', int, ret.MinPixelWidthForOCR)

    ret.MinPixelWidthForValidImage = _extract_attribute(root, 'MinPixelWidthForValidImage', int,
                                                        ret.MinPixelWidthForValidImage)

    ret.MSG_ErrorLevelLowerBound = _extract_attribute(root, 'MSG_ErrorLevelLowerBound', int,
                                                      ret.MSG_ErrorLevelLowerBound)

    ret.MSG_ExchangeIsDurable = _extract_attribute(root, 'MSG_ExchangeIsDurable', int, ret.MSG_ExchangeIsDurable)

    ret.MSG_HostName = _extract_attribute(root, 'MSG_HostName', str, ret.MSG_HostName)

    ret.MSG_MaxCPU = _extract_attribute(root, 'MSG_MaxCPU', int, ret.MSG_MaxCPU)

    ret.MSG_MaxRAM = _extract_attribute(root, 'MSG_MaxRAM', int, ret.MSG_MaxRAM)

    ret.MSG_Password = _extract_attribute(root, 'MSG_Password', str, ret.MSG_Password)

    ret.MSG_Port = _extract_attribute(root, 'MSG_Port', int, ret.MSG_Port)

    ret.MSG_QueueIsDurable = _extract_attribute(root, 'MSG_QueueIsDurable', int, ret.MSG_QueueIsDurable)

    ret.MSG_User = _extract_attribute(root, 'MSG_User', str, ret.MSG_User)

    ret.MSG_VirtualHost = _extract_attribute(root, 'MSG_VirtualHost', str, ret.MSG_VirtualHost)

    ret.MTServer_Endpoint = _extract_attribute(root, 'MTServer_Endpoint', str, ret.MTServer_Endpoint)

    ret.MTServer_LocalPathMapping = _extract_attribute(root, 'MTServer_LocalPathMapping', str,
                                                       ret.MTServer_LocalPathMapping)

    ret.MTServer_MachineName = _extract_attribute(root, 'MTServer_MachineName', str, ret.MTServer_MachineName)

    ret.MTServer_Password = _extract_attribute(root, 'MTServer_Password', str, ret.MTServer_Password)

    ret.MTServer_Port = _extract_attribute(root, 'MTServer_Port', str, ret.MTServer_Port)

    ret.MTServer_SecureHTTP = _extract_attribute(root, 'MTServer_SecureHTTP', int, ret.MTServer_SecureHTTP)

    ret.MTServer_SharedDir = _extract_attribute(root, 'MTServer_SharedDir', str, ret.MTServer_SharedDir)

    ret.MTServer_User = _extract_attribute(root, 'MTServer_User', str, ret.MTServer_User)

    ret.NLP_CharMatrixDirectory = _extract_attribute(root, 'NLP_CharMatrixDirectory', str, ret.NLP_CharMatrixDirectory)

    ret.NLP_DictionaryDirectory = _extract_attribute(root, 'NLP_DictionaryDirectory', str, ret.NLP_DictionaryDirectory)

    ret.NoiseGenMaxRecords = _extract_attribute(root, 'NoiseGenMaxRecords', int, ret.NoiseGenMaxRecords)

    ret.NoiseGenStartIndex = _extract_attribute(root, 'NoiseGenStartIndex', int, ret.NoiseGenStartIndex)

    ret.NoiseType = _extract_attribute(root, 'NoiseType', int, ret.NoiseType)

    ret.OCR_bUseSpellCheck = _extract_attribute(root, 'OCR_bUseSpellCheck', int, ret.OCR_bUseSpellCheck)

    ret.OCR_SpellCheckDirectory = _extract_attribute(root, 'OCR_SpellCheckDirectory', str, ret.OCR_SpellCheckDirectory)

    ret.OCR_UserWordsDirectory = _extract_attribute(root, 'OCR_UserWordsDirectory', str, ret.OCR_UserWordsDirectory)

    ret.OMOPUpdateFilename = _extract_attribute(root, 'OMOPUpdateFilename', str, ret.OMOPUpdateFilename)

    ret.Output_OmopPrefixText = _extract_attribute(root, 'Output_OmopPrefixText', str, ret.Output_OmopPrefixText)

    ret.Output_PrefixText = _extract_attribute(root, 'Output_PrefixText', str, ret.Output_PrefixText)

    ret.Output_QCFeedbackPrefixText = _extract_attribute(root, 'Output_QCFeedbackPrefixText', str,
                                                         ret.Output_QCFeedbackPrefixText)

    ret.Output_ToCompareDir = _extract_attribute(root, 'Output_ToCompareDir', str, ret.Output_ToCompareDir)

    ret.Output_ToMetricsDir = _extract_attribute(root, 'Output_ToMetricsDir', str, ret.Output_ToMetricsDir)

    ret.OutputDirectory = _extract_attribute(root, 'OutputDirectory', str, ret.OutputDirectory)

    ret.OutputFilename = _extract_attribute(root, 'OutputFilename', str, ret.OutputFilename)

    ret.OutputLevel = _extract_attribute(root, 'OutputLevel', int, ret.OutputLevel)

    ret.PageIndex = _extract_attribute(root, 'PageIndex', int, ret.PageIndex)

    ret.PerformBatchDocClass = _extract_attribute(root, 'PerformBatchDocClass', int, ret.PerformBatchDocClass)

    ret.PerformDocumentDeconstruction = _extract_attribute(root, 'PerformDocumentDeconstruction', int,
                                                           ret.PerformDocumentDeconstruction)

    ret.PerformDocumentReconstruction = _extract_attribute(root, 'PerformDocumentReconstruction', int,
                                                           ret.PerformDocumentReconstruction)

    ret.PerformDuplicateCheck = _extract_attribute(root, 'PerformDuplicateCheck', int, ret.PerformDuplicateCheck)

    ret.PerformImageQC = _extract_attribute(root, 'PerformImageQC', int, ret.PerformImageQC)

    ret.PerformMetadata = _extract_attribute(root, 'PerformMetadata', int, ret.PerformMetadata)

    ret.PerformRotations = _extract_attribute(root, 'PerformRotations', int, ret.PerformRotations)

    ret.PerformXLIFFReceive = _extract_attribute(root, 'PerformXLIFFReceive', int, ret.PerformXLIFFReceive)

    ret.PerformXLIFFSend = _extract_attribute(root, 'PerformXLIFFSend', int, ret.PerformXLIFFSend)

    ret.PerformXLIFFSourceCreation = _extract_attribute(root, 'PerformXLIFFSourceCreation', int,
                                                        ret.PerformXLIFFSourceCreation)

    ret.Priority = _extract_attribute(root, 'Priority', int, ret.Priority)

    ret.ProcessSource = _extract_attribute(root, 'ProcessSource', int, ret.ProcessSource)

    ret.PythonEnvironment = _extract_attribute(root, 'PythonEnvironment', str, ret.PythonEnvironment)

    ret.PythonEXEFilename = _extract_attribute(root, 'PythonEXEFilename', str, ret.PythonEXEFilename)

    ret.QCFeedbackJSONFilename = _extract_attribute(root, 'QCFeedbackJSONFilename', str, ret.QCFeedbackJSONFilename)

    ret.QCFeedbackRunId = _extract_attribute(root, 'QCFeedbackRunId', str, ret.QCFeedbackRunId)

    ret.Recon_bUseTemplateMatching = _extract_attribute(root, 'Recon_bUseTemplateMatching', int,
                                                        ret.Recon_bUseTemplateMatching)

    ret.Recon_TemplateDirectory = _extract_attribute(root, 'Recon_TemplateDirectory', str, ret.Recon_TemplateDirectory)

    ret.Recon_TemplateFilename = _extract_attribute(root, 'Recon_TemplateFilename', str, ret.Recon_TemplateFilename)

    ret.RedactionProfileID = _extract_attribute(root, 'RedactionProfileID', str, ret.RedactionProfileID)

    ret.RedactionProfileListingFilename = _extract_attribute(root, 'RedactionProfileListingFilename', str,
                                                             ret.RedactionProfileListingFilename)

    ret.RedactionReplacementMethod = _extract_attribute(root, 'RedactionReplacementMethod', str,
                                                        ret.RedactionReplacementMethod)

    ret.RedactionTextMask = _extract_attribute(root, 'RedactionTextMask', str, ret.RedactionTextMask)

    ret.RedactionTextPrefix = _extract_attribute(root, 'RedactionTextPrefix', str, ret.RedactionTextPrefix)

    ret.RedactionTextSuffix = _extract_attribute(root, 'RedactionTextSuffix', str, ret.RedactionTextSuffix)

    ret.RemoteServer_MachineName = _extract_attribute(root, 'RemoteServer_MachineName', str,
                                                      ret.RemoteServer_MachineName)

    ret.RemoteServer_Port = _extract_attribute(root, 'RemoteServer_Port', str, ret.RemoteServer_Port)

    ret.RemoteServer_ServerLocalDir = _extract_attribute(root, 'RemoteServer_ServerLocalDir', str,
                                                         ret.RemoteServer_ServerLocalDir)

    ret.RemoteServer_SharedDir = _extract_attribute(root, 'RemoteServer_SharedDir', str, ret.RemoteServer_SharedDir)

    ret.Rotation = _extract_attribute(root, 'Rotation', int, ret.Rotation)

    ret.RunRemote = _extract_attribute(root, 'RunRemote', _str2bool, ret.RunRemote)

    ret.SegmentationType = _extract_attribute(root, 'SegmentationType', int, ret.SegmentationType)

    ret.SegServer_Endpoint = _extract_attribute(root, 'SegServer_Endpoint', str, ret.SegServer_Endpoint)

    ret.SegServer_LocalPathMapping = _extract_attribute(root, 'SegServer_LocalPathMapping', str,
                                                        ret.SegServer_LocalPathMapping)

    ret.SegServer_MachineName = _extract_attribute(root, 'SegServer_MachineName', str, ret.SegServer_MachineName)

    ret.SegServer_Port = _extract_attribute(root, 'SegServer_Port', str, ret.SegServer_Port)

    ret.SegServer_SecureHTTP = _extract_attribute(root, 'SegServer_SecureHTTP', int, ret.SegServer_SecureHTTP)

    ret.SegServer_SharedDir = _extract_attribute(root, 'SegServer_SharedDir', str, ret.SegServer_SharedDir)

    ret.ShowProgressForm = _extract_attribute(root, 'ShowProgressForm', int, ret.ShowProgressForm)

    ret.sofficeLocation = _extract_attribute(root, 'sofficeLocation', str, ret.sofficeLocation)

    ret.SourceLanguage = _extract_attribute(root, 'SourceLanguage', str, ret.SourceLanguage)

    ret.StandardTemplateIQVXML = _extract_attribute(root, 'StandardTemplateIQVXML', str, ret.StandardTemplateIQVXML)

    ret.TargetLanguage = _extract_attribute(root, 'TargetLanguage', str, ret.TargetLanguage)

    ret.tessdataDir = _extract_attribute(root, 'tessdataDir', str, ret.tessdataDir)

    ret.TesseractEXEFilename = _extract_attribute(root, 'TesseractEXEFilename', str, ret.TesseractEXEFilename)

    ret.TMFGTOutputConstrained_AvgPages = _extract_attribute(root, 'TMFGTOutputConstrained_AvgPages', int,
                                                             ret.TMFGTOutputConstrained_AvgPages)

    ret.TMFGTOutputConstrained_MinSamples = _extract_attribute(root, 'TMFGTOutputConstrained_MinSamples', int,
                                                               ret.TMFGTOutputConstrained_MinSamples)

    ret.TMFRawDataSourceDirectory = _extract_attribute(root, 'TMFRawDataSourceDirectory', str,
                                                       ret.TMFRawDataSourceDirectory)

    ret.TMSServer_Endpoint = _extract_attribute(root, 'TMSServer_Endpoint', str, ret.TMSServer_Endpoint)

    ret.TMSServer_Info = _extract_attribute(root, 'TMSServer_Info', str, ret.TMSServer_Info)

    ret.TMSServer_MachineName = _extract_attribute(root, 'TMSServer_MachineName', str, ret.TMSServer_MachineName)

    ret.TMSServer_Port = _extract_attribute(root, 'TMSServer_Port', str, ret.TMSServer_Port)

    ret.TMSSharedDirectoryList = _extract_attribute_list(root, 'TMSSharedDirectoryList', _readFromXmlToStringList,
                                                         ret.TMSSharedDirectoryList)

    ret.UserEmail = _extract_attribute(root, 'UserEmail', str, ret.UserEmail)

    ret.UserID = _extract_attribute(root, 'UserID', str, ret.UserID)

    ret.WatchLogCheckIntervalSeconds = _extract_attribute(root, 'WatchLogCheckIntervalSeconds', float,
                                                          ret.WatchLogCheckIntervalSeconds)

    ret.WatchLogFilename = _extract_attribute(root, 'WatchLogFilename', str, ret.WatchLogFilename)

    ret.WatchLogOutputDir = _extract_attribute(root, 'WatchLogOutputDir', str, ret.WatchLogOutputDir)

    ret.WatchLogOutputDirPermanentStorage = _extract_attribute(root, 'WatchLogOutputDirPermanentStorage', str,
                                                               ret.WatchLogOutputDirPermanentStorage)

    ret.WorkingDirectory = _extract_attribute(root, 'WorkingDirectory', str, ret.WorkingDirectory)

    ret.XLIFFInputFilename = _extract_attribute(root, 'XLIFFInputFilename', str, ret.XLIFFInputFilename)

    ret.XLIFFMarkupVersion = _extract_attribute(root, 'XLIFFMarkupVersion', str, ret.XLIFFMarkupVersion)
    return ret


def _readFromXmlToConfigList(branch: ET.ElementTree):
    """
    Read from XML and load memory object, for list of objects
    """
    root = branch
    ret = []
    for child in root:
        if (child.tag == 'Config'):
            try:
                ret.append(_readFromXmlToConfig(child))
            except Exception as e:
                # log
                logger.info('Failed to import field ' + child.tag)
    return ret


def _readFromXmlToIQVSubText(branch):
    """
    Read from XML and load memory object
    """

    # get root element
    root = branch

    # initialize IQVSubText
    ret = IQVSubText()

    ret.Attributes = _extract_attribute_list(root, 'Attributes', _readFromXmlToIQVAttributeList, ret.Attributes)

    ret.bNoTranslate = _extract_attribute(root, 'bNoTranslate', _str2bool, ret.bNoTranslate)

    ret.doc_id = _extract_attribute(root, 'doc_id', str, ret.doc_id)

    ret.DocumentSequenceIndex = _extract_attribute(root, 'DocumentSequenceIndex', int, ret.DocumentSequenceIndex)

    fieldName = 'fontInfo'
    try:
        item = root.find(fieldName)
        if item is not None:
            subbranch = item
            ret.fontInfo = _readFromXmlToFontInfo(subbranch)
        else:
            pass
    except Exception as e:
        logger.info('Failed to import field ' + fieldName)

    ret.group_type = _extract_attribute(root, 'group_type', str, ret.group_type)

    ret.hierarchy = _extract_attribute(root, 'hierarchy', str, ret.hierarchy)

    ret.id = _extract_attribute(root, 'id', str, ret.id)

    ret.iqv_standard_term = _extract_attribute(root, 'iqv_standard_term', str, ret.iqv_standard_term)

    ret.link_id = _extract_attribute(root, 'link_id', str, ret.link_id)

    ret.link_id_level2 = _extract_attribute(root, 'link_id_level2', str, ret.link_id_level2)

    ret.link_id_level3 = _extract_attribute(root, 'link_id_level3', str, ret.link_id_level3)

    ret.link_id_level4 = _extract_attribute(root, 'link_id_level4', str, ret.link_id_level4)

    ret.link_id_level5 = _extract_attribute(root, 'link_id_level5', str, ret.link_id_level5)

    ret.link_id_level6 = _extract_attribute(root, 'link_id_level6', str, ret.link_id_level6)

    ret.link_id_subsection1 = _extract_attribute(root, 'link_id_subsection1', str, ret.link_id_subsection1)

    ret.link_id_subsection2 = _extract_attribute(root, 'link_id_subsection2', str, ret.link_id_subsection2)

    ret.link_id_subsection3 = _extract_attribute(root, 'link_id_subsection3', str, ret.link_id_subsection3)

    ret.NLP_Attributes = _extract_attribute_list(root, 'NLP_Attributes', _readFromXmlToNLP_AttributeList,
                                                 ret.NLP_Attributes)

    ret.NLP_Entities = _extract_attribute_list(root, 'NLP_Entities', _readFromXmlToNLP_EntityList, ret.NLP_Entities)

    ret.OuterXml = _extract_attribute(root, 'OuterXml', str, ret.OuterXml)

    ret.parent_id = _extract_attribute(root, 'parent_id', str, ret.parent_id)

    ret.parent2LocalName = _extract_attribute(root, 'parent2LocalName', str, ret.parent2LocalName)

    ret.parentAttributes = _extract_attribute_list(root, 'parentAttributes', _readFromXmlToIQVAttributeList,
                                                   ret.parentAttributes)

    ret.postTags = _extract_attribute_list(root, 'postTags', _readFromXmlToStringList, ret.postTags)

    ret.postTexts = _extract_attribute_list(root, 'postTexts', _readFromXmlToIntList, ret.postTexts)

    ret.preTags = _extract_attribute_list(root, 'preTags', _readFromXmlToStringList, ret.preTags)

    ret.preTexts = _extract_attribute_list(root, 'preTexts', _readFromXmlToIntList, ret.preTexts)

    ret.QCUpdates = _extract_attribute_list(root, 'QCUpdates', _readFromXmlToIQVQCUpdateTrackingList, ret.QCUpdates)

    ret.rawSegments = _extract_attribute_list(root, 'rawSegments', _readFromXmlToStringList, ret.rawSegments)

    ret.reservedTypeVal = _extract_attribute(root, 'reservedTypeVal', int, ret.reservedTypeVal)

    ret.runElementName = _extract_attribute(root, 'runElementName', str, ret.runElementName)

    ret.sequence = _extract_attribute(root, 'sequence', int, ret.sequence)

    ret.startCharIndex = _extract_attribute(root, 'startCharIndex', int, ret.startCharIndex)

    ret.strText = _extract_attribute(root, 'strText', str, ret.strText)

    ret.strTranslatedText = _extract_attribute(root, 'strTranslatedText', str, ret.strTranslatedText)

    ret.Value = _extract_attribute(root, 'Value', str, ret.Value)
    return ret


def _readFromXmlToIQVSubTextList(branch: ET.ElementTree):
    """
    Read from XML and load memory object, for list of objects
    """
    root = branch
    ret = []
    for child in root:
        if (child.tag == 'IQVSubText'):
            try:
                ret.append(_readFromXmlToIQVSubText(child))
            except Exception as e:
                # log
                logger.info('Failed to import field ' + child.tag)
    return ret


def _readFromXmlToIQVCharacter(branch):
    """
    Read from XML and load memory object
    """

    # get root element
    root = branch

    # initialize IQVCharacter
    ret = IQVCharacter()

    ret.Bottom = _extract_attribute(root, 'Bottom', int, ret.Bottom)

    ret.doc_id = _extract_attribute(root, 'doc_id', str, ret.doc_id)

    ret.group_type = _extract_attribute(root, 'group_type', str, ret.group_type)

    ret.hierarchy = _extract_attribute(root, 'hierarchy', str, ret.hierarchy)

    ret.id = _extract_attribute(root, 'id', str, ret.id)

    ret.iqv_standard_term = _extract_attribute(root, 'iqv_standard_term', str, ret.iqv_standard_term)

    ret.Left = _extract_attribute(root, 'Left', int, ret.Left)

    ret.link_id = _extract_attribute(root, 'link_id', str, ret.link_id)

    ret.link_id_level2 = _extract_attribute(root, 'link_id_level2', str, ret.link_id_level2)

    ret.link_id_level3 = _extract_attribute(root, 'link_id_level3', str, ret.link_id_level3)

    ret.link_id_level4 = _extract_attribute(root, 'link_id_level4', str, ret.link_id_level4)

    ret.link_id_level5 = _extract_attribute(root, 'link_id_level5', str, ret.link_id_level5)

    ret.link_id_level6 = _extract_attribute(root, 'link_id_level6', str, ret.link_id_level6)

    ret.link_id_subsection1 = _extract_attribute(root, 'link_id_subsection1', str, ret.link_id_subsection1)

    ret.link_id_subsection2 = _extract_attribute(root, 'link_id_subsection2', str, ret.link_id_subsection2)

    ret.link_id_subsection3 = _extract_attribute(root, 'link_id_subsection3', str, ret.link_id_subsection3)

    ret.parent_id = _extract_attribute(root, 'parent_id', str, ret.parent_id)

    ret.Right = _extract_attribute(root, 'Right', int, ret.Right)

    ret.Tag = _extract_attribute(root, 'Tag', str, ret.Tag)

    ret.Top = _extract_attribute(root, 'Top', int, ret.Top)

    ret.Value = _extract_attribute(root, 'Value', int, ret.Value)
    return ret


def _readFromXmlToIQVCharacterList(branch: ET.ElementTree):
    """
    Read from XML and load memory object, for list of objects
    """
    root = branch
    ret = []
    for child in root:
        if (child.tag == 'IQVCharacter'):
            try:
                ret.append(_readFromXmlToIQVCharacter(child))
            except Exception as e:
                # log
                logger.info('Failed to import field ' + child.tag)
    return ret


def _readFromXmlToIQVWord(branch):
    """
    Read from XML and load memory object
    """

    # get root element
    root = branch

    # initialize IQVWord
    ret = IQVWord()

    ret.Blanks = _extract_attribute(root, 'Blanks', int, ret.Blanks)

    ret.BlockIndex = _extract_attribute(root, 'BlockIndex', int, ret.BlockIndex)

    ret.Bottom = _extract_attribute(root, 'Bottom', int, ret.Bottom)

    ret.CharList = _extract_attribute_list(root, 'CharList', _readFromXmlToIQVCharacterList, ret.CharList)

    ret.Class = _extract_attribute(root, 'Class', str, ret.Class)

    ret.Confidence = _extract_attribute(root, 'Confidence', float, ret.Confidence)

    ret.doc_id = _extract_attribute(root, 'doc_id', str, ret.doc_id)

    ret.FeedbackItems = _extract_attribute_list(root, 'FeedbackItems', _readFromXmlToIQVKeyValueSetList,
                                                ret.FeedbackItems)

    ret.FontIndex = _extract_attribute(root, 'FontIndex', float, ret.FontIndex)

    ret.FontName = _extract_attribute(root, 'FontName', str, ret.FontName)

    ret.Formating = _extract_attribute(root, 'Formating', int, ret.Formating)

    ret.group_type = _extract_attribute(root, 'group_type', str, ret.group_type)

    ret.GT_ScoreMatch = _extract_attribute(root, 'GT_ScoreMatch', float, ret.GT_ScoreMatch)

    ret.GT_TextMatch = _extract_attribute(root, 'GT_TextMatch', str, ret.GT_TextMatch)

    ret.hierarchy = _extract_attribute(root, 'hierarchy', str, ret.hierarchy)

    ret.id = _extract_attribute(root, 'id', str, ret.id)

    ret.iqv_standard_term = _extract_attribute(root, 'iqv_standard_term', str, ret.iqv_standard_term)

    ret.Left = _extract_attribute(root, 'Left', int, ret.Left)

    ret.LineIndex = _extract_attribute(root, 'LineIndex', int, ret.LineIndex)

    ret.link_id = _extract_attribute(root, 'link_id', str, ret.link_id)

    ret.link_id_level2 = _extract_attribute(root, 'link_id_level2', str, ret.link_id_level2)

    ret.link_id_level3 = _extract_attribute(root, 'link_id_level3', str, ret.link_id_level3)

    ret.link_id_level4 = _extract_attribute(root, 'link_id_level4', str, ret.link_id_level4)

    ret.link_id_level5 = _extract_attribute(root, 'link_id_level5', str, ret.link_id_level5)

    ret.link_id_level6 = _extract_attribute(root, 'link_id_level6', str, ret.link_id_level6)

    ret.link_id_subsection1 = _extract_attribute(root, 'link_id_subsection1', str, ret.link_id_subsection1)

    ret.link_id_subsection2 = _extract_attribute(root, 'link_id_subsection2', str, ret.link_id_subsection2)

    ret.link_id_subsection3 = _extract_attribute(root, 'link_id_subsection3', str, ret.link_id_subsection3)

    ret.NLP_ScoreMatch = _extract_attribute(root, 'NLP_ScoreMatch', float, ret.NLP_ScoreMatch)

    ret.NLP_TextMatch = _extract_attribute(root, 'NLP_TextMatch', str, ret.NLP_TextMatch)

    ret.NLP_TextMatchReconstructed = _extract_attribute(root, 'NLP_TextMatchReconstructed', str,
                                                        ret.NLP_TextMatchReconstructed)

    ret.parent_id = _extract_attribute(root, 'parent_id', str, ret.parent_id)

    ret.PointSize = _extract_attribute(root, 'PointSize', int, ret.PointSize)

    ret.Right = _extract_attribute(root, 'Right', int, ret.Right)

    ret.Tag = _extract_attribute(root, 'Tag', str, ret.Tag)

    ret.Text = _extract_attribute(root, 'Text', str, ret.Text)

    ret.textangle = _extract_attribute(root, 'textangle', int, ret.textangle)

    ret.TextDerivedCase = _extract_attribute(root, 'TextDerivedCase', int, ret.TextDerivedCase)

    ret.TextDerivedDeconstructed = _extract_attribute(root, 'TextDerivedDeconstructed', str,
                                                      ret.TextDerivedDeconstructed)

    ret.TextDerivedIsNumeric = _extract_attribute(root, 'TextDerivedIsNumeric', int, ret.TextDerivedIsNumeric)

    ret.TextDerivedPrefix = _extract_attribute(root, 'TextDerivedPrefix', str, ret.TextDerivedPrefix)

    ret.TextDerivedSuffix = _extract_attribute(root, 'TextDerivedSuffix', str, ret.TextDerivedSuffix)

    ret.TextLanguage = _extract_attribute(root, 'TextLanguage', str, ret.TextLanguage)

    ret.Top = _extract_attribute(root, 'Top', int, ret.Top)

    ret.WordIndex = _extract_attribute(root, 'WordIndex', int, ret.WordIndex)
    return ret


def _readFromXmlToIQVWordList(branch: ET.ElementTree):
    """
    Read from XML and load memory object, for list of objects
    """
    root = branch
    ret = []
    for child in root:
        if (child.tag == 'IQVWord'):
            try:
                ret.append(_readFromXmlToIQVWord(child))
            except Exception as e:
                # log
                logger.info('Failed to import field ' + child.tag)
    return ret


def _readFromXmlToIQVKeyValueSet(branch):
    """
    Read from XML and load memory object
    """

    # get root element
    root = branch

    # initialize IQVKeyValueSet
    ret = IQVKeyValueSet()

    ret.confidence = _extract_attribute(root, 'confidence', float, ret.confidence)

    ret.doc_id = _extract_attribute(root, 'doc_id', str, ret.doc_id)

    ret.group_type = _extract_attribute(root, 'group_type', str, ret.group_type)

    ret.hierarchy = _extract_attribute(root, 'hierarchy', str, ret.hierarchy)

    ret.id = _extract_attribute(root, 'id', str, ret.id)

    ret.iqv_standard_term = _extract_attribute(root, 'iqv_standard_term', str, ret.iqv_standard_term)

    ret.key = _extract_attribute(root, 'key', str, ret.key)

    ret.link_id = _extract_attribute(root, 'link_id', str, ret.link_id)

    ret.link_id_level2 = _extract_attribute(root, 'link_id_level2', str, ret.link_id_level2)

    ret.link_id_level3 = _extract_attribute(root, 'link_id_level3', str, ret.link_id_level3)

    ret.link_id_level4 = _extract_attribute(root, 'link_id_level4', str, ret.link_id_level4)

    ret.link_id_level5 = _extract_attribute(root, 'link_id_level5', str, ret.link_id_level5)

    ret.link_id_level6 = _extract_attribute(root, 'link_id_level6', str, ret.link_id_level6)

    ret.link_id_subsection1 = _extract_attribute(root, 'link_id_subsection1', str, ret.link_id_subsection1)

    ret.link_id_subsection2 = _extract_attribute(root, 'link_id_subsection2', str, ret.link_id_subsection2)

    ret.link_id_subsection3 = _extract_attribute(root, 'link_id_subsection3', str, ret.link_id_subsection3)

    ret.NLP_Attributes = _extract_attribute_list(root, 'NLP_Attributes', _readFromXmlToNLP_AttributeList,
                                                 ret.NLP_Attributes)

    ret.NLP_Entities = _extract_attribute_list(root, 'NLP_Entities', _readFromXmlToNLP_EntityList, ret.NLP_Entities)

    ret.parent_id = _extract_attribute(root, 'parent_id', str, ret.parent_id)

    ret.QCUpdates = _extract_attribute_list(root, 'QCUpdates', _readFromXmlToIQVQCUpdateTrackingList, ret.QCUpdates)

    ret.rawScore = _extract_attribute(root, 'rawScore', float, ret.rawScore)

    ret.source_system = _extract_attribute(root, 'source_system', str, ret.source_system)

    ret.value = _extract_attribute(root, 'value', str, ret.value)
    return ret


def _readFromXmlToIQVKeyValueSetList(branch: ET.ElementTree):
    """
    Read from XML and load memory object, for list of objects
    """
    root = branch
    ret = []
    for child in root:
        if (child.tag == 'IQVKeyValueSet'):
            try:
                ret.append(_readFromXmlToIQVKeyValueSet(child))
            except Exception as e:
                # log
                logger.info('Failed to import field ' + child.tag)
    return ret


def _readFromXmlToQ_EVENT_LOG_ENTRY(branch):
    """
    Read from XML and load memory object
    """

    # get root element
    root = branch

    # initialize Q_EVENT_LOG_ENTRY
    ret = Q_EVENT_LOG_ENTRY()

    ret.bHandled = _extract_attribute(root, 'bHandled', _str2bool, ret.bHandled)

    ret.ClassMapping = _extract_attribute(root, 'ClassMapping', str, ret.ClassMapping)

    ret.CountReplace = _extract_attribute(root, 'CountReplace', int, ret.CountReplace)

    ret.doc_id = _extract_attribute(root, 'doc_id', str, ret.doc_id)

    ret.DocumentID = _extract_attribute(root, 'DocumentID', str, ret.DocumentID)

    ret.DocumentName = _extract_attribute(root, 'DocumentName', str, ret.DocumentName)

    ret.DocumentPage = _extract_attribute(root, 'DocumentPage', int, ret.DocumentPage)

    ret.ErrorLevelVal = _extract_attribute(root, 'ErrorLevelVal', int, ret.ErrorLevelVal)

    ret.EventTypeVal = _extract_attribute(root, 'EventTypeVal', int, ret.EventTypeVal)

    ret.FieldMapping = _extract_attribute(root, 'FieldMapping', str, ret.FieldMapping)

    ret.id = _extract_attribute(root, 'id', str, ret.id)

    ret.KeyValues = _extract_attribute_list(root, 'KeyValues', _readFromXmlToIQVKeyValueSetList, ret.KeyValues)

    ret.m_DateTimeStampVal = _extract_attribute(root, 'm_DateTimeStampVal', str, ret.m_DateTimeStampVal)

    ret.Message = _extract_attribute(root, 'Message', str, ret.Message)

    ret.StackTrace = _extract_attribute(root, 'StackTrace', str, ret.StackTrace)

    ret.UserEmail = _extract_attribute(root, 'UserEmail', str, ret.UserEmail)

    ret.UserID = _extract_attribute(root, 'UserID', str, ret.UserID)

    ret.UserInputMessage = _extract_attribute(root, 'UserInputMessage', str, ret.UserInputMessage)

    ret.Value = _extract_attribute(root, 'Value', str, ret.Value)
    return ret


def _readFromXmlToQ_EVENT_LOG_ENTRYList(branch: ET.ElementTree):
    """
    Read from XML and load memory object, for list of objects
    """
    root = branch
    ret = []
    for child in root:
        if (child.tag == 'Q_EVENT_LOG_ENTRY'):
            try:
                ret.append(_readFromXmlToQ_EVENT_LOG_ENTRY(child))
            except Exception as e:
                # log
                logger.info('Failed to import field ' + child.tag)
    return ret


def _readFromXmlToIQVLine(branch):
    """
    Read from XML and load memory object
    """

    # get root element
    root = branch

    # initialize IQVLine
    ret = IQVLine()

    ret.BackgroundToForeground = _extract_attribute(root, 'BackgroundToForeground', _str2bool,
                                                    ret.BackgroundToForeground)

    ret.bIncludedInBox = _extract_attribute(root, 'bIncludedInBox', _str2bool, ret.bIncludedInBox)

    ret.bIsHorizontal = _extract_attribute(root, 'bIsHorizontal', _str2bool, ret.bIsHorizontal)

    ret.doc_id = _extract_attribute(root, 'doc_id', str, ret.doc_id)

    ret.ForegroundToBackground = _extract_attribute(root, 'ForegroundToBackground', _str2bool,
                                                    ret.ForegroundToBackground)

    ret.group_type = _extract_attribute(root, 'group_type', str, ret.group_type)

    ret.hierarchy = _extract_attribute(root, 'hierarchy', str, ret.hierarchy)

    ret.id = _extract_attribute(root, 'id', str, ret.id)

    ret.intersections = _extract_attribute_list(root, 'intersections', _readFromXmlToIQVIntersectionList,
                                                ret.intersections)

    ret.iqv_standard_term = _extract_attribute(root, 'iqv_standard_term', str, ret.iqv_standard_term)

    ret.link_id = _extract_attribute(root, 'link_id', str, ret.link_id)

    ret.link_id_level2 = _extract_attribute(root, 'link_id_level2', str, ret.link_id_level2)

    ret.link_id_level3 = _extract_attribute(root, 'link_id_level3', str, ret.link_id_level3)

    ret.link_id_level4 = _extract_attribute(root, 'link_id_level4', str, ret.link_id_level4)

    ret.link_id_level5 = _extract_attribute(root, 'link_id_level5', str, ret.link_id_level5)

    ret.link_id_level6 = _extract_attribute(root, 'link_id_level6', str, ret.link_id_level6)

    ret.link_id_subsection1 = _extract_attribute(root, 'link_id_subsection1', str, ret.link_id_subsection1)

    ret.link_id_subsection2 = _extract_attribute(root, 'link_id_subsection2', str, ret.link_id_subsection2)

    ret.link_id_subsection3 = _extract_attribute(root, 'link_id_subsection3', str, ret.link_id_subsection3)

    ret.parent_id = _extract_attribute(root, 'parent_id', str, ret.parent_id)

    ret.ParentID = _extract_attribute(root, 'ParentID', int, ret.ParentID)

    ret.SequenceID = _extract_attribute(root, 'SequenceID', int, ret.SequenceID)

    ret.Thickness = _extract_attribute(root, 'Thickness', int, ret.Thickness)

    ret.ThicknessUnit = _extract_attribute(root, 'ThicknessUnit', int, ret.ThicknessUnit)

    ret.TopParentID = _extract_attribute(root, 'TopParentID', int, ret.TopParentID)

    ret.X1 = _extract_attribute(root, 'X1', int, ret.X1)

    ret.X1Right = _extract_attribute(root, 'X1Right', int, ret.X1Right)

    ret.X2 = _extract_attribute(root, 'X2', int, ret.X2)

    ret.X2Right = _extract_attribute(root, 'X2Right', int, ret.X2Right)

    ret.Y1 = _extract_attribute(root, 'Y1', int, ret.Y1)

    ret.Y1Lower = _extract_attribute(root, 'Y1Lower', int, ret.Y1Lower)

    ret.Y2 = _extract_attribute(root, 'Y2', int, ret.Y2)

    ret.Y2Lower = _extract_attribute(root, 'Y2Lower', int, ret.Y2Lower)
    return ret


def _readFromXmlToIQVLineList(branch: ET.ElementTree):
    """
    Read from XML and load memory object, for list of objects
    """
    root = branch
    ret = []
    for child in root:
        if (child.tag == 'IQVLine'):
            try:
                ret.append(_readFromXmlToIQVLine(child))
            except Exception as e:
                # log
                logger.info('Failed to import field ' + child.tag)
    return ret


def _readFromXmlToIQVIntersection(branch):
    """
    Read from XML and load memory object
    """

    # get root element
    root = branch

    # initialize IQVIntersection
    ret = IQVIntersection()

    ret.hline_id = _extract_attribute(root, 'hline_id', str, ret.hline_id)

    ret.id = _extract_attribute(root, 'id', str, ret.id)

    ret.vline_id = _extract_attribute(root, 'vline_id', str, ret.vline_id)

    ret.X = _extract_attribute(root, 'X', int, ret.X)

    ret.Y = _extract_attribute(root, 'Y', int, ret.Y)
    return ret


def _readFromXmlToIQVIntersectionList(branch: ET.ElementTree):
    """
    Read from XML and load memory object, for list of objects
    """
    root = branch
    ret = []
    for child in root:
        if (child.tag == 'IQVIntersection'):
            try:
                ret.append(_readFromXmlToIQVIntersection(child))
            except Exception as e:
                # log
                logger.info('Failed to import field ' + child.tag)
    return ret


def _readFromXmlToIQVForm(branch):
    """
    Read from XML and load memory object
    """

    # get root element
    root = branch

    # initialize IQVForm
    ret = IQVForm()

    ret.Chapter = _extract_attribute(root, 'Chapter', str, ret.Chapter)

    ret.Children = _extract_attribute_list(root, 'Children', _readFromXmlToIQVFormList, ret.Children)

    ret.FormName = _extract_attribute(root, 'FormName', str, ret.FormName)

    ret.id = _extract_attribute(root, 'id', str, ret.id)

    ret.PrimaryKeyValue = _extract_attribute_list(root, 'PrimaryKeyValue', _readFromXmlToIQVKeyValueSetList,
                                                  ret.PrimaryKeyValue)
    return ret


def _readFromXmlToIQVFormList(branch: ET.ElementTree):
    """
    Read from XML and load memory object, for list of objects
    """
    root = branch
    ret = []
    for child in root:
        if (child.tag == 'IQVForm'):
            try:
                ret.append(_readFromXmlToIQVForm(child))
            except Exception as e:
                # log
                logger.info('Failed to import field ' + child.tag)
    return ret


def _readFromXmlToIQVDocumentPage(branch):
    """
    Read from XML and load memory object
    """

    # get root element
    root = branch

    # initialize IQVDocumentPage
    ret = IQVDocumentPage()

    ret.bIsScannedPage = _extract_attribute(root, 'bIsScannedPage', _str2bool, ret.bIsScannedPage)

    ret.bNeedsToBeBinarized = _extract_attribute(root, 'bNeedsToBeBinarized', _str2bool, ret.bNeedsToBeBinarized)

    ret.Boxes = _extract_attribute_list(root, 'Boxes', _readFromXmlToIQVPageROIList, ret.Boxes)

    ret.FooterText = _extract_attribute(root, 'FooterText', str, ret.FooterText)

    ret.HeaderText = _extract_attribute(root, 'HeaderText', str, ret.HeaderText)

    ret.Hyperlinks = _extract_attribute_list(root, 'Hyperlinks', _readFromXmlToStringList, ret.Hyperlinks)

    ret.id = _extract_attribute(root, 'id', str, ret.id)

    ret.ImageLocationsOnPage = _extract_attribute_list(root, 'ImageLocationsOnPage', _readFromXmlToRectangleDList,
                                                       ret.ImageLocationsOnPage)

    ret.ImageNames = _extract_attribute_list(root, 'ImageNames', _readFromXmlToStringList, ret.ImageNames)

    ret.ImageQCError = _extract_attribute(root, 'ImageQCError', float, ret.ImageQCError)

    ret.ImageQCGT = _extract_attribute(root, 'ImageQCGT', int, ret.ImageQCGT)

    ret.ImageQCScore = _extract_attribute(root, 'ImageQCScore', int, ret.ImageQCScore)

    ret.ImageQCScore_Blank = _extract_attribute(root, 'ImageQCScore_Blank', int, ret.ImageQCScore_Blank)

    ret.ImageQCScore_Greyscale = _extract_attribute(root, 'ImageQCScore_Greyscale', int, ret.ImageQCScore_Greyscale)

    ret.ImageQCScore_Legibility = _extract_attribute(root, 'ImageQCScore_Legibility', int, ret.ImageQCScore_Legibility)

    ret.ImageQCScore_Orientation = _extract_attribute(root, 'ImageQCScore_Orientation', int,
                                                      ret.ImageQCScore_Orientation)

    ret.ImageQCScore_Pages = _extract_attribute(root, 'ImageQCScore_Pages', int, ret.ImageQCScore_Pages)

    ret.in_image_filename = _extract_attribute(root, 'in_image_filename', str, ret.in_image_filename)

    ret.in_raw_filename = _extract_attribute(root, 'in_raw_filename', str, ret.in_raw_filename)

    ret.MeanOffsetAngleInRadians = _extract_attribute(root, 'MeanOffsetAngleInRadians', float,
                                                      ret.MeanOffsetAngleInRadians)

    ret.OffsetXInches = _extract_attribute(root, 'OffsetXInches', float, ret.OffsetXInches)

    ret.OffsetYInches = _extract_attribute(root, 'OffsetYInches', float, ret.OffsetYInches)

    ret.OrientationIsPortrait = _extract_attribute(root, 'OrientationIsPortrait', _str2bool, ret.OrientationIsPortrait)

    ret.out_filename = _extract_attribute(root, 'out_filename', str, ret.out_filename)

    ret.PageSequenceIndex = _extract_attribute(root, 'PageSequenceIndex', int, ret.PageSequenceIndex)

    fieldName = 'PageSizeRectangle'
    try:
        item = root.find(fieldName)
        if item is not None:
            subbranch = item
            ret.PageSizeRectangle = _readFromXmlToRectangleD(subbranch)
        else:
            pass
    except Exception as e:
        logger.info('Failed to import field ' + fieldName)

    fieldName = 'PageSizeWithRotationRectangle'
    try:
        item = root.find(fieldName)
        if item is not None:
            subbranch = item
            ret.PageSizeWithRotationRectangle = _readFromXmlToRectangleD(subbranch)
        else:
            pass
    except Exception as e:
        logger.info('Failed to import field ' + fieldName)

    ret.PDFDocumentPageText = _extract_attribute(root, 'PDFDocumentPageText', str, ret.PDFDocumentPageText)

    ret.PDFDocumentPageTextNumChars = _extract_attribute(root, 'PDFDocumentPageTextNumChars', int,
                                                         ret.PDFDocumentPageTextNumChars)

    ret.PDFDocumentPageTextNumWords = _extract_attribute(root, 'PDFDocumentPageTextNumWords', int,
                                                         ret.PDFDocumentPageTextNumWords)

    ret.ProcessFinishTime = _extract_attribute(root, 'ProcessFinishTime', str, ret.ProcessFinishTime)

    ret.ProcessStartTime = _extract_attribute(root, 'ProcessStartTime', str, ret.ProcessStartTime)

    ret.Rotation = _extract_attribute(root, 'Rotation', int, ret.Rotation)

    ret.Rotation_MajorAxis = _extract_attribute(root, 'Rotation_MajorAxis', int, ret.Rotation_MajorAxis)

    ret.ScannedImageID = _extract_attribute(root, 'ScannedImageID', str, ret.ScannedImageID)

    ret.textFromReader = _extract_attribute(root, 'textFromReader', str, ret.textFromReader)

    ret.TitleText = _extract_attribute(root, 'TitleText', str, ret.TitleText)
    return ret


def _readFromXmlToIQVDocumentPageList(branch: ET.ElementTree):
    """
    Read from XML and load memory object, for list of objects
    """
    root = branch
    ret = []
    for child in root:
        if (child.tag == 'IQVDocumentPage'):
            try:
                ret.append(_readFromXmlToIQVDocumentPage(child))
            except Exception as e:
                # log
                logger.info('Failed to import field ' + child.tag)
    return ret


def _readFromXmlToIQVAttribute(branch):
    """
    Read from XML and load memory object
    """

    # get root element
    root = branch

    # initialize IQVAttribute
    ret = IQVAttribute()

    ret.doc_id = _extract_attribute(root, 'doc_id', str, ret.doc_id)

    ret.group_type = _extract_attribute(root, 'group_type', str, ret.group_type)

    ret.hierarchy = _extract_attribute(root, 'hierarchy', str, ret.hierarchy)

    ret.id = _extract_attribute(root, 'id', str, ret.id)

    ret.iqv_standard_term = _extract_attribute(root, 'iqv_standard_term', str, ret.iqv_standard_term)

    ret.link_id = _extract_attribute(root, 'link_id', str, ret.link_id)

    ret.link_id_level2 = _extract_attribute(root, 'link_id_level2', str, ret.link_id_level2)

    ret.link_id_level3 = _extract_attribute(root, 'link_id_level3', str, ret.link_id_level3)

    ret.link_id_level4 = _extract_attribute(root, 'link_id_level4', str, ret.link_id_level4)

    ret.link_id_level5 = _extract_attribute(root, 'link_id_level5', str, ret.link_id_level5)

    ret.link_id_level6 = _extract_attribute(root, 'link_id_level6', str, ret.link_id_level6)

    ret.link_id_subsection1 = _extract_attribute(root, 'link_id_subsection1', str, ret.link_id_subsection1)

    ret.link_id_subsection2 = _extract_attribute(root, 'link_id_subsection2', str, ret.link_id_subsection2)

    ret.link_id_subsection3 = _extract_attribute(root, 'link_id_subsection3', str, ret.link_id_subsection3)

    ret.LocalName = _extract_attribute(root, 'LocalName', str, ret.LocalName)

    ret.Name = _extract_attribute(root, 'Name', str, ret.Name)

    ret.parent_id = _extract_attribute(root, 'parent_id', str, ret.parent_id)

    ret.Value = _extract_attribute(root, 'Value', str, ret.Value)
    return ret


def _readFromXmlToIQVAttributeList(branch: ET.ElementTree):
    """
    Read from XML and load memory object, for list of objects
    """
    root = branch
    ret = []
    for child in root:
        if (child.tag == 'IQVAttribute'):
            try:
                ret.append(_readFromXmlToIQVAttribute(child))
            except Exception as e:
                # log
                logger.info('Failed to import field ' + child.tag)
    return ret


def _readFromXmlToRotationCheck(branch):
    """
    Read from XML and load memory object
    """

    # get root element
    root = branch

    # initialize RotationCheck
    ret = RotationCheck()

    ret.degree = _extract_attribute(root, 'degree', float, ret.degree)

    ret.filenameVar = _extract_attribute(root, 'filenameVar', str, ret.filenameVar)

    ret.maxVariance = _extract_attribute(root, 'maxVariance', float, ret.maxVariance)
    return ret


def _readFromXmlToRotationCheckList(branch: ET.ElementTree):
    """
    Read from XML and load memory object, for list of objects
    """
    root = branch
    ret = []
    for child in root:
        if (child.tag == 'RotationCheck'):
            try:
                ret.append(_readFromXmlToRotationCheck(child))
            except Exception as e:
                # log
                logger.info('Failed to import field ' + child.tag)
    return ret


def _readFromXmlToValueI(branch):
    """
    Read from XML and load memory object
    """

    # get root element
    root = branch

    # initialize ValueI
    ret = ValueI()

    ret.key = _extract_attribute(root, 'key', str, ret.key)

    ret.value = _extract_attribute(root, 'value', int, ret.value)
    return ret


def _readFromXmlToValueIList(branch: ET.ElementTree):
    """
    Read from XML and load memory object, for list of objects
    """
    root = branch
    ret = []
    for child in root:
        if (child.tag == 'ValueI'):
            try:
                ret.append(_readFromXmlToValueI(child))
            except Exception as e:
                # log
                logger.info('Failed to import field ' + child.tag)
    return ret


def _readFromXmlToLineBoundaries(branch):
    """
    Read from XML and load memory object
    """

    # get root element
    root = branch

    # initialize LineBoundaries
    ret = LineBoundaries()

    ret.bIsVertical = _extract_attribute(root, 'bIsVertical', _str2bool, ret.bIsVertical)

    ret.Lines = _extract_attribute_list(root, 'Lines', _readFromXmlToIQVLineList, ret.Lines)

    ret.RecursiveLevel = _extract_attribute(root, 'RecursiveLevel', int, ret.RecursiveLevel)
    return ret


def _readFromXmlToLineBoundariesList(branch: ET.ElementTree):
    """
    Read from XML and load memory object, for list of objects
    """
    root = branch
    ret = []
    for child in root:
        if (child.tag == 'LineBoundaries'):
            try:
                ret.append(_readFromXmlToLineBoundaries(child))
            except Exception as e:
                # log
                logger.info('Failed to import field ' + child.tag)
    return ret


def _readFromXmlToTextMatch(branch):
    """
    Read from XML and load memory object
    """

    # get root element
    root = branch

    # initialize TextMatch
    ret = TextMatch()

    ret.index = _extract_attribute(root, 'index', int, ret.index)

    ret.Score = _extract_attribute(root, 'Score', float, ret.Score)

    ret.text = _extract_attribute(root, 'text', str, ret.text)
    return ret


def _readFromXmlToTextMatchList(branch: ET.ElementTree):
    """
    Read from XML and load memory object, for list of objects
    """
    root = branch
    ret = []
    for child in root:
        if (child.tag == 'TextMatch'):
            try:
                ret.append(_readFromXmlToTextMatch(child))
            except Exception as e:
                # log
                logger.info('Failed to import field ' + child.tag)
    return ret


def _readFromXmlToIQVDocumentFeedbackItem(branch):
    """
    Read from XML and load memory object
    """

    # get root element
    root = branch

    # initialize IQVDocumentFeedbackItem
    ret = IQVDocumentFeedbackItem()

    ret.CheckboxValue = _extract_attribute(root, 'CheckboxValue', int, ret.CheckboxValue)

    ret.date_time_stamp = _extract_attribute(root, 'date_time_stamp', str, ret.date_time_stamp)

    ret.document_composite_confidence = _extract_attribute(root, 'document_composite_confidence', float,
                                                           ret.document_composite_confidence)

    ret.document_date = _extract_attribute(root, 'document_date', str, ret.document_date)

    ret.environment = _extract_attribute(root, 'environment', str, ret.environment)

    ret.feedback_source = _extract_attribute(root, 'feedback_source', str, ret.feedback_source)

    ret.feedback_source_version = _extract_attribute(root, 'feedback_source_version', str, ret.feedback_source_version)

    ret.id = _extract_attribute(root, 'id', str, ret.id)

    ret.Properties = _extract_attribute_list(root, 'Properties', _readFromXmlToIQVKeyValueSetList, ret.Properties)

    ret.source_system = _extract_attribute(root, 'source_system', str, ret.source_system)

    ret.user_id = _extract_attribute(root, 'user_id', str, ret.user_id)
    return ret


def _readFromXmlToIQVDocumentFeedbackItemList(branch: ET.ElementTree):
    """
    Read from XML and load memory object, for list of objects
    """
    root = branch
    ret = []
    for child in root:
        if (child.tag == 'IQVDocumentFeedbackItem'):
            try:
                ret.append(_readFromXmlToIQVDocumentFeedbackItem(child))
            except Exception as e:
                # log
                logger.info('Failed to import field ' + child.tag)
    return ret


def _readFromXmlToIQVDocumentFeedbackResults(branch):
    """
    Read from XML and load memory object
    """

    # get root element
    root = branch

    # initialize IQVDocumentFeedbackResults
    ret = IQVDocumentFeedbackResults()

    ret.alcoac_check_composite_score = _extract_attribute(root, 'alcoac_check_composite_score', float,
                                                          ret.alcoac_check_composite_score)

    ret.alcoac_check_composite_score_confidence = _extract_attribute(root, 'alcoac_check_composite_score_confidence',
                                                                     float, ret.alcoac_check_composite_score_confidence)

    ret.alcoac_check_error = _extract_attribute_list(root, 'alcoac_check_error',
                                                     _readFromXmlToIQVAttributeCandidateList, ret.alcoac_check_error)

    ret.amendment_number = _extract_attribute(root, 'amendment_number', str, ret.amendment_number)

    ret.attribute_auxiliary_list = _extract_attribute_list(root, 'attribute_auxiliary_list',
                                                           _readFromXmlToIQVKeyValueSetList, ret.attribute_auxiliary_list)

    ret.blinded = _extract_attribute(root, 'blinded', _str2bool, ret.blinded)

    ret.country = _extract_attribute(root, 'country', str, ret.country)

    ret.customer = _extract_attribute(root, 'customer', str, ret.customer)

    ret.date_time_stamp = _extract_attribute(root, 'date_time_stamp', str, ret.date_time_stamp)

    ret.DateTimeCreated = _extract_attribute(root, 'DateTimeCreated', str, ret.DateTimeCreated)

    ret.doc_id = _extract_attribute(root, 'doc_id', str, ret.doc_id)

    ret.document_class = _extract_attribute(root, 'document_class', str, ret.document_class)

    ret.document_classification = _extract_attribute_list(root, 'document_classification', _readFromXmlToStringList,
                                                          ret.document_classification)

    ret.document_classification_confidence = _extract_attribute_list(root, 'document_classification_confidence',
                                                                     _readFromXmlToDoubleList,
                                                                     ret.document_classification_confidence)

    ret.document_composite_confidence = _extract_attribute(root, 'document_composite_confidence', float,
                                                           ret.document_composite_confidence)

    ret.document_date = _extract_attribute(root, 'document_date', str, ret.document_date)

    ret.document_date_confidence = _extract_attribute(root, 'document_date_confidence', float,
                                                      ret.document_date_confidence)

    ret.document_date_list = _extract_attribute_list(root, 'document_date_list', _readFromXmlToIQVKeyValueSetList,
                                                     ret.document_date_list)

    ret.document_date_type = _extract_attribute(root, 'document_date_type', str, ret.document_date_type)

    ret.document_id = _extract_attribute(root, 'document_id', str, ret.document_id)

    ret.document_native_classification = _extract_attribute_list(root, 'document_native_classification',
                                                                 _readFromXmlToStringList,
                                                                 ret.document_native_classification)

    ret.document_native_classification_confidence = _extract_attribute_list(root,
                                                                            'document_native_classification_confidence',
                                                                            _readFromXmlToDoubleList,
                                                                            ret.document_native_classification_confidence)

    ret.document_rejected = _extract_attribute(root, 'document_rejected', str, ret.document_rejected)

    ret.document_status = _extract_attribute(root, 'document_status', str, ret.document_status)

    ret.document_subclassification = _extract_attribute_list(root, 'document_subclassification',
                                                             _readFromXmlToStringList, ret.document_subclassification)

    ret.document_subclassification_confidence = _extract_attribute_list(root,
                                                                        'document_subclassification_confidence',
                                                                        _readFromXmlToDoubleList,
                                                                        ret.document_subclassification_confidence)

    ret.draft_number = _extract_attribute(root, 'draft_number', str, ret.draft_number)

    ret.environment = _extract_attribute(root, 'environment', str, ret.environment)

    ret.expiry_date = _extract_attribute(root, 'expiry_date', str, ret.expiry_date)

    ret.expiry_date_confidence = _extract_attribute(root, 'expiry_date_confidence', float, ret.expiry_date_confidence)

    ret.feedback_source = _extract_attribute(root, 'feedback_source', str, ret.feedback_source)

    ret.feedback_source_version = _extract_attribute(root, 'feedback_source_version', str, ret.feedback_source_version)

    ret.group_type = _extract_attribute(root, 'group_type', str, ret.group_type)

    ret.hierarchy = _extract_attribute(root, 'hierarchy', str, ret.hierarchy)

    ret.id = _extract_attribute(root, 'id', str, ret.id)

    ret.indication = _extract_attribute(root, 'indication', str, ret.indication)

    ret.iqv_standard_term = _extract_attribute(root, 'iqv_standard_term', str, ret.iqv_standard_term)

    ret.iqvdata = _extract_attribute(root, 'iqvdata', str, ret.iqvdata)

    ret.language = _extract_attribute(root, 'language', str, ret.language)

    ret.language_confidence = _extract_attribute(root, 'language_confidence', float, ret.language_confidence)

    ret.link_id = _extract_attribute(root, 'link_id', str, ret.link_id)

    ret.link_id_level2 = _extract_attribute(root, 'link_id_level2', str, ret.link_id_level2)

    ret.link_id_level3 = _extract_attribute(root, 'link_id_level3', str, ret.link_id_level3)

    ret.link_id_level4 = _extract_attribute(root, 'link_id_level4', str, ret.link_id_level4)

    ret.link_id_level5 = _extract_attribute(root, 'link_id_level5', str, ret.link_id_level5)

    ret.link_id_level6 = _extract_attribute(root, 'link_id_level6', str, ret.link_id_level6)

    ret.link_id_subsection1 = _extract_attribute(root, 'link_id_subsection1', str, ret.link_id_subsection1)

    ret.link_id_subsection2 = _extract_attribute(root, 'link_id_subsection2', str, ret.link_id_subsection2)

    ret.link_id_subsection3 = _extract_attribute(root, 'link_id_subsection3', str, ret.link_id_subsection3)

    ret.molecule_device = _extract_attribute(root, 'molecule_device', str, ret.molecule_device)

    ret.name = _extract_attribute(root, 'name', str, ret.name)

    ret.name_confidence = _extract_attribute(root, 'name_confidence', float, ret.name_confidence)

    ret.parent_id = _extract_attribute(root, 'parent_id', str, ret.parent_id)

    ret.post_data = _extract_attribute(root, 'post_data', str, ret.post_data)

    ret.priority = _extract_attribute(root, 'priority', str, ret.priority)

    ret.project_id = _extract_attribute(root, 'project_id', str, ret.project_id)

    ret.protocol = _extract_attribute(root, 'protocol', str, ret.protocol)

    ret.received_date = _extract_attribute(root, 'received_date', str, ret.received_date)

    ret.ref_id = _extract_attribute(root, 'ref_id', str, ret.ref_id)

    ret.ref_id_type = _extract_attribute(root, 'ref_id_type', str, ret.ref_id_type)

    ret.site = _extract_attribute(root, 'site', str, ret.site)

    ret.site_personnel_list = _extract_attribute_list(root, 'site_personnel_list', _readFromXmlToIQVAttributeList,
                                                      ret.site_personnel_list)

    ret.source_filename = _extract_attribute(root, 'source_filename', str, ret.source_filename)

    ret.source_system = _extract_attribute(root, 'source_system', str, ret.source_system)

    ret.sponsor = _extract_attribute(root, 'sponsor', str, ret.sponsor)

    ret.study_status = _extract_attribute(root, 'study_status', str, ret.study_status)

    ret.subject = _extract_attribute(root, 'subject', str, ret.subject)

    ret.subject_confidence = _extract_attribute(root, 'subject_confidence', float, ret.subject_confidence)

    ret.tmf_environment = _extract_attribute(root, 'tmf_environment', str, ret.tmf_environment)

    ret.tmf_ibr = _extract_attribute(root, 'tmf_ibr', str, ret.tmf_ibr)

    ret.user_id = _extract_attribute(root, 'user_id', str, ret.user_id)

    ret.version_number = _extract_attribute(root, 'version_number', str, ret.version_number)
    return ret


def _readFromXmlToIQVDocumentFeedbackResultsList(branch: ET.ElementTree):
    """
    Read from XML and load memory object, for list of objects
    """
    root = branch
    ret = []
    for child in root:
        if (child.tag == 'IQVDocumentFeedbackResults'):
            try:
                ret.append(_readFromXmlToIQVDocumentFeedbackResults(child))
            except Exception as e:
                # log
                logger.info('Failed to import field ' + child.tag)
    return ret


def _readFromXmlToIQVDocumentGroundTruth(branch):
    """
    Read from XML and load memory object
    """

    # get root element
    root = branch

    # initialize IQVDocumentGroundTruth
    ret = IQVDocumentGroundTruth()

    ret.AdditionalInstructionsList = _extract_attribute_list(root, 'AdditionalInstructionsList',
                                                             _readFromXmlToIQVKeyValueSetList,
                                                             ret.AdditionalInstructionsList)

    ret.AIDocLocation = _extract_attribute(root, 'AIDocLocation', str, ret.AIDocLocation)

    ret.AIDocLocationOriginal = _extract_attribute(root, 'AIDocLocationOriginal', str, ret.AIDocLocationOriginal)

    ret.Artifact = _extract_attribute(root, 'Artifact', str, ret.Artifact)

    ret.Batch_Home_Location = _extract_attribute(root, 'Batch_Home_Location', str, ret.Batch_Home_Location)

    ret.bReservedForSVT = _extract_attribute(root, 'bReservedForSVT', int, ret.bReservedForSVT)

    ret.Certification_Date = _extract_attribute(root, 'Certification_Date', str, ret.Certification_Date)

    ret.Certification_Meaning = _extract_attribute(root, 'Certification_Meaning', str, ret.Certification_Meaning)

    ret.Certification_User = _extract_attribute(root, 'Certification_User', str, ret.Certification_User)

    ret.Country = _extract_attribute(root, 'Country', str, ret.Country)

    ret.Country_Code = _extract_attribute(root, 'Country_Code', str, ret.Country_Code)

    ret.dataset = _extract_attribute(root, 'dataset', str, ret.dataset)

    ret.dataset_source = _extract_attribute(root, 'dataset_source', str, ret.dataset_source)

    ret.Date_Created = _extract_attribute(root, 'Date_Created', str, ret.Date_Created)

    ret.Date_Created14 = _extract_attribute(root, 'Date_Created14', str, ret.Date_Created14)

    ret.Date_Identifier = _extract_attribute(root, 'Date_Identifier', str, ret.Date_Identifier)

    ret.DateID_Index = _extract_attribute(root, 'DateID_Index', int, ret.DateID_Index)

    ret.Description = _extract_attribute(root, 'Description', str, ret.Description)

    ret.DIA_Key = _extract_attribute(root, 'DIA_Key', str, ret.DIA_Key)

    ret.doc_id = _extract_attribute(root, 'doc_id', str, ret.doc_id)

    ret.doc_type_wingspan = _extract_attribute(root, 'doc_type_wingspan', str, ret.doc_type_wingspan)

    ret.Document_Abbreviation = _extract_attribute(root, 'Document_Abbreviation', str, ret.Document_Abbreviation)

    ret.Document_Abbreviation_Index = _extract_attribute(root, 'Document_Abbreviation_Index', int,
                                                         ret.Document_Abbreviation_Index)

    ret.Document_Class = _extract_attribute(root, 'Document_Class', str, ret.Document_Class)

    ret.Document_Date = _extract_attribute(root, 'Document_Date', str, ret.Document_Date)

    ret.Document_Date_FromNamingConvention = _extract_attribute(root, 'Document_Date_FromNamingConvention', str,
                                                                ret.Document_Date_FromNamingConvention)

    ret.Document_Date_Index = _extract_attribute(root, 'Document_Date_Index', int, ret.Document_Date_Index)

    ret.Document_Date14 = _extract_attribute(root, 'Document_Date14', str, ret.Document_Date14)

    ret.Document_Identifier = _extract_attribute(root, 'Document_Identifier', str, ret.Document_Identifier)

    ret.Document_Identifier_Index = _extract_attribute(root, 'Document_Identifier_Index', int,
                                                       ret.Document_Identifier_Index)

    ret.document_instructions = _extract_attribute(root, 'document_instructions', str, ret.document_instructions)

    ret.Document_Language = _extract_attribute(root, 'Document_Language', str, ret.Document_Language)

    ret.Document_Naming_Convention = _extract_attribute(root, 'Document_Naming_Convention', str,
                                                        ret.Document_Naming_Convention)

    ret.Document_Sequence_ID = _extract_attribute(root, 'Document_Sequence_ID', str, ret.Document_Sequence_ID)

    ret.Document_Status = _extract_attribute(root, 'Document_Status', str, ret.Document_Status)

    ret.Document_Type_Unique_Identifier = _extract_attribute(root, 'Document_Type_Unique_Identifier', str,
                                                             ret.Document_Type_Unique_Identifier)

    ret.DocumentImages = _extract_attribute_list(root, 'DocumentImages', _readFromXmlToIQVPageROIList,
                                                 ret.DocumentImages)

    ret.DocumentNumChars = _extract_attribute(root, 'DocumentNumChars', int, ret.DocumentNumChars)

    ret.DocumentNumImages = _extract_attribute(root, 'DocumentNumImages', int, ret.DocumentNumImages)

    ret.DocumentNumPages = _extract_attribute(root, 'DocumentNumPages', int, ret.DocumentNumPages)

    ret.DocumentNumWords = _extract_attribute(root, 'DocumentNumWords', int, ret.DocumentNumWords)

    ret.DocumentPageLevel = _extract_attribute(root, 'DocumentPageLevel', str, ret.DocumentPageLevel)

    ret.DocumentPathFilename = _extract_attribute(root, 'DocumentPathFilename', str, ret.DocumentPathFilename)

    ret.DocumentType = _extract_attribute(root, 'DocumentType', int, ret.DocumentType)

    ret.Drug_Type = _extract_attribute(root, 'Drug_Type', str, ret.Drug_Type)

    ret.Drug_Type_Index = _extract_attribute(root, 'Drug_Type_Index', int, ret.Drug_Type_Index)

    ret.EEL_Batch_ID = _extract_attribute(root, 'EEL_Batch_ID', str, ret.EEL_Batch_ID)

    ret.EEL_Batch_Type = _extract_attribute(root, 'EEL_Batch_Type', str, ret.EEL_Batch_Type)

    ret.Email_FROM = _extract_attribute(root, 'Email_FROM', str, ret.Email_FROM)

    ret.Email_Receive_Date = _extract_attribute(root, 'Email_Receive_Date', str, ret.Email_Receive_Date)

    ret.Email_Send_Date = _extract_attribute(root, 'Email_Send_Date', str, ret.Email_Send_Date)

    ret.Email_Subject = _extract_attribute(root, 'Email_Subject', str, ret.Email_Subject)

    ret.Email_TO = _extract_attribute(root, 'Email_TO', str, ret.Email_TO)

    ret.Event_Identifier = _extract_attribute(root, 'Event_Identifier', str, ret.Event_Identifier)

    ret.Export_File_Name = _extract_attribute(root, 'Export_File_Name', str, ret.Export_File_Name)

    ret.Export_Path = _extract_attribute(root, 'Export_Path', str, ret.Export_Path)

    ret.File_MimeType = _extract_attribute(root, 'File_MimeType', str, ret.File_MimeType)

    ret.File_Name_Modified = _extract_attribute(root, 'File_Name_Modified', str, ret.File_Name_Modified)

    ret.File_Plan_Category_Number = _extract_attribute(root, 'File_Plan_Category_Number', str,
                                                       ret.File_Plan_Category_Number)

    ret.First_Name = _extract_attribute(root, 'First_Name', str, ret.First_Name)

    ret.GTArtifact_Code = _extract_attribute(root, 'GTArtifact_Code', str, ret.GTArtifact_Code)

    ret.GTBatch = _extract_attribute(root, 'GTBatch', str, ret.GTBatch)

    ret.GTDuplicate = _extract_attribute(root, 'GTDuplicate', str, ret.GTDuplicate)

    ret.GTGreyscale = _extract_attribute(root, 'GTGreyscale', str, ret.GTGreyscale)

    ret.GTIndex = _extract_attribute(root, 'GTIndex', str, ret.GTIndex)

    ret.GTLegibility = _extract_attribute(root, 'GTLegibility', str, ret.GTLegibility)

    ret.GTPages = _extract_attribute(root, 'GTPages', str, ret.GTPages)

    ret.GTSection_Code = _extract_attribute(root, 'GTSection_Code', str, ret.GTSection_Code)

    ret.GTZone_Code = _extract_attribute(root, 'GTZone_Code', str, ret.GTZone_Code)

    ret.GTZone_Section_Artifact_Code = _extract_attribute(root, 'GTZone_Section_Artifact_Code', str,
                                                          ret.GTZone_Section_Artifact_Code)

    ret.GTZone_Section_Code = _extract_attribute(root, 'GTZone_Section_Code', str, ret.GTZone_Section_Code)

    ret.id = _extract_attribute(root, 'id', str, ret.id)

    ret.Inventory_Class = _extract_attribute(root, 'Inventory_Class', str, ret.Inventory_Class)

    ret.Inventory_CountryName = _extract_attribute(root, 'Inventory_CountryName', str, ret.Inventory_CountryName)

    ret.Investigator_Name = _extract_attribute(root, 'Investigator_Name', str, ret.Investigator_Name)

    ret.IQV_XML_Filename = _extract_attribute(root, 'IQV_XML_Filename', str, ret.IQV_XML_Filename)

    ret.Issue = _extract_attribute(root, 'Issue', str, ret.Issue)

    ret.IssueDescription = _extract_attribute(root, 'IssueDescription', str, ret.IssueDescription)

    ret.Language_Abbreviation = _extract_attribute(root, 'Language_Abbreviation', str, ret.Language_Abbreviation)

    ret.Language_Abbreviation_Index = _extract_attribute(root, 'Language_Abbreviation_Index', int,
                                                         ret.Language_Abbreviation_Index)

    ret.Language_ID_Index = _extract_attribute(root, 'Language_ID_Index', int, ret.Language_ID_Index)

    ret.Language_Identifier = _extract_attribute(root, 'Language_Identifier', str, ret.Language_Identifier)

    ret.Last_Name = _extract_attribute(root, 'Last_Name', str, ret.Last_Name)

    ret.LastNameFirstName_FromNamingConvention = _extract_attribute(root, 'LastNameFirstName_FromNamingConvention',
                                                                    str, ret.LastNameFirstName_FromNamingConvention)

    ret.LastNameFirstName_Index = _extract_attribute(root, 'LastNameFirstName_Index', int, ret.LastNameFirstName_Index)

    ret.LocalSubdirectory = _extract_attribute(root, 'LocalSubdirectory', str, ret.LocalSubdirectory)

    ret.Mandatory_Retention = _extract_attribute(root, 'Mandatory_Retention', str, ret.Mandatory_Retention)

    ret.Modify_Date = _extract_attribute(root, 'Modify_Date', str, ret.Modify_Date)

    ret.Name = _extract_attribute(root, 'Name', str, ret.Name)

    ret.NoisyPageIndex = _extract_attribute(root, 'NoisyPageIndex', str, ret.NoisyPageIndex)

    ret.Object_ID = _extract_attribute(root, 'Object_ID', str, ret.Object_ID)

    ret.Organization_ID = _extract_attribute(root, 'Organization_ID', str, ret.Organization_ID)

    ret.OrganizationID_Index = _extract_attribute(root, 'OrganizationID_Index', int, ret.OrganizationID_Index)

    ret.Original_Inventory_Filename = _extract_attribute(root, 'Original_Inventory_Filename', str,
                                                         ret.Original_Inventory_Filename)

    ret.Original_Path = _extract_attribute(root, 'Original_Path', str, ret.Original_Path)

    ret.OriginalSourceDataDirectory = _extract_attribute(root, 'OriginalSourceDataDirectory', str,
                                                         ret.OriginalSourceDataDirectory)

    ret.OriginalSourceDataZipFilename = _extract_attribute(root, 'OriginalSourceDataZipFilename', str,
                                                           ret.OriginalSourceDataZipFilename)

    ret.PagePathFilenamePDF = _extract_attribute(root, 'PagePathFilenamePDF', str, ret.PagePathFilenamePDF)

    ret.PageSequenceNumber = _extract_attribute(root, 'PageSequenceNumber', str, ret.PageSequenceNumber)

    ret.Paper_Received_Date = _extract_attribute(root, 'Paper_Received_Date', str, ret.Paper_Received_Date)

    ret.Phase = _extract_attribute(root, 'Phase', str, ret.Phase)

    ret.Project_Code = _extract_attribute(root, 'Project_Code', str, ret.Project_Code)

    ret.Protocol_Number = _extract_attribute(root, 'Protocol_Number', str, ret.Protocol_Number)

    ret.ref_model_subtype_code = _extract_attribute(root, 'ref_model_subtype_code', str, ret.ref_model_subtype_code)

    ret.Report_Type = _extract_attribute(root, 'Report_Type', str, ret.Report_Type)

    ret.Report_Version = _extract_attribute(root, 'Report_Version', str, ret.Report_Version)

    ret.Section = _extract_attribute(root, 'Section', str, ret.Section)

    ret.Sequence_Number = _extract_attribute(root, 'Sequence_Number', str, ret.Sequence_Number)

    ret.Sequence_Number_Index = _extract_attribute(root, 'Sequence_Number_Index', int, ret.Sequence_Number_Index)

    ret.Site_Name = _extract_attribute(root, 'Site_Name', str, ret.Site_Name)

    ret.Source_System = _extract_attribute(root, 'Source_System', str, ret.Source_System)

    ret.Source_System_Version = _extract_attribute(root, 'Source_System_Version', str, ret.Source_System_Version)

    ret.Study_Site_ID = _extract_attribute(root, 'Study_Site_ID', str, ret.Study_Site_ID)

    ret.Therapeutic_Area = _extract_attribute(root, 'Therapeutic_Area', str, ret.Therapeutic_Area)

    ret.TMF = _extract_attribute(root, 'TMF', str, ret.TMF)

    ret.Type = _extract_attribute(root, 'Type', str, ret.Type)

    ret.Type_Value = _extract_attribute(root, 'Type_Value', str, ret.Type_Value)

    ret.Visit_Document_ID = _extract_attribute(root, 'Visit_Document_ID', str, ret.Visit_Document_ID)

    ret.Visit_Type = _extract_attribute(root, 'Visit_Type', str, ret.Visit_Type)

    ret.VisitDocID_Index = _extract_attribute(root, 'VisitDocID_Index', int, ret.VisitDocID_Index)

    ret.VisitType_Index = _extract_attribute(root, 'VisitType_Index', int, ret.VisitType_Index)

    ret.XProperties = _extract_attribute_list(root, 'XProperties', _readFromXmlToIQVKeyValueSetList, ret.XProperties)

    ret.Zone = _extract_attribute(root, 'Zone', str, ret.Zone)
    return ret


def _readFromXmlToIQVDocumentGroundTruthList(branch: ET.ElementTree):
    """
    Read from XML and load memory object, for list of objects
    """
    root = branch
    ret = []
    for child in root:
        if (child.tag == 'IQVDocumentGroundTruth'):
            try:
                ret.append(_readFromXmlToIQVDocumentGroundTruth(child))
            except Exception as e:
                # log
                logger.info('Failed to import field ' + child.tag)
    return ret


def _readFromXmlToIQVPageROI(branch):
    """
    Read from XML and load memory object
    """

    # get root element
    root = branch

    # initialize IQVPageROI
    ret = IQVPageROI()

    ret.Attachments = _extract_attribute_list(root, 'Attachments', _readFromXmlToIQVPageROIList, ret.Attachments)

    ret.bIsCheckbox = _extract_attribute(root, 'bIsCheckbox', _str2bool, ret.bIsCheckbox)

    ret.bIsChecked = _extract_attribute(root, 'bIsChecked', _str2bool, ret.bIsChecked)

    ret.bIsImage = _extract_attribute(root, 'bIsImage', _str2bool, ret.bIsImage)

    ret.bIsSharedString = _extract_attribute(root, 'bIsSharedString', _str2bool, ret.bIsSharedString)

    ret.bNoTranslate = _extract_attribute(root, 'bNoTranslate', _str2bool, ret.bNoTranslate)

    ret.bOutputImageCreated = _extract_attribute(root, 'bOutputImageCreated', _str2bool, ret.bOutputImageCreated)

    ret.bScannedOCR = _extract_attribute(root, 'bScannedOCR', _str2bool, ret.bScannedOCR)

    ret.BulletIndentationLevel = _extract_attribute(root, 'BulletIndentationLevel', int, ret.BulletIndentationLevel)

    ret.BulletTypeVal = _extract_attribute(root, 'BulletTypeVal', int, ret.BulletTypeVal)

    ret.CheckboxFill = _extract_attribute(root, 'CheckboxFill', float, ret.CheckboxFill)

    ret.ChildBoxes = _extract_attribute_list(root, 'ChildBoxes', _readFromXmlToIQVPageROIList, ret.ChildBoxes)

    ret.ChildBoxesDeconstructedOCR = _extract_attribute_list(root, 'ChildBoxesDeconstructedOCR',
                                                             _readFromXmlToIQVPageROIList, ret.ChildBoxesDeconstructedOCR)

    ret.childListIndexes = _extract_attribute_list(root, 'childListIndexes', _readFromXmlToIntList,
                                                   ret.childListIndexes)

    ret.contentTypeVal = _extract_attribute(root, 'contentTypeVal', int, ret.contentTypeVal)

    ret.copyListIndexes = _extract_attribute_list(root, 'copyListIndexes', _readFromXmlToIntList, ret.copyListIndexes)

    ret.doc_id = _extract_attribute(root, 'doc_id', str, ret.doc_id)

    ret.DocumentRelId = _extract_attribute(root, 'DocumentRelId', str, ret.DocumentRelId)

    ret.DocumentSequenceIndex = _extract_attribute(root, 'DocumentSequenceIndex', int, ret.DocumentSequenceIndex)

    ret.ExternalLinks = _extract_attribute_list(root, 'ExternalLinks', _readFromXmlToIQVExternalLinkList,
                                                ret.ExternalLinks)

    ret.FeedbackItems = _extract_attribute_list(root, 'FeedbackItems', _readFromXmlToIQVKeyValueSetList,
                                                ret.FeedbackItems)

    fieldName = 'fontInfo'
    try:
        item = root.find(fieldName)
        if item is not None:
            subbranch = item
            ret.fontInfo = _readFromXmlToFontInfo(subbranch)
        else:
            pass
    except Exception as e:
        logger.info('Failed to import field ' + fieldName)

    ret.FooterSequence = _extract_attribute(root, 'FooterSequence', int, ret.FooterSequence)

    ret.group_type = _extract_attribute(root, 'group_type', str, ret.group_type)

    ret.GT_ImageFilename = _extract_attribute(root, 'GT_ImageFilename', str, ret.GT_ImageFilename)

    ret.GT_ScoreMatch = _extract_attribute(root, 'GT_ScoreMatch', float, ret.GT_ScoreMatch)

    ret.GT_TextMatch = _extract_attribute(root, 'GT_TextMatch', str, ret.GT_TextMatch)

    ret.hAlignmentVal = _extract_attribute(root, 'hAlignmentVal', int, ret.hAlignmentVal)

    ret.HeaderSequence = _extract_attribute(root, 'HeaderSequence', int, ret.HeaderSequence)

    ret.hierarchy = _extract_attribute(root, 'hierarchy', str, ret.hierarchy)

    ret.HorizontalResolution = _extract_attribute(root, 'HorizontalResolution', float, ret.HorizontalResolution)

    ret.htmlTagType = _extract_attribute(root, 'htmlTagType', str, ret.htmlTagType)

    ret.Hue = _extract_attribute(root, 'Hue', int, ret.Hue)

    ret.id = _extract_attribute(root, 'id', str, ret.id)

    ret.ImageFormatVal = _extract_attribute(root, 'ImageFormatVal', str, ret.ImageFormatVal)

    ret.ImageIndex = _extract_attribute(root, 'ImageIndex', int, ret.ImageIndex)

    ret.imagePaddingPixels = _extract_attribute(root, 'imagePaddingPixels', float, ret.imagePaddingPixels)

    ret.imageScaling = _extract_attribute(root, 'imageScaling', float, ret.imageScaling)

    ret.iqv_standard_term = _extract_attribute(root, 'iqv_standard_term', str, ret.iqv_standard_term)

    ret.IQVAttributeCandidates = _extract_attribute_list(root, 'IQVAttributeCandidates',
                                                         _readFromXmlToIQVAttributeCandidateList,
                                                         ret.IQVAttributeCandidates)

    ret.IQVSubTextList = _extract_attribute_list(root, 'IQVSubTextList', _readFromXmlToIQVSubTextList,
                                                 ret.IQVSubTextList)

    ret.IQVSubTextListTranslated = _extract_attribute_list(root, 'IQVSubTextListTranslated',
                                                           _readFromXmlToIQVSubTextList, ret.IQVSubTextListTranslated)

    ret.IsCopyOfRoiId = _extract_attribute(root, 'IsCopyOfRoiId', str, ret.IsCopyOfRoiId)

    ret.IsTableCell = _extract_attribute(root, 'IsTableCell', _str2bool, ret.IsTableCell)

    fieldName = 'lineBoundaries'
    try:
        item = root.find(fieldName)
        if item is not None:
            subbranch = item
            ret.lineBoundaries = _readFromXmlToLineBoundaries(subbranch)
        else:
            pass
    except Exception as e:
        logger.info('Failed to import field ' + fieldName)

    ret.lineBoundariesParent = _extract_attribute_list(root, 'lineBoundariesParent', _readFromXmlToLineBoundariesList,
                                                       ret.lineBoundariesParent)

    ret.link_id = _extract_attribute(root, 'link_id', str, ret.link_id)

    ret.link_id_level2 = _extract_attribute(root, 'link_id_level2', str, ret.link_id_level2)

    ret.link_id_level3 = _extract_attribute(root, 'link_id_level3', str, ret.link_id_level3)

    ret.link_id_level4 = _extract_attribute(root, 'link_id_level4', str, ret.link_id_level4)

    ret.link_id_level5 = _extract_attribute(root, 'link_id_level5', str, ret.link_id_level5)

    ret.link_id_level6 = _extract_attribute(root, 'link_id_level6', str, ret.link_id_level6)

    ret.link_id_subsection1 = _extract_attribute(root, 'link_id_subsection1', str, ret.link_id_subsection1)

    ret.link_id_subsection2 = _extract_attribute(root, 'link_id_subsection2', str, ret.link_id_subsection2)

    ret.link_id_subsection3 = _extract_attribute(root, 'link_id_subsection3', str, ret.link_id_subsection3)

    ret.m_PARENT_ROI_TYPEVal = _extract_attribute(root, 'm_PARENT_ROI_TYPEVal', int, ret.m_PARENT_ROI_TYPEVal)

    ret.m_ROI_TYPEVal = _extract_attribute(root, 'm_ROI_TYPEVal', int, ret.m_ROI_TYPEVal)

    ret.m_WORD_LAYOUTVal = _extract_attribute(root, 'm_WORD_LAYOUTVal', int, ret.m_WORD_LAYOUTVal)

    ret.NLP_Attributes = _extract_attribute_list(root, 'NLP_Attributes', _readFromXmlToNLP_AttributeList,
                                                 ret.NLP_Attributes)

    ret.NLP_Entities = _extract_attribute_list(root, 'NLP_Entities', _readFromXmlToNLP_EntityList, ret.NLP_Entities)

    ret.OriginalROIHeightInches = _extract_attribute(root, 'OriginalROIHeightInches', float,
                                                     ret.OriginalROIHeightInches)

    ret.OriginalROIWidthInches = _extract_attribute(root, 'OriginalROIWidthInches', float, ret.OriginalROIWidthInches)

    ret.OriginalSubTexts = _extract_attribute_list(root, 'OriginalSubTexts', _readFromXmlToIQVSubTextList,
                                                   ret.OriginalSubTexts)

    ret.OutputImageFilename = _extract_attribute(root, 'OutputImageFilename', str, ret.OutputImageFilename)

    ret.OutputImageFilename_Cleaned = _extract_attribute(root, 'OutputImageFilename_Cleaned', str,
                                                         ret.OutputImageFilename_Cleaned)

    ret.OutputImageFilename_FinalImageProcessingOutput = _extract_attribute(root,
                                                                            'OutputImageFilename_FinalImageProcessingOutput',
                                                                            str,
                                                                            ret.OutputImageFilename_FinalImageProcessingOutput)

    ret.OutputImageFilename_FinalImageProcessingOutputToDropBox = _extract_attribute(root,
                                                                                     'OutputImageFilename_FinalImageProcessingOutputToDropBox',
                                                                                     str,
                                                                                     ret.OutputImageFilename_FinalImageProcessingOutputToDropBox)

    ret.OutputImageFilename_OriginalSegment = _extract_attribute(root, 'OutputImageFilename_OriginalSegment', str,
                                                                 ret.OutputImageFilename_OriginalSegment)

    ret.OutputImageFilename_RotationCorrection = _extract_attribute(root, 'OutputImageFilename_RotationCorrection',
                                                                    str, ret.OutputImageFilename_RotationCorrection)

    ret.OutputImageFilename_RotationCorrectionToDropBox = _extract_attribute(root,
                                                                             'OutputImageFilename_RotationCorrectionToDropBox',
                                                                             str,
                                                                             ret.OutputImageFilename_RotationCorrectionToDropBox)

    ret.OutputImageFilename_Segments = _extract_attribute(root, 'OutputImageFilename_Segments', str,
                                                          ret.OutputImageFilename_Segments)

    ret.OutputImageFilename_SegmentsToDropBox = _extract_attribute(root, 'OutputImageFilename_SegmentsToDropBox', str,
                                                                   ret.OutputImageFilename_SegmentsToDropBox)

    ret.OutputImageFilenameT = _extract_attribute(root, 'OutputImageFilenameT', str, ret.OutputImageFilenameT)

    ret.OutputImageFilenameTDropBox = _extract_attribute(root, 'OutputImageFilenameTDropBox', str,
                                                         ret.OutputImageFilenameTDropBox)

    ret.PageID = _extract_attribute(root, 'PageID', str, ret.PageID)

    ret.PageSequenceIndex = _extract_attribute(root, 'PageSequenceIndex', int, ret.PageSequenceIndex)

    ret.parent_id = _extract_attribute(root, 'parent_id', str, ret.parent_id)

    fieldName = 'parentRectangle'
    try:
        item = root.find(fieldName)
        if item is not None:
            subbranch = item
            ret.parentRectangle = _readFromXmlToRectangle(subbranch)
        else:
            pass
    except Exception as e:
        logger.info('Failed to import field ' + fieldName)

    ret.parentrectangle_height = _extract_attribute(root, 'parentrectangle_height', int, ret.parentrectangle_height)

    ret.parentrectangle_width = _extract_attribute(root, 'parentrectangle_width', int, ret.parentrectangle_width)

    ret.parentrectangle_x = _extract_attribute(root, 'parentrectangle_x', int, ret.parentrectangle_x)

    ret.parentrectangle_y = _extract_attribute(root, 'parentrectangle_y', int, ret.parentrectangle_y)

    ret.postSubTexts = _extract_attribute_list(root, 'postSubTexts', _readFromXmlToIQVSubTextList, ret.postSubTexts)

    ret.postTags = _extract_attribute_list(root, 'postTags', _readFromXmlToStringList, ret.postTags)

    ret.postTexts = _extract_attribute_list(root, 'postTexts', _readFromXmlToIntList, ret.postTexts)

    ret.preSubTexts = _extract_attribute_list(root, 'preSubTexts', _readFromXmlToIQVSubTextList, ret.preSubTexts)

    ret.preTags = _extract_attribute_list(root, 'preTags', _readFromXmlToStringList, ret.preTags)

    ret.preTexts = _extract_attribute_list(root, 'preTexts', _readFromXmlToIntList, ret.preTexts)

    ret.ProcessingResults = _extract_attribute_list(root, 'ProcessingResults', _readFromXmlToIQVKeyValueSetList,
                                                    ret.ProcessingResults)

    ret.Properties = _extract_attribute_list(root, 'Properties', _readFromXmlToIQVKeyValueSetList, ret.Properties)

    ret.QCUpdates = _extract_attribute_list(root, 'QCUpdates', _readFromXmlToIQVQCUpdateTrackingList, ret.QCUpdates)

    ret.QWords = _extract_attribute_list(root, 'QWords', _readFromXmlToIQVWordList, ret.QWords)

    fieldName = 'rectangle'
    try:
        item = root.find(fieldName)
        if item is not None:
            subbranch = item
            ret.rectangle = _readFromXmlToRectangle(subbranch)
        else:
            pass
    except Exception as e:
        logger.info('Failed to import field ' + fieldName)

    ret.rectangle_height = _extract_attribute(root, 'rectangle_height', int, ret.rectangle_height)

    ret.rectangle_width = _extract_attribute(root, 'rectangle_width', int, ret.rectangle_width)

    ret.rectangle_x = _extract_attribute(root, 'rectangle_x', int, ret.rectangle_x)

    ret.rectangle_y = _extract_attribute(root, 'rectangle_y', int, ret.rectangle_y)

    fieldName = 'rectangleGlobalLocationOnPage'
    try:
        item = root.find(fieldName)
        if item is not None:
            subbranch = item
            ret.rectangleGlobalLocationOnPage = _readFromXmlToRectangle(subbranch)
        else:
            pass
    except Exception as e:
        logger.info('Failed to import field ' + fieldName)

    ret.rectangleGlobalLocationOnPage_height = _extract_attribute(root, 'rectangleGlobalLocationOnPage_height', int,
                                                                  ret.rectangleGlobalLocationOnPage_height)

    ret.rectangleGlobalLocationOnPage_width = _extract_attribute(root, 'rectangleGlobalLocationOnPage_width', int,
                                                                 ret.rectangleGlobalLocationOnPage_width)

    ret.rectangleGlobalLocationOnPage_x = _extract_attribute(root, 'rectangleGlobalLocationOnPage_x', int,
                                                             ret.rectangleGlobalLocationOnPage_x)

    ret.rectangleGlobalLocationOnPage_y = _extract_attribute(root, 'rectangleGlobalLocationOnPage_y', int,
                                                             ret.rectangleGlobalLocationOnPage_y)

    ret.Rotation_MajorAxis = _extract_attribute(root, 'Rotation_MajorAxis', int, ret.Rotation_MajorAxis)

    ret.RotationChecks = _extract_attribute_list(root, 'RotationChecks', _readFromXmlToRotationCheckList,
                                                 ret.RotationChecks)

    ret.RotationCorrectionDegrees = _extract_attribute(root, 'RotationCorrectionDegrees', float,
                                                       ret.RotationCorrectionDegrees)

    ret.scannedOCRCode = _extract_attribute(root, 'scannedOCRCode', str, ret.scannedOCRCode)

    ret.Score = _extract_attribute(root, 'Score', float, ret.Score)

    ret.SegmentationBreakIndexes = _extract_attribute_list(root, 'SegmentationBreakIndexes', _readFromXmlToIntList,
                                                           ret.SegmentationBreakIndexes)

    ret.SegmentationBreakStrings = _extract_attribute_list(root, 'SegmentationBreakStrings', _readFromXmlToStringList,
                                                           ret.SegmentationBreakStrings)

    ret.SegmentationMethodVal = _extract_attribute(root, 'SegmentationMethodVal', int, ret.SegmentationMethodVal)

    ret.SegmentationType = _extract_attribute(root, 'SegmentationType', int, ret.SegmentationType)

    ret.SequenceID = _extract_attribute(root, 'SequenceID', int, ret.SequenceID)

    ret.SlideIndex = _extract_attribute(root, 'SlideIndex', int, ret.SlideIndex)

    ret.SlideRelationshipId = _extract_attribute(root, 'SlideRelationshipId', str, ret.SlideRelationshipId)

    ret.strText = _extract_attribute(root, 'strText', str, ret.strText)

    ret.strTexts = _extract_attribute_list(root, 'strTexts', _readFromXmlToStringList, ret.strTexts)

    ret.strTextsOCRInitial = _extract_attribute_list(root, 'strTextsOCRInitial', _readFromXmlToStringList,
                                                     ret.strTextsOCRInitial)

    ret.strTextsOCRUpdated = _extract_attribute_list(root, 'strTextsOCRUpdated', _readFromXmlToStringList,
                                                     ret.strTextsOCRUpdated)

    ret.strTextsTranslated = _extract_attribute_list(root, 'strTextsTranslated', _readFromXmlToStringList,
                                                     ret.strTextsTranslated)

    ret.strTextTranslated = _extract_attribute(root, 'strTextTranslated', str, ret.strTextTranslated)

    ret.tableCell_colIndex = _extract_attribute(root, 'tableCell_colIndex', int, ret.tableCell_colIndex)

    ret.tableCell_pageIndex = _extract_attribute(root, 'tableCell_pageIndex', int, ret.tableCell_pageIndex)

    ret.tableCell_rowIndex = _extract_attribute(root, 'tableCell_rowIndex', int, ret.tableCell_rowIndex)

    ret.tableCell_SharedStringIndex = _extract_attribute(root, 'tableCell_SharedStringIndex', int,
                                                         ret.tableCell_SharedStringIndex)

    ret.tableCell_SheetCellReference = _extract_attribute(root, 'tableCell_SheetCellReference', str,
                                                          ret.tableCell_SheetCellReference)

    ret.tableCell_SheetColIndex = _extract_attribute(root, 'tableCell_SheetColIndex', int, ret.tableCell_SheetColIndex)

    ret.tableCell_SheetName = _extract_attribute(root, 'tableCell_SheetName', str, ret.tableCell_SheetName)

    ret.tableCell_SheetRowIndex = _extract_attribute(root, 'tableCell_SheetRowIndex', int, ret.tableCell_SheetRowIndex)

    fieldName = 'tableColumn'
    try:
        item = root.find(fieldName)
        if item is not None:
            subbranch = item
            ret.tableColumn = _readFromXmlToIQVTableColumn(subbranch)
        else:
            pass
    except Exception as e:
        logger.info('Failed to import field ' + fieldName)

    ret.TableColumns = _extract_attribute_list(root, 'TableColumns', _readFromXmlToIQVTableColumnList, ret.TableColumns)

    fieldName = 'textMatch'
    try:
        item = root.find(fieldName)
        if item is not None:
            subbranch = item
            ret.textMatch = _readFromXmlToTextMatch(subbranch)
        else:
            pass
    except Exception as e:
        logger.info('Failed to import field ' + fieldName)

    ret.textTypeVal = _extract_attribute(root, 'textTypeVal', int, ret.textTypeVal)

    ret.TranslatedTextNoSegmentation = _extract_attribute(root, 'TranslatedTextNoSegmentation', str,
                                                          ret.TranslatedTextNoSegmentation)

    ret.TranslationMatch = _extract_attribute(root, 'TranslationMatch', float, ret.TranslationMatch)

    ret.TranslationMethod1 = _extract_attribute(root, 'TranslationMethod1', str, ret.TranslationMethod1)

    ret.UncorrectedImageFilename = _extract_attribute(root, 'UncorrectedImageFilename', str,
                                                      ret.UncorrectedImageFilename)

    ret.Value = _extract_attribute(root, 'Value', str, ret.Value)

    ret.ValuesI = _extract_attribute_list(root, 'ValuesI', _readFromXmlToValueIList, ret.ValuesI)

    ret.VerticalResolution = _extract_attribute(root, 'VerticalResolution', float, ret.VerticalResolution)
    return ret


def _readFromXmlToIQVPageROIList(branch: ET.ElementTree):
    """
    Read from XML and load memory object, for list of objects
    """
    root = branch
    ret = []
    for child in root:
        if (child.tag == 'IQVPageROI'):
            try:
                ret.append(_readFromXmlToIQVPageROI(child))
            except Exception as e:
                # log
                logger.info('Failed to import field ' + child.tag)
    return ret


def _readFromXmlToIQVDocument(branch):
    """
    Read from XML and load memory object
    """

    # get root element
    root = branch

    # initialize IQVDocument
    ret = IQVDocument()

    ret.alcoac_check_error = _extract_attribute_list(root, 'alcoac_check_error',
                                                     _readFromXmlToIQVAttributeCandidateList, ret.alcoac_check_error)

    ret.bDeleteAllFilesExceptFinalizerOutputFile = _extract_attribute(root,
                                                                      'bDeleteAllFilesExceptFinalizerOutputFile',
                                                                      _str2bool,
                                                                      ret.bDeleteAllFilesExceptFinalizerOutputFile)

    ret.bDeleteInputSourceFile = _extract_attribute(root, 'bDeleteInputSourceFile', _str2bool,
                                                    ret.bDeleteInputSourceFile)

    ret.bDeleteWorkingTempDirectoryAfterCompletion = _extract_attribute(root,
                                                                        'bDeleteWorkingTempDirectoryAfterCompletion',
                                                                        int,
                                                                        ret.bDeleteWorkingTempDirectoryAfterCompletion)

    ret.bIsFullDocumentScanned = _extract_attribute(root, 'bIsFullDocumentScanned', _str2bool,
                                                    ret.bIsFullDocumentScanned)

    ret.bIsStandardForm = _extract_attribute(root, 'bIsStandardForm', _str2bool, ret.bIsStandardForm)

    ret.bIsVisibleInDocumentDisplay = _extract_attribute(root, 'bIsVisibleInDocumentDisplay', _str2bool,
                                                         ret.bIsVisibleInDocumentDisplay)

    ret.CustomHostName = _extract_attribute(root, 'CustomHostName', str, ret.CustomHostName)

    ret.dateTimeLastModified = _extract_attribute(root, 'dateTimeLastModified', str, ret.dateTimeLastModified)

    ret.dateTimeUploaded = _extract_attribute(root, 'dateTimeUploaded', str, ret.dateTimeUploaded)

    ret.debugModeVal = _extract_attribute(root, 'debugModeVal', int, ret.debugModeVal)

    ret.displayLabel = _extract_attribute(root, 'displayLabel', str, ret.displayLabel)

    ret.doc_id = _extract_attribute(root, 'doc_id', str, ret.doc_id)

    ret.DOCANALYSIS_DateID = _extract_attribute(root, 'DOCANALYSIS_DateID', str, ret.DOCANALYSIS_DateID)

    ret.DOCANALYSIS_DateValue = _extract_attribute(root, 'DOCANALYSIS_DateValue', str, ret.DOCANALYSIS_DateValue)

    ret.DOCANALYSIS_DocumentClass = _extract_attribute(root, 'DOCANALYSIS_DocumentClass', str,
                                                       ret.DOCANALYSIS_DocumentClass)

    ret.DOCANALYSIS_DocumentClassConfidence = _extract_attribute(root, 'DOCANALYSIS_DocumentClassConfidence', float,
                                                                 ret.DOCANALYSIS_DocumentClassConfidence)

    ret.DOCANALYSIS_DocumentClassConfidenceList = _extract_attribute_list(root,
                                                                          'DOCANALYSIS_DocumentClassConfidenceList',
                                                                          _readFromXmlToDoubleList,
                                                                          ret.DOCANALYSIS_DocumentClassConfidenceList)

    ret.DOCANALYSIS_DocumentClassList = _extract_attribute_list(root, 'DOCANALYSIS_DocumentClassList',
                                                                _readFromXmlToStringList,
                                                                ret.DOCANALYSIS_DocumentClassList)

    ret.DOCANALYSIS_DocumentClassList_Description = _extract_attribute_list(root,
                                                                            'DOCANALYSIS_DocumentClassList_Description',
                                                                            _readFromXmlToStringList,
                                                                            ret.DOCANALYSIS_DocumentClassList_Description)

    ret.DOCANALYSIS_DocumentClassList_DIACode = _extract_attribute_list(root,
                                                                        'DOCANALYSIS_DocumentClassList_DIACode',
                                                                        _readFromXmlToStringList,
                                                                        ret.DOCANALYSIS_DocumentClassList_DIACode)

    ret.DOCANALYSIS_DocumentClassRawScoreList = _extract_attribute_list(root,
                                                                        'DOCANALYSIS_DocumentClassRawScoreList',
                                                                        _readFromXmlToDoubleList,
                                                                        ret.DOCANALYSIS_DocumentClassRawScoreList)

    ret.DOCANALYSIS_DocumentMetadata = _extract_attribute_list(root, 'DOCANALYSIS_DocumentMetadata',
                                                               _readFromXmlToIQVKeyValueSetList,
                                                               ret.DOCANALYSIS_DocumentMetadata)

    ret.DocumentCompares = _extract_attribute_list(root, 'DocumentCompares', _readFromXmlToIQVDocumentCompareList,
                                                   ret.DocumentCompares)

    ret.DocumentFooters = _extract_attribute_list(root, 'DocumentFooters', _readFromXmlToIQVPageROIList,
                                                  ret.DocumentFooters)

    ret.DocumentFootnotes = _extract_attribute_list(root, 'DocumentFootnotes', _readFromXmlToIQVPageROIList,
                                                    ret.DocumentFootnotes)

    fieldName = 'DocumentGroundTruth'
    try:
        item = root.find(fieldName)
        if item is not None:
            subbranch = item
            ret.DocumentGroundTruth = _readFromXmlToIQVDocumentGroundTruth(subbranch)
        else:
            pass
    except Exception as e:
        logger.info('Failed to import field ' + fieldName)

    ret.DocumentHeaders = _extract_attribute_list(root, 'DocumentHeaders', _readFromXmlToIQVPageROIList,
                                                  ret.DocumentHeaders)

    ret.DocumentImages = _extract_attribute_list(root, 'DocumentImages', _readFromXmlToIQVPageROIList,
                                                 ret.DocumentImages)

    ret.DocumentItems = _extract_attribute_list(root, 'DocumentItems', _readFromXmlToIQVPageROIList, ret.DocumentItems)

    ret.DocumentLinks = _extract_attribute_list(root, 'DocumentLinks', _readFromXmlToIQVDocumentLinkList,
                                                ret.DocumentLinks)

    ret.DocumentParagraphs = _extract_attribute_list(root, 'DocumentParagraphs', _readFromXmlToIQVPageROIList,
                                                     ret.DocumentParagraphs)

    ret.DocumentPartsList = _extract_attribute_list(root, 'DocumentPartsList', _readFromXmlToStringList,
                                                    ret.DocumentPartsList)

    ret.DocumentTables = _extract_attribute_list(root, 'DocumentTables', _readFromXmlToIQVPageROIList,
                                                 ret.DocumentTables)

    ret.DocumentTypeVal = _extract_attribute(root, 'DocumentTypeVal', int, ret.DocumentTypeVal)

    ret.DocumentTypeValOriginal = _extract_attribute(root, 'DocumentTypeValOriginal', int, ret.DocumentTypeValOriginal)

    ret.DropBoxDir = _extract_attribute(root, 'DropBoxDir', str, ret.DropBoxDir)

    ret.DropBoxDirWebUI = _extract_attribute(root, 'DropBoxDirWebUI', str, ret.DropBoxDirWebUI)

    ret.EndPage = _extract_attribute(root, 'EndPage', int, ret.EndPage)

    ret.id = _extract_attribute(root, 'id', str, ret.id)

    ret.image_count = _extract_attribute(root, 'image_count', int, ret.image_count)

    fieldName = 'InitialConfig'
    try:
        item = root.find(fieldName)
        if item is not None:
            subbranch = item
            ret.InitialConfig = _readFromXmlToConfig(subbranch)
        else:
            pass
    except Exception as e:
        logger.info('Failed to import field ' + fieldName)

    ret.IQVAttributeCandidates = _extract_attribute_list(root, 'IQVAttributeCandidates',
                                                         _readFromXmlToIQVAttributeCandidateList,
                                                         ret.IQVAttributeCandidates)

    ret.IQVDocumentFeedbackResultsList = _extract_attribute_list(root, 'IQVDocumentFeedbackResultsList',
                                                                 _readFromXmlToIQVDocumentFeedbackResultsList,
                                                                 ret.IQVDocumentFeedbackResultsList)

    ret.IQVDocumentFilename_SourceXML = _extract_attribute(root, 'IQVDocumentFilename_SourceXML', str,
                                                           ret.IQVDocumentFilename_SourceXML)

    ret.IQVDocumentFilename_TranslatedXML = _extract_attribute(root, 'IQVDocumentFilename_TranslatedXML', str,
                                                               ret.IQVDocumentFilename_TranslatedXML)

    ret.IQVDocumentProcesses = _extract_attribute_list(root, 'IQVDocumentProcesses',
                                                       _readFromXmlToIQVDocumentProcessList, ret.IQVDocumentProcesses)

    fieldName = 'iqvForm'
    try:
        item = root.find(fieldName)
        if item is not None:
            subbranch = item
            ret.iqvForm = _readFromXmlToIQVForm(subbranch)
        else:
            pass
    except Exception as e:
        logger.info('Failed to import field ' + fieldName)

    ret.IsDocInitialWorkflowCompleted = _extract_attribute(root, 'IsDocInitialWorkflowCompleted', _str2bool,
                                                           ret.IsDocInitialWorkflowCompleted)

    ret.link_id = _extract_attribute(root, 'link_id', str, ret.link_id)

    ret.LogEntries = _extract_attribute_list(root, 'LogEntries', _readFromXmlToQ_EVENT_LOG_ENTRYList, ret.LogEntries)

    ret.logFilename = _extract_attribute(root, 'logFilename', str, ret.logFilename)

    ret.logFilenameDropBox = _extract_attribute(root, 'logFilenameDropBox', str, ret.logFilenameDropBox)

    ret.MachineName = _extract_attribute(root, 'MachineName', str, ret.MachineName)

    ret.NLP_Attributes = _extract_attribute_list(root, 'NLP_Attributes', _readFromXmlToNLP_AttributeList,
                                                 ret.NLP_Attributes)

    ret.NLP_Entities = _extract_attribute_list(root, 'NLP_Entities', _readFromXmlToNLP_EntityList, ret.NLP_Entities)

    ret.NLP_Relations = _extract_attribute_list(root, 'NLP_Relations', _readFromXmlToNLP_RelationList,
                                                ret.NLP_Relations)

    ret.numberingGroups = _extract_attribute_list(root, 'numberingGroups', _readFromXmlToIQVNumberingGroupList,
                                                  ret.numberingGroups)

    ret.NumPDFPages = _extract_attribute(root, 'NumPDFPages', int, ret.NumPDFPages)

    ret.NumSegments = _extract_attribute(root, 'NumSegments', int, ret.NumSegments)

    ret.originalSourceFilename = _extract_attribute(root, 'originalSourceFilename', str, ret.originalSourceFilename)

    ret.outputHTMLFilename = _extract_attribute(root, 'outputHTMLFilename', str, ret.outputHTMLFilename)

    ret.outputHTMLFilename_Cleaned = _extract_attribute(root, 'outputHTMLFilename_Cleaned', str,
                                                        ret.outputHTMLFilename_Cleaned)

    ret.outputHTMLFilename_OCRDig = _extract_attribute(root, 'outputHTMLFilename_OCRDig', str,
                                                       ret.outputHTMLFilename_OCRDig)

    ret.outputHTMLFilename_Orig = _extract_attribute(root, 'outputHTMLFilename_Orig', str, ret.outputHTMLFilename_Orig)

    ret.outputHTMLFilename_Segmented = _extract_attribute(root, 'outputHTMLFilename_Segmented', str,
                                                          ret.outputHTMLFilename_Segmented)

    ret.outputHTMLFilename_XMLSource = _extract_attribute(root, 'outputHTMLFilename_XMLSource', str,
                                                          ret.outputHTMLFilename_XMLSource)

    ret.outputHTMLFilename_XMLTrans = _extract_attribute(root, 'outputHTMLFilename_XMLTrans', str,
                                                         ret.outputHTMLFilename_XMLTrans)

    ret.outputHTMLFilenameToDropBox = _extract_attribute(root, 'outputHTMLFilenameToDropBox', str,
                                                         ret.outputHTMLFilenameToDropBox)

    ret.outputHTMLFilenameToDropBox_Cleaned = _extract_attribute(root, 'outputHTMLFilenameToDropBox_Cleaned', str,
                                                                 ret.outputHTMLFilenameToDropBox_Cleaned)

    ret.outputHTMLFilenameToDropBox_OCRDig = _extract_attribute(root, 'outputHTMLFilenameToDropBox_OCRDig', str,
                                                                ret.outputHTMLFilenameToDropBox_OCRDig)

    ret.outputHTMLFilenameToDropBox_Orig = _extract_attribute(root, 'outputHTMLFilenameToDropBox_Orig', str,
                                                              ret.outputHTMLFilenameToDropBox_Orig)

    ret.outputHTMLFilenameToDropBox_Segmented = _extract_attribute(root, 'outputHTMLFilenameToDropBox_Segmented', str,
                                                                   ret.outputHTMLFilenameToDropBox_Segmented)

    ret.outputHTMLFilenameToDropBox_XMLSource = _extract_attribute(root, 'outputHTMLFilenameToDropBox_XMLSource', str,
                                                                   ret.outputHTMLFilenameToDropBox_XMLSource)

    ret.outputHTMLFilenameToDropBox_XMLTrans = _extract_attribute(root, 'outputHTMLFilenameToDropBox_XMLTrans', str,
                                                                  ret.outputHTMLFilenameToDropBox_XMLTrans)

    ret.outputHTMLFilenameTranslated = _extract_attribute(root, 'outputHTMLFilenameTranslated', str,
                                                          ret.outputHTMLFilenameTranslated)

    ret.outputHTMLFilenameTranslatedToDropBox = _extract_attribute(root, 'outputHTMLFilenameTranslatedToDropBox', str,
                                                                   ret.outputHTMLFilenameTranslatedToDropBox)

    ret.outputHTMLFilenameWithID = _extract_attribute(root, 'outputHTMLFilenameWithID', str,
                                                      ret.outputHTMLFilenameWithID)

    ret.outputHTMLSideBySideFilename = _extract_attribute(root, 'outputHTMLSideBySideFilename', str,
                                                          ret.outputHTMLSideBySideFilename)

    ret.outputHTMLSideBySideFilename_OCRDig_to_XMLSource = _extract_attribute(root,
                                                                              'outputHTMLSideBySideFilename_OCRDig_to_XMLSource',
                                                                              str,
                                                                              ret.outputHTMLSideBySideFilename_OCRDig_to_XMLSource)

    ret.outputHTMLSideBySideFilename_Orig_to_Cleaned = _extract_attribute(root,
                                                                          'outputHTMLSideBySideFilename_Orig_to_Cleaned',
                                                                          str,
                                                                          ret.outputHTMLSideBySideFilename_Orig_to_Cleaned)

    ret.outputHTMLSideBySideFilename_Orig_to_OCRDig = _extract_attribute(root,
                                                                         'outputHTMLSideBySideFilename_Orig_to_OCRDig',
                                                                         str,
                                                                         ret.outputHTMLSideBySideFilename_Orig_to_OCRDig)

    ret.outputHTMLSideBySideFilename_Segmented_to_OCRDig = _extract_attribute(root,
                                                                              'outputHTMLSideBySideFilename_Segmented_to_OCRDig',
                                                                              str,
                                                                              ret.outputHTMLSideBySideFilename_Segmented_to_OCRDig)

    ret.outputHTMLSideBySideFilename_XMLSource_to_XMLTrans = _extract_attribute(root,
                                                                                'outputHTMLSideBySideFilename_XMLSource_to_XMLTrans',
                                                                                str,
                                                                                ret.outputHTMLSideBySideFilename_XMLSource_to_XMLTrans)

    ret.outputHTMLSideBySideFilenameToDropBox = _extract_attribute(root, 'outputHTMLSideBySideFilenameToDropBox', str,
                                                                   ret.outputHTMLSideBySideFilenameToDropBox)

    ret.outputHTMLSideBySideFilenameToDropBox_OCRDig_to_XMLSource = _extract_attribute(root,
                                                                                       'outputHTMLSideBySideFilenameToDropBox_OCRDig_to_XMLSource',
                                                                                       str,
                                                                                       ret.outputHTMLSideBySideFilenameToDropBox_OCRDig_to_XMLSource)

    ret.outputHTMLSideBySideFilenameToDropBox_Orig_to_Cleaned = _extract_attribute(root,
                                                                                   'outputHTMLSideBySideFilenameToDropBox_Orig_to_Cleaned',
                                                                                   str,
                                                                                   ret.outputHTMLSideBySideFilenameToDropBox_Orig_to_Cleaned)

    ret.outputHTMLSideBySideFilenameToDropBox_Orig_to_OCRDig = _extract_attribute(root,
                                                                                  'outputHTMLSideBySideFilenameToDropBox_Orig_to_OCRDig',
                                                                                  str,
                                                                                  ret.outputHTMLSideBySideFilenameToDropBox_Orig_to_OCRDig)

    ret.outputHTMLSideBySideFilenameToDropBox_Segmented_to_OCRDig = _extract_attribute(root,
                                                                                       'outputHTMLSideBySideFilenameToDropBox_Segmented_to_OCRDig',
                                                                                       str,
                                                                                       ret.outputHTMLSideBySideFilenameToDropBox_Segmented_to_OCRDig)

    ret.outputHTMLSideBySideFilenameToDropBox_XMLSource_to_XMLTrans = _extract_attribute(root,
                                                                                         'outputHTMLSideBySideFilenameToDropBox_XMLSource_to_XMLTrans',
                                                                                         str,
                                                                                         ret.outputHTMLSideBySideFilenameToDropBox_XMLSource_to_XMLTrans)

    ret.outputHTMLSideBySideOCRFilename = _extract_attribute(root, 'outputHTMLSideBySideOCRFilename', str,
                                                             ret.outputHTMLSideBySideOCRFilename)

    ret.outputHTMLSideBySideOCRFilenameToDropBox = _extract_attribute(root,
                                                                      'outputHTMLSideBySideOCRFilenameToDropBox',
                                                                      str,
                                                                      ret.outputHTMLSideBySideOCRFilenameToDropBox)

    ret.outputImagesToDropBoxDir = _extract_attribute(root, 'outputImagesToDropBoxDir', str,
                                                      ret.outputImagesToDropBoxDir)

    ret.outputIQVXMLFilenameToDropBox = _extract_attribute(root, 'outputIQVXMLFilenameToDropBox', str,
                                                           ret.outputIQVXMLFilenameToDropBox)

    ret.OutputLevel = _extract_attribute(root, 'OutputLevel', int, ret.OutputLevel)

    ret.outputMetadataFilename = _extract_attribute(root, 'outputMetadataFilename', str, ret.outputMetadataFilename)

    ret.outputMetatdataFilenameTranslated = _extract_attribute(root, 'outputMetatdataFilenameTranslated', str,
                                                               ret.outputMetatdataFilenameTranslated)

    ret.outputPDFFilename = _extract_attribute(root, 'outputPDFFilename', str, ret.outputPDFFilename)

    ret.outputPDFFilenameToDropBox = _extract_attribute(root, 'outputPDFFilenameToDropBox', str,
                                                        ret.outputPDFFilenameToDropBox)

    ret.outputPDFFilenameTranslated = _extract_attribute(root, 'outputPDFFilenameTranslated', str,
                                                         ret.outputPDFFilenameTranslated)

    ret.outputPDFFilenameTranslatedToDropBox = _extract_attribute(root, 'outputPDFFilenameTranslatedToDropBox', str,
                                                                  ret.outputPDFFilenameTranslatedToDropBox)

    ret.outputWordDocFilename = _extract_attribute(root, 'outputWordDocFilename', str, ret.outputWordDocFilename)

    ret.outputWordDocFilenameDropBox = _extract_attribute(root, 'outputWordDocFilenameDropBox', str,
                                                          ret.outputWordDocFilenameDropBox)

    ret.outputWordDocFilenameTranslated = _extract_attribute(root, 'outputWordDocFilenameTranslated', str,
                                                             ret.outputWordDocFilenameTranslated)

    ret.outputWordDocFilenameTranslatedDropBox = _extract_attribute(root, 'outputWordDocFilenameTranslatedDropBox',
                                                                    str, ret.outputWordDocFilenameTranslatedDropBox)

    ret.outputXLIFFFilename = _extract_attribute(root, 'outputXLIFFFilename', str, ret.outputXLIFFFilename)

    ret.outputXLIFFFilenameDropBox = _extract_attribute(root, 'outputXLIFFFilenameDropBox', str,
                                                        ret.outputXLIFFFilenameDropBox)

    ret.outputXLIFFFilenameT = _extract_attribute(root, 'outputXLIFFFilenameT', str, ret.outputXLIFFFilenameT)

    ret.outputXLIFFFilenameTDropBox = _extract_attribute(root, 'outputXLIFFFilenameTDropBox', str,
                                                         ret.outputXLIFFFilenameTDropBox)

    ret.pages = _extract_attribute_list(root, 'pages', _readFromXmlToIQVDocumentPageList, ret.pages)

    ret.ProcessFinishTime = _extract_attribute(root, 'ProcessFinishTime', str, ret.ProcessFinishTime)

    ret.ProcessingResults = _extract_attribute_list(root, 'ProcessingResults', _readFromXmlToIQVKeyValueSetList,
                                                    ret.ProcessingResults)

    ret.ProcessStartTime = _extract_attribute(root, 'ProcessStartTime', str, ret.ProcessStartTime)

    ret.Properties = _extract_attribute_list(root, 'Properties', _readFromXmlToIQVKeyValueSetList, ret.Properties)

    ret.QDocumentWorkingDirectory = _extract_attribute(root, 'QDocumentWorkingDirectory', str,
                                                       ret.QDocumentWorkingDirectory)

    ret.QDocumentWorkingTempDirectory = _extract_attribute(root, 'QDocumentWorkingTempDirectory', str,
                                                           ret.QDocumentWorkingTempDirectory)

    ret.ReconDocumentFooters = _extract_attribute_list(root, 'ReconDocumentFooters', _readFromXmlToIQVPageROIList,
                                                       ret.ReconDocumentFooters)

    ret.ReconDocumentHeaders = _extract_attribute_list(root, 'ReconDocumentHeaders', _readFromXmlToIQVPageROIList,
                                                       ret.ReconDocumentHeaders)

    ret.ReconDocumentImages = _extract_attribute_list(root, 'ReconDocumentImages', _readFromXmlToIQVPageROIList,
                                                      ret.ReconDocumentImages)

    ret.ReconDocumentItems = _extract_attribute_list(root, 'ReconDocumentItems', _readFromXmlToIQVPageROIList,
                                                     ret.ReconDocumentItems)

    ret.ReconDocumentParagraphs = _extract_attribute_list(root, 'ReconDocumentParagraphs',
                                                          _readFromXmlToIQVPageROIList, ret.ReconDocumentParagraphs)

    ret.ReconDocumentTables = _extract_attribute_list(root, 'ReconDocumentTables', _readFromXmlToIQVPageROIList,
                                                      ret.ReconDocumentTables)

    ret.SegmentationFilename_PostSegmentation = _extract_attribute(root, 'SegmentationFilename_PostSegmentation', str,
                                                                   ret.SegmentationFilename_PostSegmentation)

    ret.SegmentationFilename_PreSegmentation = _extract_attribute(root, 'SegmentationFilename_PreSegmentation', str,
                                                                  ret.SegmentationFilename_PreSegmentation)

    ret.SelectedWordTemplateCode = _extract_attribute(root, 'SelectedWordTemplateCode', int,
                                                      ret.SelectedWordTemplateCode)

    ret.SelectedWordTemplateFilename = _extract_attribute(root, 'SelectedWordTemplateFilename', str,
                                                          ret.SelectedWordTemplateFilename)

    ret.sourceFilename = _extract_attribute(root, 'sourceFilename', str, ret.sourceFilename)

    ret.sourceFilenameWorkingCopy = _extract_attribute(root, 'sourceFilenameWorkingCopy', str,
                                                       ret.sourceFilenameWorkingCopy)

    ret.sourceFilenameWorkingCopyToDropBox = _extract_attribute(root, 'sourceFilenameWorkingCopyToDropBox', str,
                                                                ret.sourceFilenameWorkingCopyToDropBox)

    ret.SourceLanguage = _extract_attribute(root, 'SourceLanguage', str, ret.SourceLanguage)

    ret.StandardForm = _extract_attribute(root, 'StandardForm', str, ret.StandardForm)

    ret.StandardFormPageIndex = _extract_attribute(root, 'StandardFormPageIndex', int, ret.StandardFormPageIndex)

    ret.StartPage = _extract_attribute(root, 'StartPage', int, ret.StartPage)

    ret.SubmitterEmail = _extract_attribute(root, 'SubmitterEmail', str, ret.SubmitterEmail)

    ret.SubmitterID = _extract_attribute(root, 'SubmitterID', str, ret.SubmitterID)

    ret.TargetLanguage = _extract_attribute(root, 'TargetLanguage', str, ret.TargetLanguage)

    ret.workingFilename = _extract_attribute(root, 'workingFilename', str, ret.workingFilename)

    ret.workingFilename_NoiseGenerator = _extract_attribute(root, 'workingFilename_NoiseGenerator', str,
                                                            ret.workingFilename_NoiseGenerator)
    return ret


def _readFromXmlToIQVDocumentList(branch: ET.ElementTree):
    """
    Read from XML and load memory object, for list of objects
    """
    root = branch
    ret = []
    for child in root:
        if (child.tag == 'IQVDocument'):
            try:
                ret.append(_readFromXmlToIQVDocument(child))
            except Exception as e:
                # log
                logger.info('Failed to import field ' + child.tag)
    return ret


def _readFromXmlToIQVDocument_db(branch):
    """
    Read from XML and load memory object
    """

    # get root element
    root = branch

    # initialize IQVDocument_db
    ret = IQVDocument_db()

    ret.bDeleteAllFilesExceptFinalizerOutputFile = _extract_attribute(root,
                                                                      'bDeleteAllFilesExceptFinalizerOutputFile',
                                                                      _str2bool,
                                                                      ret.bDeleteAllFilesExceptFinalizerOutputFile)

    ret.bDeleteInputSourceFile = _extract_attribute(root, 'bDeleteInputSourceFile', _str2bool,
                                                    ret.bDeleteInputSourceFile)

    ret.bDeleteWorkingTempDirectoryAfterCompletion = _extract_attribute(root,
                                                                        'bDeleteWorkingTempDirectoryAfterCompletion',
                                                                        int,
                                                                        ret.bDeleteWorkingTempDirectoryAfterCompletion)

    ret.bIsFullDocumentScanned = _extract_attribute(root, 'bIsFullDocumentScanned', _str2bool,
                                                    ret.bIsFullDocumentScanned)

    ret.bIsStandardForm = _extract_attribute(root, 'bIsStandardForm', _str2bool, ret.bIsStandardForm)

    ret.bIsVisibleInDocumentDisplay = _extract_attribute(root, 'bIsVisibleInDocumentDisplay', _str2bool,
                                                         ret.bIsVisibleInDocumentDisplay)

    ret.CustomHostName = _extract_attribute(root, 'CustomHostName', str, ret.CustomHostName)

    ret.dateTimeLastModified = _extract_attribute(root, 'dateTimeLastModified', str, ret.dateTimeLastModified)

    ret.dateTimeUploaded = _extract_attribute(root, 'dateTimeUploaded', str, ret.dateTimeUploaded)

    ret.debugModeVal = _extract_attribute(root, 'debugModeVal', int, ret.debugModeVal)

    ret.displayLabel = _extract_attribute(root, 'displayLabel', str, ret.displayLabel)

    ret.doc_id = _extract_attribute(root, 'doc_id', str, ret.doc_id)

    ret.DOCANALYSIS_DateID = _extract_attribute(root, 'DOCANALYSIS_DateID', str, ret.DOCANALYSIS_DateID)

    ret.DOCANALYSIS_DateValue = _extract_attribute(root, 'DOCANALYSIS_DateValue', str, ret.DOCANALYSIS_DateValue)

    ret.DOCANALYSIS_DocumentClass = _extract_attribute(root, 'DOCANALYSIS_DocumentClass', str,
                                                       ret.DOCANALYSIS_DocumentClass)

    ret.DOCANALYSIS_DocumentClassConfidence = _extract_attribute(root, 'DOCANALYSIS_DocumentClassConfidence', float,
                                                                 ret.DOCANALYSIS_DocumentClassConfidence)

    ret.DocumentTypeVal = _extract_attribute(root, 'DocumentTypeVal', int, ret.DocumentTypeVal)

    ret.DocumentTypeValOriginal = _extract_attribute(root, 'DocumentTypeValOriginal', int, ret.DocumentTypeValOriginal)

    ret.DropBoxDir = _extract_attribute(root, 'DropBoxDir', str, ret.DropBoxDir)

    ret.DropBoxDirWebUI = _extract_attribute(root, 'DropBoxDirWebUI', str, ret.DropBoxDirWebUI)

    ret.EndPage = _extract_attribute(root, 'EndPage', int, ret.EndPage)

    ret.id = _extract_attribute(root, 'id', str, ret.id)

    ret.image_count = _extract_attribute(root, 'image_count', int, ret.image_count)

    ret.IQVDocumentFilename_SourceXML = _extract_attribute(root, 'IQVDocumentFilename_SourceXML', str,
                                                           ret.IQVDocumentFilename_SourceXML)

    ret.IQVDocumentFilename_TranslatedXML = _extract_attribute(root, 'IQVDocumentFilename_TranslatedXML', str,
                                                               ret.IQVDocumentFilename_TranslatedXML)

    ret.IsDocInitialWorkflowCompleted = _extract_attribute(root, 'IsDocInitialWorkflowCompleted', _str2bool,
                                                           ret.IsDocInitialWorkflowCompleted)

    ret.link_id = _extract_attribute(root, 'link_id', str, ret.link_id)

    ret.logFilename = _extract_attribute(root, 'logFilename', str, ret.logFilename)

    ret.logFilenameDropBox = _extract_attribute(root, 'logFilenameDropBox', str, ret.logFilenameDropBox)

    ret.MachineName = _extract_attribute(root, 'MachineName', str, ret.MachineName)

    ret.NumPDFPages = _extract_attribute(root, 'NumPDFPages', int, ret.NumPDFPages)

    ret.NumSegments = _extract_attribute(root, 'NumSegments', int, ret.NumSegments)

    ret.originalSourceFilename = _extract_attribute(root, 'originalSourceFilename', str, ret.originalSourceFilename)

    ret.outputHTMLFilename = _extract_attribute(root, 'outputHTMLFilename', str, ret.outputHTMLFilename)

    ret.outputHTMLFilename_Cleaned = _extract_attribute(root, 'outputHTMLFilename_Cleaned', str,
                                                        ret.outputHTMLFilename_Cleaned)

    ret.outputHTMLFilename_OCRDig = _extract_attribute(root, 'outputHTMLFilename_OCRDig', str,
                                                       ret.outputHTMLFilename_OCRDig)

    ret.outputHTMLFilename_Orig = _extract_attribute(root, 'outputHTMLFilename_Orig', str, ret.outputHTMLFilename_Orig)

    ret.outputHTMLFilename_Segmented = _extract_attribute(root, 'outputHTMLFilename_Segmented', str,
                                                          ret.outputHTMLFilename_Segmented)

    ret.outputHTMLFilename_XMLSource = _extract_attribute(root, 'outputHTMLFilename_XMLSource', str,
                                                          ret.outputHTMLFilename_XMLSource)

    ret.outputHTMLFilename_XMLTrans = _extract_attribute(root, 'outputHTMLFilename_XMLTrans', str,
                                                         ret.outputHTMLFilename_XMLTrans)

    ret.outputHTMLFilenameToDropBox = _extract_attribute(root, 'outputHTMLFilenameToDropBox', str,
                                                         ret.outputHTMLFilenameToDropBox)

    ret.outputHTMLFilenameToDropBox_Cleaned = _extract_attribute(root, 'outputHTMLFilenameToDropBox_Cleaned', str,
                                                                 ret.outputHTMLFilenameToDropBox_Cleaned)

    ret.outputHTMLFilenameToDropBox_OCRDig = _extract_attribute(root, 'outputHTMLFilenameToDropBox_OCRDig', str,
                                                                ret.outputHTMLFilenameToDropBox_OCRDig)

    ret.outputHTMLFilenameToDropBox_Orig = _extract_attribute(root, 'outputHTMLFilenameToDropBox_Orig', str,
                                                              ret.outputHTMLFilenameToDropBox_Orig)

    ret.outputHTMLFilenameToDropBox_Segmented = _extract_attribute(root, 'outputHTMLFilenameToDropBox_Segmented', str,
                                                                   ret.outputHTMLFilenameToDropBox_Segmented)

    ret.outputHTMLFilenameToDropBox_XMLSource = _extract_attribute(root, 'outputHTMLFilenameToDropBox_XMLSource', str,
                                                                   ret.outputHTMLFilenameToDropBox_XMLSource)

    ret.outputHTMLFilenameToDropBox_XMLTrans = _extract_attribute(root, 'outputHTMLFilenameToDropBox_XMLTrans', str,
                                                                  ret.outputHTMLFilenameToDropBox_XMLTrans)

    ret.outputHTMLFilenameTranslated = _extract_attribute(root, 'outputHTMLFilenameTranslated', str,
                                                          ret.outputHTMLFilenameTranslated)

    ret.outputHTMLFilenameTranslatedToDropBox = _extract_attribute(root, 'outputHTMLFilenameTranslatedToDropBox', str,
                                                                   ret.outputHTMLFilenameTranslatedToDropBox)

    ret.outputHTMLFilenameWithID = _extract_attribute(root, 'outputHTMLFilenameWithID', str,
                                                      ret.outputHTMLFilenameWithID)

    ret.outputHTMLSideBySideFilename = _extract_attribute(root, 'outputHTMLSideBySideFilename', str,
                                                          ret.outputHTMLSideBySideFilename)

    ret.outputHTMLSideBySideFilename_OCRDig_to_XMLSource = _extract_attribute(root,
                                                                              'outputHTMLSideBySideFilename_OCRDig_to_XMLSource',
                                                                              str,
                                                                              ret.outputHTMLSideBySideFilename_OCRDig_to_XMLSource)

    ret.outputHTMLSideBySideFilename_Orig_to_Cleaned = _extract_attribute(root,
                                                                          'outputHTMLSideBySideFilename_Orig_to_Cleaned',
                                                                          str,
                                                                          ret.outputHTMLSideBySideFilename_Orig_to_Cleaned)

    ret.outputHTMLSideBySideFilename_Orig_to_OCRDig = _extract_attribute(root,
                                                                         'outputHTMLSideBySideFilename_Orig_to_OCRDig',
                                                                         str,
                                                                         ret.outputHTMLSideBySideFilename_Orig_to_OCRDig)

    ret.outputHTMLSideBySideFilename_Segmented_to_OCRDig = _extract_attribute(root,
                                                                              'outputHTMLSideBySideFilename_Segmented_to_OCRDig',
                                                                              str,
                                                                              ret.outputHTMLSideBySideFilename_Segmented_to_OCRDig)

    ret.outputHTMLSideBySideFilename_XMLSource_to_XMLTrans = _extract_attribute(root,
                                                                                'outputHTMLSideBySideFilename_XMLSource_to_XMLTrans',
                                                                                str,
                                                                                ret.outputHTMLSideBySideFilename_XMLSource_to_XMLTrans)

    ret.outputHTMLSideBySideFilenameToDropBox = _extract_attribute(root, 'outputHTMLSideBySideFilenameToDropBox', str,
                                                                   ret.outputHTMLSideBySideFilenameToDropBox)

    ret.outputHTMLSideBySideFilenameToDropBox_OCRDig_to_XMLSource = _extract_attribute(root,
                                                                                       'outputHTMLSideBySideFilenameToDropBox_OCRDig_to_XMLSource',
                                                                                       str,
                                                                                       ret.outputHTMLSideBySideFilenameToDropBox_OCRDig_to_XMLSource)

    ret.outputHTMLSideBySideFilenameToDropBox_Orig_to_Cleaned = _extract_attribute(root,
                                                                                   'outputHTMLSideBySideFilenameToDropBox_Orig_to_Cleaned',
                                                                                   str,
                                                                                   ret.outputHTMLSideBySideFilenameToDropBox_Orig_to_Cleaned)

    ret.outputHTMLSideBySideFilenameToDropBox_Orig_to_OCRDig = _extract_attribute(root,
                                                                                  'outputHTMLSideBySideFilenameToDropBox_Orig_to_OCRDig',
                                                                                  str,
                                                                                  ret.outputHTMLSideBySideFilenameToDropBox_Orig_to_OCRDig)

    ret.outputHTMLSideBySideFilenameToDropBox_Segmented_to_OCRDig = _extract_attribute(root,
                                                                                       'outputHTMLSideBySideFilenameToDropBox_Segmented_to_OCRDig',
                                                                                       str,
                                                                                       ret.outputHTMLSideBySideFilenameToDropBox_Segmented_to_OCRDig)

    ret.outputHTMLSideBySideFilenameToDropBox_XMLSource_to_XMLTrans = _extract_attribute(root,
                                                                                         'outputHTMLSideBySideFilenameToDropBox_XMLSource_to_XMLTrans',
                                                                                         str,
                                                                                         ret.outputHTMLSideBySideFilenameToDropBox_XMLSource_to_XMLTrans)

    ret.outputHTMLSideBySideOCRFilename = _extract_attribute(root, 'outputHTMLSideBySideOCRFilename', str,
                                                             ret.outputHTMLSideBySideOCRFilename)

    ret.outputHTMLSideBySideOCRFilenameToDropBox = _extract_attribute(root,
                                                                      'outputHTMLSideBySideOCRFilenameToDropBox',
                                                                      str,
                                                                      ret.outputHTMLSideBySideOCRFilenameToDropBox)

    ret.outputImagesToDropBoxDir = _extract_attribute(root, 'outputImagesToDropBoxDir', str,
                                                      ret.outputImagesToDropBoxDir)

    ret.outputIQVXMLFilenameToDropBox = _extract_attribute(root, 'outputIQVXMLFilenameToDropBox', str,
                                                           ret.outputIQVXMLFilenameToDropBox)

    ret.OutputLevel = _extract_attribute(root, 'OutputLevel', int, ret.OutputLevel)

    ret.outputMetadataFilename = _extract_attribute(root, 'outputMetadataFilename', str, ret.outputMetadataFilename)

    ret.outputMetatdataFilenameTranslated = _extract_attribute(root, 'outputMetatdataFilenameTranslated', str,
                                                               ret.outputMetatdataFilenameTranslated)

    ret.outputPDFFilename = _extract_attribute(root, 'outputPDFFilename', str, ret.outputPDFFilename)

    ret.outputPDFFilenameToDropBox = _extract_attribute(root, 'outputPDFFilenameToDropBox', str,
                                                        ret.outputPDFFilenameToDropBox)

    ret.outputPDFFilenameTranslated = _extract_attribute(root, 'outputPDFFilenameTranslated', str,
                                                         ret.outputPDFFilenameTranslated)

    ret.outputPDFFilenameTranslatedToDropBox = _extract_attribute(root, 'outputPDFFilenameTranslatedToDropBox', str,
                                                                  ret.outputPDFFilenameTranslatedToDropBox)

    ret.outputWordDocFilename = _extract_attribute(root, 'outputWordDocFilename', str, ret.outputWordDocFilename)

    ret.outputWordDocFilenameDropBox = _extract_attribute(root, 'outputWordDocFilenameDropBox', str,
                                                          ret.outputWordDocFilenameDropBox)

    ret.outputWordDocFilenameTranslated = _extract_attribute(root, 'outputWordDocFilenameTranslated', str,
                                                             ret.outputWordDocFilenameTranslated)

    ret.outputWordDocFilenameTranslatedDropBox = _extract_attribute(root, 'outputWordDocFilenameTranslatedDropBox',
                                                                    str, ret.outputWordDocFilenameTranslatedDropBox)

    ret.outputXLIFFFilename = _extract_attribute(root, 'outputXLIFFFilename', str, ret.outputXLIFFFilename)

    ret.outputXLIFFFilenameDropBox = _extract_attribute(root, 'outputXLIFFFilenameDropBox', str,
                                                        ret.outputXLIFFFilenameDropBox)

    ret.outputXLIFFFilenameT = _extract_attribute(root, 'outputXLIFFFilenameT', str, ret.outputXLIFFFilenameT)

    ret.outputXLIFFFilenameTDropBox = _extract_attribute(root, 'outputXLIFFFilenameTDropBox', str,
                                                         ret.outputXLIFFFilenameTDropBox)

    ret.ProcessFinishTime = _extract_attribute(root, 'ProcessFinishTime', str, ret.ProcessFinishTime)

    ret.ProcessStartTime = _extract_attribute(root, 'ProcessStartTime', str, ret.ProcessStartTime)

    ret.QDocumentWorkingDirectory = _extract_attribute(root, 'QDocumentWorkingDirectory', str,
                                                       ret.QDocumentWorkingDirectory)

    ret.QDocumentWorkingTempDirectory = _extract_attribute(root, 'QDocumentWorkingTempDirectory', str,
                                                           ret.QDocumentWorkingTempDirectory)

    ret.SegmentationFilename_PostSegmentation = _extract_attribute(root, 'SegmentationFilename_PostSegmentation', str,
                                                                   ret.SegmentationFilename_PostSegmentation)

    ret.SegmentationFilename_PreSegmentation = _extract_attribute(root, 'SegmentationFilename_PreSegmentation', str,
                                                                  ret.SegmentationFilename_PreSegmentation)

    ret.SelectedWordTemplateCode = _extract_attribute(root, 'SelectedWordTemplateCode', int,
                                                      ret.SelectedWordTemplateCode)

    ret.SelectedWordTemplateFilename = _extract_attribute(root, 'SelectedWordTemplateFilename', str,
                                                          ret.SelectedWordTemplateFilename)

    ret.sourceFilename = _extract_attribute(root, 'sourceFilename', str, ret.sourceFilename)

    ret.sourceFilenameWorkingCopy = _extract_attribute(root, 'sourceFilenameWorkingCopy', str,
                                                       ret.sourceFilenameWorkingCopy)

    ret.sourceFilenameWorkingCopyToDropBox = _extract_attribute(root, 'sourceFilenameWorkingCopyToDropBox', str,
                                                                ret.sourceFilenameWorkingCopyToDropBox)

    ret.SourceLanguage = _extract_attribute(root, 'SourceLanguage', str, ret.SourceLanguage)

    ret.StandardForm = _extract_attribute(root, 'StandardForm', str, ret.StandardForm)

    ret.StandardFormPageIndex = _extract_attribute(root, 'StandardFormPageIndex', int, ret.StandardFormPageIndex)

    ret.StartPage = _extract_attribute(root, 'StartPage', int, ret.StartPage)

    ret.SubmitterEmail = _extract_attribute(root, 'SubmitterEmail', str, ret.SubmitterEmail)

    ret.SubmitterID = _extract_attribute(root, 'SubmitterID', str, ret.SubmitterID)

    ret.TargetLanguage = _extract_attribute(root, 'TargetLanguage', str, ret.TargetLanguage)

    ret.workingFilename = _extract_attribute(root, 'workingFilename', str, ret.workingFilename)

    ret.workingFilename_NoiseGenerator = _extract_attribute(root, 'workingFilename_NoiseGenerator', str,
                                                            ret.workingFilename_NoiseGenerator)
    return ret


def _readFromXmlToIQVDocument_dbList(branch: ET.ElementTree):
    """
    Read from XML and load memory object, for list of objects
    """
    root = branch
    ret = []
    for child in root:
        if (child.tag == 'IQVDocument_db'):
            try:
                ret.append(_readFromXmlToIQVDocument_db(child))
            except Exception as e:
                # log
                logger.info('Failed to import field ' + child.tag)
    return ret


def _readFromXmlToDocumentPartsList_db(branch):
    """
    Read from XML and load memory object
    """

    # get root element
    root = branch

    # initialize DocumentPartsList_db
    ret = DocumentPartsList_db()

    ret.doc_id = _extract_attribute(root, 'doc_id', str, ret.doc_id)

    ret.group_type = _extract_attribute(root, 'group_type', str, ret.group_type)

    ret.hierarchy = _extract_attribute(root, 'hierarchy', str, ret.hierarchy)

    ret.id = _extract_attribute(root, 'id', str, ret.id)

    ret.iqv_standard_term = _extract_attribute(root, 'iqv_standard_term', str, ret.iqv_standard_term)

    ret.link_id = _extract_attribute(root, 'link_id', str, ret.link_id)

    ret.link_id_level2 = _extract_attribute(root, 'link_id_level2', str, ret.link_id_level2)

    ret.link_id_level3 = _extract_attribute(root, 'link_id_level3', str, ret.link_id_level3)

    ret.link_id_level4 = _extract_attribute(root, 'link_id_level4', str, ret.link_id_level4)

    ret.link_id_level5 = _extract_attribute(root, 'link_id_level5', str, ret.link_id_level5)

    ret.link_id_level6 = _extract_attribute(root, 'link_id_level6', str, ret.link_id_level6)

    ret.link_id_subsection1 = _extract_attribute(root, 'link_id_subsection1', str, ret.link_id_subsection1)

    ret.link_id_subsection2 = _extract_attribute(root, 'link_id_subsection2', str, ret.link_id_subsection2)

    ret.link_id_subsection3 = _extract_attribute(root, 'link_id_subsection3', str, ret.link_id_subsection3)

    ret.parent_id = _extract_attribute(root, 'parent_id', str, ret.parent_id)

    ret.sequence_id = _extract_attribute(root, 'sequence_id', int, ret.sequence_id)
    return ret


def _readFromXmlToDocumentPartsList_dbList(branch: ET.ElementTree):
    """
    Read from XML and load memory object, for list of objects
    """
    root = branch
    ret = []
    for child in root:
        if (child.tag == 'DocumentPartsList_db'):
            try:
                ret.append(_readFromXmlToDocumentPartsList_db(child))
            except Exception as e:
                # log
                logger.info('Failed to import field ' + child.tag)
    return ret


def _readFromXmlToIQVPageROI_db(branch):
    """
    Read from XML and load memory object
    """

    # get root element
    root = branch

    # initialize IQVPageROI_db
    ret = IQVPageROI_db()

    ret.bIsCheckbox = _extract_attribute(root, 'bIsCheckbox', _str2bool, ret.bIsCheckbox)

    ret.bIsChecked = _extract_attribute(root, 'bIsChecked', _str2bool, ret.bIsChecked)

    ret.bIsImage = _extract_attribute(root, 'bIsImage', _str2bool, ret.bIsImage)

    ret.bIsSharedString = _extract_attribute(root, 'bIsSharedString', _str2bool, ret.bIsSharedString)

    ret.bNoTranslate = _extract_attribute(root, 'bNoTranslate', _str2bool, ret.bNoTranslate)

    ret.bOutputImageCreated = _extract_attribute(root, 'bOutputImageCreated', _str2bool, ret.bOutputImageCreated)

    ret.bScannedOCR = _extract_attribute(root, 'bScannedOCR', _str2bool, ret.bScannedOCR)

    ret.BulletIndentationLevel = _extract_attribute(root, 'BulletIndentationLevel', int, ret.BulletIndentationLevel)

    ret.BulletTypeVal = _extract_attribute(root, 'BulletTypeVal', int, ret.BulletTypeVal)

    ret.CheckboxFill = _extract_attribute(root, 'CheckboxFill', float, ret.CheckboxFill)

    ret.contentTypeVal = _extract_attribute(root, 'contentTypeVal', int, ret.contentTypeVal)

    ret.doc_id = _extract_attribute(root, 'doc_id', str, ret.doc_id)

    ret.DocumentRelId = _extract_attribute(root, 'DocumentRelId', str, ret.DocumentRelId)

    ret.DocumentSequenceIndex = _extract_attribute(root, 'DocumentSequenceIndex', int, ret.DocumentSequenceIndex)

    ret.FooterSequence = _extract_attribute(root, 'FooterSequence', int, ret.FooterSequence)

    ret.group_type = _extract_attribute(root, 'group_type', str, ret.group_type)

    ret.GT_ImageFilename = _extract_attribute(root, 'GT_ImageFilename', str, ret.GT_ImageFilename)

    ret.GT_ScoreMatch = _extract_attribute(root, 'GT_ScoreMatch', float, ret.GT_ScoreMatch)

    ret.GT_TextMatch = _extract_attribute(root, 'GT_TextMatch', str, ret.GT_TextMatch)

    ret.hAlignmentVal = _extract_attribute(root, 'hAlignmentVal', int, ret.hAlignmentVal)

    ret.HeaderSequence = _extract_attribute(root, 'HeaderSequence', int, ret.HeaderSequence)

    ret.hierarchy = _extract_attribute(root, 'hierarchy', str, ret.hierarchy)

    ret.HorizontalResolution = _extract_attribute(root, 'HorizontalResolution', float, ret.HorizontalResolution)

    ret.htmlTagType = _extract_attribute(root, 'htmlTagType', str, ret.htmlTagType)

    ret.Hue = _extract_attribute(root, 'Hue', int, ret.Hue)

    ret.id = _extract_attribute(root, 'id', str, ret.id)

    ret.ImageFormatVal = _extract_attribute(root, 'ImageFormatVal', str, ret.ImageFormatVal)

    ret.ImageIndex = _extract_attribute(root, 'ImageIndex', int, ret.ImageIndex)

    ret.imagePaddingPixels = _extract_attribute(root, 'imagePaddingPixels', float, ret.imagePaddingPixels)

    ret.imageScaling = _extract_attribute(root, 'imageScaling', float, ret.imageScaling)

    ret.iqv_standard_term = _extract_attribute(root, 'iqv_standard_term', str, ret.iqv_standard_term)

    ret.IsCopyOfRoiId = _extract_attribute(root, 'IsCopyOfRoiId', str, ret.IsCopyOfRoiId)

    ret.IsTableCell = _extract_attribute(root, 'IsTableCell', _str2bool, ret.IsTableCell)

    ret.link_id = _extract_attribute(root, 'link_id', str, ret.link_id)

    ret.link_id_level2 = _extract_attribute(root, 'link_id_level2', str, ret.link_id_level2)

    ret.link_id_level3 = _extract_attribute(root, 'link_id_level3', str, ret.link_id_level3)

    ret.link_id_level4 = _extract_attribute(root, 'link_id_level4', str, ret.link_id_level4)

    ret.link_id_level5 = _extract_attribute(root, 'link_id_level5', str, ret.link_id_level5)

    ret.link_id_level6 = _extract_attribute(root, 'link_id_level6', str, ret.link_id_level6)

    ret.link_id_subsection1 = _extract_attribute(root, 'link_id_subsection1', str, ret.link_id_subsection1)

    ret.link_id_subsection2 = _extract_attribute(root, 'link_id_subsection2', str, ret.link_id_subsection2)

    ret.link_id_subsection3 = _extract_attribute(root, 'link_id_subsection3', str, ret.link_id_subsection3)

    ret.m_PARENT_ROI_TYPEVal = _extract_attribute(root, 'm_PARENT_ROI_TYPEVal', int, ret.m_PARENT_ROI_TYPEVal)

    ret.m_ROI_TYPEVal = _extract_attribute(root, 'm_ROI_TYPEVal', int, ret.m_ROI_TYPEVal)

    ret.m_WORD_LAYOUTVal = _extract_attribute(root, 'm_WORD_LAYOUTVal', int, ret.m_WORD_LAYOUTVal)

    ret.OriginalROIHeightInches = _extract_attribute(root, 'OriginalROIHeightInches', float,
                                                     ret.OriginalROIHeightInches)

    ret.OriginalROIWidthInches = _extract_attribute(root, 'OriginalROIWidthInches', float, ret.OriginalROIWidthInches)

    ret.OutputImageFilename = _extract_attribute(root, 'OutputImageFilename', str, ret.OutputImageFilename)

    ret.OutputImageFilename_Cleaned = _extract_attribute(root, 'OutputImageFilename_Cleaned', str,
                                                         ret.OutputImageFilename_Cleaned)

    ret.OutputImageFilename_FinalImageProcessingOutput = _extract_attribute(root,
                                                                            'OutputImageFilename_FinalImageProcessingOutput',
                                                                            str,
                                                                            ret.OutputImageFilename_FinalImageProcessingOutput)

    ret.OutputImageFilename_FinalImageProcessingOutputToDropBox = _extract_attribute(root,
                                                                                     'OutputImageFilename_FinalImageProcessingOutputToDropBox',
                                                                                     str,
                                                                                     ret.OutputImageFilename_FinalImageProcessingOutputToDropBox)

    ret.OutputImageFilename_OriginalSegment = _extract_attribute(root, 'OutputImageFilename_OriginalSegment', str,
                                                                 ret.OutputImageFilename_OriginalSegment)

    ret.OutputImageFilename_RotationCorrection = _extract_attribute(root, 'OutputImageFilename_RotationCorrection',
                                                                    str, ret.OutputImageFilename_RotationCorrection)

    ret.OutputImageFilename_RotationCorrectionToDropBox = _extract_attribute(root,
                                                                             'OutputImageFilename_RotationCorrectionToDropBox',
                                                                             str,
                                                                             ret.OutputImageFilename_RotationCorrectionToDropBox)

    ret.OutputImageFilename_Segments = _extract_attribute(root, 'OutputImageFilename_Segments', str,
                                                          ret.OutputImageFilename_Segments)

    ret.OutputImageFilename_SegmentsToDropBox = _extract_attribute(root, 'OutputImageFilename_SegmentsToDropBox', str,
                                                                   ret.OutputImageFilename_SegmentsToDropBox)

    ret.OutputImageFilenameT = _extract_attribute(root, 'OutputImageFilenameT', str, ret.OutputImageFilenameT)

    ret.OutputImageFilenameTDropBox = _extract_attribute(root, 'OutputImageFilenameTDropBox', str,
                                                         ret.OutputImageFilenameTDropBox)

    ret.PageID = _extract_attribute(root, 'PageID', str, ret.PageID)

    ret.PageSequenceIndex = _extract_attribute(root, 'PageSequenceIndex', int, ret.PageSequenceIndex)

    ret.parent_id = _extract_attribute(root, 'parent_id', str, ret.parent_id)

    ret.parentrectangle_height = _extract_attribute(root, 'parentrectangle_height', int, ret.parentrectangle_height)

    ret.parentrectangle_width = _extract_attribute(root, 'parentrectangle_width', int, ret.parentrectangle_width)

    ret.parentrectangle_x = _extract_attribute(root, 'parentrectangle_x', int, ret.parentrectangle_x)

    ret.parentrectangle_y = _extract_attribute(root, 'parentrectangle_y', int, ret.parentrectangle_y)

    ret.rectangle_height = _extract_attribute(root, 'rectangle_height', int, ret.rectangle_height)

    ret.rectangle_width = _extract_attribute(root, 'rectangle_width', int, ret.rectangle_width)

    ret.rectangle_x = _extract_attribute(root, 'rectangle_x', int, ret.rectangle_x)

    ret.rectangle_y = _extract_attribute(root, 'rectangle_y', int, ret.rectangle_y)

    ret.rectangleGlobalLocationOnPage_height = _extract_attribute(root, 'rectangleGlobalLocationOnPage_height', int,
                                                                  ret.rectangleGlobalLocationOnPage_height)

    ret.rectangleGlobalLocationOnPage_width = _extract_attribute(root, 'rectangleGlobalLocationOnPage_width', int,
                                                                 ret.rectangleGlobalLocationOnPage_width)

    ret.rectangleGlobalLocationOnPage_x = _extract_attribute(root, 'rectangleGlobalLocationOnPage_x', int,
                                                             ret.rectangleGlobalLocationOnPage_x)

    ret.rectangleGlobalLocationOnPage_y = _extract_attribute(root, 'rectangleGlobalLocationOnPage_y', int,
                                                             ret.rectangleGlobalLocationOnPage_y)

    ret.Rotation_MajorAxis = _extract_attribute(root, 'Rotation_MajorAxis', int, ret.Rotation_MajorAxis)

    ret.RotationCorrectionDegrees = _extract_attribute(root, 'RotationCorrectionDegrees', float,
                                                       ret.RotationCorrectionDegrees)

    ret.scannedOCRCode = _extract_attribute(root, 'scannedOCRCode', str, ret.scannedOCRCode)

    ret.Score = _extract_attribute(root, 'Score', float, ret.Score)

    ret.SegmentationMethodVal = _extract_attribute(root, 'SegmentationMethodVal', int, ret.SegmentationMethodVal)

    ret.SegmentationType = _extract_attribute(root, 'SegmentationType', int, ret.SegmentationType)

    ret.SequenceID = _extract_attribute(root, 'SequenceID', int, ret.SequenceID)

    ret.SlideIndex = _extract_attribute(root, 'SlideIndex', int, ret.SlideIndex)

    ret.SlideRelationshipId = _extract_attribute(root, 'SlideRelationshipId', str, ret.SlideRelationshipId)

    ret.strText = _extract_attribute(root, 'strText', str, ret.strText)

    ret.strTextTranslated = _extract_attribute(root, 'strTextTranslated', str, ret.strTextTranslated)

    ret.tableCell_colIndex = _extract_attribute(root, 'tableCell_colIndex', int, ret.tableCell_colIndex)

    ret.tableCell_pageIndex = _extract_attribute(root, 'tableCell_pageIndex', int, ret.tableCell_pageIndex)

    ret.tableCell_rowIndex = _extract_attribute(root, 'tableCell_rowIndex', int, ret.tableCell_rowIndex)

    ret.tableCell_SharedStringIndex = _extract_attribute(root, 'tableCell_SharedStringIndex', int,
                                                         ret.tableCell_SharedStringIndex)

    ret.tableCell_SheetCellReference = _extract_attribute(root, 'tableCell_SheetCellReference', str,
                                                          ret.tableCell_SheetCellReference)

    ret.tableCell_SheetColIndex = _extract_attribute(root, 'tableCell_SheetColIndex', int, ret.tableCell_SheetColIndex)

    ret.tableCell_SheetName = _extract_attribute(root, 'tableCell_SheetName', str, ret.tableCell_SheetName)

    ret.tableCell_SheetRowIndex = _extract_attribute(root, 'tableCell_SheetRowIndex', int, ret.tableCell_SheetRowIndex)

    ret.textTypeVal = _extract_attribute(root, 'textTypeVal', int, ret.textTypeVal)

    ret.TranslatedTextNoSegmentation = _extract_attribute(root, 'TranslatedTextNoSegmentation', str,
                                                          ret.TranslatedTextNoSegmentation)

    ret.TranslationMatch = _extract_attribute(root, 'TranslationMatch', float, ret.TranslationMatch)

    ret.TranslationMethod1 = _extract_attribute(root, 'TranslationMethod1', str, ret.TranslationMethod1)

    ret.UncorrectedImageFilename = _extract_attribute(root, 'UncorrectedImageFilename', str,
                                                      ret.UncorrectedImageFilename)

    ret.Value = _extract_attribute(root, 'Value', str, ret.Value)

    ret.VerticalResolution = _extract_attribute(root, 'VerticalResolution', float, ret.VerticalResolution)
    return ret


def _readFromXmlToIQVPageROI_dbList(branch: ET.ElementTree):
    """
    Read from XML and load memory object, for list of objects
    """
    root = branch
    ret = []
    for child in root:
        if (child.tag == 'IQVPageROI_db'):
            try:
                ret.append(_readFromXmlToIQVPageROI_db(child))
            except Exception as e:
                # log
                logger.info('Failed to import field ' + child.tag)
    return ret


def _readFromXmlToIQVDocumentLink_db(branch):
    """
    Read from XML and load memory object
    """

    # get root element
    root = branch

    # initialize IQVDocumentLink_db
    ret = IQVDocumentLink_db()

    ret.doc_id = _extract_attribute(root, 'doc_id', str, ret.doc_id)

    ret.DocumentSequenceIndex = _extract_attribute(root, 'DocumentSequenceIndex', int, ret.DocumentSequenceIndex)

    ret.group_type = _extract_attribute(root, 'group_type', str, ret.group_type)

    ret.hierarchy = _extract_attribute(root, 'hierarchy', str, ret.hierarchy)

    ret.id = _extract_attribute(root, 'id', str, ret.id)

    ret.iqv_standard_term = _extract_attribute(root, 'iqv_standard_term', str, ret.iqv_standard_term)

    ret.link_id = _extract_attribute(root, 'link_id', str, ret.link_id)

    ret.link_id_level2 = _extract_attribute(root, 'link_id_level2', str, ret.link_id_level2)

    ret.link_id_level3 = _extract_attribute(root, 'link_id_level3', str, ret.link_id_level3)

    ret.link_id_level4 = _extract_attribute(root, 'link_id_level4', str, ret.link_id_level4)

    ret.link_id_level5 = _extract_attribute(root, 'link_id_level5', str, ret.link_id_level5)

    ret.link_id_level6 = _extract_attribute(root, 'link_id_level6', str, ret.link_id_level6)

    ret.link_id_subsection1 = _extract_attribute(root, 'link_id_subsection1', str, ret.link_id_subsection1)

    ret.link_id_subsection2 = _extract_attribute(root, 'link_id_subsection2', str, ret.link_id_subsection2)

    ret.link_id_subsection3 = _extract_attribute(root, 'link_id_subsection3', str, ret.link_id_subsection3)

    ret.LinkLevel = _extract_attribute(root, 'LinkLevel', int, ret.LinkLevel)

    ret.LinkPage = _extract_attribute(root, 'LinkPage', int, ret.LinkPage)

    ret.LinkPrefix = _extract_attribute(root, 'LinkPrefix', str, ret.LinkPrefix)

    ret.LinkText = _extract_attribute(root, 'LinkText', str, ret.LinkText)

    ret.LinkType = _extract_attribute(root, 'LinkType', str, ret.LinkType)

    ret.parent_id = _extract_attribute(root, 'parent_id', str, ret.parent_id)
    return ret


def _readFromXmlToIQVDocumentLink_dbList(branch: ET.ElementTree):
    """
    Read from XML and load memory object, for list of objects
    """
    root = branch
    ret = []
    for child in root:
        if (child.tag == 'IQVDocumentLink_db'):
            try:
                ret.append(_readFromXmlToIQVDocumentLink_db(child))
            except Exception as e:
                # log
                logger.info('Failed to import field ' + child.tag)
    return ret


def _readFromXmlToIQVKeyValueSet_db(branch):
    """
    Read from XML and load memory object
    """

    # get root element
    root = branch

    # initialize IQVKeyValueSet_db
    ret = IQVKeyValueSet_db()

    ret.confidence = _extract_attribute(root, 'confidence', float, ret.confidence)

    ret.doc_id = _extract_attribute(root, 'doc_id', str, ret.doc_id)

    ret.group_type = _extract_attribute(root, 'group_type', str, ret.group_type)

    ret.hierarchy = _extract_attribute(root, 'hierarchy', str, ret.hierarchy)

    ret.id = _extract_attribute(root, 'id', str, ret.id)

    ret.iqv_standard_term = _extract_attribute(root, 'iqv_standard_term', str, ret.iqv_standard_term)

    ret.key = _extract_attribute(root, 'key', str, ret.key)

    ret.link_id = _extract_attribute(root, 'link_id', str, ret.link_id)

    ret.link_id_level2 = _extract_attribute(root, 'link_id_level2', str, ret.link_id_level2)

    ret.link_id_level3 = _extract_attribute(root, 'link_id_level3', str, ret.link_id_level3)

    ret.link_id_level4 = _extract_attribute(root, 'link_id_level4', str, ret.link_id_level4)

    ret.link_id_level5 = _extract_attribute(root, 'link_id_level5', str, ret.link_id_level5)

    ret.link_id_level6 = _extract_attribute(root, 'link_id_level6', str, ret.link_id_level6)

    ret.link_id_subsection1 = _extract_attribute(root, 'link_id_subsection1', str, ret.link_id_subsection1)

    ret.link_id_subsection2 = _extract_attribute(root, 'link_id_subsection2', str, ret.link_id_subsection2)

    ret.link_id_subsection3 = _extract_attribute(root, 'link_id_subsection3', str, ret.link_id_subsection3)

    ret.parent_id = _extract_attribute(root, 'parent_id', str, ret.parent_id)

    ret.rawScore = _extract_attribute(root, 'rawScore', float, ret.rawScore)

    ret.source_system = _extract_attribute(root, 'source_system', str, ret.source_system)

    ret.value = _extract_attribute(root, 'value', str, ret.value)
    return ret


def _readFromXmlToIQVKeyValueSet_dbList(branch: ET.ElementTree):
    """
    Read from XML and load memory object, for list of objects
    """
    root = branch
    ret = []
    for child in root:
        if (child.tag == 'IQVKeyValueSet_db'):
            try:
                ret.append(_readFromXmlToIQVKeyValueSet_db(child))
            except Exception as e:
                # log
                logger.info('Failed to import field ' + child.tag)
    return ret


def _readFromXmlToIQVQCUpdateTracking_db(branch):
    """
    Read from XML and load memory object
    """

    # get root element
    root = branch

    # initialize IQVQCUpdateTracking_db
    ret = IQVQCUpdateTracking_db()

    ret.doc_id = _extract_attribute(root, 'doc_id', str, ret.doc_id)

    ret.dts = _extract_attribute(root, 'dts', str, ret.dts)

    ret.group_type = _extract_attribute(root, 'group_type', str, ret.group_type)

    ret.hierarchy = _extract_attribute(root, 'hierarchy', str, ret.hierarchy)

    ret.id = _extract_attribute(root, 'id', str, ret.id)

    ret.iqv_standard_term = _extract_attribute(root, 'iqv_standard_term', str, ret.iqv_standard_term)

    ret.ItemDataType = _extract_attribute(root, 'ItemDataType', str, ret.ItemDataType)

    ret.link_id = _extract_attribute(root, 'link_id', str, ret.link_id)

    ret.link_id_level2 = _extract_attribute(root, 'link_id_level2', str, ret.link_id_level2)

    ret.link_id_level3 = _extract_attribute(root, 'link_id_level3', str, ret.link_id_level3)

    ret.link_id_level4 = _extract_attribute(root, 'link_id_level4', str, ret.link_id_level4)

    ret.link_id_level5 = _extract_attribute(root, 'link_id_level5', str, ret.link_id_level5)

    ret.link_id_level6 = _extract_attribute(root, 'link_id_level6', str, ret.link_id_level6)

    ret.link_id_subsection1 = _extract_attribute(root, 'link_id_subsection1', str, ret.link_id_subsection1)

    ret.link_id_subsection2 = _extract_attribute(root, 'link_id_subsection2', str, ret.link_id_subsection2)

    ret.link_id_subsection3 = _extract_attribute(root, 'link_id_subsection3', str, ret.link_id_subsection3)

    ret.OriginalText = _extract_attribute(root, 'OriginalText', str, ret.OriginalText)

    ret.parent_id = _extract_attribute(root, 'parent_id', str, ret.parent_id)

    ret.QC_id = _extract_attribute(root, 'QC_id', str, ret.QC_id)

    ret.QCType = _extract_attribute(root, 'QCType', str, ret.QCType)

    ret.roi_id = _extract_attribute(root, 'roi_id', str, ret.roi_id)

    ret.seq_num = _extract_attribute(root, 'seq_num', int, ret.seq_num)

    ret.source_system = _extract_attribute(root, 'source_system', str, ret.source_system)

    ret.UpdatedText = _extract_attribute(root, 'UpdatedText', str, ret.UpdatedText)

    ret.user_id = _extract_attribute(root, 'user_id', str, ret.user_id)
    return ret


def _readFromXmlToIQVQCUpdateTracking_dbList(branch: ET.ElementTree):
    """
    Read from XML and load memory object, for list of objects
    """
    root = branch
    ret = []
    for child in root:
        if (child.tag == 'IQVQCUpdateTracking_db'):
            try:
                ret.append(_readFromXmlToIQVQCUpdateTracking_db(child))
            except Exception as e:
                # log
                logger.info('Failed to import field ' + child.tag)
    return ret


def _readFromXmlToIQVDocumentProcess_db(branch):
    """
    Read from XML and load memory object
    """

    # get root element
    root = branch

    # initialize IQVDocumentProcess_db
    ret = IQVDocumentProcess_db()

    ret.bProcessRequired = _extract_attribute(root, 'bProcessRequired', _str2bool, ret.bProcessRequired)

    ret.doc_id = _extract_attribute(root, 'doc_id', str, ret.doc_id)

    ret.group_type = _extract_attribute(root, 'group_type', str, ret.group_type)

    ret.hierarchy = _extract_attribute(root, 'hierarchy', str, ret.hierarchy)

    ret.id = _extract_attribute(root, 'id', str, ret.id)

    ret.iqv_standard_term = _extract_attribute(root, 'iqv_standard_term', str, ret.iqv_standard_term)

    ret.link_id = _extract_attribute(root, 'link_id', str, ret.link_id)

    ret.link_id_level2 = _extract_attribute(root, 'link_id_level2', str, ret.link_id_level2)

    ret.link_id_level3 = _extract_attribute(root, 'link_id_level3', str, ret.link_id_level3)

    ret.link_id_level4 = _extract_attribute(root, 'link_id_level4', str, ret.link_id_level4)

    ret.link_id_level5 = _extract_attribute(root, 'link_id_level5', str, ret.link_id_level5)

    ret.link_id_level6 = _extract_attribute(root, 'link_id_level6', str, ret.link_id_level6)

    ret.link_id_subsection1 = _extract_attribute(root, 'link_id_subsection1', str, ret.link_id_subsection1)

    ret.link_id_subsection2 = _extract_attribute(root, 'link_id_subsection2', str, ret.link_id_subsection2)

    ret.link_id_subsection3 = _extract_attribute(root, 'link_id_subsection3', str, ret.link_id_subsection3)

    ret.parent_id = _extract_attribute(root, 'parent_id', str, ret.parent_id)

    ret.ProcessEnvironment = _extract_attribute(root, 'ProcessEnvironment', str, ret.ProcessEnvironment)

    ret.ProcessFinishTime = _extract_attribute(root, 'ProcessFinishTime', str, ret.ProcessFinishTime)

    ret.ProcessMachineName = _extract_attribute(root, 'ProcessMachineName', str, ret.ProcessMachineName)

    ret.ProcessName = _extract_attribute(root, 'ProcessName', str, ret.ProcessName)

    ret.ProcessStartTime = _extract_attribute(root, 'ProcessStartTime', str, ret.ProcessStartTime)

    ret.ProcessType = _extract_attribute(root, 'ProcessType', str, ret.ProcessType)

    ret.ProcessUserID = _extract_attribute(root, 'ProcessUserID', str, ret.ProcessUserID)

    ret.ProcessVersion = _extract_attribute(root, 'ProcessVersion', str, ret.ProcessVersion)

    ret.ProcessVersionHash = _extract_attribute(root, 'ProcessVersionHash', str, ret.ProcessVersionHash)
    return ret


def _readFromXmlToIQVDocumentProcess_dbList(branch: ET.ElementTree):
    """
    Read from XML and load memory object, for list of objects
    """
    root = branch
    ret = []
    for child in root:
        if (child.tag == 'IQVDocumentProcess_db'):
            try:
                ret.append(_readFromXmlToIQVDocumentProcess_db(child))
            except Exception as e:
                # log
                logger.info('Failed to import field ' + child.tag)
    return ret


def _readFromXmlToIQVSubText_db(branch):
    """
    Read from XML and load memory object
    """

    # get root element
    root = branch

    # initialize IQVSubText_db
    ret = IQVSubText_db()

    ret.bNoTranslate = _extract_attribute(root, 'bNoTranslate', _str2bool, ret.bNoTranslate)

    ret.doc_id = _extract_attribute(root, 'doc_id', str, ret.doc_id)

    ret.DocumentSequenceIndex = _extract_attribute(root, 'DocumentSequenceIndex', int, ret.DocumentSequenceIndex)

    ret.group_type = _extract_attribute(root, 'group_type', str, ret.group_type)

    ret.hierarchy = _extract_attribute(root, 'hierarchy', str, ret.hierarchy)

    ret.id = _extract_attribute(root, 'id', str, ret.id)

    ret.iqv_standard_term = _extract_attribute(root, 'iqv_standard_term', str, ret.iqv_standard_term)

    ret.link_id = _extract_attribute(root, 'link_id', str, ret.link_id)

    ret.link_id_level2 = _extract_attribute(root, 'link_id_level2', str, ret.link_id_level2)

    ret.link_id_level3 = _extract_attribute(root, 'link_id_level3', str, ret.link_id_level3)

    ret.link_id_level4 = _extract_attribute(root, 'link_id_level4', str, ret.link_id_level4)

    ret.link_id_level5 = _extract_attribute(root, 'link_id_level5', str, ret.link_id_level5)

    ret.link_id_level6 = _extract_attribute(root, 'link_id_level6', str, ret.link_id_level6)

    ret.link_id_subsection1 = _extract_attribute(root, 'link_id_subsection1', str, ret.link_id_subsection1)

    ret.link_id_subsection2 = _extract_attribute(root, 'link_id_subsection2', str, ret.link_id_subsection2)

    ret.link_id_subsection3 = _extract_attribute(root, 'link_id_subsection3', str, ret.link_id_subsection3)

    ret.OuterXml = _extract_attribute(root, 'OuterXml', str, ret.OuterXml)

    ret.parent_id = _extract_attribute(root, 'parent_id', str, ret.parent_id)

    ret.parent2LocalName = _extract_attribute(root, 'parent2LocalName', str, ret.parent2LocalName)

    ret.reservedTypeVal = _extract_attribute(root, 'reservedTypeVal', int, ret.reservedTypeVal)

    ret.runElementName = _extract_attribute(root, 'runElementName', str, ret.runElementName)

    ret.sequence = _extract_attribute(root, 'sequence', int, ret.sequence)

    ret.startCharIndex = _extract_attribute(root, 'startCharIndex', int, ret.startCharIndex)

    ret.strText = _extract_attribute(root, 'strText', str, ret.strText)

    ret.strTranslatedText = _extract_attribute(root, 'strTranslatedText', str, ret.strTranslatedText)

    ret.Value = _extract_attribute(root, 'Value', str, ret.Value)
    return ret


def _readFromXmlToIQVSubText_dbList(branch: ET.ElementTree):
    """
    Read from XML and load memory object, for list of objects
    """
    root = branch
    ret = []
    for child in root:
        if (child.tag == 'IQVSubText_db'):
            try:
                ret.append(_readFromXmlToIQVSubText_db(child))
            except Exception as e:
                # log
                logger.info('Failed to import field ' + child.tag)
    return ret


def _readFromXmlToIQVDocumentFeedbackQC_db(branch):
    """
    Read from XML and load memory object
    """

    # get root element
    root = branch

    # initialize IQVDocumentFeedbackQC_db
    ret = IQVDocumentFeedbackQC_db()

    ret.bIsActive = _extract_attribute(root, 'bIsActive', _str2bool, ret.bIsActive)

    ret.doc_id = _extract_attribute(root, 'doc_id', str, ret.doc_id)

    ret.documentFilePath = _extract_attribute(root, 'documentFilePath', str, ret.documentFilePath)

    ret.fileName = _extract_attribute(root, 'fileName', str, ret.fileName)

    ret.group_type = _extract_attribute(root, 'group_type', str, ret.group_type)

    ret.hierarchy = _extract_attribute(root, 'hierarchy', str, ret.hierarchy)

    ret.id = _extract_attribute(root, 'id', str, ret.id)

    ret.iqv_standard_term = _extract_attribute(root, 'iqv_standard_term', str, ret.iqv_standard_term)

    ret.link_id = _extract_attribute(root, 'link_id', str, ret.link_id)

    ret.link_id_level2 = _extract_attribute(root, 'link_id_level2', str, ret.link_id_level2)

    ret.link_id_level3 = _extract_attribute(root, 'link_id_level3', str, ret.link_id_level3)

    ret.link_id_level4 = _extract_attribute(root, 'link_id_level4', str, ret.link_id_level4)

    ret.link_id_level5 = _extract_attribute(root, 'link_id_level5', str, ret.link_id_level5)

    ret.link_id_level6 = _extract_attribute(root, 'link_id_level6', str, ret.link_id_level6)

    ret.link_id_subsection1 = _extract_attribute(root, 'link_id_subsection1', str, ret.link_id_subsection1)

    ret.link_id_subsection2 = _extract_attribute(root, 'link_id_subsection2', str, ret.link_id_subsection2)

    ret.link_id_subsection3 = _extract_attribute(root, 'link_id_subsection3', str, ret.link_id_subsection3)

    ret.parent_id = _extract_attribute(root, 'parent_id', str, ret.parent_id)

    ret.source_system = _extract_attribute(root, 'source_system', str, ret.source_system)

    ret.timeCreated = _extract_attribute(root, 'timeCreated', str, ret.timeCreated)

    ret.timeUpdated = _extract_attribute(root, 'timeUpdated', str, ret.timeUpdated)

    ret.userId = _extract_attribute(root, 'userId', str, ret.userId)
    return ret


def _readFromXmlToIQVDocumentFeedbackQC_dbList(branch: ET.ElementTree):
    """
    Read from XML and load memory object, for list of objects
    """
    root = branch
    ret = []
    for child in root:
        if (child.tag == 'IQVDocumentFeedbackQC_db'):
            try:
                ret.append(_readFromXmlToIQVDocumentFeedbackQC_db(child))
            except Exception as e:
                # log
                logger.info('Failed to import field ' + child.tag)
    return ret


def _readFromXmlToIQVDocumentFeedbackResults_db(branch):
    """
    Read from XML and load memory object
    """

    # get root element
    root = branch

    # initialize IQVDocumentFeedbackResults_db
    ret = IQVDocumentFeedbackResults_db()

    ret.alcoac_check_composite_score = _extract_attribute(root, 'alcoac_check_composite_score', float,
                                                          ret.alcoac_check_composite_score)

    ret.alcoac_check_composite_score_confidence = _extract_attribute(root, 'alcoac_check_composite_score_confidence',
                                                                     float, ret.alcoac_check_composite_score_confidence)

    ret.amendment_number = _extract_attribute(root, 'amendment_number', str, ret.amendment_number)

    ret.blinded = _extract_attribute(root, 'blinded', _str2bool, ret.blinded)

    ret.country = _extract_attribute(root, 'country', str, ret.country)

    ret.customer = _extract_attribute(root, 'customer', str, ret.customer)

    ret.date_time_stamp = _extract_attribute(root, 'date_time_stamp', str, ret.date_time_stamp)

    ret.doc_id = _extract_attribute(root, 'doc_id', str, ret.doc_id)

    ret.document_class = _extract_attribute(root, 'document_class', str, ret.document_class)

    ret.document_composite_confidence = _extract_attribute(root, 'document_composite_confidence', float,
                                                           ret.document_composite_confidence)

    ret.document_date = _extract_attribute(root, 'document_date', str, ret.document_date)

    ret.document_date_confidence = _extract_attribute(root, 'document_date_confidence', float,
                                                      ret.document_date_confidence)

    ret.document_date_type = _extract_attribute(root, 'document_date_type', str, ret.document_date_type)

    ret.document_id = _extract_attribute(root, 'document_id', str, ret.document_id)

    ret.document_rejected = _extract_attribute(root, 'document_rejected', str, ret.document_rejected)

    ret.document_status = _extract_attribute(root, 'document_status', str, ret.document_status)

    ret.draft_number = _extract_attribute(root, 'draft_number', str, ret.draft_number)

    ret.environment = _extract_attribute(root, 'environment', str, ret.environment)

    ret.expiry_date = _extract_attribute(root, 'expiry_date', str, ret.expiry_date)

    ret.expiry_date_confidence = _extract_attribute(root, 'expiry_date_confidence', float, ret.expiry_date_confidence)

    ret.feedback_source = _extract_attribute(root, 'feedback_source', str, ret.feedback_source)

    ret.feedback_source_version = _extract_attribute(root, 'feedback_source_version', str, ret.feedback_source_version)

    ret.group_type = _extract_attribute(root, 'group_type', str, ret.group_type)

    ret.hierarchy = _extract_attribute(root, 'hierarchy', str, ret.hierarchy)

    ret.id = _extract_attribute(root, 'id', str, ret.id)

    ret.indication = _extract_attribute(root, 'indication', str, ret.indication)

    ret.iqv_standard_term = _extract_attribute(root, 'iqv_standard_term', str, ret.iqv_standard_term)

    ret.iqvdata = _extract_attribute(root, 'iqvdata', str, ret.iqvdata)

    ret.language = _extract_attribute(root, 'language', str, ret.language)

    ret.language_confidence = _extract_attribute(root, 'language_confidence', float, ret.language_confidence)

    ret.link_id = _extract_attribute(root, 'link_id', str, ret.link_id)

    ret.link_id_level2 = _extract_attribute(root, 'link_id_level2', str, ret.link_id_level2)

    ret.link_id_level3 = _extract_attribute(root, 'link_id_level3', str, ret.link_id_level3)

    ret.link_id_level4 = _extract_attribute(root, 'link_id_level4', str, ret.link_id_level4)

    ret.link_id_level5 = _extract_attribute(root, 'link_id_level5', str, ret.link_id_level5)

    ret.link_id_level6 = _extract_attribute(root, 'link_id_level6', str, ret.link_id_level6)

    ret.link_id_subsection1 = _extract_attribute(root, 'link_id_subsection1', str, ret.link_id_subsection1)

    ret.link_id_subsection2 = _extract_attribute(root, 'link_id_subsection2', str, ret.link_id_subsection2)

    ret.link_id_subsection3 = _extract_attribute(root, 'link_id_subsection3', str, ret.link_id_subsection3)

    ret.molecule_device = _extract_attribute(root, 'molecule_device', str, ret.molecule_device)

    ret.name = _extract_attribute(root, 'name', str, ret.name)

    ret.name_confidence = _extract_attribute(root, 'name_confidence', float, ret.name_confidence)

    ret.parent_id = _extract_attribute(root, 'parent_id', str, ret.parent_id)

    ret.post_data = _extract_attribute(root, 'post_data', str, ret.post_data)

    ret.priority = _extract_attribute(root, 'priority', str, ret.priority)

    ret.project_id = _extract_attribute(root, 'project_id', str, ret.project_id)

    ret.protocol = _extract_attribute(root, 'protocol', str, ret.protocol)

    ret.received_date = _extract_attribute(root, 'received_date', str, ret.received_date)

    ret.ref_id = _extract_attribute(root, 'ref_id', str, ret.ref_id)

    ret.ref_id_type = _extract_attribute(root, 'ref_id_type', str, ret.ref_id_type)

    ret.site = _extract_attribute(root, 'site', str, ret.site)

    ret.source_filename = _extract_attribute(root, 'source_filename', str, ret.source_filename)

    ret.source_system = _extract_attribute(root, 'source_system', str, ret.source_system)

    ret.sponsor = _extract_attribute(root, 'sponsor', str, ret.sponsor)

    ret.study_status = _extract_attribute(root, 'study_status', str, ret.study_status)

    ret.subject = _extract_attribute(root, 'subject', str, ret.subject)

    ret.subject_confidence = _extract_attribute(root, 'subject_confidence', float, ret.subject_confidence)

    ret.tmf_environment = _extract_attribute(root, 'tmf_environment', str, ret.tmf_environment)

    ret.tmf_ibr = _extract_attribute(root, 'tmf_ibr', str, ret.tmf_ibr)

    ret.user_id = _extract_attribute(root, 'user_id', str, ret.user_id)

    ret.version_number = _extract_attribute(root, 'version_number', str, ret.version_number)
    return ret


def _readFromXmlToIQVDocumentFeedbackResults_dbList(branch: ET.ElementTree):
    """
    Read from XML and load memory object, for list of objects
    """
    root = branch
    ret = []
    for child in root:
        if (child.tag == 'IQVDocumentFeedbackResults_db'):
            try:
                ret.append(_readFromXmlToIQVDocumentFeedbackResults_db(child))
            except Exception as e:
                # log
                logger.info('Failed to import field ' + child.tag)
    return ret


def _readFromXmlToIQVLanguageMapping_db(branch):
    """
    Read from XML and load memory object
    """

    # get root element
    root = branch

    # initialize IQVLanguageMapping_db
    ret = IQVLanguageMapping_db()

    ret.HistoricalCount = _extract_attribute(root, 'HistoricalCount', int, ret.HistoricalCount)

    ret.HistoricalCountWeight = _extract_attribute(root, 'HistoricalCountWeight', float, ret.HistoricalCountWeight)

    ret.id = _extract_attribute(root, 'id', str, ret.id)

    ret.script_list = _extract_attribute(root, 'script_list', str, ret.script_list)
    return ret


def _readFromXmlToIQVLanguageMapping_dbList(branch: ET.ElementTree):
    """
    Read from XML and load memory object, for list of objects
    """
    root = branch
    ret = []
    for child in root:
        if (child.tag == 'IQVLanguageMapping_db'):
            try:
                ret.append(_readFromXmlToIQVLanguageMapping_db(child))
            except Exception as e:
                # log
                logger.info('Failed to import field ' + child.tag)
    return ret


def _readFromXmlToLanguageCode_db(branch):
    """
    Read from XML and load memory object
    """

    # get root element
    root = branch

    # initialize LanguageCode_db
    ret = LanguageCode_db()

    ret.code = _extract_attribute(root, 'code', str, ret.code)

    ret.description = _extract_attribute(root, 'description', str, ret.description)

    ret.eTMFCode = _extract_attribute(root, 'eTMFCode', str, ret.eTMFCode)

    ret.fourLetterCode = _extract_attribute(root, 'fourLetterCode', str, ret.fourLetterCode)

    ret.id = _extract_attribute(root, 'id', str, ret.id)

    ret.ReleaseVersionAvailability = _extract_attribute(root, 'ReleaseVersionAvailability', int,
                                                        ret.ReleaseVersionAvailability)

    ret.tesseractCode = _extract_attribute(root, 'tesseractCode', str, ret.tesseractCode)
    return ret


def _readFromXmlToLanguageCode_dbList(branch: ET.ElementTree):
    """
    Read from XML and load memory object, for list of objects
    """
    root = branch
    ret = []
    for child in root:
        if (child.tag == 'LanguageCode_db'):
            try:
                ret.append(_readFromXmlToLanguageCode_db(child))
            except Exception as e:
                # log
                logger.info('Failed to import field ' + child.tag)
    return ret


def _readFromXmlToIQVDocumentMapping_db(branch):
    """
    Read from XML and load memory object
    """

    # get root element
    root = branch

    # initialize IQVDocumentMapping_db
    ret = IQVDocumentMapping_db()

    ret.Additional_instructions = _extract_attribute(root, 'Additional_instructions', str, ret.Additional_instructions)

    ret.CONTENT_TYPE = _extract_attribute(root, 'CONTENT_TYPE', str, ret.CONTENT_TYPE)

    ret.DateGuidance = _extract_attribute(root, 'DateGuidance', str, ret.DateGuidance)

    ret.DateGuidanceSecondary = _extract_attribute(root, 'DateGuidanceSecondary', str, ret.DateGuidanceSecondary)

    ret.DIA_KEY = _extract_attribute(root, 'DIA_KEY', str, ret.DIA_KEY)

    ret.DOC_ABBREVIATION = _extract_attribute(root, 'DOC_ABBREVIATION', str, ret.DOC_ABBREVIATION)

    ret.DOC_ARTIFACT = _extract_attribute(root, 'DOC_ARTIFACT', str, ret.DOC_ARTIFACT)

    ret.DOC_CLASS = _extract_attribute(root, 'DOC_CLASS', str, ret.DOC_CLASS)

    ret.DOC_COUNT = _extract_attribute(root, 'DOC_COUNT', int, ret.DOC_COUNT)

    ret.DOC_COUNT_CURRENT = _extract_attribute(root, 'DOC_COUNT_CURRENT', int, ret.DOC_COUNT_CURRENT)

    ret.DOC_SECTION = _extract_attribute(root, 'DOC_SECTION', str, ret.DOC_SECTION)

    ret.DOC_ZONE = _extract_attribute(root, 'DOC_ZONE', str, ret.DOC_ZONE)

    ret.Document_Description = _extract_attribute(root, 'Document_Description', str, ret.Document_Description)

    ret.ExpirationDateExpected = _extract_attribute(root, 'ExpirationDateExpected', int, ret.ExpirationDateExpected)

    ret.Full_Classification_Historical = _extract_attribute(root, 'Full_Classification_Historical', str,
                                                            ret.Full_Classification_Historical)

    ret.Full_Classification_Wingspan = _extract_attribute(root, 'Full_Classification_Wingspan', str,
                                                          ret.Full_Classification_Wingspan)

    ret.id = _extract_attribute(root, 'id', str, ret.id)

    ret.MLClassificationGroup = _extract_attribute(root, 'MLClassificationGroup', str, ret.MLClassificationGroup)

    ret.MLClassificationRole = _extract_attribute(root, 'MLClassificationRole', str, ret.MLClassificationRole)

    ret.MLConfusionCluster = _extract_attribute(root, 'MLConfusionCluster', str, ret.MLConfusionCluster)

    ret.Subject = _extract_attribute(root, 'Subject', str, ret.Subject)

    ret.Subtype = _extract_attribute(root, 'Subtype', str, ret.Subtype)

    ret.TargetSystemName = _extract_attribute(root, 'TargetSystemName', str, ret.TargetSystemName)

    ret.TargetSystemVersion = _extract_attribute(root, 'TargetSystemVersion', str, ret.TargetSystemVersion)

    ret.Wingspan_DIA = _extract_attribute(root, 'Wingspan_DIA', str, ret.Wingspan_DIA)

    ret.Wingspan_Doc_ID = _extract_attribute(root, 'Wingspan_Doc_ID', str, ret.Wingspan_Doc_ID)

    ret.Wingspan_doc_type = _extract_attribute(root, 'Wingspan_doc_type', str, ret.Wingspan_doc_type)
    return ret


def _readFromXmlToIQVDocumentMapping_dbList(branch: ET.ElementTree):
    """
    Read from XML and load memory object, for list of objects
    """
    root = branch
    ret = []
    for child in root:
        if (child.tag == 'IQVDocumentMapping_db'):
            try:
                ret.append(_readFromXmlToIQVDocumentMapping_db(child))
            except Exception as e:
                # log
                logger.info('Failed to import field ' + child.tag)
    return ret


def _readFromXmlToConfig_db(branch):
    """
    Read from XML and load memory object
    """

    # get root element
    root = branch

    # initialize Config_db
    ret = Config_db()

    ret.AIDocQueue_IsAdmin = _extract_attribute(root, 'AIDocQueue_IsAdmin', int, ret.AIDocQueue_IsAdmin)

    ret.AIDocQueue_IsWorker = _extract_attribute(root, 'AIDocQueue_IsWorker', int, ret.AIDocQueue_IsWorker)

    ret.AIDocQueue_NumWorkers = _extract_attribute(root, 'AIDocQueue_NumWorkers', int, ret.AIDocQueue_NumWorkers)

    ret.API_Endpoint = _extract_attribute(root, 'API_Endpoint', str, ret.API_Endpoint)

    ret.API_Key = _extract_attribute(root, 'API_Key', str, ret.API_Key)

    ret.bClearWorkingDirectory = _extract_attribute(root, 'bClearWorkingDirectory', int, ret.bClearWorkingDirectory)

    ret.bCorrectRotation = _extract_attribute(root, 'bCorrectRotation', int, ret.bCorrectRotation)

    ret.bDeleteAllFilesExceptFinalizerOutputFile = _extract_attribute(root,
                                                                      'bDeleteAllFilesExceptFinalizerOutputFile',
                                                                      _str2bool,
                                                                      ret.bDeleteAllFilesExceptFinalizerOutputFile)

    ret.bDeleteInputSourceFile = _extract_attribute(root, 'bDeleteInputSourceFile', _str2bool,
                                                    ret.bDeleteInputSourceFile)

    ret.bDeleteWorkingTempDirOnSuccessComplete = _extract_attribute(root, 'bDeleteWorkingTempDirOnSuccessComplete',
                                                                    int, ret.bDeleteWorkingTempDirOnSuccessComplete)

    ret.bDictionaryBernoulliSingleCounts = _extract_attribute(root, 'bDictionaryBernoulliSingleCounts', int,
                                                              ret.bDictionaryBernoulliSingleCounts)

    ret.bDocumentManagerEXE_CloseAfterProcessDocument = _extract_attribute(root,
                                                                           'bDocumentManagerEXE_CloseAfterProcessDocument',
                                                                           int,
                                                                           ret.bDocumentManagerEXE_CloseAfterProcessDocument)

    ret.bELK_EnableLogging = _extract_attribute(root, 'bELK_EnableLogging', int, ret.bELK_EnableLogging)

    ret.bMSG_EnableMessaging = _extract_attribute(root, 'bMSG_EnableMessaging', int, ret.bMSG_EnableMessaging)

    ret.bMSG_EnableMessaging_CompareProcessing = _extract_attribute(root, 'bMSG_EnableMessaging_CompareProcessing',
                                                                    int, ret.bMSG_EnableMessaging_CompareProcessing)

    ret.bMSG_EnableMessaging_Digitizer2Processing = _extract_attribute(root,
                                                                       'bMSG_EnableMessaging_Digitizer2Processing',
                                                                       int,
                                                                       ret.bMSG_EnableMessaging_Digitizer2Processing)

    ret.bMSG_EnableMessaging_OMOPGenerate = _extract_attribute(root, 'bMSG_EnableMessaging_OMOPGenerate', int,
                                                               ret.bMSG_EnableMessaging_OMOPGenerate)

    ret.bMSG_EnableMessaging_OMOPProcessing = _extract_attribute(root, 'bMSG_EnableMessaging_OMOPProcessing', int,
                                                                 ret.bMSG_EnableMessaging_OMOPProcessing)

    ret.bMSG_EnableMessaging_QCFeedbackProcessing = _extract_attribute(root,
                                                                       'bMSG_EnableMessaging_QCFeedbackProcessing',
                                                                       int,
                                                                       ret.bMSG_EnableMessaging_QCFeedbackProcessing)

    ret.bNoiseGenGreyscale = _extract_attribute(root, 'bNoiseGenGreyscale', _str2bool, ret.bNoiseGenGreyscale)

    ret.bNoiseGenLegibility = _extract_attribute(root, 'bNoiseGenLegibility', _str2bool, ret.bNoiseGenLegibility)

    ret.bNoiseGenPageBlanks = _extract_attribute(root, 'bNoiseGenPageBlanks', _str2bool, ret.bNoiseGenPageBlanks)

    ret.bNoiseGenPageOrientation = _extract_attribute(root, 'bNoiseGenPageOrientation', _str2bool,
                                                      ret.bNoiseGenPageOrientation)

    ret.bNoiseGenPageSequence = _extract_attribute(root, 'bNoiseGenPageSequence', _str2bool, ret.bNoiseGenPageSequence)

    ret.bOCRRaiseErrorIfScan = _extract_attribute(root, 'bOCRRaiseErrorIfScan', int, ret.bOCRRaiseErrorIfScan)

    ret.bOutput_OmopPrefixText = _extract_attribute(root, 'bOutput_OmopPrefixText', int, ret.bOutput_OmopPrefixText)

    ret.bOutput_PrefixText = _extract_attribute(root, 'bOutput_PrefixText', int, ret.bOutput_PrefixText)

    ret.bOutput_QCFeedbackPrefixText = _extract_attribute(root, 'bOutput_QCFeedbackPrefixText', int,
                                                          ret.bOutput_QCFeedbackPrefixText)

    ret.bOutput_ToMetricsDir = _extract_attribute(root, 'bOutput_ToMetricsDir', int, ret.bOutput_ToMetricsDir)

    ret.bProvideRemoteService = _extract_attribute(root, 'bProvideRemoteService', int, ret.bProvideRemoteService)

    ret.bRunInternalOCRProcesses = _extract_attribute(root, 'bRunInternalOCRProcesses', int,
                                                      ret.bRunInternalOCRProcesses)

    ret.bRunPyIPOCRProcesses = _extract_attribute(root, 'bRunPyIPOCRProcesses', int, ret.bRunPyIPOCRProcesses)

    ret.bTMFGTOutputConstrained = _extract_attribute(root, 'bTMFGTOutputConstrained', _str2bool,
                                                     ret.bTMFGTOutputConstrained)

    ret.bUseDBConnection = _extract_attribute(root, 'bUseDBConnection', int, ret.bUseDBConnection)

    ret.bUseMTServer = _extract_attribute(root, 'bUseMTServer', int, ret.bUseMTServer)

    ret.bUseSegServer = _extract_attribute(root, 'bUseSegServer', int, ret.bUseSegServer)

    ret.bWatchLog_EnableWebserverRequests = _extract_attribute(root, 'bWatchLog_EnableWebserverRequests', int,
                                                               ret.bWatchLog_EnableWebserverRequests)

    ret.ConfigFilename = _extract_attribute(root, 'ConfigFilename', str, ret.ConfigFilename)

    ret.CorpusLevel = _extract_attribute(root, 'CorpusLevel', int, ret.CorpusLevel)

    ret.CorrectRotation_RotationIncrementDegrees = _extract_attribute(root,
                                                                      'CorrectRotation_RotationIncrementDegrees',
                                                                      float,
                                                                      ret.CorrectRotation_RotationIncrementDegrees)

    ret.CorrectRotation_RotationRangeDegrees = _extract_attribute(root, 'CorrectRotation_RotationRangeDegrees', float,
                                                                  ret.CorrectRotation_RotationRangeDegrees)

    ret.CountryMappingFilename = _extract_attribute(root, 'CountryMappingFilename', str, ret.CountryMappingFilename)

    ret.CustomHostName = _extract_attribute(root, 'CustomHostName', str, ret.CustomHostName)

    ret.DataSplit_TestPercent = _extract_attribute(root, 'DataSplit_TestPercent', int, ret.DataSplit_TestPercent)

    ret.DataSplit_TrainingPercent = _extract_attribute(root, 'DataSplit_TrainingPercent', int,
                                                       ret.DataSplit_TrainingPercent)

    ret.DBConn_Database = _extract_attribute(root, 'DBConn_Database', str, ret.DBConn_Database)

    ret.DBConn_Login = _extract_attribute(root, 'DBConn_Login', str, ret.DBConn_Login)

    ret.DBConn_Password = _extract_attribute(root, 'DBConn_Password', str, ret.DBConn_Password)

    ret.DBConn_Server = _extract_attribute(root, 'DBConn_Server', str, ret.DBConn_Server)

    ret.DebugMode = _extract_attribute(root, 'DebugMode', int, ret.DebugMode)

    ret.DebugType = _extract_attribute(root, 'DebugType', int, ret.DebugType)

    ret.DefaultRotation = _extract_attribute(root, 'DefaultRotation', float, ret.DefaultRotation)

    ret.DictionarybRemoveCommonTerms = _extract_attribute(root, 'DictionarybRemoveCommonTerms', int,
                                                          ret.DictionarybRemoveCommonTerms)

    ret.DictionarybRemoveSparseTerms = _extract_attribute(root, 'DictionarybRemoveSparseTerms', int,
                                                          ret.DictionarybRemoveSparseTerms)

    ret.DictionaryIncludeAdditionalFeatures = _extract_attribute(root, 'DictionaryIncludeAdditionalFeatures', int,
                                                                 ret.DictionaryIncludeAdditionalFeatures)

    ret.DictionaryIncludeBigrams = _extract_attribute(root, 'DictionaryIncludeBigrams', int,
                                                      ret.DictionaryIncludeBigrams)

    ret.DictionaryIncludeLines = _extract_attribute(root, 'DictionaryIncludeLines', int, ret.DictionaryIncludeLines)

    ret.DictionaryIncludeStopWords = _extract_attribute(root, 'DictionaryIncludeStopWords', int,
                                                        ret.DictionaryIncludeStopWords)

    ret.DictionaryIncludeTrigrams = _extract_attribute(root, 'DictionaryIncludeTrigrams', int,
                                                       ret.DictionaryIncludeTrigrams)

    ret.DictionaryRemoveCommonTerms_MaxDocCount = _extract_attribute(root, 'DictionaryRemoveCommonTerms_MaxDocCount',
                                                                     int, ret.DictionaryRemoveCommonTerms_MaxDocCount)

    ret.DictionaryRemoveSparseTerms_MinDocCount = _extract_attribute(root, 'DictionaryRemoveSparseTerms_MinDocCount',
                                                                     int, ret.DictionaryRemoveSparseTerms_MinDocCount)

    ret.Dig1CodePathFilename = _extract_attribute(root, 'Dig1CodePathFilename', str, ret.Dig1CodePathFilename)

    ret.Dig1DocID = _extract_attribute(root, 'Dig1DocID', str, ret.Dig1DocID)

    ret.DisplayLabel = _extract_attribute(root, 'DisplayLabel', str, ret.DisplayLabel)

    ret.DOCANALYSIS_TrainedNaiveBayesLibFilename = _extract_attribute(root,
                                                                      'DOCANALYSIS_TrainedNaiveBayesLibFilename',
                                                                      str,
                                                                      ret.DOCANALYSIS_TrainedNaiveBayesLibFilename)

    ret.DocID = _extract_attribute(root, 'DocID', str, ret.DocID)

    ret.DocID1 = _extract_attribute(root, 'DocID1', str, ret.DocID1)

    ret.DocID2 = _extract_attribute(root, 'DocID2', str, ret.DocID2)

    ret.DocumentManagerEXE = _extract_attribute(root, 'DocumentManagerEXE', str, ret.DocumentManagerEXE)

    ret.DocumentManagerVersion = _extract_attribute(root, 'DocumentManagerVersion', str, ret.DocumentManagerVersion)

    ret.DropBox1Dir = _extract_attribute(root, 'DropBox1Dir', str, ret.DropBox1Dir)

    ret.DropBoxWebUI = _extract_attribute(root, 'DropBoxWebUI', str, ret.DropBoxWebUI)

    ret.ELK_HostName = _extract_attribute(root, 'ELK_HostName', str, ret.ELK_HostName)

    ret.ELK_Port = _extract_attribute(root, 'ELK_Port', int, ret.ELK_Port)

    ret.ETMFDocumentSource = _extract_attribute(root, 'ETMFDocumentSource', str, ret.ETMFDocumentSource)

    ret.ETMFOutputDir = _extract_attribute(root, 'ETMFOutputDir', str, ret.ETMFOutputDir)

    ret.ExcelTemplate_SOA = _extract_attribute(root, 'ExcelTemplate_SOA', str, ret.ExcelTemplate_SOA)

    ret.FileDownloadStartIndex = _extract_attribute(root, 'FileDownloadStartIndex', int, ret.FileDownloadStartIndex)

    ret.flow_id = _extract_attribute(root, 'flow_id', str, ret.flow_id)

    ret.flow_name = _extract_attribute(root, 'flow_name', str, ret.flow_name)

    ret.GenerateNoise = _extract_attribute(root, 'GenerateNoise', int, ret.GenerateNoise)

    ret.GhostscriptEXEFilename = _extract_attribute(root, 'GhostscriptEXEFilename', str, ret.GhostscriptEXEFilename)

    ret.GroundTruthMasterFilename = _extract_attribute(root, 'GroundTruthMasterFilename', str,
                                                       ret.GroundTruthMasterFilename)

    ret.GroundTruthOutputDirectory = _extract_attribute(root, 'GroundTruthOutputDirectory', str,
                                                        ret.GroundTruthOutputDirectory)

    ret.id = _extract_attribute(root, 'id', str, ret.id)

    ret.ImageProc_BulletImagesDir = _extract_attribute(root, 'ImageProc_BulletImagesDir', str,
                                                       ret.ImageProc_BulletImagesDir)

    ret.ImageQC_GreyscaleThreshold = _extract_attribute(root, 'ImageQC_GreyscaleThreshold', float,
                                                        ret.ImageQC_GreyscaleThreshold)

    ret.ImageQC_LegibilityThreshold = _extract_attribute(root, 'ImageQC_LegibilityThreshold', float,
                                                         ret.ImageQC_LegibilityThreshold)

    ret.ImagesDirectory = _extract_attribute(root, 'ImagesDirectory', str, ret.ImagesDirectory)

    ret.InputDataDirectory = _extract_attribute(root, 'InputDataDirectory', str, ret.InputDataDirectory)

    ret.InputImageFilename = _extract_attribute(root, 'InputImageFilename', str, ret.InputImageFilename)

    ret.InputRawFilename = _extract_attribute(root, 'InputRawFilename', str, ret.InputRawFilename)

    ret.InputSourceMasterFilename = _extract_attribute(root, 'InputSourceMasterFilename', str,
                                                       ret.InputSourceMasterFilename)

    ret.InputWorkingMasterFilename = _extract_attribute(root, 'InputWorkingMasterFilename', str,
                                                        ret.InputWorkingMasterFilename)

    ret.IQVDocumentMappingFilename = _extract_attribute(root, 'IQVDocumentMappingFilename', str,
                                                        ret.IQVDocumentMappingFilename)

    ret.IQVEnvironment = _extract_attribute(root, 'IQVEnvironment', str, ret.IQVEnvironment)

    ret.IQVXML_DBConn_bUseDBConnection = _extract_attribute(root, 'IQVXML_DBConn_bUseDBConnection', int,
                                                            ret.IQVXML_DBConn_bUseDBConnection)

    ret.IQVXML_DBConn_Database = _extract_attribute(root, 'IQVXML_DBConn_Database', str, ret.IQVXML_DBConn_Database)

    ret.IQVXML_DBConn_Login = _extract_attribute(root, 'IQVXML_DBConn_Login', str, ret.IQVXML_DBConn_Login)

    ret.IQVXML_DBConn_Password = _extract_attribute(root, 'IQVXML_DBConn_Password', str, ret.IQVXML_DBConn_Password)

    ret.IQVXML_DBConn_Port = _extract_attribute(root, 'IQVXML_DBConn_Port', int, ret.IQVXML_DBConn_Port)

    ret.IQVXML_DBConn_Server = _extract_attribute(root, 'IQVXML_DBConn_Server', str, ret.IQVXML_DBConn_Server)

    ret.IQVXMLInputFilename = _extract_attribute(root, 'IQVXMLInputFilename', str, ret.IQVXMLInputFilename)

    ret.IQVXMLInputFilename2 = _extract_attribute(root, 'IQVXMLInputFilename2', str, ret.IQVXMLInputFilename2)

    ret.LanguageAnalysisLib = _extract_attribute(root, 'LanguageAnalysisLib', str, ret.LanguageAnalysisLib)

    ret.LocalTopLevelDataDir = _extract_attribute(root, 'LocalTopLevelDataDir', str, ret.LocalTopLevelDataDir)

    ret.LogDirectory = _extract_attribute(root, 'LogDirectory', str, ret.LogDirectory)

    ret.LogFilename = _extract_attribute(root, 'LogFilename', str, ret.LogFilename)

    ret.MasterFile = _extract_attribute(root, 'MasterFile', int, ret.MasterFile)

    ret.MasterIQVDocumentListFilename = _extract_attribute(root, 'MasterIQVDocumentListFilename', str,
                                                           ret.MasterIQVDocumentListFilename)

    ret.MatrixFile = _extract_attribute(root, 'MatrixFile', str, ret.MatrixFile)

    ret.MaxCellsPerPage = _extract_attribute(root, 'MaxCellsPerPage', int, ret.MaxCellsPerPage)

    ret.MaxNumDocsToProcess = _extract_attribute(root, 'MaxNumDocsToProcess', int, ret.MaxNumDocsToProcess)

    ret.MaxPagesCoreProcessing_BackSection = _extract_attribute(root, 'MaxPagesCoreProcessing_BackSection', int,
                                                                ret.MaxPagesCoreProcessing_BackSection)

    ret.MaxPagesCoreProcessing_FrontSection = _extract_attribute(root, 'MaxPagesCoreProcessing_FrontSection', int,
                                                                 ret.MaxPagesCoreProcessing_FrontSection)

    ret.MaxPagesToProcess = _extract_attribute(root, 'MaxPagesToProcess', int, ret.MaxPagesToProcess)

    ret.MaxPagesToProcessIQVTM = _extract_attribute(root, 'MaxPagesToProcessIQVTM', int, ret.MaxPagesToProcessIQVTM)

    ret.MaxTimeMinutesPerPage = _extract_attribute(root, 'MaxTimeMinutesPerPage', int, ret.MaxTimeMinutesPerPage)

    ret.MinPixelHeightForOCR = _extract_attribute(root, 'MinPixelHeightForOCR', int, ret.MinPixelHeightForOCR)

    ret.MinPixelHeightForValidImage = _extract_attribute(root, 'MinPixelHeightForValidImage', int,
                                                         ret.MinPixelHeightForValidImage)

    ret.MinPixelWidthForOCR = _extract_attribute(root, 'MinPixelWidthForOCR', int, ret.MinPixelWidthForOCR)

    ret.MinPixelWidthForValidImage = _extract_attribute(root, 'MinPixelWidthForValidImage', int,
                                                        ret.MinPixelWidthForValidImage)

    ret.MSG_ErrorLevelLowerBound = _extract_attribute(root, 'MSG_ErrorLevelLowerBound', int,
                                                      ret.MSG_ErrorLevelLowerBound)

    ret.MSG_ExchangeIsDurable = _extract_attribute(root, 'MSG_ExchangeIsDurable', int, ret.MSG_ExchangeIsDurable)

    ret.MSG_HostName = _extract_attribute(root, 'MSG_HostName', str, ret.MSG_HostName)

    ret.MSG_MaxCPU = _extract_attribute(root, 'MSG_MaxCPU', int, ret.MSG_MaxCPU)

    ret.MSG_MaxRAM = _extract_attribute(root, 'MSG_MaxRAM', int, ret.MSG_MaxRAM)

    ret.MSG_Password = _extract_attribute(root, 'MSG_Password', str, ret.MSG_Password)

    ret.MSG_Port = _extract_attribute(root, 'MSG_Port', int, ret.MSG_Port)

    ret.MSG_QueueIsDurable = _extract_attribute(root, 'MSG_QueueIsDurable', int, ret.MSG_QueueIsDurable)

    ret.MSG_User = _extract_attribute(root, 'MSG_User', str, ret.MSG_User)

    ret.MSG_VirtualHost = _extract_attribute(root, 'MSG_VirtualHost', str, ret.MSG_VirtualHost)

    ret.MTServer_Endpoint = _extract_attribute(root, 'MTServer_Endpoint', str, ret.MTServer_Endpoint)

    ret.MTServer_LocalPathMapping = _extract_attribute(root, 'MTServer_LocalPathMapping', str,
                                                       ret.MTServer_LocalPathMapping)

    ret.MTServer_MachineName = _extract_attribute(root, 'MTServer_MachineName', str, ret.MTServer_MachineName)

    ret.MTServer_Password = _extract_attribute(root, 'MTServer_Password', str, ret.MTServer_Password)

    ret.MTServer_Port = _extract_attribute(root, 'MTServer_Port', str, ret.MTServer_Port)

    ret.MTServer_SecureHTTP = _extract_attribute(root, 'MTServer_SecureHTTP', int, ret.MTServer_SecureHTTP)

    ret.MTServer_SharedDir = _extract_attribute(root, 'MTServer_SharedDir', str, ret.MTServer_SharedDir)

    ret.MTServer_User = _extract_attribute(root, 'MTServer_User', str, ret.MTServer_User)

    ret.NLP_CharMatrixDirectory = _extract_attribute(root, 'NLP_CharMatrixDirectory', str, ret.NLP_CharMatrixDirectory)

    ret.NLP_DictionaryDirectory = _extract_attribute(root, 'NLP_DictionaryDirectory', str, ret.NLP_DictionaryDirectory)

    ret.NoiseGenMaxRecords = _extract_attribute(root, 'NoiseGenMaxRecords', int, ret.NoiseGenMaxRecords)

    ret.NoiseGenStartIndex = _extract_attribute(root, 'NoiseGenStartIndex', int, ret.NoiseGenStartIndex)

    ret.NoiseType = _extract_attribute(root, 'NoiseType', int, ret.NoiseType)

    ret.OCR_bUseSpellCheck = _extract_attribute(root, 'OCR_bUseSpellCheck', int, ret.OCR_bUseSpellCheck)

    ret.OCR_SpellCheckDirectory = _extract_attribute(root, 'OCR_SpellCheckDirectory', str, ret.OCR_SpellCheckDirectory)

    ret.OCR_UserWordsDirectory = _extract_attribute(root, 'OCR_UserWordsDirectory', str, ret.OCR_UserWordsDirectory)

    ret.OMOPUpdateFilename = _extract_attribute(root, 'OMOPUpdateFilename', str, ret.OMOPUpdateFilename)

    ret.Output_OmopPrefixText = _extract_attribute(root, 'Output_OmopPrefixText', str, ret.Output_OmopPrefixText)

    ret.Output_PrefixText = _extract_attribute(root, 'Output_PrefixText', str, ret.Output_PrefixText)

    ret.Output_QCFeedbackPrefixText = _extract_attribute(root, 'Output_QCFeedbackPrefixText', str,
                                                         ret.Output_QCFeedbackPrefixText)

    ret.Output_ToCompareDir = _extract_attribute(root, 'Output_ToCompareDir', str, ret.Output_ToCompareDir)

    ret.Output_ToMetricsDir = _extract_attribute(root, 'Output_ToMetricsDir', str, ret.Output_ToMetricsDir)

    ret.OutputDirectory = _extract_attribute(root, 'OutputDirectory', str, ret.OutputDirectory)

    ret.OutputFilename = _extract_attribute(root, 'OutputFilename', str, ret.OutputFilename)

    ret.OutputLevel = _extract_attribute(root, 'OutputLevel', int, ret.OutputLevel)

    ret.PageIndex = _extract_attribute(root, 'PageIndex', int, ret.PageIndex)

    ret.PerformBatchDocClass = _extract_attribute(root, 'PerformBatchDocClass', int, ret.PerformBatchDocClass)

    ret.PerformDocumentDeconstruction = _extract_attribute(root, 'PerformDocumentDeconstruction', int,
                                                           ret.PerformDocumentDeconstruction)

    ret.PerformDocumentReconstruction = _extract_attribute(root, 'PerformDocumentReconstruction', int,
                                                           ret.PerformDocumentReconstruction)

    ret.PerformDuplicateCheck = _extract_attribute(root, 'PerformDuplicateCheck', int, ret.PerformDuplicateCheck)

    ret.PerformImageQC = _extract_attribute(root, 'PerformImageQC', int, ret.PerformImageQC)

    ret.PerformMetadata = _extract_attribute(root, 'PerformMetadata', int, ret.PerformMetadata)

    ret.PerformRotations = _extract_attribute(root, 'PerformRotations', int, ret.PerformRotations)

    ret.PerformXLIFFReceive = _extract_attribute(root, 'PerformXLIFFReceive', int, ret.PerformXLIFFReceive)

    ret.PerformXLIFFSend = _extract_attribute(root, 'PerformXLIFFSend', int, ret.PerformXLIFFSend)

    ret.PerformXLIFFSourceCreation = _extract_attribute(root, 'PerformXLIFFSourceCreation', int,
                                                        ret.PerformXLIFFSourceCreation)

    ret.Priority = _extract_attribute(root, 'Priority', int, ret.Priority)

    ret.ProcessSource = _extract_attribute(root, 'ProcessSource', int, ret.ProcessSource)

    ret.PythonEnvironment = _extract_attribute(root, 'PythonEnvironment', str, ret.PythonEnvironment)

    ret.PythonEXEFilename = _extract_attribute(root, 'PythonEXEFilename', str, ret.PythonEXEFilename)

    ret.QCFeedbackJSONFilename = _extract_attribute(root, 'QCFeedbackJSONFilename', str, ret.QCFeedbackJSONFilename)

    ret.QCFeedbackRunId = _extract_attribute(root, 'QCFeedbackRunId', str, ret.QCFeedbackRunId)

    ret.Recon_bUseTemplateMatching = _extract_attribute(root, 'Recon_bUseTemplateMatching', int,
                                                        ret.Recon_bUseTemplateMatching)

    ret.Recon_TemplateDirectory = _extract_attribute(root, 'Recon_TemplateDirectory', str, ret.Recon_TemplateDirectory)

    ret.Recon_TemplateFilename = _extract_attribute(root, 'Recon_TemplateFilename', str, ret.Recon_TemplateFilename)

    ret.RedactionProfileID = _extract_attribute(root, 'RedactionProfileID', str, ret.RedactionProfileID)

    ret.RedactionProfileListingFilename = _extract_attribute(root, 'RedactionProfileListingFilename', str,
                                                             ret.RedactionProfileListingFilename)

    ret.RedactionReplacementMethod = _extract_attribute(root, 'RedactionReplacementMethod', str,
                                                        ret.RedactionReplacementMethod)

    ret.RedactionTextMask = _extract_attribute(root, 'RedactionTextMask', str, ret.RedactionTextMask)

    ret.RedactionTextPrefix = _extract_attribute(root, 'RedactionTextPrefix', str, ret.RedactionTextPrefix)

    ret.RedactionTextSuffix = _extract_attribute(root, 'RedactionTextSuffix', str, ret.RedactionTextSuffix)

    ret.RemoteServer_MachineName = _extract_attribute(root, 'RemoteServer_MachineName', str,
                                                      ret.RemoteServer_MachineName)

    ret.RemoteServer_Port = _extract_attribute(root, 'RemoteServer_Port', str, ret.RemoteServer_Port)

    ret.RemoteServer_ServerLocalDir = _extract_attribute(root, 'RemoteServer_ServerLocalDir', str,
                                                         ret.RemoteServer_ServerLocalDir)

    ret.RemoteServer_SharedDir = _extract_attribute(root, 'RemoteServer_SharedDir', str, ret.RemoteServer_SharedDir)

    ret.Rotation = _extract_attribute(root, 'Rotation', int, ret.Rotation)

    ret.RunRemote = _extract_attribute(root, 'RunRemote', _str2bool, ret.RunRemote)

    ret.SegmentationType = _extract_attribute(root, 'SegmentationType', int, ret.SegmentationType)

    ret.SegServer_Endpoint = _extract_attribute(root, 'SegServer_Endpoint', str, ret.SegServer_Endpoint)

    ret.SegServer_LocalPathMapping = _extract_attribute(root, 'SegServer_LocalPathMapping', str,
                                                        ret.SegServer_LocalPathMapping)

    ret.SegServer_MachineName = _extract_attribute(root, 'SegServer_MachineName', str, ret.SegServer_MachineName)

    ret.SegServer_Port = _extract_attribute(root, 'SegServer_Port', str, ret.SegServer_Port)

    ret.SegServer_SecureHTTP = _extract_attribute(root, 'SegServer_SecureHTTP', int, ret.SegServer_SecureHTTP)

    ret.SegServer_SharedDir = _extract_attribute(root, 'SegServer_SharedDir', str, ret.SegServer_SharedDir)

    ret.ShowProgressForm = _extract_attribute(root, 'ShowProgressForm', int, ret.ShowProgressForm)

    ret.sofficeLocation = _extract_attribute(root, 'sofficeLocation', str, ret.sofficeLocation)

    ret.SourceLanguage = _extract_attribute(root, 'SourceLanguage', str, ret.SourceLanguage)

    ret.StandardTemplateIQVXML = _extract_attribute(root, 'StandardTemplateIQVXML', str, ret.StandardTemplateIQVXML)

    ret.TargetLanguage = _extract_attribute(root, 'TargetLanguage', str, ret.TargetLanguage)

    ret.tessdataDir = _extract_attribute(root, 'tessdataDir', str, ret.tessdataDir)

    ret.TesseractEXEFilename = _extract_attribute(root, 'TesseractEXEFilename', str, ret.TesseractEXEFilename)

    ret.TMFGTOutputConstrained_AvgPages = _extract_attribute(root, 'TMFGTOutputConstrained_AvgPages', int,
                                                             ret.TMFGTOutputConstrained_AvgPages)

    ret.TMFGTOutputConstrained_MinSamples = _extract_attribute(root, 'TMFGTOutputConstrained_MinSamples', int,
                                                               ret.TMFGTOutputConstrained_MinSamples)

    ret.TMFRawDataSourceDirectory = _extract_attribute(root, 'TMFRawDataSourceDirectory', str,
                                                       ret.TMFRawDataSourceDirectory)

    ret.TMSServer_Endpoint = _extract_attribute(root, 'TMSServer_Endpoint', str, ret.TMSServer_Endpoint)

    ret.TMSServer_Info = _extract_attribute(root, 'TMSServer_Info', str, ret.TMSServer_Info)

    ret.TMSServer_MachineName = _extract_attribute(root, 'TMSServer_MachineName', str, ret.TMSServer_MachineName)

    ret.TMSServer_Port = _extract_attribute(root, 'TMSServer_Port', str, ret.TMSServer_Port)

    ret.UserEmail = _extract_attribute(root, 'UserEmail', str, ret.UserEmail)

    ret.UserID = _extract_attribute(root, 'UserID', str, ret.UserID)

    ret.WatchLogCheckIntervalSeconds = _extract_attribute(root, 'WatchLogCheckIntervalSeconds', float,
                                                          ret.WatchLogCheckIntervalSeconds)

    ret.WatchLogFilename = _extract_attribute(root, 'WatchLogFilename', str, ret.WatchLogFilename)

    ret.WatchLogOutputDir = _extract_attribute(root, 'WatchLogOutputDir', str, ret.WatchLogOutputDir)

    ret.WorkingDirectory = _extract_attribute(root, 'WorkingDirectory', str, ret.WorkingDirectory)

    ret.XLIFFInputFilename = _extract_attribute(root, 'XLIFFInputFilename', str, ret.XLIFFInputFilename)

    ret.XLIFFMarkupVersion = _extract_attribute(root, 'XLIFFMarkupVersion', str, ret.XLIFFMarkupVersion)
    return ret


def _readFromXmlToConfig_dbList(branch: ET.ElementTree):
    """
    Read from XML and load memory object, for list of objects
    """
    root = branch
    ret = []
    for child in root:
        if (child.tag == 'Config_db'):
            try:
                ret.append(_readFromXmlToConfig_db(child))
            except Exception as e:
                # log
                logger.info('Failed to import field ' + child.tag)
    return ret


def _readFromXmlToFontInfo_db(branch):
    """
    Read from XML and load memory object
    """

    # get root element
    root = branch

    # initialize FontInfo_db
    ret = FontInfo_db()

    ret.Bold = _extract_attribute(root, 'Bold', _str2bool, ret.Bold)

    ret.Caps = _extract_attribute(root, 'Caps', _str2bool, ret.Caps)

    ret.ColorRGB = _extract_attribute(root, 'ColorRGB', int, ret.ColorRGB)

    ret.doc_id = _extract_attribute(root, 'doc_id', str, ret.doc_id)

    ret.DStrike = _extract_attribute(root, 'DStrike', _str2bool, ret.DStrike)

    ret.Emboss = _extract_attribute(root, 'Emboss', _str2bool, ret.Emboss)

    ret.group_type = _extract_attribute(root, 'group_type', str, ret.group_type)

    ret.hierarchy = _extract_attribute(root, 'hierarchy', str, ret.hierarchy)

    ret.Highlight = _extract_attribute(root, 'Highlight', str, ret.Highlight)

    ret.id = _extract_attribute(root, 'id', str, ret.id)

    ret.Imprint = _extract_attribute(root, 'Imprint', _str2bool, ret.Imprint)

    ret.iqv_standard_term = _extract_attribute(root, 'iqv_standard_term', str, ret.iqv_standard_term)

    ret.Italics = _extract_attribute(root, 'Italics', _str2bool, ret.Italics)

    ret.link_id = _extract_attribute(root, 'link_id', str, ret.link_id)

    ret.link_id_level2 = _extract_attribute(root, 'link_id_level2', str, ret.link_id_level2)

    ret.link_id_level3 = _extract_attribute(root, 'link_id_level3', str, ret.link_id_level3)

    ret.link_id_level4 = _extract_attribute(root, 'link_id_level4', str, ret.link_id_level4)

    ret.link_id_level5 = _extract_attribute(root, 'link_id_level5', str, ret.link_id_level5)

    ret.link_id_level6 = _extract_attribute(root, 'link_id_level6', str, ret.link_id_level6)

    ret.link_id_subsection1 = _extract_attribute(root, 'link_id_subsection1', str, ret.link_id_subsection1)

    ret.link_id_subsection2 = _extract_attribute(root, 'link_id_subsection2', str, ret.link_id_subsection2)

    ret.link_id_subsection3 = _extract_attribute(root, 'link_id_subsection3', str, ret.link_id_subsection3)

    ret.Outline = _extract_attribute(root, 'Outline', _str2bool, ret.Outline)

    ret.parent_id = _extract_attribute(root, 'parent_id', str, ret.parent_id)

    ret.rFonts = _extract_attribute(root, 'rFonts', str, ret.rFonts)

    ret.rStyle = _extract_attribute(root, 'rStyle', str, ret.rStyle)

    ret.Shadow = _extract_attribute(root, 'Shadow', _str2bool, ret.Shadow)

    ret.Size = _extract_attribute(root, 'Size', int, ret.Size)

    ret.SmallCaps = _extract_attribute(root, 'SmallCaps', _str2bool, ret.SmallCaps)

    ret.Strike = _extract_attribute(root, 'Strike', _str2bool, ret.Strike)

    ret.Underline = _extract_attribute(root, 'Underline', str, ret.Underline)

    ret.Vanish = _extract_attribute(root, 'Vanish', _str2bool, ret.Vanish)

    ret.VertAlign = _extract_attribute(root, 'VertAlign', str, ret.VertAlign)
    return ret


def _readFromXmlToFontInfo_dbList(branch: ET.ElementTree):
    """
    Read from XML and load memory object, for list of objects
    """
    root = branch
    ret = []
    for child in root:
        if (child.tag == 'FontInfo_db'):
            try:
                ret.append(_readFromXmlToFontInfo_db(child))
            except Exception as e:
                # log
                logger.info('Failed to import field ' + child.tag)
    return ret


def _readFromXmlToIQVAttribute_db(branch):
    """
    Read from XML and load memory object
    """

    # get root element
    root = branch

    # initialize IQVAttribute_db
    ret = IQVAttribute_db()

    ret.doc_id = _extract_attribute(root, 'doc_id', str, ret.doc_id)

    ret.group_type = _extract_attribute(root, 'group_type', str, ret.group_type)

    ret.hierarchy = _extract_attribute(root, 'hierarchy', str, ret.hierarchy)

    ret.id = _extract_attribute(root, 'id', str, ret.id)

    ret.iqv_standard_term = _extract_attribute(root, 'iqv_standard_term', str, ret.iqv_standard_term)

    ret.link_id = _extract_attribute(root, 'link_id', str, ret.link_id)

    ret.link_id_level2 = _extract_attribute(root, 'link_id_level2', str, ret.link_id_level2)

    ret.link_id_level3 = _extract_attribute(root, 'link_id_level3', str, ret.link_id_level3)

    ret.link_id_level4 = _extract_attribute(root, 'link_id_level4', str, ret.link_id_level4)

    ret.link_id_level5 = _extract_attribute(root, 'link_id_level5', str, ret.link_id_level5)

    ret.link_id_level6 = _extract_attribute(root, 'link_id_level6', str, ret.link_id_level6)

    ret.link_id_subsection1 = _extract_attribute(root, 'link_id_subsection1', str, ret.link_id_subsection1)

    ret.link_id_subsection2 = _extract_attribute(root, 'link_id_subsection2', str, ret.link_id_subsection2)

    ret.link_id_subsection3 = _extract_attribute(root, 'link_id_subsection3', str, ret.link_id_subsection3)

    ret.LocalName = _extract_attribute(root, 'LocalName', str, ret.LocalName)

    ret.Name = _extract_attribute(root, 'Name', str, ret.Name)

    ret.parent_id = _extract_attribute(root, 'parent_id', str, ret.parent_id)

    ret.Value = _extract_attribute(root, 'Value', str, ret.Value)
    return ret


def _readFromXmlToIQVAttribute_dbList(branch: ET.ElementTree):
    """
    Read from XML and load memory object, for list of objects
    """
    root = branch
    ret = []
    for child in root:
        if (child.tag == 'IQVAttribute_db'):
            try:
                ret.append(_readFromXmlToIQVAttribute_db(child))
            except Exception as e:
                # log
                logger.info('Failed to import field ' + child.tag)
    return ret


def _readFromXmlToIQVAttributeCandidate_db(branch):
    """
    Read from XML and load memory object
    """

    # get root element
    root = branch

    # initialize IQVAttributeCandidate_db
    ret = IQVAttributeCandidate_db()

    ret.AttributeKey = _extract_attribute(root, 'AttributeKey', str, ret.AttributeKey)

    ret.AttributeValue = _extract_attribute(root, 'AttributeValue', str, ret.AttributeValue)

    ret.CandidateSelected = _extract_attribute(root, 'CandidateSelected', int, ret.CandidateSelected)

    ret.doc_id = _extract_attribute(root, 'doc_id', str, ret.doc_id)

    ret.group_type = _extract_attribute(root, 'group_type', str, ret.group_type)

    ret.hierarchy = _extract_attribute(root, 'hierarchy', str, ret.hierarchy)

    ret.id = _extract_attribute(root, 'id', str, ret.id)

    ret.iqv_standard_term = _extract_attribute(root, 'iqv_standard_term', str, ret.iqv_standard_term)

    ret.link_id = _extract_attribute(root, 'link_id', str, ret.link_id)

    ret.link_id_level2 = _extract_attribute(root, 'link_id_level2', str, ret.link_id_level2)

    ret.link_id_level3 = _extract_attribute(root, 'link_id_level3', str, ret.link_id_level3)

    ret.link_id_level4 = _extract_attribute(root, 'link_id_level4', str, ret.link_id_level4)

    ret.link_id_level5 = _extract_attribute(root, 'link_id_level5', str, ret.link_id_level5)

    ret.link_id_level6 = _extract_attribute(root, 'link_id_level6', str, ret.link_id_level6)

    ret.link_id_subsection1 = _extract_attribute(root, 'link_id_subsection1', str, ret.link_id_subsection1)

    ret.link_id_subsection2 = _extract_attribute(root, 'link_id_subsection2', str, ret.link_id_subsection2)

    ret.link_id_subsection3 = _extract_attribute(root, 'link_id_subsection3', str, ret.link_id_subsection3)

    ret.parent_id = _extract_attribute(root, 'parent_id', str, ret.parent_id)

    ret.RawProbabilitiyScore = _extract_attribute(root, 'RawProbabilitiyScore', float, ret.RawProbabilitiyScore)

    ret.roi_id = _extract_attribute(root, 'roi_id', str, ret.roi_id)
    return ret


def _readFromXmlToIQVAttributeCandidate_dbList(branch: ET.ElementTree):
    """
    Read from XML and load memory object, for list of objects
    """
    root = branch
    ret = []
    for child in root:
        if (child.tag == 'IQVAttributeCandidate_db'):
            try:
                ret.append(_readFromXmlToIQVAttributeCandidate_db(child))
            except Exception as e:
                # log
                logger.info('Failed to import field ' + child.tag)
    return ret


def _readFromXmlToIQVCharacter_db(branch):
    """
    Read from XML and load memory object
    """

    # get root element
    root = branch

    # initialize IQVCharacter_db
    ret = IQVCharacter_db()

    ret.Bottom = _extract_attribute(root, 'Bottom', int, ret.Bottom)

    ret.doc_id = _extract_attribute(root, 'doc_id', str, ret.doc_id)

    ret.group_type = _extract_attribute(root, 'group_type', str, ret.group_type)

    ret.hierarchy = _extract_attribute(root, 'hierarchy', str, ret.hierarchy)

    ret.id = _extract_attribute(root, 'id', str, ret.id)

    ret.iqv_standard_term = _extract_attribute(root, 'iqv_standard_term', str, ret.iqv_standard_term)

    ret.Left = _extract_attribute(root, 'Left', int, ret.Left)

    ret.link_id = _extract_attribute(root, 'link_id', str, ret.link_id)

    ret.link_id_level2 = _extract_attribute(root, 'link_id_level2', str, ret.link_id_level2)

    ret.link_id_level3 = _extract_attribute(root, 'link_id_level3', str, ret.link_id_level3)

    ret.link_id_level4 = _extract_attribute(root, 'link_id_level4', str, ret.link_id_level4)

    ret.link_id_level5 = _extract_attribute(root, 'link_id_level5', str, ret.link_id_level5)

    ret.link_id_level6 = _extract_attribute(root, 'link_id_level6', str, ret.link_id_level6)

    ret.link_id_subsection1 = _extract_attribute(root, 'link_id_subsection1', str, ret.link_id_subsection1)

    ret.link_id_subsection2 = _extract_attribute(root, 'link_id_subsection2', str, ret.link_id_subsection2)

    ret.link_id_subsection3 = _extract_attribute(root, 'link_id_subsection3', str, ret.link_id_subsection3)

    ret.parent_id = _extract_attribute(root, 'parent_id', str, ret.parent_id)

    ret.Right = _extract_attribute(root, 'Right', int, ret.Right)

    ret.Tag = _extract_attribute(root, 'Tag', str, ret.Tag)

    ret.Top = _extract_attribute(root, 'Top', int, ret.Top)

    ret.Value = _extract_attribute(root, 'Value', int, ret.Value)
    return ret


def _readFromXmlToIQVCharacter_dbList(branch: ET.ElementTree):
    """
    Read from XML and load memory object, for list of objects
    """
    root = branch
    ret = []
    for child in root:
        if (child.tag == 'IQVCharacter_db'):
            try:
                ret.append(_readFromXmlToIQVCharacter_db(child))
            except Exception as e:
                # log
                logger.info('Failed to import field ' + child.tag)
    return ret


def _readFromXmlToIQVWord_db(branch):
    """
    Read from XML and load memory object
    """

    # get root element
    root = branch

    # initialize IQVWord_db
    ret = IQVWord_db()

    ret.Blanks = _extract_attribute(root, 'Blanks', int, ret.Blanks)

    ret.BlockIndex = _extract_attribute(root, 'BlockIndex', int, ret.BlockIndex)

    ret.Bottom = _extract_attribute(root, 'Bottom', int, ret.Bottom)

    ret.Class = _extract_attribute(root, 'Class', str, ret.Class)

    ret.Confidence = _extract_attribute(root, 'Confidence', float, ret.Confidence)

    ret.doc_id = _extract_attribute(root, 'doc_id', str, ret.doc_id)

    ret.FontIndex = _extract_attribute(root, 'FontIndex', float, ret.FontIndex)

    ret.FontName = _extract_attribute(root, 'FontName', str, ret.FontName)

    ret.Formating = _extract_attribute(root, 'Formating', int, ret.Formating)

    ret.group_type = _extract_attribute(root, 'group_type', str, ret.group_type)

    ret.GT_ScoreMatch = _extract_attribute(root, 'GT_ScoreMatch', float, ret.GT_ScoreMatch)

    ret.GT_TextMatch = _extract_attribute(root, 'GT_TextMatch', str, ret.GT_TextMatch)

    ret.hierarchy = _extract_attribute(root, 'hierarchy', str, ret.hierarchy)

    ret.id = _extract_attribute(root, 'id', str, ret.id)

    ret.iqv_standard_term = _extract_attribute(root, 'iqv_standard_term', str, ret.iqv_standard_term)

    ret.Left = _extract_attribute(root, 'Left', int, ret.Left)

    ret.LineIndex = _extract_attribute(root, 'LineIndex', int, ret.LineIndex)

    ret.link_id = _extract_attribute(root, 'link_id', str, ret.link_id)

    ret.link_id_level2 = _extract_attribute(root, 'link_id_level2', str, ret.link_id_level2)

    ret.link_id_level3 = _extract_attribute(root, 'link_id_level3', str, ret.link_id_level3)

    ret.link_id_level4 = _extract_attribute(root, 'link_id_level4', str, ret.link_id_level4)

    ret.link_id_level5 = _extract_attribute(root, 'link_id_level5', str, ret.link_id_level5)

    ret.link_id_level6 = _extract_attribute(root, 'link_id_level6', str, ret.link_id_level6)

    ret.link_id_subsection1 = _extract_attribute(root, 'link_id_subsection1', str, ret.link_id_subsection1)

    ret.link_id_subsection2 = _extract_attribute(root, 'link_id_subsection2', str, ret.link_id_subsection2)

    ret.link_id_subsection3 = _extract_attribute(root, 'link_id_subsection3', str, ret.link_id_subsection3)

    ret.NLP_ScoreMatch = _extract_attribute(root, 'NLP_ScoreMatch', float, ret.NLP_ScoreMatch)

    ret.NLP_TextMatch = _extract_attribute(root, 'NLP_TextMatch', str, ret.NLP_TextMatch)

    ret.NLP_TextMatchReconstructed = _extract_attribute(root, 'NLP_TextMatchReconstructed', str,
                                                        ret.NLP_TextMatchReconstructed)

    ret.parent_id = _extract_attribute(root, 'parent_id', str, ret.parent_id)

    ret.PointSize = _extract_attribute(root, 'PointSize', int, ret.PointSize)

    ret.Right = _extract_attribute(root, 'Right', int, ret.Right)

    ret.Tag = _extract_attribute(root, 'Tag', str, ret.Tag)

    ret.Text = _extract_attribute(root, 'Text', str, ret.Text)

    ret.textangle = _extract_attribute(root, 'textangle', int, ret.textangle)

    ret.TextDerivedCase = _extract_attribute(root, 'TextDerivedCase', int, ret.TextDerivedCase)

    ret.TextDerivedDeconstructed = _extract_attribute(root, 'TextDerivedDeconstructed', str,
                                                      ret.TextDerivedDeconstructed)

    ret.TextDerivedIsNumeric = _extract_attribute(root, 'TextDerivedIsNumeric', int, ret.TextDerivedIsNumeric)

    ret.TextDerivedPrefix = _extract_attribute(root, 'TextDerivedPrefix', str, ret.TextDerivedPrefix)

    ret.TextDerivedSuffix = _extract_attribute(root, 'TextDerivedSuffix', str, ret.TextDerivedSuffix)

    ret.TextLanguage = _extract_attribute(root, 'TextLanguage', str, ret.TextLanguage)

    ret.Top = _extract_attribute(root, 'Top', int, ret.Top)

    ret.WordIndex = _extract_attribute(root, 'WordIndex', int, ret.WordIndex)
    return ret


def _readFromXmlToIQVWord_dbList(branch: ET.ElementTree):
    """
    Read from XML and load memory object, for list of objects
    """
    root = branch
    ret = []
    for child in root:
        if (child.tag == 'IQVWord_db'):
            try:
                ret.append(_readFromXmlToIQVWord_db(child))
            except Exception as e:
                # log
                logger.info('Failed to import field ' + child.tag)
    return ret


def _readFromXmlToIQVClassifierModel_db(branch):
    """
    Read from XML and load memory object
    """

    # get root element
    root = branch

    # initialize IQVClassifierModel_db
    ret = IQVClassifierModel_db()

    ret.Base_Model_Version = _extract_attribute(root, 'Base_Model_Version', str, ret.Base_Model_Version)

    ret.Country = _extract_attribute(root, 'Country', str, ret.Country)

    ret.Doc_Class = _extract_attribute(root, 'Doc_Class', str, ret.Doc_Class)

    ret.Full_Classification_List_list = _extract_attribute_list(root, 'Full_Classification_List_list',
                                                                _readFromXmlToStringList,
                                                                ret.Full_Classification_List_list)

    ret.id = _extract_attribute(root, 'id', str, ret.id)

    ret.Language = _extract_attribute(root, 'Language', str, ret.Language)

    ret.Model_Directory = _extract_attribute(root, 'Model_Directory', str, ret.Model_Directory)

    ret.Model_Index = _extract_attribute(root, 'Model_Index', str, ret.Model_Index)

    ret.Model_Label = _extract_attribute(root, 'Model_Label', str, ret.Model_Label)

    ret.Model_Name = _extract_attribute(root, 'Model_Name', str, ret.Model_Name)

    ret.Model_Sequence = _extract_attribute(root, 'Model_Sequence', str, ret.Model_Sequence)
    return ret


def _readFromXmlToIQVClassifierModel_dbList(branch: ET.ElementTree):
    """
    Read from XML and load memory object, for list of objects
    """
    root = branch
    ret = []
    for child in root:
        if (child.tag == 'IQVClassifierModel_db'):
            try:
                ret.append(_readFromXmlToIQVClassifierModel_db(child))
            except Exception as e:
                # log
                logger.info('Failed to import field ' + child.tag)
    return ret


def _readFromXmlToIQVCountryMapping_db(branch):
    """
    Read from XML and load memory object
    """

    # get root element
    root = branch

    # initialize IQVCountryMapping_db
    ret = IQVCountryMapping_db()

    ret.Country = _extract_attribute(root, 'Country', str, ret.Country)

    ret.DateFormats_list = _extract_attribute_list(root, 'DateFormats_list', _readFromXmlToStringList,
                                                   ret.DateFormats_list)

    ret.id = _extract_attribute(root, 'id', str, ret.id)
    return ret


def _readFromXmlToIQVCountryMapping_dbList(branch: ET.ElementTree):
    """
    Read from XML and load memory object, for list of objects
    """
    root = branch
    ret = []
    for child in root:
        if (child.tag == 'IQVCountryMapping_db'):
            try:
                ret.append(_readFromXmlToIQVCountryMapping_db(child))
            except Exception as e:
                # log
                logger.info('Failed to import field ' + child.tag)
    return ret


def _readFromXmlToIQVDocumentCompare_db(branch):
    """
    Read from XML and load memory object
    """

    # get root element
    root = branch

    # initialize IQVDocumentCompare_db
    ret = IQVDocumentCompare_db()

    ret.base_doc_id = _extract_attribute(root, 'base_doc_id', str, ret.base_doc_id)

    ret.base_doc_name = _extract_attribute(root, 'base_doc_name', str, ret.base_doc_name)

    ret.compare_doc_id = _extract_attribute(root, 'compare_doc_id', str, ret.compare_doc_id)

    ret.compare_doc_name = _extract_attribute(root, 'compare_doc_name', str, ret.compare_doc_name)

    ret.id = _extract_attribute(root, 'id', str, ret.id)

    ret.redaction_profile_id = _extract_attribute(root, 'redaction_profile_id', str, ret.redaction_profile_id)
    return ret


def _readFromXmlToIQVDocumentCompare_dbList(branch: ET.ElementTree):
    """
    Read from XML and load memory object, for list of objects
    """
    root = branch
    ret = []
    for child in root:
        if (child.tag == 'IQVDocumentCompare_db'):
            try:
                ret.append(_readFromXmlToIQVDocumentCompare_db(child))
            except Exception as e:
                # log
                logger.info('Failed to import field ' + child.tag)
    return ret


def _readFromXmlToIQVDocumentDiff_db(branch):
    """
    Read from XML and load memory object
    """

    # get root element
    root = branch

    # initialize IQVDocumentDiff_db
    ret = IQVDocumentDiff_db()

    ret.compare_roi_id = _extract_attribute(root, 'compare_roi_id', str, ret.compare_roi_id)

    ret.confidence = _extract_attribute(root, 'confidence', float, ret.confidence)

    ret.diff_category = _extract_attribute(root, 'diff_category', str, ret.diff_category)

    ret.diff_string = _extract_attribute(root, 'diff_string', str, ret.diff_string)

    ret.diff_subcategory = _extract_attribute(root, 'diff_subcategory', str, ret.diff_subcategory)

    ret.diff_type = _extract_attribute(root, 'diff_type', int, ret.diff_type)

    ret.id = _extract_attribute(root, 'id', str, ret.id)

    ret.IsPreferredTermComparison = _extract_attribute(root, 'IsPreferredTermComparison', _str2bool,
                                                       ret.IsPreferredTermComparison)

    ret.local_roi_id = _extract_attribute(root, 'local_roi_id', str, ret.local_roi_id)
    return ret


def _readFromXmlToIQVDocumentDiff_dbList(branch: ET.ElementTree):
    """
    Read from XML and load memory object, for list of objects
    """
    root = branch
    ret = []
    for child in root:
        if (child.tag == 'IQVDocumentDiff_db'):
            try:
                ret.append(_readFromXmlToIQVDocumentDiff_db(child))
            except Exception as e:
                # log
                logger.info('Failed to import field ' + child.tag)
    return ret


def _readFromXmlToIQVExternalLink_db(branch):
    """
    Read from XML and load memory object
    """

    # get root element
    root = branch

    # initialize IQVExternalLink_db
    ret = IQVExternalLink_db()

    ret.connection_type = _extract_attribute(root, 'connection_type', str, ret.connection_type)

    ret.destination_link_id = _extract_attribute(root, 'destination_link_id', str, ret.destination_link_id)

    ret.destination_link_prefix = _extract_attribute(root, 'destination_link_prefix', str, ret.destination_link_prefix)

    ret.destination_link_text = _extract_attribute(root, 'destination_link_text', str, ret.destination_link_text)

    ret.destination_url = _extract_attribute(root, 'destination_url', str, ret.destination_url)

    ret.doc_id = _extract_attribute(root, 'doc_id', str, ret.doc_id)

    ret.group_type = _extract_attribute(root, 'group_type', str, ret.group_type)

    ret.hierarchy = _extract_attribute(root, 'hierarchy', str, ret.hierarchy)

    ret.id = _extract_attribute(root, 'id', str, ret.id)

    ret.iqv_standard_term = _extract_attribute(root, 'iqv_standard_term', str, ret.iqv_standard_term)

    ret.length = _extract_attribute(root, 'length', int, ret.length)

    ret.link_id = _extract_attribute(root, 'link_id', str, ret.link_id)

    ret.link_id_level2 = _extract_attribute(root, 'link_id_level2', str, ret.link_id_level2)

    ret.link_id_level3 = _extract_attribute(root, 'link_id_level3', str, ret.link_id_level3)

    ret.link_id_level4 = _extract_attribute(root, 'link_id_level4', str, ret.link_id_level4)

    ret.link_id_level5 = _extract_attribute(root, 'link_id_level5', str, ret.link_id_level5)

    ret.link_id_level6 = _extract_attribute(root, 'link_id_level6', str, ret.link_id_level6)

    ret.link_id_subsection1 = _extract_attribute(root, 'link_id_subsection1', str, ret.link_id_subsection1)

    ret.link_id_subsection2 = _extract_attribute(root, 'link_id_subsection2', str, ret.link_id_subsection2)

    ret.link_id_subsection3 = _extract_attribute(root, 'link_id_subsection3', str, ret.link_id_subsection3)

    ret.link_text = _extract_attribute(root, 'link_text', str, ret.link_text)

    ret.parent_id = _extract_attribute(root, 'parent_id', str, ret.parent_id)

    ret.source_text = _extract_attribute(root, 'source_text', str, ret.source_text)

    ret.startIndex = _extract_attribute(root, 'startIndex', int, ret.startIndex)
    return ret


def _readFromXmlToIQVExternalLink_dbList(branch: ET.ElementTree):
    """
    Read from XML and load memory object, for list of objects
    """
    root = branch
    ret = []
    for child in root:
        if (child.tag == 'IQVExternalLink_db'):
            try:
                ret.append(_readFromXmlToIQVExternalLink_db(child))
            except Exception as e:
                # log
                logger.info('Failed to import field ' + child.tag)
    return ret


def _readFromXmlToIQVExternalLinkElement_db(branch):
    """
    Read from XML and load memory object
    """

    # get root element
    root = branch

    # initialize IQVExternalLinkElement_db
    ret = IQVExternalLinkElement_db()

    ret.doc_id = _extract_attribute(root, 'doc_id', str, ret.doc_id)

    ret.group_type = _extract_attribute(root, 'group_type', str, ret.group_type)

    ret.hierarchy = _extract_attribute(root, 'hierarchy', str, ret.hierarchy)

    ret.id = _extract_attribute(root, 'id', str, ret.id)

    ret.iqv_standard_term = _extract_attribute(root, 'iqv_standard_term', str, ret.iqv_standard_term)

    ret.length = _extract_attribute(root, 'length', int, ret.length)

    ret.link_id = _extract_attribute(root, 'link_id', str, ret.link_id)

    ret.link_id_level2 = _extract_attribute(root, 'link_id_level2', str, ret.link_id_level2)

    ret.link_id_level3 = _extract_attribute(root, 'link_id_level3', str, ret.link_id_level3)

    ret.link_id_level4 = _extract_attribute(root, 'link_id_level4', str, ret.link_id_level4)

    ret.link_id_level5 = _extract_attribute(root, 'link_id_level5', str, ret.link_id_level5)

    ret.link_id_level6 = _extract_attribute(root, 'link_id_level6', str, ret.link_id_level6)

    ret.link_id_subsection1 = _extract_attribute(root, 'link_id_subsection1', str, ret.link_id_subsection1)

    ret.link_id_subsection2 = _extract_attribute(root, 'link_id_subsection2', str, ret.link_id_subsection2)

    ret.link_id_subsection3 = _extract_attribute(root, 'link_id_subsection3', str, ret.link_id_subsection3)

    ret.parent_id = _extract_attribute(root, 'parent_id', str, ret.parent_id)

    ret.startIndex = _extract_attribute(root, 'startIndex', int, ret.startIndex)

    ret.text = _extract_attribute(root, 'text', str, ret.text)
    return ret


def _readFromXmlToIQVExternalLinkElement_dbList(branch: ET.ElementTree):
    """
    Read from XML and load memory object, for list of objects
    """
    root = branch
    ret = []
    for child in root:
        if (child.tag == 'IQVExternalLinkElement_db'):
            try:
                ret.append(_readFromXmlToIQVExternalLinkElement_db(child))
            except Exception as e:
                # log
                logger.info('Failed to import field ' + child.tag)
    return ret


def _readFromXmlToIQVLine_db(branch):
    """
    Read from XML and load memory object
    """

    # get root element
    root = branch

    # initialize IQVLine_db
    ret = IQVLine_db()

    ret.BackgroundToForeground = _extract_attribute(root, 'BackgroundToForeground', _str2bool,
                                                    ret.BackgroundToForeground)

    ret.bIncludedInBox = _extract_attribute(root, 'bIncludedInBox', _str2bool, ret.bIncludedInBox)

    ret.bIsHorizontal = _extract_attribute(root, 'bIsHorizontal', _str2bool, ret.bIsHorizontal)

    ret.doc_id = _extract_attribute(root, 'doc_id', str, ret.doc_id)

    ret.ForegroundToBackground = _extract_attribute(root, 'ForegroundToBackground', _str2bool,
                                                    ret.ForegroundToBackground)

    ret.group_type = _extract_attribute(root, 'group_type', str, ret.group_type)

    ret.hierarchy = _extract_attribute(root, 'hierarchy', str, ret.hierarchy)

    ret.id = _extract_attribute(root, 'id', str, ret.id)

    ret.iqv_standard_term = _extract_attribute(root, 'iqv_standard_term', str, ret.iqv_standard_term)

    ret.link_id = _extract_attribute(root, 'link_id', str, ret.link_id)

    ret.link_id_level2 = _extract_attribute(root, 'link_id_level2', str, ret.link_id_level2)

    ret.link_id_level3 = _extract_attribute(root, 'link_id_level3', str, ret.link_id_level3)

    ret.link_id_level4 = _extract_attribute(root, 'link_id_level4', str, ret.link_id_level4)

    ret.link_id_level5 = _extract_attribute(root, 'link_id_level5', str, ret.link_id_level5)

    ret.link_id_level6 = _extract_attribute(root, 'link_id_level6', str, ret.link_id_level6)

    ret.link_id_subsection1 = _extract_attribute(root, 'link_id_subsection1', str, ret.link_id_subsection1)

    ret.link_id_subsection2 = _extract_attribute(root, 'link_id_subsection2', str, ret.link_id_subsection2)

    ret.link_id_subsection3 = _extract_attribute(root, 'link_id_subsection3', str, ret.link_id_subsection3)

    ret.parent_id = _extract_attribute(root, 'parent_id', str, ret.parent_id)

    ret.ParentID = _extract_attribute(root, 'ParentID', int, ret.ParentID)

    ret.SequenceID = _extract_attribute(root, 'SequenceID', int, ret.SequenceID)

    ret.Thickness = _extract_attribute(root, 'Thickness', int, ret.Thickness)

    ret.ThicknessUnit = _extract_attribute(root, 'ThicknessUnit', int, ret.ThicknessUnit)

    ret.TopParentID = _extract_attribute(root, 'TopParentID', int, ret.TopParentID)

    ret.X1 = _extract_attribute(root, 'X1', int, ret.X1)

    ret.X1Right = _extract_attribute(root, 'X1Right', int, ret.X1Right)

    ret.X2 = _extract_attribute(root, 'X2', int, ret.X2)

    ret.X2Right = _extract_attribute(root, 'X2Right', int, ret.X2Right)

    ret.Y1 = _extract_attribute(root, 'Y1', int, ret.Y1)

    ret.Y1Lower = _extract_attribute(root, 'Y1Lower', int, ret.Y1Lower)

    ret.Y2 = _extract_attribute(root, 'Y2', int, ret.Y2)

    ret.Y2Lower = _extract_attribute(root, 'Y2Lower', int, ret.Y2Lower)
    return ret


def _readFromXmlToIQVLine_dbList(branch: ET.ElementTree):
    """
    Read from XML and load memory object, for list of objects
    """
    root = branch
    ret = []
    for child in root:
        if (child.tag == 'IQVLine_db'):
            try:
                ret.append(_readFromXmlToIQVLine_db(child))
            except Exception as e:
                # log
                logger.info('Failed to import field ' + child.tag)
    return ret


def _readFromXmlToIQVNumberingGroup_db(branch):
    """
    Read from XML and load memory object
    """

    # get root element
    root = branch

    # initialize IQVNumberingGroup_db
    ret = IQVNumberingGroup_db()

    ret.abstractNumId = _extract_attribute(root, 'abstractNumId', int, ret.abstractNumId)

    ret.countItems = _extract_attribute(root, 'countItems', int, ret.countItems)

    ret.doc_id = _extract_attribute(root, 'doc_id', str, ret.doc_id)

    ret.group_type = _extract_attribute(root, 'group_type', str, ret.group_type)

    ret.hierarchy = _extract_attribute(root, 'hierarchy', str, ret.hierarchy)

    ret.id = _extract_attribute(root, 'id', str, ret.id)

    ret.iqv_standard_term = _extract_attribute(root, 'iqv_standard_term', str, ret.iqv_standard_term)

    ret.link_id = _extract_attribute(root, 'link_id', str, ret.link_id)

    ret.link_id_level2 = _extract_attribute(root, 'link_id_level2', str, ret.link_id_level2)

    ret.link_id_level3 = _extract_attribute(root, 'link_id_level3', str, ret.link_id_level3)

    ret.link_id_level4 = _extract_attribute(root, 'link_id_level4', str, ret.link_id_level4)

    ret.link_id_level5 = _extract_attribute(root, 'link_id_level5', str, ret.link_id_level5)

    ret.link_id_level6 = _extract_attribute(root, 'link_id_level6', str, ret.link_id_level6)

    ret.link_id_subsection1 = _extract_attribute(root, 'link_id_subsection1', str, ret.link_id_subsection1)

    ret.link_id_subsection2 = _extract_attribute(root, 'link_id_subsection2', str, ret.link_id_subsection2)

    ret.link_id_subsection3 = _extract_attribute(root, 'link_id_subsection3', str, ret.link_id_subsection3)

    ret.numId = _extract_attribute(root, 'numId', int, ret.numId)

    ret.paraEndIndex = _extract_attribute(root, 'paraEndIndex', int, ret.paraEndIndex)

    ret.paraIds_list = _extract_attribute(root, 'paraIds_list', str, ret.paraIds_list)

    ret.paraStartIndex = _extract_attribute(root, 'paraStartIndex', int, ret.paraStartIndex)

    ret.parent_id = _extract_attribute(root, 'parent_id', str, ret.parent_id)
    return ret


def _readFromXmlToIQVNumberingGroup_dbList(branch: ET.ElementTree):
    """
    Read from XML and load memory object, for list of objects
    """
    root = branch
    ret = []
    for child in root:
        if (child.tag == 'IQVNumberingGroup_db'):
            try:
                ret.append(_readFromXmlToIQVNumberingGroup_db(child))
            except Exception as e:
                # log
                logger.info('Failed to import field ' + child.tag)
    return ret


def _readFromXmlToIQVNumberingLevel_db(branch):
    """
    Read from XML and load memory object
    """

    # get root element
    root = branch

    # initialize IQVNumberingLevel_db
    ret = IQVNumberingLevel_db()

    ret.doc_id = _extract_attribute(root, 'doc_id', str, ret.doc_id)

    ret.group_type = _extract_attribute(root, 'group_type', str, ret.group_type)

    ret.hierarchy = _extract_attribute(root, 'hierarchy', str, ret.hierarchy)

    ret.id = _extract_attribute(root, 'id', str, ret.id)

    ret.ilvl = _extract_attribute(root, 'ilvl', int, ret.ilvl)

    ret.iqv_standard_term = _extract_attribute(root, 'iqv_standard_term', str, ret.iqv_standard_term)

    ret.link_id = _extract_attribute(root, 'link_id', str, ret.link_id)

    ret.link_id_level2 = _extract_attribute(root, 'link_id_level2', str, ret.link_id_level2)

    ret.link_id_level3 = _extract_attribute(root, 'link_id_level3', str, ret.link_id_level3)

    ret.link_id_level4 = _extract_attribute(root, 'link_id_level4', str, ret.link_id_level4)

    ret.link_id_level5 = _extract_attribute(root, 'link_id_level5', str, ret.link_id_level5)

    ret.link_id_level6 = _extract_attribute(root, 'link_id_level6', str, ret.link_id_level6)

    ret.link_id_subsection1 = _extract_attribute(root, 'link_id_subsection1', str, ret.link_id_subsection1)

    ret.link_id_subsection2 = _extract_attribute(root, 'link_id_subsection2', str, ret.link_id_subsection2)

    ret.link_id_subsection3 = _extract_attribute(root, 'link_id_subsection3', str, ret.link_id_subsection3)

    ret.lvlText = _extract_attribute(root, 'lvlText', str, ret.lvlText)

    ret.numFmt = _extract_attribute(root, 'numFmt', str, ret.numFmt)

    ret.parent_id = _extract_attribute(root, 'parent_id', str, ret.parent_id)

    ret.start = _extract_attribute(root, 'start', str, ret.start)
    return ret


def _readFromXmlToIQVNumberingLevel_dbList(branch: ET.ElementTree):
    """
    Read from XML and load memory object, for list of objects
    """
    root = branch
    ret = []
    for child in root:
        if (child.tag == 'IQVNumberingLevel_db'):
            try:
                ret.append(_readFromXmlToIQVNumberingLevel_db(child))
            except Exception as e:
                # log
                logger.info('Failed to import field ' + child.tag)
    return ret


def _readFromXmlToIQVRedactionProfile_db(branch):
    """
    Read from XML and load memory object
    """

    # get root element
    root = branch

    # initialize IQVRedactionProfile_db
    ret = IQVRedactionProfile_db()

    ret.DefaultIsRedacted = _extract_attribute(root, 'DefaultIsRedacted', int, ret.DefaultIsRedacted)

    ret.id = _extract_attribute(root, 'id', str, ret.id)
    return ret


def _readFromXmlToIQVRedactionProfile_dbList(branch: ET.ElementTree):
    """
    Read from XML and load memory object, for list of objects
    """
    root = branch
    ret = []
    for child in root:
        if (child.tag == 'IQVRedactionProfile_db'):
            try:
                ret.append(_readFromXmlToIQVRedactionProfile_db(child))
            except Exception as e:
                # log
                logger.info('Failed to import field ' + child.tag)
    return ret


def _readFromXmlToIQVRedactionCategory_db(branch):
    """
    Read from XML and load memory object
    """

    # get root element
    root = branch

    # initialize IQVRedactionCategory_db
    ret = IQVRedactionCategory_db()

    ret.Category = _extract_attribute(root, 'Category', str, ret.Category)

    ret.id = _extract_attribute(root, 'id', str, ret.id)

    ret.IsRedacted = _extract_attribute(root, 'IsRedacted', int, ret.IsRedacted)

    ret.Query = _extract_attribute(root, 'Query', str, ret.Query)
    return ret


def _readFromXmlToIQVRedactionCategory_dbList(branch: ET.ElementTree):
    """
    Read from XML and load memory object, for list of objects
    """
    root = branch
    ret = []
    for child in root:
        if (child.tag == 'IQVRedactionCategory_db'):
            try:
                ret.append(_readFromXmlToIQVRedactionCategory_db(child))
            except Exception as e:
                # log
                logger.info('Failed to import field ' + child.tag)
    return ret


def _readFromXmlToNLP_System_Mapping_db(branch):
    """
    Read from XML and load memory object
    """

    # get root element
    root = branch

    # initialize NLP_System_Mapping_db
    ret = NLP_System_Mapping_db()

    ret.DataType = _extract_attribute(root, 'DataType', str, ret.DataType)

    ret.doc_id = _extract_attribute(root, 'doc_id', str, ret.doc_id)

    ret.EntityKey = _extract_attribute(root, 'EntityKey', str, ret.EntityKey)

    ret.FilenameKey = _extract_attribute(root, 'FilenameKey', str, ret.FilenameKey)

    ret.group_type = _extract_attribute(root, 'group_type', str, ret.group_type)

    ret.hierarchy = _extract_attribute(root, 'hierarchy', str, ret.hierarchy)

    ret.id = _extract_attribute(root, 'id', str, ret.id)

    ret.iqv_standard_term = _extract_attribute(root, 'iqv_standard_term', str, ret.iqv_standard_term)

    ret.link_id = _extract_attribute(root, 'link_id', str, ret.link_id)

    ret.link_id_level2 = _extract_attribute(root, 'link_id_level2', str, ret.link_id_level2)

    ret.link_id_level3 = _extract_attribute(root, 'link_id_level3', str, ret.link_id_level3)

    ret.link_id_level4 = _extract_attribute(root, 'link_id_level4', str, ret.link_id_level4)

    ret.link_id_level5 = _extract_attribute(root, 'link_id_level5', str, ret.link_id_level5)

    ret.link_id_level6 = _extract_attribute(root, 'link_id_level6', str, ret.link_id_level6)

    ret.link_id_subsection1 = _extract_attribute(root, 'link_id_subsection1', str, ret.link_id_subsection1)

    ret.link_id_subsection2 = _extract_attribute(root, 'link_id_subsection2', str, ret.link_id_subsection2)

    ret.link_id_subsection3 = _extract_attribute(root, 'link_id_subsection3', str, ret.link_id_subsection3)

    ret.NLPSystem = _extract_attribute(root, 'NLPSystem', str, ret.NLPSystem)

    ret.NLPSystemQueryName = _extract_attribute(root, 'NLPSystemQueryName', str, ret.NLPSystemQueryName)

    ret.NLPSystemVersion = _extract_attribute(root, 'NLPSystemVersion', str, ret.NLPSystemVersion)

    ret.parent_id = _extract_attribute(root, 'parent_id', str, ret.parent_id)

    ret.QCFeedbackUIKey = _extract_attribute(root, 'QCFeedbackUIKey', str, ret.QCFeedbackUIKey)
    return ret


def _readFromXmlToNLP_System_Mapping_dbList(branch: ET.ElementTree):
    """
    Read from XML and load memory object, for list of objects
    """
    root = branch
    ret = []
    for child in root:
        if (child.tag == 'NLP_System_Mapping_db'):
            try:
                ret.append(_readFromXmlToNLP_System_Mapping_db(child))
            except Exception as e:
                # log
                logger.info('Failed to import field ' + child.tag)
    return ret


def _readFromXmlToNLP_Segment_db(branch):
    """
    Read from XML and load memory object
    """

    # get root element
    root = branch

    # initialize NLP_Segment_db
    ret = NLP_Segment_db()

    ret.doc_id = _extract_attribute(root, 'doc_id', str, ret.doc_id)

    ret.group_type = _extract_attribute(root, 'group_type', str, ret.group_type)

    ret.hierarchy = _extract_attribute(root, 'hierarchy', str, ret.hierarchy)

    ret.id = _extract_attribute(root, 'id', str, ret.id)

    ret.iqv_standard_term = _extract_attribute(root, 'iqv_standard_term', str, ret.iqv_standard_term)

    ret.link_id = _extract_attribute(root, 'link_id', str, ret.link_id)

    ret.link_id_level2 = _extract_attribute(root, 'link_id_level2', str, ret.link_id_level2)

    ret.link_id_level3 = _extract_attribute(root, 'link_id_level3', str, ret.link_id_level3)

    ret.link_id_level4 = _extract_attribute(root, 'link_id_level4', str, ret.link_id_level4)

    ret.link_id_level5 = _extract_attribute(root, 'link_id_level5', str, ret.link_id_level5)

    ret.link_id_level6 = _extract_attribute(root, 'link_id_level6', str, ret.link_id_level6)

    ret.link_id_subsection1 = _extract_attribute(root, 'link_id_subsection1', str, ret.link_id_subsection1)

    ret.link_id_subsection2 = _extract_attribute(root, 'link_id_subsection2', str, ret.link_id_subsection2)

    ret.link_id_subsection3 = _extract_attribute(root, 'link_id_subsection3', str, ret.link_id_subsection3)

    ret.parent_id = _extract_attribute(root, 'parent_id', str, ret.parent_id)

    ret.primary_section = _extract_attribute(root, 'primary_section', str, ret.primary_section)

    ret.secondary_section = _extract_attribute(root, 'secondary_section', str, ret.secondary_section)

    ret.segment_type = _extract_attribute(root, 'segment_type', str, ret.segment_type)

    ret.text = _extract_attribute(root, 'text', str, ret.text)

    ret.text_footnotes_list = _extract_attribute_list(root, 'text_footnotes_list', _readFromXmlToStringList,
                                                      ret.text_footnotes_list)
    return ret


def _readFromXmlToNLP_Segment_dbList(branch: ET.ElementTree):
    """
    Read from XML and load memory object, for list of objects
    """
    root = branch
    ret = []
    for child in root:
        if (child.tag == 'NLP_Segment_db'):
            try:
                ret.append(_readFromXmlToNLP_Segment_db(child))
            except Exception as e:
                # log
                logger.info('Failed to import field ' + child.tag)
    return ret


def _readFromXmlToNLP_Relation_db(branch):
    """
    Read from XML and load memory object
    """

    # get root element
    root = branch

    # initialize NLP_Relation_db
    ret = NLP_Relation_db()

    ret.confidence = _extract_attribute(root, 'confidence', float, ret.confidence)

    ret.doc_id = _extract_attribute(root, 'doc_id', str, ret.doc_id)

    ret.entities_list = _extract_attribute(root, 'entities_list', str, ret.entities_list)

    ret.group_type = _extract_attribute(root, 'group_type', str, ret.group_type)

    ret.hierarchy = _extract_attribute(root, 'hierarchy', str, ret.hierarchy)

    ret.id = _extract_attribute(root, 'id', str, ret.id)

    ret.iqv_standard_term = _extract_attribute(root, 'iqv_standard_term', str, ret.iqv_standard_term)

    ret.is_bidirectional = _extract_attribute(root, 'is_bidirectional', int, ret.is_bidirectional)

    ret.is_hierarchical = _extract_attribute(root, 'is_hierarchical', int, ret.is_hierarchical)

    ret.link_id = _extract_attribute(root, 'link_id', str, ret.link_id)

    ret.link_id_level2 = _extract_attribute(root, 'link_id_level2', str, ret.link_id_level2)

    ret.link_id_level3 = _extract_attribute(root, 'link_id_level3', str, ret.link_id_level3)

    ret.link_id_level4 = _extract_attribute(root, 'link_id_level4', str, ret.link_id_level4)

    ret.link_id_level5 = _extract_attribute(root, 'link_id_level5', str, ret.link_id_level5)

    ret.link_id_level6 = _extract_attribute(root, 'link_id_level6', str, ret.link_id_level6)

    ret.link_id_subsection1 = _extract_attribute(root, 'link_id_subsection1', str, ret.link_id_subsection1)

    ret.link_id_subsection2 = _extract_attribute(root, 'link_id_subsection2', str, ret.link_id_subsection2)

    ret.link_id_subsection3 = _extract_attribute(root, 'link_id_subsection3', str, ret.link_id_subsection3)

    ret.parent_id = _extract_attribute(root, 'parent_id', str, ret.parent_id)

    ret.process_source = _extract_attribute(root, 'process_source', str, ret.process_source)

    ret.relation_name = _extract_attribute(root, 'relation_name', str, ret.relation_name)

    ret.relation_type = _extract_attribute(root, 'relation_type', str, ret.relation_type)
    return ret


def _readFromXmlToNLP_Relation_dbList(branch: ET.ElementTree):
    """
    Read from XML and load memory object, for list of objects
    """
    root = branch
    ret = []
    for child in root:
        if (child.tag == 'NLP_Relation_db'):
            try:
                ret.append(_readFromXmlToNLP_Relation_db(child))
            except Exception as e:
                # log
                logger.info('Failed to import field ' + child.tag)
    return ret


def _readFromXmlToIQVTableRow_db(branch):
    """
    Read from XML and load memory object
    """

    # get root element
    root = branch

    # initialize IQVTableRow_db
    ret = IQVTableRow_db()

    ret.doc_id = _extract_attribute(root, 'doc_id', str, ret.doc_id)

    ret.group_type = _extract_attribute(root, 'group_type', str, ret.group_type)

    ret.header = _extract_attribute(root, 'header', str, ret.header)

    ret.hierarchy = _extract_attribute(root, 'hierarchy', str, ret.hierarchy)

    ret.id = _extract_attribute(root, 'id', str, ret.id)

    ret.iqv_standard_term = _extract_attribute(root, 'iqv_standard_term', str, ret.iqv_standard_term)

    ret.link_id = _extract_attribute(root, 'link_id', str, ret.link_id)

    ret.link_id_level2 = _extract_attribute(root, 'link_id_level2', str, ret.link_id_level2)

    ret.link_id_level3 = _extract_attribute(root, 'link_id_level3', str, ret.link_id_level3)

    ret.link_id_level4 = _extract_attribute(root, 'link_id_level4', str, ret.link_id_level4)

    ret.link_id_level5 = _extract_attribute(root, 'link_id_level5', str, ret.link_id_level5)

    ret.link_id_level6 = _extract_attribute(root, 'link_id_level6', str, ret.link_id_level6)

    ret.link_id_subsection1 = _extract_attribute(root, 'link_id_subsection1', str, ret.link_id_subsection1)

    ret.link_id_subsection2 = _extract_attribute(root, 'link_id_subsection2', str, ret.link_id_subsection2)

    ret.link_id_subsection3 = _extract_attribute(root, 'link_id_subsection3', str, ret.link_id_subsection3)

    ret.maxY = _extract_attribute(root, 'maxY', int, ret.maxY)

    ret.minY = _extract_attribute(root, 'minY', int, ret.minY)

    ret.parent_id = _extract_attribute(root, 'parent_id', str, ret.parent_id)

    ret.tableIndex = _extract_attribute(root, 'tableIndex', int, ret.tableIndex)

    ret.tableRowIndex = _extract_attribute(root, 'tableRowIndex', int, ret.tableRowIndex)

    ret.tableRowRef = _extract_attribute(root, 'tableRowRef', str, ret.tableRowRef)
    return ret


def _readFromXmlToIQVTableRow_dbList(branch: ET.ElementTree):
    """
    Read from XML and load memory object, for list of objects
    """
    root = branch
    ret = []
    for child in root:
        if (child.tag == 'IQVTableRow_db'):
            try:
                ret.append(_readFromXmlToIQVTableRow_db(child))
            except Exception as e:
                # log
                logger.info('Failed to import field ' + child.tag)
    return ret


def _readFromXmlToIQVTableColumn_db(branch):
    """
    Read from XML and load memory object
    """

    # get root element
    root = branch

    # initialize IQVTableColumn_db
    ret = IQVTableColumn_db()

    ret.doc_id = _extract_attribute(root, 'doc_id', str, ret.doc_id)

    ret.group_type = _extract_attribute(root, 'group_type', str, ret.group_type)

    ret.hierarchy = _extract_attribute(root, 'hierarchy', str, ret.hierarchy)

    ret.id = _extract_attribute(root, 'id', str, ret.id)

    ret.iqv_standard_term = _extract_attribute(root, 'iqv_standard_term', str, ret.iqv_standard_term)

    ret.link_id = _extract_attribute(root, 'link_id', str, ret.link_id)

    ret.link_id_level2 = _extract_attribute(root, 'link_id_level2', str, ret.link_id_level2)

    ret.link_id_level3 = _extract_attribute(root, 'link_id_level3', str, ret.link_id_level3)

    ret.link_id_level4 = _extract_attribute(root, 'link_id_level4', str, ret.link_id_level4)

    ret.link_id_level5 = _extract_attribute(root, 'link_id_level5', str, ret.link_id_level5)

    ret.link_id_level6 = _extract_attribute(root, 'link_id_level6', str, ret.link_id_level6)

    ret.link_id_subsection1 = _extract_attribute(root, 'link_id_subsection1', str, ret.link_id_subsection1)

    ret.link_id_subsection2 = _extract_attribute(root, 'link_id_subsection2', str, ret.link_id_subsection2)

    ret.link_id_subsection3 = _extract_attribute(root, 'link_id_subsection3', str, ret.link_id_subsection3)

    ret.maxX = _extract_attribute(root, 'maxX', int, ret.maxX)

    ret.minX = _extract_attribute(root, 'minX', int, ret.minX)

    ret.parent_id = _extract_attribute(root, 'parent_id', str, ret.parent_id)

    ret.table_roi_id = _extract_attribute(root, 'table_roi_id', str, ret.table_roi_id)

    ret.tableColumnIndex = _extract_attribute(root, 'tableColumnIndex', int, ret.tableColumnIndex)

    ret.tableColumnRef = _extract_attribute(root, 'tableColumnRef', str, ret.tableColumnRef)

    ret.tableIndex = _extract_attribute(root, 'tableIndex', int, ret.tableIndex)
    return ret


def _readFromXmlToIQVTableColumn_dbList(branch: ET.ElementTree):
    """
    Read from XML and load memory object, for list of objects
    """
    root = branch
    ret = []
    for child in root:
        if (child.tag == 'IQVTableColumn_db'):
            try:
                ret.append(_readFromXmlToIQVTableColumn_db(child))
            except Exception as e:
                # log
                logger.info('Failed to import field ' + child.tag)
    return ret


def _readFromXmlToIQVTableColumnHeader_db(branch):
    """
    Read from XML and load memory object
    """

    # get root element
    root = branch

    # initialize IQVTableColumnHeader_db
    ret = IQVTableColumnHeader_db()

    ret.doc_id = _extract_attribute(root, 'doc_id', str, ret.doc_id)

    ret.group_type = _extract_attribute(root, 'group_type', str, ret.group_type)

    ret.hierarchy = _extract_attribute(root, 'hierarchy', str, ret.hierarchy)

    ret.id = _extract_attribute(root, 'id', str, ret.id)

    ret.iqv_standard_term = _extract_attribute(root, 'iqv_standard_term', str, ret.iqv_standard_term)

    ret.link_id = _extract_attribute(root, 'link_id', str, ret.link_id)

    ret.link_id_level2 = _extract_attribute(root, 'link_id_level2', str, ret.link_id_level2)

    ret.link_id_level3 = _extract_attribute(root, 'link_id_level3', str, ret.link_id_level3)

    ret.link_id_level4 = _extract_attribute(root, 'link_id_level4', str, ret.link_id_level4)

    ret.link_id_level5 = _extract_attribute(root, 'link_id_level5', str, ret.link_id_level5)

    ret.link_id_level6 = _extract_attribute(root, 'link_id_level6', str, ret.link_id_level6)

    ret.link_id_subsection1 = _extract_attribute(root, 'link_id_subsection1', str, ret.link_id_subsection1)

    ret.link_id_subsection2 = _extract_attribute(root, 'link_id_subsection2', str, ret.link_id_subsection2)

    ret.link_id_subsection3 = _extract_attribute(root, 'link_id_subsection3', str, ret.link_id_subsection3)

    ret.OriginalText = _extract_attribute(root, 'OriginalText', str, ret.OriginalText)

    ret.parent_id = _extract_attribute(root, 'parent_id', str, ret.parent_id)

    ret.roi_id = _extract_attribute(root, 'roi_id', str, ret.roi_id)

    ret.rowIndex = _extract_attribute(root, 'rowIndex', int, ret.rowIndex)

    ret.rowRef = _extract_attribute(root, 'rowRef', str, ret.rowRef)
    return ret


def _readFromXmlToIQVTableColumnHeader_dbList(branch: ET.ElementTree):
    """
    Read from XML and load memory object, for list of objects
    """
    root = branch
    ret = []
    for child in root:
        if (child.tag == 'IQVTableColumnHeader_db'):
            try:
                ret.append(_readFromXmlToIQVTableColumnHeader_db(child))
            except Exception as e:
                # log
                logger.info('Failed to import field ' + child.tag)
    return ret


def _readFromXmlToNLP_Entity_db(branch):
    """
    Read from XML and load memory object
    """

    # get root element
    root = branch

    # initialize NLP_Entity_db
    ret = NLP_Entity_db()

    ret.confidence = _extract_attribute(root, 'confidence', float, ret.confidence)

    ret.doc_id = _extract_attribute(root, 'doc_id', str, ret.doc_id)

    ret.dts = _extract_attribute(root, 'dts', str, ret.dts)

    ret.entity_class = _extract_attribute(root, 'entity_class', str, ret.entity_class)

    ret.entity_index = _extract_attribute(root, 'entity_index', str, ret.entity_index)

    ret.entity_key = _extract_attribute(root, 'entity_key', str, ret.entity_key)

    ret.group_type = _extract_attribute(root, 'group_type', str, ret.group_type)

    ret.hierarchy = _extract_attribute(root, 'hierarchy', str, ret.hierarchy)

    ret.id = _extract_attribute(root, 'id', str, ret.id)

    ret.iqv_standard_term = _extract_attribute(root, 'iqv_standard_term', str, ret.iqv_standard_term)

    ret.link_id = _extract_attribute(root, 'link_id', str, ret.link_id)

    ret.link_id_level2 = _extract_attribute(root, 'link_id_level2', str, ret.link_id_level2)

    ret.link_id_level3 = _extract_attribute(root, 'link_id_level3', str, ret.link_id_level3)

    ret.link_id_level4 = _extract_attribute(root, 'link_id_level4', str, ret.link_id_level4)

    ret.link_id_level5 = _extract_attribute(root, 'link_id_level5', str, ret.link_id_level5)

    ret.link_id_level6 = _extract_attribute(root, 'link_id_level6', str, ret.link_id_level6)

    ret.link_id_subsection1 = _extract_attribute(root, 'link_id_subsection1', str, ret.link_id_subsection1)

    ret.link_id_subsection2 = _extract_attribute(root, 'link_id_subsection2', str, ret.link_id_subsection2)

    ret.link_id_subsection3 = _extract_attribute(root, 'link_id_subsection3', str, ret.link_id_subsection3)

    ret.negated = _extract_attribute(root, 'negated', str, ret.negated)

    ret.ontology = _extract_attribute(root, 'ontology', str, ret.ontology)

    ret.ontology_item_code = _extract_attribute(root, 'ontology_item_code', str, ret.ontology_item_code)

    ret.ontology_version = _extract_attribute(root, 'ontology_version', str, ret.ontology_version)

    ret.parent_id = _extract_attribute(root, 'parent_id', str, ret.parent_id)

    ret.process_source = _extract_attribute(root, 'process_source', str, ret.process_source)

    ret.standard_entity_name = _extract_attribute(root, 'standard_entity_name', str, ret.standard_entity_name)

    ret.start = _extract_attribute(root, 'start', int, ret.start)

    ret.text = _extract_attribute(root, 'text', str, ret.text)

    ret.text_len = _extract_attribute(root, 'text_len', int, ret.text_len)

    ret.user_id = _extract_attribute(root, 'user_id', str, ret.user_id)
    return ret


def _readFromXmlToNLP_Entity_dbList(branch: ET.ElementTree):
    """
    Read from XML and load memory object, for list of objects
    """
    root = branch
    ret = []
    for child in root:
        if (child.tag == 'NLP_Entity_db'):
            try:
                ret.append(_readFromXmlToNLP_Entity_db(child))
            except Exception as e:
                # log
                logger.info('Failed to import field ' + child.tag)
    return ret


def _readFromXmlToIQVConceptTerm_db(branch):
    """
    Read from XML and load memory object
    """

    # get root element
    root = branch

    # initialize IQVConceptTerm_db
    ret = IQVConceptTerm_db()

    ret.cui = _extract_attribute(root, 'cui', str, ret.cui)

    ret.entity_class = _extract_attribute(root, 'entity_class', str, ret.entity_class)

    ret.entity_text = _extract_attribute(root, 'entity_text', str, ret.entity_text)

    ret.entity_xref = _extract_attribute(root, 'entity_xref', str, ret.entity_xref)

    ret.id = _extract_attribute(root, 'id', str, ret.id)

    ret.info = _extract_attribute(root, 'info', str, ret.info)

    ret.ontology = _extract_attribute(root, 'ontology', str, ret.ontology)

    ret.preferred_term = _extract_attribute(root, 'preferred_term', str, ret.preferred_term)
    return ret


def _readFromXmlToIQVConceptTerm_dbList(branch: ET.ElementTree):
    """
    Read from XML and load memory object, for list of objects
    """
    root = branch
    ret = []
    for child in root:
        if (child.tag == 'IQVConceptTerm_db'):
            try:
                ret.append(_readFromXmlToIQVConceptTerm_db(child))
            except Exception as e:
                # log
                logger.info('Failed to import field ' + child.tag)
    return ret


def _readFromXmlToIQVConceptRelation_db(branch):
    """
    Read from XML and load memory object
    """

    # get root element
    root = branch

    # initialize IQVConceptRelation_db
    ret = IQVConceptRelation_db()

    ret.context_unit = _extract_attribute(root, 'context_unit', str, ret.context_unit)

    ret.dts = _extract_attribute(root, 'dts', str, ret.dts)

    ret.id = _extract_attribute(root, 'id', str, ret.id)

    ret.id1 = _extract_attribute(root, 'id1', str, ret.id1)

    ret.id2 = _extract_attribute(root, 'id2', str, ret.id2)

    ret.relation_type = _extract_attribute(root, 'relation_type', str, ret.relation_type)

    ret.user_id = _extract_attribute(root, 'user_id', str, ret.user_id)

    ret.weight = _extract_attribute(root, 'weight', float, ret.weight)
    return ret


def _readFromXmlToIQVConceptRelation_dbList(branch: ET.ElementTree):
    """
    Read from XML and load memory object, for list of objects
    """
    root = branch
    ret = []
    for child in root:
        if (child.tag == 'IQVConceptRelation_db'):
            try:
                ret.append(_readFromXmlToIQVConceptRelation_db(child))
            except Exception as e:
                # log
                logger.info('Failed to import field ' + child.tag)
    return ret


def _readFromXmlToNLP_Attribute_db(branch):
    """
    Read from XML and load memory object
    """

    # get root element
    root = branch

    # initialize NLP_Attribute_db
    ret = NLP_Attribute_db()

    ret.attribute_class = _extract_attribute(root, 'attribute_class', str, ret.attribute_class)

    ret.attribute_index = _extract_attribute(root, 'attribute_index', str, ret.attribute_index)

    ret.doc_id = _extract_attribute(root, 'doc_id', str, ret.doc_id)

    ret.group_type = _extract_attribute(root, 'group_type', str, ret.group_type)

    ret.hierarchy = _extract_attribute(root, 'hierarchy', str, ret.hierarchy)

    ret.id = _extract_attribute(root, 'id', str, ret.id)

    ret.iqv_standard_term = _extract_attribute(root, 'iqv_standard_term', str, ret.iqv_standard_term)

    ret.link_id = _extract_attribute(root, 'link_id', str, ret.link_id)

    ret.link_id_level2 = _extract_attribute(root, 'link_id_level2', str, ret.link_id_level2)

    ret.link_id_level3 = _extract_attribute(root, 'link_id_level3', str, ret.link_id_level3)

    ret.link_id_level4 = _extract_attribute(root, 'link_id_level4', str, ret.link_id_level4)

    ret.link_id_level5 = _extract_attribute(root, 'link_id_level5', str, ret.link_id_level5)

    ret.link_id_level6 = _extract_attribute(root, 'link_id_level6', str, ret.link_id_level6)

    ret.link_id_subsection1 = _extract_attribute(root, 'link_id_subsection1', str, ret.link_id_subsection1)

    ret.link_id_subsection2 = _extract_attribute(root, 'link_id_subsection2', str, ret.link_id_subsection2)

    ret.link_id_subsection3 = _extract_attribute(root, 'link_id_subsection3', str, ret.link_id_subsection3)

    ret.parent_id = _extract_attribute(root, 'parent_id', str, ret.parent_id)

    ret.process_source = _extract_attribute(root, 'process_source', str, ret.process_source)

    ret.start = _extract_attribute(root, 'start', int, ret.start)

    ret.text = _extract_attribute(root, 'text', str, ret.text)
    return ret


def _readFromXmlToNLP_Attribute_dbList(branch: ET.ElementTree):
    """
    Read from XML and load memory object, for list of objects
    """
    root = branch
    ret = []
    for child in root:
        if (child.tag == 'NLP_Attribute_db'):
            try:
                ret.append(_readFromXmlToNLP_Attribute_db(child))
            except Exception as e:
                # log
                logger.info('Failed to import field ' + child.tag)
    return ret


def _readFromXmlToIQVAssessmentVisitRecord_db(branch):
    """
    Read from XML and load memory object
    """

    # get root element
    root = branch

    # initialize IQVAssessmentVisitRecord_db
    ret = IQVAssessmentVisitRecord_db()

    ret.assessment = _extract_attribute(root, 'assessment', str, ret.assessment)

    ret.assessment_text = _extract_attribute(root, 'assessment_text', str, ret.assessment_text)

    ret.cycle_timepoint = _extract_attribute(root, 'cycle_timepoint', str, ret.cycle_timepoint)

    ret.day_timepoint = _extract_attribute(root, 'day_timepoint', str, ret.day_timepoint)

    ret.doc_id = _extract_attribute(root, 'doc_id', str, ret.doc_id)

    ret.DocumentSequenceIndex = _extract_attribute(root, 'DocumentSequenceIndex', int, ret.DocumentSequenceIndex)

    ret.dts = _extract_attribute(root, 'dts', str, ret.dts)

    ret.epoch_timepoint = _extract_attribute(root, 'epoch_timepoint', str, ret.epoch_timepoint)

    ret.footnote_0 = _extract_attribute(root, 'footnote_0', str, ret.footnote_0)

    ret.footnote_1 = _extract_attribute(root, 'footnote_1', str, ret.footnote_1)

    ret.footnote_2 = _extract_attribute(root, 'footnote_2', str, ret.footnote_2)

    ret.footnote_3 = _extract_attribute(root, 'footnote_3', str, ret.footnote_3)

    ret.footnote_4 = _extract_attribute(root, 'footnote_4', str, ret.footnote_4)

    ret.footnote_5 = _extract_attribute(root, 'footnote_5', str, ret.footnote_5)

    ret.footnote_6 = _extract_attribute(root, 'footnote_6', str, ret.footnote_6)

    ret.footnote_7 = _extract_attribute(root, 'footnote_7', str, ret.footnote_7)

    ret.footnote_8 = _extract_attribute(root, 'footnote_8', str, ret.footnote_8)

    ret.footnote_9 = _extract_attribute(root, 'footnote_9', str, ret.footnote_9)

    ret.id = _extract_attribute(root, 'id', str, ret.id)

    ret.indicator_text = _extract_attribute(root, 'indicator_text', str, ret.indicator_text)

    ret.month_timepoint = _extract_attribute(root, 'month_timepoint', str, ret.month_timepoint)

    ret.pname = _extract_attribute(root, 'pname', str, ret.pname)

    ret.procedure = _extract_attribute(root, 'procedure', str, ret.procedure)

    ret.procedure_text = _extract_attribute(root, 'procedure_text', str, ret.procedure_text)

    ret.ProcessMachineName = _extract_attribute(root, 'ProcessMachineName', str, ret.ProcessMachineName)

    ret.ProcessVersion = _extract_attribute(root, 'ProcessVersion', str, ret.ProcessVersion)

    ret.roi_id = _extract_attribute(root, 'roi_id', str, ret.roi_id)

    ret.run_id = _extract_attribute(root, 'run_id', str, ret.run_id)

    ret.section = _extract_attribute(root, 'section', str, ret.section)

    ret.study_cohort = _extract_attribute(root, 'study_cohort', str, ret.study_cohort)

    ret.table_link_text = _extract_attribute(root, 'table_link_text', str, ret.table_link_text)

    ret.table_roi_id = _extract_attribute(root, 'table_roi_id', str, ret.table_roi_id)

    ret.table_sequence_index = _extract_attribute(root, 'table_sequence_index', int, ret.table_sequence_index)

    ret.visit_timepoint = _extract_attribute(root, 'visit_timepoint', str, ret.visit_timepoint)

    ret.week_timepoint = _extract_attribute(root, 'week_timepoint', str, ret.week_timepoint)

    ret.window_timepoint = _extract_attribute(root, 'window_timepoint', str, ret.window_timepoint)

    ret.year_timepoint = _extract_attribute(root, 'year_timepoint', str, ret.year_timepoint)
    return ret


def _readFromXmlToIQVAssessmentVisitRecord_dbList(branch: ET.ElementTree):
    """
    Read from XML and load memory object, for list of objects
    """
    root = branch
    ret = []
    for child in root:
        if (child.tag == 'IQVAssessmentVisitRecord_db'):
            try:
                ret.append(_readFromXmlToIQVAssessmentVisitRecord_db(child))
            except Exception as e:
                # log
                logger.info('Failed to import field ' + child.tag)
    return ret


def _readFromXmlToIQVAssessmentRecord_db(branch):
    """
    Read from XML and load memory object
    """

    # get root element
    root = branch

    # initialize IQVAssessmentRecord_db
    ret = IQVAssessmentRecord_db()

    ret.assessment = _extract_attribute(root, 'assessment', str, ret.assessment)

    ret.assessment_text = _extract_attribute(root, 'assessment_text', str, ret.assessment_text)

    ret.doc_id = _extract_attribute(root, 'doc_id', str, ret.doc_id)

    ret.DocumentSequenceIndex = _extract_attribute(root, 'DocumentSequenceIndex', int, ret.DocumentSequenceIndex)

    ret.dts = _extract_attribute(root, 'dts', str, ret.dts)

    ret.footnote_0 = _extract_attribute(root, 'footnote_0', str, ret.footnote_0)

    ret.footnote_1 = _extract_attribute(root, 'footnote_1', str, ret.footnote_1)

    ret.footnote_2 = _extract_attribute(root, 'footnote_2', str, ret.footnote_2)

    ret.footnote_3 = _extract_attribute(root, 'footnote_3', str, ret.footnote_3)

    ret.footnote_4 = _extract_attribute(root, 'footnote_4', str, ret.footnote_4)

    ret.footnote_5 = _extract_attribute(root, 'footnote_5', str, ret.footnote_5)

    ret.footnote_6 = _extract_attribute(root, 'footnote_6', str, ret.footnote_6)

    ret.footnote_7 = _extract_attribute(root, 'footnote_7', str, ret.footnote_7)

    ret.footnote_8 = _extract_attribute(root, 'footnote_8', str, ret.footnote_8)

    ret.footnote_9 = _extract_attribute(root, 'footnote_9', str, ret.footnote_9)

    ret.id = _extract_attribute(root, 'id', str, ret.id)

    ret.num_visits = _extract_attribute(root, 'num_visits', int, ret.num_visits)

    ret.pname = _extract_attribute(root, 'pname', str, ret.pname)

    ret.procedure = _extract_attribute(root, 'procedure', str, ret.procedure)

    ret.procedure_text = _extract_attribute(root, 'procedure_text', str, ret.procedure_text)

    ret.ProcessMachineName = _extract_attribute(root, 'ProcessMachineName', str, ret.ProcessMachineName)

    ret.ProcessVersion = _extract_attribute(root, 'ProcessVersion', str, ret.ProcessVersion)

    ret.roi_id = _extract_attribute(root, 'roi_id', str, ret.roi_id)

    ret.run_id = _extract_attribute(root, 'run_id', str, ret.run_id)

    ret.section = _extract_attribute(root, 'section', str, ret.section)

    ret.study_cohort = _extract_attribute(root, 'study_cohort', str, ret.study_cohort)

    ret.table_link_text = _extract_attribute(root, 'table_link_text', str, ret.table_link_text)

    ret.table_roi_id = _extract_attribute(root, 'table_roi_id', str, ret.table_roi_id)

    ret.table_sequence_index = _extract_attribute(root, 'table_sequence_index', int, ret.table_sequence_index)
    return ret


def _readFromXmlToIQVAssessmentRecord_dbList(branch: ET.ElementTree):
    """
    Read from XML and load memory object, for list of objects
    """
    root = branch
    ret = []
    for child in root:
        if (child.tag == 'IQVAssessmentRecord_db'):
            try:
                ret.append(_readFromXmlToIQVAssessmentRecord_db(child))
            except Exception as e:
                # log
                logger.info('Failed to import field ' + child.tag)
    return ret


def _readFromXmlToIQVLabParameterRecord_db(branch):
    """
    Read from XML and load memory object
    """

    # get root element
    root = branch

    # initialize IQVLabParameterRecord_db
    ret = IQVLabParameterRecord_db()

    ret.assessment = _extract_attribute(root, 'assessment', str, ret.assessment)

    ret.doc_id = _extract_attribute(root, 'doc_id', str, ret.doc_id)

    ret.dts = _extract_attribute(root, 'dts', str, ret.dts)

    ret.id = _extract_attribute(root, 'id', str, ret.id)

    ret.parameter = _extract_attribute(root, 'parameter', str, ret.parameter)

    ret.parameter_text = _extract_attribute(root, 'parameter_text', str, ret.parameter_text)

    ret.pname = _extract_attribute(root, 'pname', str, ret.pname)

    ret.procedure_panel = _extract_attribute(root, 'procedure_panel', str, ret.procedure_panel)

    ret.procedure_panel_text = _extract_attribute(root, 'procedure_panel_text', str, ret.procedure_panel_text)

    ret.ProcessMachineName = _extract_attribute(root, 'ProcessMachineName', str, ret.ProcessMachineName)

    ret.ProcessVersion = _extract_attribute(root, 'ProcessVersion', str, ret.ProcessVersion)

    ret.roi_id = _extract_attribute(root, 'roi_id', str, ret.roi_id)

    ret.run_id = _extract_attribute(root, 'run_id', str, ret.run_id)

    ret.section = _extract_attribute(root, 'section', str, ret.section)

    ret.table_link_text = _extract_attribute(root, 'table_link_text', str, ret.table_link_text)

    ret.table_roi_id = _extract_attribute(root, 'table_roi_id', str, ret.table_roi_id)

    ret.table_sequence_index = _extract_attribute(root, 'table_sequence_index', int, ret.table_sequence_index)
    return ret


def _readFromXmlToIQVLabParameterRecord_dbList(branch: ET.ElementTree):
    """
    Read from XML and load memory object, for list of objects
    """
    root = branch
    ret = []
    for child in root:
        if (child.tag == 'IQVLabParameterRecord_db'):
            try:
                ret.append(_readFromXmlToIQVLabParameterRecord_db(child))
            except Exception as e:
                # log
                logger.info('Failed to import field ' + child.tag)
    return ret


def _readFromXmlToIQVVisitRecord_db(branch):
    """
    Read from XML and load memory object
    """

    # get root element
    root = branch

    # initialize IQVVisitRecord_db
    ret = IQVVisitRecord_db()

    ret.cycle_timepoint = _extract_attribute(root, 'cycle_timepoint', str, ret.cycle_timepoint)

    ret.day_timepoint = _extract_attribute(root, 'day_timepoint', str, ret.day_timepoint)

    ret.doc_id = _extract_attribute(root, 'doc_id', str, ret.doc_id)

    ret.DocumentSequenceIndex = _extract_attribute(root, 'DocumentSequenceIndex', int, ret.DocumentSequenceIndex)

    ret.dts = _extract_attribute(root, 'dts', str, ret.dts)

    ret.epoch_timepoint = _extract_attribute(root, 'epoch_timepoint', str, ret.epoch_timepoint)

    ret.footnote_0 = _extract_attribute(root, 'footnote_0', str, ret.footnote_0)

    ret.footnote_1 = _extract_attribute(root, 'footnote_1', str, ret.footnote_1)

    ret.footnote_2 = _extract_attribute(root, 'footnote_2', str, ret.footnote_2)

    ret.footnote_3 = _extract_attribute(root, 'footnote_3', str, ret.footnote_3)

    ret.footnote_4 = _extract_attribute(root, 'footnote_4', str, ret.footnote_4)

    ret.footnote_5 = _extract_attribute(root, 'footnote_5', str, ret.footnote_5)

    ret.footnote_6 = _extract_attribute(root, 'footnote_6', str, ret.footnote_6)

    ret.footnote_7 = _extract_attribute(root, 'footnote_7', str, ret.footnote_7)

    ret.footnote_8 = _extract_attribute(root, 'footnote_8', str, ret.footnote_8)

    ret.footnote_9 = _extract_attribute(root, 'footnote_9', str, ret.footnote_9)

    ret.id = _extract_attribute(root, 'id', str, ret.id)

    ret.month_timepoint = _extract_attribute(root, 'month_timepoint', str, ret.month_timepoint)

    ret.num_assessments = _extract_attribute(root, 'num_assessments', int, ret.num_assessments)

    ret.pname = _extract_attribute(root, 'pname', str, ret.pname)

    ret.ProcessMachineName = _extract_attribute(root, 'ProcessMachineName', str, ret.ProcessMachineName)

    ret.ProcessVersion = _extract_attribute(root, 'ProcessVersion', str, ret.ProcessVersion)

    ret.run_id = _extract_attribute(root, 'run_id', str, ret.run_id)

    ret.study_cohort = _extract_attribute(root, 'study_cohort', str, ret.study_cohort)

    ret.table_link_text = _extract_attribute(root, 'table_link_text', str, ret.table_link_text)

    ret.table_roi_id = _extract_attribute(root, 'table_roi_id', str, ret.table_roi_id)

    ret.table_sequence_index = _extract_attribute(root, 'table_sequence_index', int, ret.table_sequence_index)

    ret.visit_timepoint = _extract_attribute(root, 'visit_timepoint', str, ret.visit_timepoint)

    ret.week_timepoint = _extract_attribute(root, 'week_timepoint', str, ret.week_timepoint)

    ret.window_timepoint = _extract_attribute(root, 'window_timepoint', str, ret.window_timepoint)

    ret.year_timepoint = _extract_attribute(root, 'year_timepoint', str, ret.year_timepoint)
    return ret


def _readFromXmlToIQVVisitRecord_dbList(branch: ET.ElementTree):
    """
    Read from XML and load memory object, for list of objects
    """
    root = branch
    ret = []
    for child in root:
        if (child.tag == 'IQVVisitRecord_db'):
            try:
                ret.append(_readFromXmlToIQVVisitRecord_db(child))
            except Exception as e:
                # log
                logger.info('Failed to import field ' + child.tag)
    return ret


def _readFromXmlToIQVIECriteriaRecord_db(branch):
    """
    Read from XML and load memory object
    """

    # get root element
    root = branch

    # initialize IQVIECriteriaRecord_db
    ret = IQVIECriteriaRecord_db()

    ret.doc_id = _extract_attribute(root, 'doc_id', str, ret.doc_id)

    ret.DocumentSequenceIndex = _extract_attribute(root, 'DocumentSequenceIndex', int, ret.DocumentSequenceIndex)

    ret.dts = _extract_attribute(root, 'dts', str, ret.dts)

    ret.footnote_0 = _extract_attribute(root, 'footnote_0', str, ret.footnote_0)

    ret.footnote_1 = _extract_attribute(root, 'footnote_1', str, ret.footnote_1)

    ret.footnote_2 = _extract_attribute(root, 'footnote_2', str, ret.footnote_2)

    ret.footnote_3 = _extract_attribute(root, 'footnote_3', str, ret.footnote_3)

    ret.footnote_4 = _extract_attribute(root, 'footnote_4', str, ret.footnote_4)

    ret.footnote_5 = _extract_attribute(root, 'footnote_5', str, ret.footnote_5)

    ret.footnote_6 = _extract_attribute(root, 'footnote_6', str, ret.footnote_6)

    ret.footnote_7 = _extract_attribute(root, 'footnote_7', str, ret.footnote_7)

    ret.footnote_8 = _extract_attribute(root, 'footnote_8', str, ret.footnote_8)

    ret.footnote_9 = _extract_attribute(root, 'footnote_9', str, ret.footnote_9)

    ret.id = _extract_attribute(root, 'id', str, ret.id)

    ret.ie_type = _extract_attribute(root, 'ie_type', str, ret.ie_type)

    ret.item_text = _extract_attribute(root, 'item_text', str, ret.item_text)

    ret.link_text = _extract_attribute(root, 'link_text', str, ret.link_text)

    ret.pname = _extract_attribute(root, 'pname', str, ret.pname)

    ret.procedure = _extract_attribute(root, 'procedure', str, ret.procedure)

    ret.ProcessMachineName = _extract_attribute(root, 'ProcessMachineName', str, ret.ProcessMachineName)

    ret.ProcessVersion = _extract_attribute(root, 'ProcessVersion', str, ret.ProcessVersion)

    ret.roi_id = _extract_attribute(root, 'roi_id', str, ret.roi_id)

    ret.section = _extract_attribute(root, 'section', str, ret.section)

    ret.study_cohort = _extract_attribute(root, 'study_cohort', str, ret.study_cohort)
    return ret


def _readFromXmlToIQVIECriteriaRecord_dbList(branch: ET.ElementTree):
    """
    Read from XML and load memory object, for list of objects
    """
    root = branch
    ret = []
    for child in root:
        if (child.tag == 'IQVIECriteriaRecord_db'):
            try:
                ret.append(_readFromXmlToIQVIECriteriaRecord_db(child))
            except Exception as e:
                # log
                logger.info('Failed to import field ' + child.tag)
    return ret


def _readFromXmlToIQVDocumentVariable_db(branch):
    """
    Read from XML and load memory object
    """

    # get root element
    root = branch

    # initialize IQVDocumentVariable_db
    ret = IQVDocumentVariable_db()

    ret.doc_id = _extract_attribute(root, 'doc_id', str, ret.doc_id)

    ret.dts = _extract_attribute(root, 'dts', str, ret.dts)

    ret.id = _extract_attribute(root, 'id', str, ret.id)

    ret.run_id = _extract_attribute(root, 'run_id', str, ret.run_id)

    ret.source_filename = _extract_attribute(root, 'source_filename', str, ret.source_filename)

    ret.variable_category = _extract_attribute(root, 'variable_category', str, ret.variable_category)

    ret.variable_datatype = _extract_attribute(root, 'variable_datatype', str, ret.variable_datatype)

    ret.variable_index = _extract_attribute(root, 'variable_index', int, ret.variable_index)

    ret.variable_key = _extract_attribute(root, 'variable_key', str, ret.variable_key)

    ret.variable_label = _extract_attribute(root, 'variable_label', str, ret.variable_label)

    ret.variable_listing_filename = _extract_attribute(root, 'variable_listing_filename', str,
                                                       ret.variable_listing_filename)

    ret.variable_notes = _extract_attribute(root, 'variable_notes', str, ret.variable_notes)

    ret.variable_score = _extract_attribute(root, 'variable_score', float, ret.variable_score)

    ret.variable_source = _extract_attribute(root, 'variable_source', str, ret.variable_source)

    ret.variable_value = _extract_attribute(root, 'variable_value', str, ret.variable_value)
    return ret


def _readFromXmlToIQVDocumentVariable_dbList(branch: ET.ElementTree):
    """
    Read from XML and load memory object, for list of objects
    """
    root = branch
    ret = []
    for child in root:
        if (child.tag == 'IQVDocumentVariable_db'):
            try:
                ret.append(_readFromXmlToIQVDocumentVariable_db(child))
            except Exception as e:
                # log
                logger.info('Failed to import field ' + child.tag)
    return ret


def _readFromXmlToQ_EVENT_LOG_ENTRY_db(branch):
    """
    Read from XML and load memory object
    """

    # get root element
    root = branch

    # initialize Q_EVENT_LOG_ENTRY_db
    ret = Q_EVENT_LOG_ENTRY_db()

    ret.bHandled = _extract_attribute(root, 'bHandled', _str2bool, ret.bHandled)

    ret.ClassMapping = _extract_attribute(root, 'ClassMapping', str, ret.ClassMapping)

    ret.CountReplace = _extract_attribute(root, 'CountReplace', int, ret.CountReplace)

    ret.DocumentID = _extract_attribute(root, 'DocumentID', str, ret.DocumentID)

    ret.DocumentName = _extract_attribute(root, 'DocumentName', str, ret.DocumentName)

    ret.DocumentPage = _extract_attribute(root, 'DocumentPage', int, ret.DocumentPage)

    ret.ErrorLevelVal = _extract_attribute(root, 'ErrorLevelVal', int, ret.ErrorLevelVal)

    ret.EventTypeVal = _extract_attribute(root, 'EventTypeVal', int, ret.EventTypeVal)

    ret.FieldMapping = _extract_attribute(root, 'FieldMapping', str, ret.FieldMapping)

    ret.id = _extract_attribute(root, 'id', str, ret.id)

    ret.Message = _extract_attribute(root, 'Message', str, ret.Message)

    ret.StackTrace = _extract_attribute(root, 'StackTrace', str, ret.StackTrace)

    ret.UserEmail = _extract_attribute(root, 'UserEmail', str, ret.UserEmail)

    ret.UserID = _extract_attribute(root, 'UserID', str, ret.UserID)

    ret.UserInputMessage = _extract_attribute(root, 'UserInputMessage', str, ret.UserInputMessage)

    ret.Value = _extract_attribute(root, 'Value', str, ret.Value)
    return ret


def _readFromXmlToQ_EVENT_LOG_ENTRY_dbList(branch: ET.ElementTree):
    """
    Read from XML and load memory object, for list of objects
    """
    root = branch
    ret = []
    for child in root:
        if (child.tag == 'Q_EVENT_LOG_ENTRY_db'):
            try:
                ret.append(_readFromXmlToQ_EVENT_LOG_ENTRY_db(child))
            except Exception as e:
                # log
                logger.info('Failed to import field ' + child.tag)
    return ret


def _readFromXmlToIQVTM_PDFDocumentPage(branch):
    """
    Read from XML and load memory object
    """

    # get root element
    root = branch

    # initialize IQVTM_PDFDocumentPage
    ret = IQVTM_PDFDocumentPage()

    ret.FooterText = _extract_attribute(root, 'FooterText', str, ret.FooterText)

    ret.HeaderText = _extract_attribute(root, 'HeaderText', str, ret.HeaderText)

    ret.Hyperlinks = _extract_attribute_list(root, 'Hyperlinks', _readFromXmlToStringList, ret.Hyperlinks)

    ret.ImageNames = _extract_attribute_list(root, 'ImageNames', _readFromXmlToStringList, ret.ImageNames)

    ret.OrientationIsPortrait = _extract_attribute(root, 'OrientationIsPortrait', _str2bool, ret.OrientationIsPortrait)

    fieldName = 'PageSizeRectangle'
    try:
        item = root.find(fieldName)
        if item is not None:
            subbranch = item
            ret.PageSizeRectangle = _readFromXmlToRectangle(subbranch)
        else:
            pass
    except Exception as e:
        logger.info('Failed to import field ' + fieldName)

    fieldName = 'PageSizeWithRotationRectangle'
    try:
        item = root.find(fieldName)
        if item is not None:
            subbranch = item
            ret.PageSizeWithRotationRectangle = _readFromXmlToRectangle(subbranch)
        else:
            pass
    except Exception as e:
        logger.info('Failed to import field ' + fieldName)

    ret.PDFDocumentPageIndex = _extract_attribute(root, 'PDFDocumentPageIndex', int, ret.PDFDocumentPageIndex)

    ret.PDFDocumentPageText = _extract_attribute(root, 'PDFDocumentPageText', str, ret.PDFDocumentPageText)

    ret.PDFDocumentPageTextNumChars = _extract_attribute(root, 'PDFDocumentPageTextNumChars', int,
                                                         ret.PDFDocumentPageTextNumChars)

    ret.PDFDocumentPageTextNumWords = _extract_attribute(root, 'PDFDocumentPageTextNumWords', int,
                                                         ret.PDFDocumentPageTextNumWords)

    ret.Rotation = _extract_attribute(root, 'Rotation', int, ret.Rotation)

    ret.TitleText = _extract_attribute(root, 'TitleText', str, ret.TitleText)
    return ret


def _readFromXmlToIQVTM_PDFDocumentPageList(branch: ET.ElementTree):
    """
    Read from XML and load memory object, for list of objects
    """
    root = branch
    ret = []
    for child in root:
        if (child.tag == 'IQVTM_PDFDocumentPage'):
            try:
                ret.append(_readFromXmlToIQVTM_PDFDocumentPage(child))
            except Exception as e:
                # log
                logger.info('Failed to import field ' + child.tag)
    return ret


def _readFromXmlToIQVDocumentTest(branch):
    """
    Read from XML and load memory object
    """

    # get root element
    root = branch

    # initialize IQVDocumentTest
    ret = IQVDocumentTest()

    ret.ActualClassFromGT = _extract_attribute(root, 'ActualClassFromGT', str, ret.ActualClassFromGT)

    ret.ActualDIACodeFromGT = _extract_attribute(root, 'ActualDIACodeFromGT', str, ret.ActualDIACodeFromGT)

    ret.CodeVersion = _extract_attribute(root, 'CodeVersion', str, ret.CodeVersion)

    ret.Confidence = _extract_attribute(root, 'Confidence', float, ret.Confidence)

    ret.ConfuserClasses = _extract_attribute_list(root, 'ConfuserClasses', _readFromXmlToStringList,
                                                  ret.ConfuserClasses)

    ret.ConfuserRawLogProbScores = _extract_attribute_list(root, 'ConfuserRawLogProbScores', _readFromXmlToDoubleList,
                                                           ret.ConfuserRawLogProbScores)

    ret.MeanLogProbScoreAllClasses = _extract_attribute(root, 'MeanLogProbScoreAllClasses', float,
                                                        ret.MeanLogProbScoreAllClasses)

    ret.PredictedClass = _extract_attribute(root, 'PredictedClass', str, ret.PredictedClass)

    ret.PredictedDIACode = _extract_attribute(root, 'PredictedDIACode', str, ret.PredictedDIACode)

    ret.RankingActualClass = _extract_attribute(root, 'RankingActualClass', int, ret.RankingActualClass)

    ret.RawLogProbScoreActualClass = _extract_attribute(root, 'RawLogProbScoreActualClass', float,
                                                        ret.RawLogProbScoreActualClass)

    ret.RawLogProbScoreSelectedClass = _extract_attribute(root, 'RawLogProbScoreSelectedClass', float,
                                                          ret.RawLogProbScoreSelectedClass)

    ret.TestDate = _extract_attribute(root, 'TestDate', str, ret.TestDate)

    ret.Variance = _extract_attribute(root, 'Variance', float, ret.Variance)

    ret.ZScore = _extract_attribute(root, 'ZScore', float, ret.ZScore)
    return ret


def _readFromXmlToIQVDocumentTestList(branch: ET.ElementTree):
    """
    Read from XML and load memory object, for list of objects
    """
    root = branch
    ret = []
    for child in root:
        if (child.tag == 'IQVDocumentTest'):
            try:
                ret.append(_readFromXmlToIQVDocumentTest(child))
            except Exception as e:
                # log
                logger.info('Failed to import field ' + child.tag)
    return ret


def _readFromXmlToIQVTM_PDFDocument(branch):
    """
    Read from XML and load memory object
    """

    # get root element
    root = branch

    # initialize IQVTM_PDFDocument
    ret = IQVTM_PDFDocument()

    ret.DocumentClass = _extract_attribute(root, 'DocumentClass', str, ret.DocumentClass)

    fieldName = 'DocumentGroundTruth'
    try:
        item = root.find(fieldName)
        if item is not None:
            subbranch = item
            ret.DocumentGroundTruth = _readFromXmlToIQVDocumentGroundTruth(subbranch)
        else:
            pass
    except Exception as e:
        logger.info('Failed to import field ' + fieldName)

    ret.DocumentName = _extract_attribute(root, 'DocumentName', str, ret.DocumentName)

    ret.id = _extract_attribute(root, 'id', str, ret.id)

    ret.IQVDocumentTests = _extract_attribute_list(root, 'IQVDocumentTests', _readFromXmlToIQVDocumentTestList,
                                                   ret.IQVDocumentTests)

    ret.NumberOfPages = _extract_attribute(root, 'NumberOfPages', int, ret.NumberOfPages)

    ret.PDFDocumentPageList = _extract_attribute_list(root, 'PDFDocumentPageList',
                                                      _readFromXmlToIQVTM_PDFDocumentPageList, ret.PDFDocumentPageList)

    ret.PDFDocumentTextNumChars = _extract_attribute(root, 'PDFDocumentTextNumChars', int, ret.PDFDocumentTextNumChars)
    return ret


def _readFromXmlToIQVTM_PDFDocumentList(branch: ET.ElementTree):
    """
    Read from XML and load memory object, for list of objects
    """
    root = branch
    ret = []
    for child in root:
        if (child.tag == 'IQVTM_PDFDocument'):
            try:
                ret.append(_readFromXmlToIQVTM_PDFDocument(child))
            except Exception as e:
                # log
                logger.info('Failed to import field ' + child.tag)
    return ret


def _readFromXmlToIQVKeyMapping(branch):
    """
    Read from XML and load memory object
    """

    # get root element
    root = branch

    # initialize IQVKeyMapping
    ret = IQVKeyMapping()

    ret.container = _extract_attribute(root, 'container', str, ret.container)

    ret.description = _extract_attribute(root, 'description', str, ret.description)

    ret.key = _extract_attribute(root, 'key', str, ret.key)

    ret.synonyms = _extract_attribute_list(root, 'synonyms', _readFromXmlToIQVKeyValueSetList, ret.synonyms)

    ret.value_type = _extract_attribute(root, 'value_type', str, ret.value_type)
    return ret


def _readFromXmlToIQVKeyMappingList(branch: ET.ElementTree):
    """
    Read from XML and load memory object, for list of objects
    """
    root = branch
    ret = []
    for child in root:
        if (child.tag == 'IQVKeyMapping'):
            try:
                ret.append(_readFromXmlToIQVKeyMapping(child))
            except Exception as e:
                # log
                logger.info('Failed to import field ' + child.tag)
    return ret


def _readFromXmlToIQV_KEY_STRING(branch):
    """
    Read from XML and load memory object
    """

    # get root element
    root = branch

    # initialize IQV_KEY_STRING
    ret = IQV_KEY_STRING()

    ret.KEY_AlternateContent = _extract_attribute(root, 'KEY_AlternateContent', str, ret.KEY_AlternateContent)

    ret.KEY_amendment_number = _extract_attribute(root, 'KEY_amendment_number', str, ret.KEY_amendment_number)

    ret.KEY_approval_date = _extract_attribute(root, 'KEY_approval_date', str, ret.KEY_approval_date)

    ret.KEY_arm = _extract_attribute(root, 'KEY_arm', str, ret.KEY_arm)

    ret.KEY_blank_header = _extract_attribute(root, 'KEY_blank_header', str, ret.KEY_blank_header)

    ret.KEY_blinding = _extract_attribute(root, 'KEY_blinding', str, ret.KEY_blinding)

    ret.KEY_BlockInsert = _extract_attribute(root, 'KEY_BlockInsert', str, ret.KEY_BlockInsert)

    ret.KEY_BlockLineROIExactMatch = _extract_attribute(root, 'KEY_BlockLineROIExactMatch', str,
                                                        ret.KEY_BlockLineROIExactMatch)

    ret.KEY_BlockPrintPage = _extract_attribute(root, 'KEY_BlockPrintPage', str, ret.KEY_BlockPrintPage)

    ret.KEY_BlockROI = _extract_attribute(root, 'KEY_BlockROI', str, ret.KEY_BlockROI)

    ret.KEY_BulletPrefix = _extract_attribute(root, 'KEY_BulletPrefix', str, ret.KEY_BulletPrefix)

    ret.KEY_color = _extract_attribute(root, 'KEY_color', str, ret.KEY_color)

    ret.KEY_COMPARE_base_text = _extract_attribute(root, 'KEY_COMPARE_base_text', str, ret.KEY_COMPARE_base_text)

    ret.KEY_COMPARE_char_roi_base_location = _extract_attribute(root, 'KEY_COMPARE_char_roi_base_location', str,
                                                                ret.KEY_COMPARE_char_roi_base_location)

    ret.KEY_COMPARE_char_roi_compare_location = _extract_attribute(root, 'KEY_COMPARE_char_roi_compare_location', str,
                                                                   ret.KEY_COMPARE_char_roi_compare_location)

    ret.KEY_COMPARE_char_section_location = _extract_attribute(root, 'KEY_COMPARE_char_section_location', str,
                                                               ret.KEY_COMPARE_char_section_location)

    ret.KEY_COMPARE_compare_text = _extract_attribute(root, 'KEY_COMPARE_compare_text', str,
                                                      ret.KEY_COMPARE_compare_text)

    ret.KEY_compare_document_a = _extract_attribute(root, 'KEY_compare_document_a', str, ret.KEY_compare_document_a)

    ret.KEY_compare_document_b = _extract_attribute(root, 'KEY_compare_document_b', str, ret.KEY_compare_document_b)

    ret.KEY_COMPARE_summary_num_chars = _extract_attribute(root, 'KEY_COMPARE_summary_num_chars', str,
                                                           ret.KEY_COMPARE_summary_num_chars)

    ret.KEY_COMPARE_summary_num_diffs = _extract_attribute(root, 'KEY_COMPARE_summary_num_diffs', str,
                                                           ret.KEY_COMPARE_summary_num_diffs)

    ret.KEY_compound = _extract_attribute(root, 'KEY_compound', str, ret.KEY_compound)

    ret.KEY_ConjoinedSegments = _extract_attribute(root, 'KEY_ConjoinedSegments', str, ret.KEY_ConjoinedSegments)

    ret.KEY_control = _extract_attribute(root, 'KEY_control', str, ret.KEY_control)

    ret.KEY_CumulativeWordCount = _extract_attribute(root, 'KEY_CumulativeWordCount', str, ret.KEY_CumulativeWordCount)

    ret.KEY_CustomXML = _extract_attribute(root, 'KEY_CustomXML', str, ret.KEY_CustomXML)

    ret.KEY_decon_soa_max_x = _extract_attribute(root, 'KEY_decon_soa_max_x', str, ret.KEY_decon_soa_max_x)

    ret.KEY_decon_soa_page = _extract_attribute(root, 'KEY_decon_soa_page', str, ret.KEY_decon_soa_page)

    ret.KEY_design = _extract_attribute(root, 'KEY_design', str, ret.KEY_design)

    ret.KEY_DiscontinuationofStudyInterventionsandParticipantWithdrawalHeader = _extract_attribute(root,
                                                                                                   'KEY_DiscontinuationofStudyInterventionsandParticipantWithdrawalHeader',
                                                                                                   str,
                                                                                                   ret.KEY_DiscontinuationofStudyInterventionsandParticipantWithdrawalHeader)

    ret.KEY_DiscontinuationofStudyInterventionsandParticipantWithdrawalRefRoiId = _extract_attribute(root,
                                                                                                     'KEY_DiscontinuationofStudyInterventionsandParticipantWithdrawalRefRoiId',
                                                                                                     str,
                                                                                                     ret.KEY_DiscontinuationofStudyInterventionsandParticipantWithdrawalRefRoiId)

    ret.KEY_document_keyword = _extract_attribute(root, 'KEY_document_keyword', str, ret.KEY_document_keyword)

    ret.KEY_document_status = _extract_attribute(root, 'KEY_document_status', str, ret.KEY_document_status)

    ret.KEY_document_topic = _extract_attribute(root, 'KEY_document_topic', str, ret.KEY_document_topic)

    ret.KEY_document_version = _extract_attribute(root, 'KEY_document_version', str, ret.KEY_document_version)

    ret.KEY_DocumentPropertyKey = _extract_attribute(root, 'KEY_DocumentPropertyKey', str, ret.KEY_DocumentPropertyKey)

    ret.KEY_drug = _extract_attribute(root, 'KEY_drug', str, ret.KEY_drug)

    ret.KEY_dts = _extract_attribute(root, 'KEY_dts', str, ret.KEY_dts)

    ret.KEY_endpoints = _extract_attribute(root, 'KEY_endpoints', str, ret.KEY_endpoints)

    ret.KEY_EndpointsHeader = _extract_attribute(root, 'KEY_EndpointsHeader', str, ret.KEY_EndpointsHeader)

    ret.KEY_EndpointsRefRoiId = _extract_attribute(root, 'KEY_EndpointsRefRoiId', str, ret.KEY_EndpointsRefRoiId)

    ret.KEY_entities_in_assessments = _extract_attribute(root, 'KEY_entities_in_assessments', str,
                                                         ret.KEY_entities_in_assessments)

    ret.KEY_entity_key = _extract_attribute(root, 'KEY_entity_key', str, ret.KEY_entity_key)

    ret.KEY_environment = _extract_attribute(root, 'KEY_environment', str, ret.KEY_environment)

    ret.KEY_exclusion_section = _extract_attribute(root, 'KEY_exclusion_section', str, ret.KEY_exclusion_section)

    ret.KEY_ExclusionCriteriaHeader = _extract_attribute(root, 'KEY_ExclusionCriteriaHeader', str,
                                                         ret.KEY_ExclusionCriteriaHeader)

    ret.KEY_ExclusionCriteriaRefRoiId = _extract_attribute(root, 'KEY_ExclusionCriteriaRefRoiId', str,
                                                           ret.KEY_ExclusionCriteriaRefRoiId)

    ret.KEY_font_bold = _extract_attribute(root, 'KEY_font_bold', str, ret.KEY_font_bold)

    ret.KEY_font_size = _extract_attribute(root, 'KEY_font_size', str, ret.KEY_font_size)

    ret.KEY_font_style = _extract_attribute(root, 'KEY_font_style', str, ret.KEY_font_style)

    ret.KEY_Footnote_ = _extract_attribute(root, 'KEY_Footnote_', str, ret.KEY_Footnote_)

    ret.KEY_FootnoteID_ = _extract_attribute(root, 'KEY_FootnoteID_', str, ret.KEY_FootnoteID_)

    ret.KEY_FootnoteParaROI = _extract_attribute(root, 'KEY_FootnoteParaROI', str, ret.KEY_FootnoteParaROI)

    ret.KEY_FootnoteTableROI = _extract_attribute(root, 'KEY_FootnoteTableROI', str, ret.KEY_FootnoteTableROI)

    ret.KEY_FootnoteText_ = _extract_attribute(root, 'KEY_FootnoteText_', str, ret.KEY_FootnoteText_)

    ret.KEY_gridspan = _extract_attribute(root, 'KEY_gridspan', str, ret.KEY_gridspan)

    ret.KEY_HeaderNumericSection = _extract_attribute(root, 'KEY_HeaderNumericSection', str,
                                                      ret.KEY_HeaderNumericSection)

    ret.KEY_HeaderText = _extract_attribute(root, 'KEY_HeaderText', str, ret.KEY_HeaderText)

    ret.KEY_ilvl = _extract_attribute(root, 'KEY_ilvl', str, ret.KEY_ilvl)

    ret.KEY_inclusion_section = _extract_attribute(root, 'KEY_inclusion_section', str, ret.KEY_inclusion_section)

    ret.KEY_InclusionCriteriaHeader = _extract_attribute(root, 'KEY_InclusionCriteriaHeader', str,
                                                         ret.KEY_InclusionCriteriaHeader)

    ret.KEY_InclusionCriteriaRefRoiId = _extract_attribute(root, 'KEY_InclusionCriteriaRefRoiId', str,
                                                           ret.KEY_InclusionCriteriaRefRoiId)

    ret.KEY_indication = _extract_attribute(root, 'KEY_indication', str, ret.KEY_indication)

    ret.KEY_InsertRectifyText = _extract_attribute(root, 'KEY_InsertRectifyText', str, ret.KEY_InsertRectifyText)

    ret.KEY_intervention_form = _extract_attribute(root, 'KEY_intervention_form', str, ret.KEY_intervention_form)

    ret.KEY_intervention_method = _extract_attribute(root, 'KEY_intervention_method', str, ret.KEY_intervention_method)

    ret.KEY_IntroductionHeader = _extract_attribute(root, 'KEY_IntroductionHeader', str, ret.KEY_IntroductionHeader)

    ret.KEY_IntroductionRefRoiId = _extract_attribute(root, 'KEY_IntroductionRefRoiId', str,
                                                      ret.KEY_IntroductionRefRoiId)

    ret.KEY_investigator = _extract_attribute(root, 'KEY_investigator', str, ret.KEY_investigator)

    ret.KEY_iqv_standard_term = _extract_attribute(root, 'KEY_iqv_standard_term', str, ret.KEY_iqv_standard_term)

    ret.KEY_IsAmendment = _extract_attribute(root, 'KEY_IsAmendment', str, ret.KEY_IsAmendment)

    ret.KEY_IsAttachment = _extract_attribute(root, 'KEY_IsAttachment', str, ret.KEY_IsAttachment)

    ret.KEY_IsColumnHeader = _extract_attribute(root, 'KEY_IsColumnHeader', str, ret.KEY_IsColumnHeader)

    ret.KEY_IsDiscontinuationofStudyInterventionsandParticipantWithdrawalElement = _extract_attribute(root,
                                                                                                      'KEY_IsDiscontinuationofStudyInterventionsandParticipantWithdrawalElement',
                                                                                                      str,
                                                                                                      ret.KEY_IsDiscontinuationofStudyInterventionsandParticipantWithdrawalElement)

    ret.KEY_IsDiscontinuationofStudyInterventionsandParticipantWithdrawalHeader = _extract_attribute(root,
                                                                                                     'KEY_IsDiscontinuationofStudyInterventionsandParticipantWithdrawalHeader',
                                                                                                     str,
                                                                                                     ret.KEY_IsDiscontinuationofStudyInterventionsandParticipantWithdrawalHeader)

    ret.KEY_IsEndpointsElement = _extract_attribute(root, 'KEY_IsEndpointsElement', str, ret.KEY_IsEndpointsElement)

    ret.KEY_IsEndpointsHeader = _extract_attribute(root, 'KEY_IsEndpointsHeader', str, ret.KEY_IsEndpointsHeader)

    ret.KEY_IsEndpointTable = _extract_attribute(root, 'KEY_IsEndpointTable', str, ret.KEY_IsEndpointTable)

    ret.KEY_IsExclusionCriteria = _extract_attribute(root, 'KEY_IsExclusionCriteria', str, ret.KEY_IsExclusionCriteria)

    ret.KEY_IsExclusionCriteriaElement = _extract_attribute(root, 'KEY_IsExclusionCriteriaElement', str,
                                                            ret.KEY_IsExclusionCriteriaElement)

    ret.KEY_IsExclusionCriteriaHeader = _extract_attribute(root, 'KEY_IsExclusionCriteriaHeader', str,
                                                           ret.KEY_IsExclusionCriteriaHeader)

    ret.KEY_IsFootnote = _extract_attribute(root, 'KEY_IsFootnote', str, ret.KEY_IsFootnote)

    ret.KEY_IsFootnote_ = _extract_attribute(root, 'KEY_IsFootnote_', str, ret.KEY_IsFootnote_)

    ret.KEY_IsFootnoteText_ = _extract_attribute(root, 'KEY_IsFootnoteText_', str, ret.KEY_IsFootnoteText_)

    ret.KEY_IsInclusionCriteria = _extract_attribute(root, 'KEY_IsInclusionCriteria', str, ret.KEY_IsInclusionCriteria)

    ret.KEY_IsInclusionCriteriaElement = _extract_attribute(root, 'KEY_IsInclusionCriteriaElement', str,
                                                            ret.KEY_IsInclusionCriteriaElement)

    ret.KEY_IsInclusionCriteriaHeader = _extract_attribute(root, 'KEY_IsInclusionCriteriaHeader', str,
                                                           ret.KEY_IsInclusionCriteriaHeader)

    ret.KEY_IsIntroductionElement = _extract_attribute(root, 'KEY_IsIntroductionElement', str,
                                                       ret.KEY_IsIntroductionElement)

    ret.KEY_IsIntroductionHeader = _extract_attribute(root, 'KEY_IsIntroductionHeader', str,
                                                      ret.KEY_IsIntroductionHeader)

    ret.KEY_IsObjectivesElement = _extract_attribute(root, 'KEY_IsObjectivesElement', str, ret.KEY_IsObjectivesElement)

    ret.KEY_IsObjectivesEndpointsElement = _extract_attribute(root, 'KEY_IsObjectivesEndpointsElement', str,
                                                              ret.KEY_IsObjectivesEndpointsElement)

    ret.KEY_IsObjectivesEndpointsHeader = _extract_attribute(root, 'KEY_IsObjectivesEndpointsHeader', str,
                                                             ret.KEY_IsObjectivesEndpointsHeader)

    ret.KEY_IsObjectivesHeader = _extract_attribute(root, 'KEY_IsObjectivesHeader', str, ret.KEY_IsObjectivesHeader)

    ret.KEY_IsReferencesElement = _extract_attribute(root, 'KEY_IsReferencesElement', str, ret.KEY_IsReferencesElement)

    ret.KEY_IsReferencesHeader = _extract_attribute(root, 'KEY_IsReferencesHeader', str, ret.KEY_IsReferencesHeader)

    ret.KEY_IsRootElement = _extract_attribute(root, 'KEY_IsRootElement', str, ret.KEY_IsRootElement)

    ret.KEY_IsSectionElement = _extract_attribute(root, 'KEY_IsSectionElement', str, ret.KEY_IsSectionElement)

    ret.KEY_IsSectionElementDiff = _extract_attribute(root, 'KEY_IsSectionElementDiff', str,
                                                      ret.KEY_IsSectionElementDiff)

    ret.KEY_IsSectionHeader = _extract_attribute(root, 'KEY_IsSectionHeader', str, ret.KEY_IsSectionHeader)

    ret.KEY_IsSOAAssessment = _extract_attribute(root, 'KEY_IsSOAAssessment', str, ret.KEY_IsSOAAssessment)

    ret.KEY_IsSOAAssessmentPreferredTerm = _extract_attribute(root, 'KEY_IsSOAAssessmentPreferredTerm', str,
                                                              ret.KEY_IsSOAAssessmentPreferredTerm)

    ret.KEY_IsSOAElement = _extract_attribute(root, 'KEY_IsSOAElement', str, ret.KEY_IsSOAElement)

    ret.KEY_IsSOAEpoch = _extract_attribute(root, 'KEY_IsSOAEpoch', str, ret.KEY_IsSOAEpoch)

    ret.KEY_IsSOAHeader = _extract_attribute(root, 'KEY_IsSOAHeader', str, ret.KEY_IsSOAHeader)

    ret.KEY_IsSOALink = _extract_attribute(root, 'KEY_IsSOALink', str, ret.KEY_IsSOALink)

    ret.KEY_IsSOATable = _extract_attribute(root, 'KEY_IsSOATable', str, ret.KEY_IsSOATable)

    ret.KEY_IsSOATableColumn = _extract_attribute(root, 'KEY_IsSOATableColumn', str, ret.KEY_IsSOATableColumn)

    ret.KEY_IsStatisticalConsiderationsElement = _extract_attribute(root, 'KEY_IsStatisticalConsiderationsElement',
                                                                    str, ret.KEY_IsStatisticalConsiderationsElement)

    ret.KEY_IsStatisticalConsiderationsHeader = _extract_attribute(root, 'KEY_IsStatisticalConsiderationsHeader', str,
                                                                   ret.KEY_IsStatisticalConsiderationsHeader)

    ret.KEY_IsStudyAssessmentsandProceduresElement = _extract_attribute(root,
                                                                        'KEY_IsStudyAssessmentsandProceduresElement',
                                                                        str,
                                                                        ret.KEY_IsStudyAssessmentsandProceduresElement)

    ret.KEY_IsStudyAssessmentsandProceduresHeader = _extract_attribute(root,
                                                                       'KEY_IsStudyAssessmentsandProceduresHeader',
                                                                       str,
                                                                       ret.KEY_IsStudyAssessmentsandProceduresHeader)

    ret.KEY_IsStudyDesignElement = _extract_attribute(root, 'KEY_IsStudyDesignElement', str,
                                                      ret.KEY_IsStudyDesignElement)

    ret.KEY_IsStudyDesignHeader = _extract_attribute(root, 'KEY_IsStudyDesignHeader', str, ret.KEY_IsStudyDesignHeader)

    ret.KEY_IsStudyInterventionsandConcomitantTherapyElement = _extract_attribute(root,
                                                                                  'KEY_IsStudyInterventionsandConcomitantTherapyElement',
                                                                                  str,
                                                                                  ret.KEY_IsStudyInterventionsandConcomitantTherapyElement)

    ret.KEY_IsStudyInterventionsandConcomitantTherapyHeader = _extract_attribute(root,
                                                                                 'KEY_IsStudyInterventionsandConcomitantTherapyHeader',
                                                                                 str,
                                                                                 ret.KEY_IsStudyInterventionsandConcomitantTherapyHeader)

    ret.KEY_IsStudyPopulationElement = _extract_attribute(root, 'KEY_IsStudyPopulationElement', str,
                                                          ret.KEY_IsStudyPopulationElement)

    ret.KEY_IsStudyPopulationHeader = _extract_attribute(root, 'KEY_IsStudyPopulationHeader', str,
                                                         ret.KEY_IsStudyPopulationHeader)

    ret.KEY_IsSummaryElement = _extract_attribute(root, 'KEY_IsSummaryElement', str, ret.KEY_IsSummaryElement)

    ret.KEY_IsSummaryHeader = _extract_attribute(root, 'KEY_IsSummaryHeader', str, ret.KEY_IsSummaryHeader)

    ret.KEY_IsSupportingDocumentationElement = _extract_attribute(root, 'KEY_IsSupportingDocumentationElement', str,
                                                                  ret.KEY_IsSupportingDocumentationElement)

    ret.KEY_IsSupportingDocumentationHeader = _extract_attribute(root, 'KEY_IsSupportingDocumentationHeader', str,
                                                                 ret.KEY_IsSupportingDocumentationHeader)

    ret.KEY_IsTOAElement = _extract_attribute(root, 'KEY_IsTOAElement', str, ret.KEY_IsTOAElement)

    ret.KEY_IsTOAHeader = _extract_attribute(root, 'KEY_IsTOAHeader', str, ret.KEY_IsTOAHeader)

    ret.KEY_IsTOCElement = _extract_attribute(root, 'KEY_IsTOCElement', str, ret.KEY_IsTOCElement)

    ret.KEY_IsTOCHeader = _extract_attribute(root, 'KEY_IsTOCHeader', str, ret.KEY_IsTOCHeader)

    ret.KEY_IsTOCLink = _extract_attribute(root, 'KEY_IsTOCLink', str, ret.KEY_IsTOCLink)

    ret.KEY_IsTOFElement = _extract_attribute(root, 'KEY_IsTOFElement', str, ret.KEY_IsTOFElement)

    ret.KEY_IsTOFHeader = _extract_attribute(root, 'KEY_IsTOFHeader', str, ret.KEY_IsTOFHeader)

    ret.KEY_IsTOTElement = _extract_attribute(root, 'KEY_IsTOTElement', str, ret.KEY_IsTOTElement)

    ret.KEY_IsTOTHeader = _extract_attribute(root, 'KEY_IsTOTHeader', str, ret.KEY_IsTOTHeader)

    ret.KEY_ItemType = _extract_attribute(root, 'KEY_ItemType', str, ret.KEY_ItemType)

    ret.KEY_ItemType_Endpoint = _extract_attribute(root, 'KEY_ItemType_Endpoint', str, ret.KEY_ItemType_Endpoint)

    ret.KEY_ItemType_EndpointType = _extract_attribute(root, 'KEY_ItemType_EndpointType', str,
                                                       ret.KEY_ItemType_EndpointType)

    ret.KEY_ItemType_Objective = _extract_attribute(root, 'KEY_ItemType_Objective', str, ret.KEY_ItemType_Objective)

    ret.KEY_ItemType_ObjectiveType = _extract_attribute(root, 'KEY_ItemType_ObjectiveType', str,
                                                        ret.KEY_ItemType_ObjectiveType)

    ret.KEY_LinkLevel = _extract_attribute(root, 'KEY_LinkLevel', str, ret.KEY_LinkLevel)

    ret.KEY_LinkPage = _extract_attribute(root, 'KEY_LinkPage', str, ret.KEY_LinkPage)

    ret.KEY_LinkPageLHS = _extract_attribute(root, 'KEY_LinkPageLHS', str, ret.KEY_LinkPageLHS)

    ret.KEY_LinkPageRHS = _extract_attribute(root, 'KEY_LinkPageRHS', str, ret.KEY_LinkPageRHS)

    ret.KEY_LinkPrefix = _extract_attribute(root, 'KEY_LinkPrefix', str, ret.KEY_LinkPrefix)

    ret.KEY_LinkROI = _extract_attribute(root, 'KEY_LinkROI', str, ret.KEY_LinkROI)

    ret.KEY_LinkText = _extract_attribute(root, 'KEY_LinkText', str, ret.KEY_LinkText)

    ret.KEY_ManualInsert = _extract_attribute(root, 'KEY_ManualInsert', str, ret.KEY_ManualInsert)

    ret.KEY_masking = _extract_attribute(root, 'KEY_masking', str, ret.KEY_masking)

    ret.KEY_molecule_device = _extract_attribute(root, 'KEY_molecule_device', str, ret.KEY_molecule_device)

    ret.KEY_next = _extract_attribute(root, 'KEY_next', str, ret.KEY_next)

    ret.KEY_nid = _extract_attribute(root, 'KEY_nid', str, ret.KEY_nid)

    ret.KEY_NormalizedSOA_CSVFilename = _extract_attribute(root, 'KEY_NormalizedSOA_CSVFilename', str,
                                                           ret.KEY_NormalizedSOA_CSVFilename)

    ret.KEY_NormalizedSOA_JSONFilename = _extract_attribute(root, 'KEY_NormalizedSOA_JSONFilename', str,
                                                            ret.KEY_NormalizedSOA_JSONFilename)

    ret.KEY_num_entities = _extract_attribute(root, 'KEY_num_entities', str, ret.KEY_num_entities)

    ret.KEY_number_of_subjects = _extract_attribute(root, 'KEY_number_of_subjects', str, ret.KEY_number_of_subjects)

    ret.KEY_numId = _extract_attribute(root, 'KEY_numId', str, ret.KEY_numId)

    ret.KEY_ObjectiveRefRoiId = _extract_attribute(root, 'KEY_ObjectiveRefRoiId', str, ret.KEY_ObjectiveRefRoiId)

    ret.KEY_objectives_section = _extract_attribute(root, 'KEY_objectives_section', str, ret.KEY_objectives_section)

    ret.KEY_ObjectivesEndpointsHeader = _extract_attribute(root, 'KEY_ObjectivesEndpointsHeader', str,
                                                           ret.KEY_ObjectivesEndpointsHeader)

    ret.KEY_ObjectivesEndpointsRefRoiId = _extract_attribute(root, 'KEY_ObjectivesEndpointsRefRoiId', str,
                                                             ret.KEY_ObjectivesEndpointsRefRoiId)

    ret.KEY_ObjectivesHeader = _extract_attribute(root, 'KEY_ObjectivesHeader', str, ret.KEY_ObjectivesHeader)

    ret.KEY_ObjectivesRefRoiId = _extract_attribute(root, 'KEY_ObjectivesRefRoiId', str, ret.KEY_ObjectivesRefRoiId)

    ret.KEY_observation = _extract_attribute(root, 'KEY_observation', str, ret.KEY_observation)

    ret.KEY_ParaIndex = _extract_attribute(root, 'KEY_ParaIndex', str, ret.KEY_ParaIndex)

    ret.KEY_ParaPrintPage = _extract_attribute(root, 'KEY_ParaPrintPage', str, ret.KEY_ParaPrintPage)

    ret.KEY_ParaROI = _extract_attribute(root, 'KEY_ParaROI', str, ret.KEY_ParaROI)

    ret.KEY_ParaROIExactMatch = _extract_attribute(root, 'KEY_ParaROIExactMatch', str, ret.KEY_ParaROIExactMatch)

    ret.KEY_participant_age = _extract_attribute(root, 'KEY_participant_age', str, ret.KEY_participant_age)

    ret.KEY_participant_sex = _extract_attribute(root, 'KEY_participant_sex', str, ret.KEY_participant_sex)

    ret.KEY_PB_biopsy = _extract_attribute(root, 'KEY_PB_biopsy', str, ret.KEY_PB_biopsy)

    ret.KEY_PB_blood_draw = _extract_attribute(root, 'KEY_PB_blood_draw', str, ret.KEY_PB_blood_draw)

    ret.KEY_PB_caregiver = _extract_attribute(root, 'KEY_PB_caregiver', str, ret.KEY_PB_caregiver)

    ret.KEY_PB_colonoscopy = _extract_attribute(root, 'KEY_PB_colonoscopy', str, ret.KEY_PB_colonoscopy)

    ret.KEY_PB_diary = _extract_attribute(root, 'KEY_PB_diary', str, ret.KEY_PB_diary)

    ret.KEY_PB_discontinue_treatment = _extract_attribute(root, 'KEY_PB_discontinue_treatment', str,
                                                          ret.KEY_PB_discontinue_treatment)

    ret.KEY_PB_endoscopy = _extract_attribute(root, 'KEY_PB_endoscopy', str, ret.KEY_PB_endoscopy)

    ret.KEY_PB_freq_pro = _extract_attribute(root, 'KEY_PB_freq_pro', str, ret.KEY_PB_freq_pro)

    ret.KEY_PB_imaging_ct = _extract_attribute(root, 'KEY_PB_imaging_ct', str, ret.KEY_PB_imaging_ct)

    ret.KEY_PB_imaging_dexa = _extract_attribute(root, 'KEY_PB_imaging_dexa', str, ret.KEY_PB_imaging_dexa)

    ret.KEY_PB_imaging_mammogram = _extract_attribute(root, 'KEY_PB_imaging_mammogram', str,
                                                      ret.KEY_PB_imaging_mammogram)

    ret.KEY_PB_imaging_mri = _extract_attribute(root, 'KEY_PB_imaging_mri', str, ret.KEY_PB_imaging_mri)

    ret.KEY_PB_imaging_pet = _extract_attribute(root, 'KEY_PB_imaging_pet', str, ret.KEY_PB_imaging_pet)

    ret.KEY_PB_imaging_xray = _extract_attribute(root, 'KEY_PB_imaging_xray', str, ret.KEY_PB_imaging_xray)

    ret.KEY_PB_IncludesPRO = _extract_attribute(root, 'KEY_PB_IncludesPRO', str, ret.KEY_PB_IncludesPRO)

    ret.KEY_PB_injectable = _extract_attribute(root, 'KEY_PB_injectable', str, ret.KEY_PB_injectable)

    ret.KEY_PB_injection_gt1_visit = _extract_attribute(root, 'KEY_PB_injection_gt1_visit', str,
                                                        ret.KEY_PB_injection_gt1_visit)

    ret.KEY_PB_inpatient = _extract_attribute(root, 'KEY_PB_inpatient', str, ret.KEY_PB_inpatient)

    ret.KEY_PB_lumbar_puncture = _extract_attribute(root, 'KEY_PB_lumbar_puncture', str, ret.KEY_PB_lumbar_puncture)

    ret.KEY_PB_median_visit_len = _extract_attribute(root, 'KEY_PB_median_visit_len', str, ret.KEY_PB_median_visit_len)

    ret.KEY_PB_novel_drug = _extract_attribute(root, 'KEY_PB_novel_drug', str, ret.KEY_PB_novel_drug)

    ret.KEY_PB_num_visits_per_month = _extract_attribute(root, 'KEY_PB_num_visits_per_month', str,
                                                         ret.KEY_PB_num_visits_per_month)

    ret.KEY_PB_pb_total_score = _extract_attribute(root, 'KEY_PB_pb_total_score', str, ret.KEY_PB_pb_total_score)

    ret.KEY_PB_percent_placebo = _extract_attribute(root, 'KEY_PB_percent_placebo', str, ret.KEY_PB_percent_placebo)

    ret.KEY_PB_percent_visit_blood_gte1 = _extract_attribute(root, 'KEY_PB_percent_visit_blood_gte1', str,
                                                             ret.KEY_PB_percent_visit_blood_gte1)

    ret.KEY_PB_pro = _extract_attribute(root, 'KEY_PB_pro', str, ret.KEY_PB_pro)

    ret.KEY_PB_total_num_months = _extract_attribute(root, 'KEY_PB_total_num_months', str, ret.KEY_PB_total_num_months)

    ret.KEY_PB_total_num_pro = _extract_attribute(root, 'KEY_PB_total_num_pro', str, ret.KEY_PB_total_num_pro)

    ret.KEY_PB_total_num_site_visit = _extract_attribute(root, 'KEY_PB_total_num_site_visit', str,
                                                         ret.KEY_PB_total_num_site_visit)

    ret.KEY_phase = _extract_attribute(root, 'KEY_phase', str, ret.KEY_phase)

    ret.KEY_PhysicalTableIndex = _extract_attribute(root, 'KEY_PhysicalTableIndex', str, ret.KEY_PhysicalTableIndex)

    ret.KEY_population = _extract_attribute(root, 'KEY_population', str, ret.KEY_population)

    ret.KEY_PopulationCountElement = _extract_attribute(root, 'KEY_PopulationCountElement', str,
                                                        ret.KEY_PopulationCountElement)

    ret.KEY_priority = _extract_attribute(root, 'KEY_priority', str, ret.KEY_priority)

    ret.KEY_prob = _extract_attribute(root, 'KEY_prob', str, ret.KEY_prob)

    ret.KEY_ProcessDateTime = _extract_attribute(root, 'KEY_ProcessDateTime', str, ret.KEY_ProcessDateTime)

    ret.KEY_ProcessMachineName = _extract_attribute(root, 'KEY_ProcessMachineName', str, ret.KEY_ProcessMachineName)

    ret.KEY_ProcessName = _extract_attribute(root, 'KEY_ProcessName', str, ret.KEY_ProcessName)

    ret.KEY_ProcessVersion = _extract_attribute(root, 'KEY_ProcessVersion', str, ret.KEY_ProcessVersion)

    ret.KEY_project_id = _extract_attribute(root, 'KEY_project_id', str, ret.KEY_project_id)

    ret.KEY_ProtocolName = _extract_attribute(root, 'KEY_ProtocolName', str, ret.KEY_ProtocolName)

    ret.KEY_ProtocolNumber = _extract_attribute(root, 'KEY_ProtocolNumber', str, ret.KEY_ProtocolNumber)

    ret.KEY_ProtocolNumberElement = _extract_attribute(root, 'KEY_ProtocolNumberElement', str,
                                                       ret.KEY_ProtocolNumberElement)

    ret.KEY_ProtocolSponsorElement = _extract_attribute(root, 'KEY_ProtocolSponsorElement', str,
                                                        ret.KEY_ProtocolSponsorElement)

    ret.KEY_ProtocolTitle = _extract_attribute(root, 'KEY_ProtocolTitle', str, ret.KEY_ProtocolTitle)

    ret.KEY_ProtocolTitleElement = _extract_attribute(root, 'KEY_ProtocolTitleElement', str,
                                                      ret.KEY_ProtocolTitleElement)

    ret.KEY_ProtocolVersion = _extract_attribute(root, 'KEY_ProtocolVersion', str, ret.KEY_ProtocolVersion)

    ret.KEY_pt = _extract_attribute(root, 'KEY_pt', str, ret.KEY_pt)

    ret.KEY_qcfeedback_runid = _extract_attribute(root, 'KEY_qcfeedback_runid', str, ret.KEY_qcfeedback_runid)

    ret.KEY_redaction_any_address = _extract_attribute(root, 'KEY_redaction_any_address', str,
                                                       ret.KEY_redaction_any_address)

    ret.KEY_redaction_any_email = _extract_attribute(root, 'KEY_redaction_any_email', str, ret.KEY_redaction_any_email)

    ret.KEY_redaction_any_organization = _extract_attribute(root, 'KEY_redaction_any_organization', str,
                                                            ret.KEY_redaction_any_organization)

    ret.KEY_redaction_any_telephone = _extract_attribute(root, 'KEY_redaction_any_telephone', str,
                                                         ret.KEY_redaction_any_telephone)

    ret.KEY_redaction_category = _extract_attribute(root, 'KEY_redaction_category', str, ret.KEY_redaction_category)

    ret.KEY_redaction_investigator = _extract_attribute(root, 'KEY_redaction_investigator', str,
                                                        ret.KEY_redaction_investigator)

    ret.KEY_redaction_molecule_name = _extract_attribute(root, 'KEY_redaction_molecule_name', str,
                                                         ret.KEY_redaction_molecule_name)

    ret.KEY_redaction_other_person_role = _extract_attribute(root, 'KEY_redaction_other_person_role', str,
                                                             ret.KEY_redaction_other_person_role)

    ret.KEY_redaction_primary_investigator = _extract_attribute(root, 'KEY_redaction_primary_investigator', str,
                                                                ret.KEY_redaction_primary_investigator)

    ret.KEY_redaction_profile_id = _extract_attribute(root, 'KEY_redaction_profile_id', str,
                                                      ret.KEY_redaction_profile_id)

    ret.KEY_redaction_qualified_physician = _extract_attribute(root, 'KEY_redaction_qualified_physician', str,
                                                               ret.KEY_redaction_qualified_physician)

    ret.KEY_redaction_sponsor_address = _extract_attribute(root, 'KEY_redaction_sponsor_address', str,
                                                           ret.KEY_redaction_sponsor_address)

    ret.KEY_redaction_sponsor_monitor = _extract_attribute(root, 'KEY_redaction_sponsor_monitor', str,
                                                           ret.KEY_redaction_sponsor_monitor)

    ret.KEY_redaction_sponsor_name = _extract_attribute(root, 'KEY_redaction_sponsor_name', str,
                                                        ret.KEY_redaction_sponsor_name)

    ret.KEY_redaction_sponsor_signatory = _extract_attribute(root, 'KEY_redaction_sponsor_signatory', str,
                                                             ret.KEY_redaction_sponsor_signatory)

    ret.KEY_redaction_sponsors_medical_expert = _extract_attribute(root, 'KEY_redaction_sponsors_medical_expert', str,
                                                                   ret.KEY_redaction_sponsors_medical_expert)

    ret.KEY_redaction_subcategory = _extract_attribute(root, 'KEY_redaction_subcategory', str,
                                                       ret.KEY_redaction_subcategory)

    ret.KEY_ReferencesHeader = _extract_attribute(root, 'KEY_ReferencesHeader', str, ret.KEY_ReferencesHeader)

    ret.KEY_ReferencesRefRoiId = _extract_attribute(root, 'KEY_ReferencesRefRoiId', str, ret.KEY_ReferencesRefRoiId)

    ret.KEY_roi_id = _extract_attribute(root, 'KEY_roi_id', str, ret.KEY_roi_id)

    ret.KEY_roi_text = _extract_attribute(root, 'KEY_roi_text', str, ret.KEY_roi_text)

    ret.KEY_secondary_objectives = _extract_attribute(root, 'KEY_secondary_objectives', str,
                                                      ret.KEY_secondary_objectives)

    ret.KEY_SectionHeader = _extract_attribute(root, 'KEY_SectionHeader', str, ret.KEY_SectionHeader)

    ret.KEY_SectionHeaderPrintPage = _extract_attribute(root, 'KEY_SectionHeaderPrintPage', str,
                                                        ret.KEY_SectionHeaderPrintPage)

    ret.KEY_SectionHeaderROI = _extract_attribute(root, 'KEY_SectionHeaderROI', str, ret.KEY_SectionHeaderROI)

    ret.KEY_SectionHeaderRoiId = _extract_attribute(root, 'KEY_SectionHeaderRoiId', str, ret.KEY_SectionHeaderRoiId)

    ret.KEY_SectionRefRoiId = _extract_attribute(root, 'KEY_SectionRefRoiId', str, ret.KEY_SectionRefRoiId)

    ret.KEY_short_title = _extract_attribute(root, 'KEY_short_title', str, ret.KEY_short_title)

    ret.KEY_sid = _extract_attribute(root, 'KEY_sid', str, ret.KEY_sid)

    ret.KEY_site = _extract_attribute(root, 'KEY_site', str, ret.KEY_site)

    ret.KEY_soa_days = _extract_attribute(root, 'KEY_soa_days', str, ret.KEY_soa_days)

    ret.KEY_soa_epochs = _extract_attribute(root, 'KEY_soa_epochs', str, ret.KEY_soa_epochs)

    ret.KEY_soa_footnotes = _extract_attribute(root, 'KEY_soa_footnotes', str, ret.KEY_soa_footnotes)

    ret.KEY_soa_months = _extract_attribute(root, 'KEY_soa_months', str, ret.KEY_soa_months)

    ret.KEY_soa_section_links = _extract_attribute(root, 'KEY_soa_section_links', str, ret.KEY_soa_section_links)

    ret.KEY_soa_visit = _extract_attribute(root, 'KEY_soa_visit', str, ret.KEY_soa_visit)

    ret.KEY_soa_weeks = _extract_attribute(root, 'KEY_soa_weeks', str, ret.KEY_soa_weeks)

    ret.KEY_soa_window = _extract_attribute(root, 'KEY_soa_window', str, ret.KEY_soa_window)

    ret.KEY_soa_years = _extract_attribute(root, 'KEY_soa_years', str, ret.KEY_soa_years)

    ret.KEY_SOAHeader = _extract_attribute(root, 'KEY_SOAHeader', str, ret.KEY_SOAHeader)

    ret.KEY_SOARefRoiId = _extract_attribute(root, 'KEY_SOARefRoiId', str, ret.KEY_SOARefRoiId)

    ret.KEY_SOATableFeatures = _extract_attribute(root, 'KEY_SOATableFeatures', str, ret.KEY_SOATableFeatures)

    ret.KEY_span = _extract_attribute(root, 'KEY_span', str, ret.KEY_span)

    ret.KEY_sponsor = _extract_attribute(root, 'KEY_sponsor', str, ret.KEY_sponsor)

    ret.KEY_sponsor_address = _extract_attribute(root, 'KEY_sponsor_address', str, ret.KEY_sponsor_address)

    ret.KEY_standard_template_level = _extract_attribute(root, 'KEY_standard_template_level', str,
                                                         ret.KEY_standard_template_level)

    ret.KEY_standard_template_level_item = _extract_attribute(root, 'KEY_standard_template_level_item', str,
                                                              ret.KEY_standard_template_level_item)

    ret.KEY_standard_template_placeholder = _extract_attribute(root, 'KEY_standard_template_placeholder', str,
                                                               ret.KEY_standard_template_placeholder)

    ret.KEY_standard_template_placeholder_item = _extract_attribute(root, 'KEY_standard_template_placeholder_item',
                                                                    str, ret.KEY_standard_template_placeholder_item)

    ret.KEY_standard_template_prefix = _extract_attribute(root, 'KEY_standard_template_prefix', str,
                                                          ret.KEY_standard_template_prefix)

    ret.KEY_standard_template_prefix_item = _extract_attribute(root, 'KEY_standard_template_prefix_item', str,
                                                               ret.KEY_standard_template_prefix_item)

    ret.KEY_standard_template_similarity_score = _extract_attribute(root, 'KEY_standard_template_similarity_score',
                                                                    str, ret.KEY_standard_template_similarity_score)

    ret.KEY_standard_template_text = _extract_attribute(root, 'KEY_standard_template_text', str,
                                                        ret.KEY_standard_template_text)

    ret.KEY_StatisticalConsiderationsHeader = _extract_attribute(root, 'KEY_StatisticalConsiderationsHeader', str,
                                                                 ret.KEY_StatisticalConsiderationsHeader)

    ret.KEY_StatisticalConsiderationsRefRoiId = _extract_attribute(root, 'KEY_StatisticalConsiderationsRefRoiId', str,
                                                                   ret.KEY_StatisticalConsiderationsRefRoiId)

    ret.KEY_study_id = _extract_attribute(root, 'KEY_study_id', str, ret.KEY_study_id)

    ret.KEY_study_status = _extract_attribute(root, 'KEY_study_status', str, ret.KEY_study_status)

    ret.KEY_StudyAssessmentsandProceduresHeader = _extract_attribute(root, 'KEY_StudyAssessmentsandProceduresHeader',
                                                                     str, ret.KEY_StudyAssessmentsandProceduresHeader)

    ret.KEY_StudyAssessmentsandProceduresRefRoiId = _extract_attribute(root,
                                                                       'KEY_StudyAssessmentsandProceduresRefRoiId',
                                                                       str,
                                                                       ret.KEY_StudyAssessmentsandProceduresRefRoiId)

    ret.KEY_StudyDesignHeader = _extract_attribute(root, 'KEY_StudyDesignHeader', str, ret.KEY_StudyDesignHeader)

    ret.KEY_StudyDesignRefRoiId = _extract_attribute(root, 'KEY_StudyDesignRefRoiId', str, ret.KEY_StudyDesignRefRoiId)

    ret.KEY_StudyInterventionsandConcomitantTherapyHeader = _extract_attribute(root,
                                                                               'KEY_StudyInterventionsandConcomitantTherapyHeader',
                                                                               str,
                                                                               ret.KEY_StudyInterventionsandConcomitantTherapyHeader)

    ret.KEY_StudyInterventionsandConcomitantTherapyRefRoiId = _extract_attribute(root,
                                                                                 'KEY_StudyInterventionsandConcomitantTherapyRefRoiId',
                                                                                 str,
                                                                                 ret.KEY_StudyInterventionsandConcomitantTherapyRefRoiId)

    ret.KEY_StudyPopulationHeader = _extract_attribute(root, 'KEY_StudyPopulationHeader', str,
                                                       ret.KEY_StudyPopulationHeader)

    ret.KEY_StudyPopulationRefRoiId = _extract_attribute(root, 'KEY_StudyPopulationRefRoiId', str,
                                                         ret.KEY_StudyPopulationRefRoiId)

    ret.KEY_SummaryHeader = _extract_attribute(root, 'KEY_SummaryHeader', str, ret.KEY_SummaryHeader)

    ret.KEY_SummaryRefRoiId = _extract_attribute(root, 'KEY_SummaryRefRoiId', str, ret.KEY_SummaryRefRoiId)

    ret.KEY_SupportingDocumentationHeader = _extract_attribute(root, 'KEY_SupportingDocumentationHeader', str,
                                                               ret.KEY_SupportingDocumentationHeader)

    ret.KEY_SupportingDocumentationRefRoiId = _extract_attribute(root, 'KEY_SupportingDocumentationRefRoiId', str,
                                                                 ret.KEY_SupportingDocumentationRefRoiId)

    ret.KEY_TableColumnIndex = _extract_attribute(root, 'KEY_TableColumnIndex', str, ret.KEY_TableColumnIndex)

    ret.KEY_TableROI = _extract_attribute(root, 'KEY_TableROI', str, ret.KEY_TableROI)

    ret.KEY_TableRowIndex = _extract_attribute(root, 'KEY_TableRowIndex', str, ret.KEY_TableRowIndex)

    ret.KEY_this = _extract_attribute(root, 'KEY_this', str, ret.KEY_this)

    ret.KEY_time_unit = _extract_attribute(root, 'KEY_time_unit', str, ret.KEY_time_unit)

    ret.KEY_time_unit_day = _extract_attribute(root, 'KEY_time_unit_day', str, ret.KEY_time_unit_day)

    ret.KEY_time_unit_epoch = _extract_attribute(root, 'KEY_time_unit_epoch', str, ret.KEY_time_unit_epoch)

    ret.KEY_time_unit_month = _extract_attribute(root, 'KEY_time_unit_month', str, ret.KEY_time_unit_month)

    ret.KEY_time_unit_sub_epoch = _extract_attribute(root, 'KEY_time_unit_sub_epoch', str, ret.KEY_time_unit_sub_epoch)

    ret.KEY_time_unit_visit = _extract_attribute(root, 'KEY_time_unit_visit', str, ret.KEY_time_unit_visit)

    ret.KEY_time_unit_week = _extract_attribute(root, 'KEY_time_unit_week', str, ret.KEY_time_unit_week)

    ret.KEY_time_unit_window = _extract_attribute(root, 'KEY_time_unit_window', str, ret.KEY_time_unit_window)

    ret.KEY_time_unit_year = _extract_attribute(root, 'KEY_time_unit_year', str, ret.KEY_time_unit_year)

    ret.KEY_time_value = _extract_attribute(root, 'KEY_time_value', str, ret.KEY_time_value)

    ret.KEY_TOAHeader = _extract_attribute(root, 'KEY_TOAHeader', str, ret.KEY_TOAHeader)

    ret.KEY_TOARefRoiId = _extract_attribute(root, 'KEY_TOARefRoiId', str, ret.KEY_TOARefRoiId)

    ret.KEY_TOCHeader = _extract_attribute(root, 'KEY_TOCHeader', str, ret.KEY_TOCHeader)

    ret.KEY_TOCRefRoiId = _extract_attribute(root, 'KEY_TOCRefRoiId', str, ret.KEY_TOCRefRoiId)

    ret.KEY_TOFHeader = _extract_attribute(root, 'KEY_TOFHeader', str, ret.KEY_TOFHeader)

    ret.KEY_TOFRefRoiId = _extract_attribute(root, 'KEY_TOFRefRoiId', str, ret.KEY_TOFRefRoiId)

    ret.KEY_TOTHeader = _extract_attribute(root, 'KEY_TOTHeader', str, ret.KEY_TOTHeader)

    ret.KEY_TOTRefRoiId = _extract_attribute(root, 'KEY_TOTRefRoiId', str, ret.KEY_TOTRefRoiId)

    ret.KEY_trial_type_randomized = _extract_attribute(root, 'KEY_trial_type_randomized', str,
                                                       ret.KEY_trial_type_randomized)

    ret.KEY_uploadDate = _extract_attribute(root, 'KEY_uploadDate', str, ret.KEY_uploadDate)

    ret.KEY_user_filename = _extract_attribute(root, 'KEY_user_filename', str, ret.KEY_user_filename)

    ret.KEY_UserBusinessUnit = _extract_attribute(root, 'KEY_UserBusinessUnit', str, ret.KEY_UserBusinessUnit)

    ret.KEY_version_date = _extract_attribute(root, 'KEY_version_date', str, ret.KEY_version_date)

    ret.KEY_Y = _extract_attribute(root, 'KEY_Y', str, ret.KEY_Y)
    return ret


def _readFromXmlToIQV_KEY_STRINGList(branch: ET.ElementTree):
    """
    Read from XML and load memory object, for list of objects
    """
    root = branch
    ret = []
    for child in root:
        if (child.tag == 'IQV_KEY_STRING'):
            try:
                ret.append(_readFromXmlToIQV_KEY_STRING(child))
            except Exception as e:
                # log
                logger.info('Failed to import field ' + child.tag)
    return ret


def _readFromXmlToNLP_Entity(branch):
    """
    Read from XML and load memory object
    """

    # get root element
    root = branch

    # initialize NLP_Entity
    ret = NLP_Entity()

    ret.confidence = _extract_attribute(root, 'confidence', float, ret.confidence)

    ret.doc_id = _extract_attribute(root, 'doc_id', str, ret.doc_id)

    ret.dts = _extract_attribute(root, 'dts', str, ret.dts)

    ret.entity_class = _extract_attribute(root, 'entity_class', str, ret.entity_class)

    ret.entity_index = _extract_attribute(root, 'entity_index', str, ret.entity_index)

    ret.entity_key = _extract_attribute(root, 'entity_key', str, ret.entity_key)

    ret.group_type = _extract_attribute(root, 'group_type', str, ret.group_type)

    ret.hierarchy = _extract_attribute(root, 'hierarchy', str, ret.hierarchy)

    ret.id = _extract_attribute(root, 'id', str, ret.id)

    ret.iqv_standard_term = _extract_attribute(root, 'iqv_standard_term', str, ret.iqv_standard_term)

    ret.link_id = _extract_attribute(root, 'link_id', str, ret.link_id)

    ret.link_id_level2 = _extract_attribute(root, 'link_id_level2', str, ret.link_id_level2)

    ret.link_id_level3 = _extract_attribute(root, 'link_id_level3', str, ret.link_id_level3)

    ret.link_id_level4 = _extract_attribute(root, 'link_id_level4', str, ret.link_id_level4)

    ret.link_id_level5 = _extract_attribute(root, 'link_id_level5', str, ret.link_id_level5)

    ret.link_id_level6 = _extract_attribute(root, 'link_id_level6', str, ret.link_id_level6)

    ret.link_id_subsection1 = _extract_attribute(root, 'link_id_subsection1', str, ret.link_id_subsection1)

    ret.link_id_subsection2 = _extract_attribute(root, 'link_id_subsection2', str, ret.link_id_subsection2)

    ret.link_id_subsection3 = _extract_attribute(root, 'link_id_subsection3', str, ret.link_id_subsection3)

    ret.negated = _extract_attribute(root, 'negated', str, ret.negated)

    ret.ontology = _extract_attribute(root, 'ontology', str, ret.ontology)

    ret.ontology_item_code = _extract_attribute(root, 'ontology_item_code', str, ret.ontology_item_code)

    ret.ontology_version = _extract_attribute(root, 'ontology_version', str, ret.ontology_version)

    ret.parent_id = _extract_attribute(root, 'parent_id', str, ret.parent_id)

    ret.process_source = _extract_attribute(root, 'process_source', str, ret.process_source)

    ret.Properties = _extract_attribute_list(root, 'Properties', _readFromXmlToIQVKeyValueSetList, ret.Properties)

    ret.standard_entity_name = _extract_attribute(root, 'standard_entity_name', str, ret.standard_entity_name)

    ret.start = _extract_attribute(root, 'start', int, ret.start)

    ret.text = _extract_attribute(root, 'text', str, ret.text)

    ret.text_len = _extract_attribute(root, 'text_len', int, ret.text_len)

    ret.user_id = _extract_attribute(root, 'user_id', str, ret.user_id)
    return ret


def _readFromXmlToNLP_EntityList(branch: ET.ElementTree):
    """
    Read from XML and load memory object, for list of objects
    """
    root = branch
    ret = []
    for child in root:
        if (child.tag == 'NLP_Entity'):
            try:
                ret.append(_readFromXmlToNLP_Entity(child))
            except Exception as e:
                # log
                logger.info('Failed to import field ' + child.tag)
    return ret


def _readFromXmlToIQVConceptTerm(branch):
    """
    Read from XML and load memory object
    """

    # get root element
    root = branch

    # initialize IQVConceptTerm
    ret = IQVConceptTerm()

    ret.cui = _extract_attribute(root, 'cui', str, ret.cui)

    ret.entity_class = _extract_attribute(root, 'entity_class', str, ret.entity_class)

    ret.entity_text = _extract_attribute(root, 'entity_text', str, ret.entity_text)

    ret.entity_xref = _extract_attribute(root, 'entity_xref', str, ret.entity_xref)

    ret.id = _extract_attribute(root, 'id', str, ret.id)

    ret.info = _extract_attribute(root, 'info', str, ret.info)

    ret.ontology = _extract_attribute(root, 'ontology', str, ret.ontology)

    ret.preferred_term = _extract_attribute(root, 'preferred_term', str, ret.preferred_term)
    return ret


def _readFromXmlToIQVConceptTermList(branch: ET.ElementTree):
    """
    Read from XML and load memory object, for list of objects
    """
    root = branch
    ret = []
    for child in root:
        if (child.tag == 'IQVConceptTerm'):
            try:
                ret.append(_readFromXmlToIQVConceptTerm(child))
            except Exception as e:
                # log
                logger.info('Failed to import field ' + child.tag)
    return ret


def _readFromXmlToIQVConceptRelation(branch):
    """
    Read from XML and load memory object
    """

    # get root element
    root = branch

    # initialize IQVConceptRelation
    ret = IQVConceptRelation()

    ret.context_unit = _extract_attribute(root, 'context_unit', str, ret.context_unit)

    ret.dts = _extract_attribute(root, 'dts', str, ret.dts)

    ret.id = _extract_attribute(root, 'id', str, ret.id)

    ret.id1 = _extract_attribute(root, 'id1', str, ret.id1)

    ret.id2 = _extract_attribute(root, 'id2', str, ret.id2)

    ret.relation_type = _extract_attribute(root, 'relation_type', str, ret.relation_type)

    ret.user_id = _extract_attribute(root, 'user_id', str, ret.user_id)

    ret.weight = _extract_attribute(root, 'weight', float, ret.weight)
    return ret


def _readFromXmlToIQVConceptRelationList(branch: ET.ElementTree):
    """
    Read from XML and load memory object, for list of objects
    """
    root = branch
    ret = []
    for child in root:
        if (child.tag == 'IQVConceptRelation'):
            try:
                ret.append(_readFromXmlToIQVConceptRelation(child))
            except Exception as e:
                # log
                logger.info('Failed to import field ' + child.tag)
    return ret


def _readFromXmlToNLP_Attribute(branch):
    """
    Read from XML and load memory object
    """

    # get root element
    root = branch

    # initialize NLP_Attribute
    ret = NLP_Attribute()

    ret.attribute_class = _extract_attribute(root, 'attribute_class', str, ret.attribute_class)

    ret.attribute_index = _extract_attribute(root, 'attribute_index', str, ret.attribute_index)

    ret.doc_id = _extract_attribute(root, 'doc_id', str, ret.doc_id)

    ret.group_type = _extract_attribute(root, 'group_type', str, ret.group_type)

    ret.hierarchy = _extract_attribute(root, 'hierarchy', str, ret.hierarchy)

    ret.id = _extract_attribute(root, 'id', str, ret.id)

    ret.iqv_standard_term = _extract_attribute(root, 'iqv_standard_term', str, ret.iqv_standard_term)

    ret.link_id = _extract_attribute(root, 'link_id', str, ret.link_id)

    ret.link_id_level2 = _extract_attribute(root, 'link_id_level2', str, ret.link_id_level2)

    ret.link_id_level3 = _extract_attribute(root, 'link_id_level3', str, ret.link_id_level3)

    ret.link_id_level4 = _extract_attribute(root, 'link_id_level4', str, ret.link_id_level4)

    ret.link_id_level5 = _extract_attribute(root, 'link_id_level5', str, ret.link_id_level5)

    ret.link_id_level6 = _extract_attribute(root, 'link_id_level6', str, ret.link_id_level6)

    ret.link_id_subsection1 = _extract_attribute(root, 'link_id_subsection1', str, ret.link_id_subsection1)

    ret.link_id_subsection2 = _extract_attribute(root, 'link_id_subsection2', str, ret.link_id_subsection2)

    ret.link_id_subsection3 = _extract_attribute(root, 'link_id_subsection3', str, ret.link_id_subsection3)

    ret.parent_id = _extract_attribute(root, 'parent_id', str, ret.parent_id)

    ret.process_source = _extract_attribute(root, 'process_source', str, ret.process_source)

    ret.start = _extract_attribute(root, 'start', int, ret.start)

    ret.text = _extract_attribute(root, 'text', str, ret.text)
    return ret


def _readFromXmlToNLP_AttributeList(branch: ET.ElementTree):
    """
    Read from XML and load memory object, for list of objects
    """
    root = branch
    ret = []
    for child in root:
        if (child.tag == 'NLP_Attribute'):
            try:
                ret.append(_readFromXmlToNLP_Attribute(child))
            except Exception as e:
                # log
                logger.info('Failed to import field ' + child.tag)
    return ret


def _readFromXmlToNLP_Relation(branch):
    """
    Read from XML and load memory object
    """

    # get root element
    root = branch

    # initialize NLP_Relation
    ret = NLP_Relation()

    ret.confidence = _extract_attribute(root, 'confidence', float, ret.confidence)

    ret.doc_id = _extract_attribute(root, 'doc_id', str, ret.doc_id)

    ret.entities = _extract_attribute_list(root, 'entities', _readFromXmlToStringList, ret.entities)

    ret.entities_list = _extract_attribute(root, 'entities_list', str, ret.entities_list)

    ret.group_type = _extract_attribute(root, 'group_type', str, ret.group_type)

    ret.hierarchy = _extract_attribute(root, 'hierarchy', str, ret.hierarchy)

    ret.id = _extract_attribute(root, 'id', str, ret.id)

    ret.iqv_standard_term = _extract_attribute(root, 'iqv_standard_term', str, ret.iqv_standard_term)

    ret.is_bidirectional = _extract_attribute(root, 'is_bidirectional', int, ret.is_bidirectional)

    ret.is_hierarchical = _extract_attribute(root, 'is_hierarchical', int, ret.is_hierarchical)

    ret.link_id = _extract_attribute(root, 'link_id', str, ret.link_id)

    ret.link_id_level2 = _extract_attribute(root, 'link_id_level2', str, ret.link_id_level2)

    ret.link_id_level3 = _extract_attribute(root, 'link_id_level3', str, ret.link_id_level3)

    ret.link_id_level4 = _extract_attribute(root, 'link_id_level4', str, ret.link_id_level4)

    ret.link_id_level5 = _extract_attribute(root, 'link_id_level5', str, ret.link_id_level5)

    ret.link_id_level6 = _extract_attribute(root, 'link_id_level6', str, ret.link_id_level6)

    ret.link_id_subsection1 = _extract_attribute(root, 'link_id_subsection1', str, ret.link_id_subsection1)

    ret.link_id_subsection2 = _extract_attribute(root, 'link_id_subsection2', str, ret.link_id_subsection2)

    ret.link_id_subsection3 = _extract_attribute(root, 'link_id_subsection3', str, ret.link_id_subsection3)

    ret.parent_id = _extract_attribute(root, 'parent_id', str, ret.parent_id)

    ret.process_source = _extract_attribute(root, 'process_source', str, ret.process_source)

    ret.relation_name = _extract_attribute(root, 'relation_name', str, ret.relation_name)

    ret.relation_type = _extract_attribute(root, 'relation_type', str, ret.relation_type)
    return ret


def _readFromXmlToNLP_RelationList(branch: ET.ElementTree):
    """
    Read from XML and load memory object, for list of objects
    """
    root = branch
    ret = []
    for child in root:
        if (child.tag == 'NLP_Relation'):
            try:
                ret.append(_readFromXmlToNLP_Relation(child))
            except Exception as e:
                # log
                logger.info('Failed to import field ' + child.tag)
    return ret


def _readFromXmlToNLP_Segment(branch):
    """
    Read from XML and load memory object
    """

    # get root element
    root = branch

    # initialize NLP_Segment
    ret = NLP_Segment()

    ret.attributes = _extract_attribute_list(root, 'attributes', _readFromXmlToNLP_AttributeList, ret.attributes)

    ret.doc_id = _extract_attribute(root, 'doc_id', str, ret.doc_id)

    ret.entities = _extract_attribute_list(root, 'entities', _readFromXmlToNLP_EntityList, ret.entities)

    ret.group_type = _extract_attribute(root, 'group_type', str, ret.group_type)

    ret.hierarchy = _extract_attribute(root, 'hierarchy', str, ret.hierarchy)

    ret.id = _extract_attribute(root, 'id', str, ret.id)

    ret.iqv_standard_term = _extract_attribute(root, 'iqv_standard_term', str, ret.iqv_standard_term)

    ret.link_id = _extract_attribute(root, 'link_id', str, ret.link_id)

    ret.link_id_level2 = _extract_attribute(root, 'link_id_level2', str, ret.link_id_level2)

    ret.link_id_level3 = _extract_attribute(root, 'link_id_level3', str, ret.link_id_level3)

    ret.link_id_level4 = _extract_attribute(root, 'link_id_level4', str, ret.link_id_level4)

    ret.link_id_level5 = _extract_attribute(root, 'link_id_level5', str, ret.link_id_level5)

    ret.link_id_level6 = _extract_attribute(root, 'link_id_level6', str, ret.link_id_level6)

    ret.link_id_subsection1 = _extract_attribute(root, 'link_id_subsection1', str, ret.link_id_subsection1)

    ret.link_id_subsection2 = _extract_attribute(root, 'link_id_subsection2', str, ret.link_id_subsection2)

    ret.link_id_subsection3 = _extract_attribute(root, 'link_id_subsection3', str, ret.link_id_subsection3)

    ret.parent_id = _extract_attribute(root, 'parent_id', str, ret.parent_id)

    ret.primary_section = _extract_attribute(root, 'primary_section', str, ret.primary_section)

    ret.Properties = _extract_attribute_list(root, 'Properties', _readFromXmlToIQVKeyValueSetList, ret.Properties)

    ret.secondary_section = _extract_attribute(root, 'secondary_section', str, ret.secondary_section)

    ret.segment_type = _extract_attribute(root, 'segment_type', str, ret.segment_type)

    ret.segments = _extract_attribute_list(root, 'segments', _readFromXmlToNLP_EntityList, ret.segments)

    ret.text = _extract_attribute(root, 'text', str, ret.text)

    ret.text_footnotes = _extract_attribute_list(root, 'text_footnotes', _readFromXmlToStringList, ret.text_footnotes)
    return ret


def _readFromXmlToNLP_SegmentList(branch: ET.ElementTree):
    """
    Read from XML and load memory object, for list of objects
    """
    root = branch
    ret = []
    for child in root:
        if (child.tag == 'NLP_Segment'):
            try:
                ret.append(_readFromXmlToNLP_Segment(child))
            except Exception as e:
                # log
                logger.info('Failed to import field ' + child.tag)
    return ret


def _readFromXmlToNLP_System_Mapping(branch):
    """
    Read from XML and load memory object
    """

    # get root element
    root = branch

    # initialize NLP_System_Mapping
    ret = NLP_System_Mapping()

    ret.DataType = _extract_attribute(root, 'DataType', str, ret.DataType)

    ret.doc_id = _extract_attribute(root, 'doc_id', str, ret.doc_id)

    ret.EntityKey = _extract_attribute(root, 'EntityKey', str, ret.EntityKey)

    ret.FilenameKey = _extract_attribute(root, 'FilenameKey', str, ret.FilenameKey)

    ret.group_type = _extract_attribute(root, 'group_type', str, ret.group_type)

    ret.hierarchy = _extract_attribute(root, 'hierarchy', str, ret.hierarchy)

    ret.id = _extract_attribute(root, 'id', str, ret.id)

    ret.iqv_standard_term = _extract_attribute(root, 'iqv_standard_term', str, ret.iqv_standard_term)

    ret.link_id = _extract_attribute(root, 'link_id', str, ret.link_id)

    ret.link_id_level2 = _extract_attribute(root, 'link_id_level2', str, ret.link_id_level2)

    ret.link_id_level3 = _extract_attribute(root, 'link_id_level3', str, ret.link_id_level3)

    ret.link_id_level4 = _extract_attribute(root, 'link_id_level4', str, ret.link_id_level4)

    ret.link_id_level5 = _extract_attribute(root, 'link_id_level5', str, ret.link_id_level5)

    ret.link_id_level6 = _extract_attribute(root, 'link_id_level6', str, ret.link_id_level6)

    ret.link_id_subsection1 = _extract_attribute(root, 'link_id_subsection1', str, ret.link_id_subsection1)

    ret.link_id_subsection2 = _extract_attribute(root, 'link_id_subsection2', str, ret.link_id_subsection2)

    ret.link_id_subsection3 = _extract_attribute(root, 'link_id_subsection3', str, ret.link_id_subsection3)

    ret.NLPSystem = _extract_attribute(root, 'NLPSystem', str, ret.NLPSystem)

    ret.NLPSystemQueryName = _extract_attribute(root, 'NLPSystemQueryName', str, ret.NLPSystemQueryName)

    ret.NLPSystemVersion = _extract_attribute(root, 'NLPSystemVersion', str, ret.NLPSystemVersion)

    ret.parent_id = _extract_attribute(root, 'parent_id', str, ret.parent_id)

    ret.QCFeedbackUIKey = _extract_attribute(root, 'QCFeedbackUIKey', str, ret.QCFeedbackUIKey)
    return ret


def _readFromXmlToNLP_System_MappingList(branch: ET.ElementTree):
    """
    Read from XML and load memory object, for list of objects
    """
    root = branch
    ret = []
    for child in root:
        if (child.tag == 'NLP_System_Mapping'):
            try:
                ret.append(_readFromXmlToNLP_System_Mapping(child))
            except Exception as e:
                # log
                logger.info('Failed to import field ' + child.tag)
    return ret


def _readFromXmlToIQVRedactionCategory(branch):
    """
    Read from XML and load memory object
    """

    # get root element
    root = branch

    # initialize IQVRedactionCategory
    ret = IQVRedactionCategory()

    ret.Category = _extract_attribute(root, 'Category', str, ret.Category)

    ret.id = _extract_attribute(root, 'id', str, ret.id)

    ret.IsRedacted = _extract_attribute(root, 'IsRedacted', int, ret.IsRedacted)

    ret.Query = _extract_attribute(root, 'Query', str, ret.Query)
    return ret


def _readFromXmlToIQVRedactionCategoryList(branch: ET.ElementTree):
    """
    Read from XML and load memory object, for list of objects
    """
    root = branch
    ret = []
    for child in root:
        if (child.tag == 'IQVRedactionCategory'):
            try:
                ret.append(_readFromXmlToIQVRedactionCategory(child))
            except Exception as e:
                # log
                logger.info('Failed to import field ' + child.tag)
    return ret


def _readFromXmlToIQVRedactionProfile(branch):
    """
    Read from XML and load memory object
    """

    # get root element
    root = branch

    # initialize IQVRedactionProfile
    ret = IQVRedactionProfile()

    ret.Categories = _extract_attribute_list(root, 'Categories', _readFromXmlToIQVKeyValueSetList, ret.Categories)

    ret.DefaultIsRedacted = _extract_attribute(root, 'DefaultIsRedacted', int, ret.DefaultIsRedacted)

    ret.id = _extract_attribute(root, 'id', str, ret.id)
    return ret


def _readFromXmlToIQVRedactionProfileList(branch: ET.ElementTree):
    """
    Read from XML and load memory object, for list of objects
    """
    root = branch
    ret = []
    for child in root:
        if (child.tag == 'IQVRedactionProfile'):
            try:
                ret.append(_readFromXmlToIQVRedactionProfile(child))
            except Exception as e:
                # log
                logger.info('Failed to import field ' + child.tag)
    return ret


def _readFromXmlToIQVDocumentLink(branch):
    """
    Read from XML and load memory object
    """

    # get root element
    root = branch

    # initialize IQVDocumentLink
    ret = IQVDocumentLink()

    ret.doc_id = _extract_attribute(root, 'doc_id', str, ret.doc_id)

    ret.group_type = _extract_attribute(root, 'group_type', str, ret.group_type)

    ret.hierarchy = _extract_attribute(root, 'hierarchy', str, ret.hierarchy)

    ret.id = _extract_attribute(root, 'id', str, ret.id)

    ret.iqv_standard_term = _extract_attribute(root, 'iqv_standard_term', str, ret.iqv_standard_term)

    ret.link_id = _extract_attribute(root, 'link_id', str, ret.link_id)

    ret.link_id_level2 = _extract_attribute(root, 'link_id_level2', str, ret.link_id_level2)

    ret.link_id_level3 = _extract_attribute(root, 'link_id_level3', str, ret.link_id_level3)

    ret.link_id_level4 = _extract_attribute(root, 'link_id_level4', str, ret.link_id_level4)

    ret.link_id_level5 = _extract_attribute(root, 'link_id_level5', str, ret.link_id_level5)

    ret.link_id_level6 = _extract_attribute(root, 'link_id_level6', str, ret.link_id_level6)

    ret.link_id_subsection1 = _extract_attribute(root, 'link_id_subsection1', str, ret.link_id_subsection1)

    ret.link_id_subsection2 = _extract_attribute(root, 'link_id_subsection2', str, ret.link_id_subsection2)

    ret.link_id_subsection3 = _extract_attribute(root, 'link_id_subsection3', str, ret.link_id_subsection3)

    ret.LinkDestinations = _extract_attribute_list(root, 'LinkDestinations', _readFromXmlToIQVPageROIList,
                                                   ret.LinkDestinations)

    ret.LinkLevel = _extract_attribute(root, 'LinkLevel', int, ret.LinkLevel)

    ret.LinkPage = _extract_attribute(root, 'LinkPage', int, ret.LinkPage)

    ret.LinkPointers = _extract_attribute_list(root, 'LinkPointers', _readFromXmlToIQVPageROIList, ret.LinkPointers)

    ret.LinkPrefix = _extract_attribute(root, 'LinkPrefix', str, ret.LinkPrefix)

    ret.LinkText = _extract_attribute(root, 'LinkText', str, ret.LinkText)

    ret.LinkType = _extract_attribute(root, 'LinkType', str, ret.LinkType)

    ret.parent_id = _extract_attribute(root, 'parent_id', str, ret.parent_id)

    ret.Properties = _extract_attribute_list(root, 'Properties', _readFromXmlToIQVKeyValueSetList, ret.Properties)
    return ret


def _readFromXmlToIQVDocumentLinkList(branch: ET.ElementTree):
    """
    Read from XML and load memory object, for list of objects
    """
    root = branch
    ret = []
    for child in root:
        if (child.tag == 'IQVDocumentLink'):
            try:
                ret.append(_readFromXmlToIQVDocumentLink(child))
            except Exception as e:
                # log
                logger.info('Failed to import field ' + child.tag)
    return ret


def _readFromXmlToIQVDocumentVariable(branch):
    """
    Read from XML and load memory object
    """

    # get root element
    root = branch

    # initialize IQVDocumentVariable
    ret = IQVDocumentVariable()

    ret.doc_id = _extract_attribute(root, 'doc_id', str, ret.doc_id)

    ret.dts = _extract_attribute(root, 'dts', str, ret.dts)

    ret.id = _extract_attribute(root, 'id', str, ret.id)

    ret.run_id = _extract_attribute(root, 'run_id', str, ret.run_id)

    ret.source_filename = _extract_attribute(root, 'source_filename', str, ret.source_filename)

    ret.variable_category = _extract_attribute(root, 'variable_category', str, ret.variable_category)

    ret.variable_datatype = _extract_attribute(root, 'variable_datatype', str, ret.variable_datatype)

    ret.variable_index = _extract_attribute(root, 'variable_index', int, ret.variable_index)

    ret.variable_key = _extract_attribute(root, 'variable_key', str, ret.variable_key)

    ret.variable_label = _extract_attribute(root, 'variable_label', str, ret.variable_label)

    ret.variable_listing_filename = _extract_attribute(root, 'variable_listing_filename', str,
                                                       ret.variable_listing_filename)

    ret.variable_notes = _extract_attribute(root, 'variable_notes', str, ret.variable_notes)

    ret.variable_score = _extract_attribute(root, 'variable_score', float, ret.variable_score)

    ret.variable_source = _extract_attribute(root, 'variable_source', str, ret.variable_source)

    ret.variable_value = _extract_attribute(root, 'variable_value', str, ret.variable_value)
    return ret


def _readFromXmlToIQVDocumentVariableList(branch: ET.ElementTree):
    """
    Read from XML and load memory object, for list of objects
    """
    root = branch
    ret = []
    for child in root:
        if (child.tag == 'IQVDocumentVariable'):
            try:
                ret.append(_readFromXmlToIQVDocumentVariable(child))
            except Exception as e:
                # log
                logger.info('Failed to import field ' + child.tag)
    return ret


def _readFromXmlToIQVDocumentDiff(branch):
    """
    Read from XML and load memory object
    """

    # get root element
    root = branch

    # initialize IQVDocumentDiff
    ret = IQVDocumentDiff()

    ret.ChildDiffs = _extract_attribute_list(root, 'ChildDiffs', _readFromXmlToIQVDocumentDiffList, ret.ChildDiffs)

    ret.compare_roi_id = _extract_attribute(root, 'compare_roi_id', str, ret.compare_roi_id)

    ret.confidence = _extract_attribute(root, 'confidence', float, ret.confidence)

    ret.diff_category = _extract_attribute(root, 'diff_category', str, ret.diff_category)

    ret.diff_string = _extract_attribute(root, 'diff_string', str, ret.diff_string)

    ret.diff_subcategory = _extract_attribute(root, 'diff_subcategory', str, ret.diff_subcategory)

    ret.diff_type = _extract_attribute(root, 'diff_type', int, ret.diff_type)

    ret.id = _extract_attribute(root, 'id', str, ret.id)

    ret.IsPreferredTermComparison = _extract_attribute(root, 'IsPreferredTermComparison', _str2bool,
                                                       ret.IsPreferredTermComparison)

    ret.local_roi_id = _extract_attribute(root, 'local_roi_id', str, ret.local_roi_id)

    ret.Properties = _extract_attribute_list(root, 'Properties', _readFromXmlToIQVKeyValueSetList, ret.Properties)

    ret.PropertiesBase = _extract_attribute_list(root, 'PropertiesBase', _readFromXmlToIQVKeyValueSetList,
                                                 ret.PropertiesBase)

    ret.PropertiesCompare = _extract_attribute_list(root, 'PropertiesCompare', _readFromXmlToIQVKeyValueSetList,
                                                    ret.PropertiesCompare)

    fieldName = 'tableColumnLHS'
    try:
        item = root.find(fieldName)
        if item is not None:
            subbranch = item
            ret.tableColumnLHS = _readFromXmlToIQVTableColumn(subbranch)
        else:
            pass
    except Exception as e:
        logger.info('Failed to import field ' + fieldName)

    fieldName = 'tableColumnRHS'
    try:
        item = root.find(fieldName)
        if item is not None:
            subbranch = item
            ret.tableColumnRHS = _readFromXmlToIQVTableColumn(subbranch)
        else:
            pass
    except Exception as e:
        logger.info('Failed to import field ' + fieldName)

    fieldName = 'tableRowHeaderLHS'
    try:
        item = root.find(fieldName)
        if item is not None:
            subbranch = item
            ret.tableRowHeaderLHS = _readFromXmlToIQVPageROI(subbranch)
        else:
            pass
    except Exception as e:
        logger.info('Failed to import field ' + fieldName)

    fieldName = 'tableRowHeaderRHS'
    try:
        item = root.find(fieldName)
        if item is not None:
            subbranch = item
            ret.tableRowHeaderRHS = _readFromXmlToIQVPageROI(subbranch)
        else:
            pass
    except Exception as e:
        logger.info('Failed to import field ' + fieldName)
    return ret


def _readFromXmlToIQVDocumentDiffList(branch: ET.ElementTree):
    """
    Read from XML and load memory object, for list of objects
    """
    root = branch
    ret = []
    for child in root:
        if (child.tag == 'IQVDocumentDiff'):
            try:
                ret.append(_readFromXmlToIQVDocumentDiff(child))
            except Exception as e:
                # log
                logger.info('Failed to import field ' + child.tag)
    return ret


def _readFromXmlToIQVDocumentCompare(branch):
    """
    Read from XML and load memory object
    """

    # get root element
    root = branch

    # initialize IQVDocumentCompare
    ret = IQVDocumentCompare()

    ret.base_doc_id = _extract_attribute(root, 'base_doc_id', str, ret.base_doc_id)

    ret.base_doc_name = _extract_attribute(root, 'base_doc_name', str, ret.base_doc_name)

    ret.BaseDocProperties = _extract_attribute_list(root, 'BaseDocProperties', _readFromXmlToIQVKeyValueSetList,
                                                    ret.BaseDocProperties)

    ret.compare_doc_id = _extract_attribute(root, 'compare_doc_id', str, ret.compare_doc_id)

    ret.compare_doc_name = _extract_attribute(root, 'compare_doc_name', str, ret.compare_doc_name)

    ret.CompareDocProperties = _extract_attribute_list(root, 'CompareDocProperties', _readFromXmlToIQVKeyValueSetList,
                                                       ret.CompareDocProperties)

    ret.DocumentDiffs = _extract_attribute_list(root, 'DocumentDiffs', _readFromXmlToIQVDocumentDiffList,
                                                ret.DocumentDiffs)

    ret.id = _extract_attribute(root, 'id', str, ret.id)

    ret.Properties = _extract_attribute_list(root, 'Properties', _readFromXmlToIQVKeyValueSetList, ret.Properties)

    ret.redaction_profile_id = _extract_attribute(root, 'redaction_profile_id', str, ret.redaction_profile_id)

    fieldName = 'RedactionProfile'
    try:
        item = root.find(fieldName)
        if item is not None:
            subbranch = item
            ret.RedactionProfile = _readFromXmlToIQVRedactionProfile(subbranch)
        else:
            pass
    except Exception as e:
        logger.info('Failed to import field ' + fieldName)
    return ret


def _readFromXmlToIQVDocumentCompareList(branch: ET.ElementTree):
    """
    Read from XML and load memory object, for list of objects
    """
    root = branch
    ret = []
    for child in root:
        if (child.tag == 'IQVDocumentCompare'):
            try:
                ret.append(_readFromXmlToIQVDocumentCompare(child))
            except Exception as e:
                # log
                logger.info('Failed to import field ' + child.tag)
    return ret


def _readFromXmlToIQVDiffRecord(branch):
    """
    Read from XML and load memory object
    """

    # get root element
    root = branch

    # initialize IQVDiffRecord
    ret = IQVDiffRecord()

    ret.category = _extract_attribute(root, 'category', str, ret.category)

    ret.diff_string = _extract_attribute(root, 'diff_string', str, ret.diff_string)

    ret.diff_type = _extract_attribute(root, 'diff_type', str, ret.diff_type)

    ret.doc_id_a = _extract_attribute(root, 'doc_id_a', str, ret.doc_id_a)

    ret.doc_id_b = _extract_attribute(root, 'doc_id_b', str, ret.doc_id_b)

    ret.dts = _extract_attribute(root, 'dts', str, ret.dts)

    ret.id = _extract_attribute(root, 'id', str, ret.id)

    ret.pname_a = _extract_attribute(root, 'pname_a', str, ret.pname_a)

    ret.pname_b = _extract_attribute(root, 'pname_b', str, ret.pname_b)

    ret.ProcessMachineName = _extract_attribute(root, 'ProcessMachineName', str, ret.ProcessMachineName)

    ret.ProcessVersion = _extract_attribute(root, 'ProcessVersion', str, ret.ProcessVersion)

    ret.ptdiff_string = _extract_attribute(root, 'ptdiff_string', str, ret.ptdiff_string)

    ret.ptdiff_type = _extract_attribute(root, 'ptdiff_type', str, ret.ptdiff_type)

    ret.pttext_a = _extract_attribute(root, 'pttext_a', str, ret.pttext_a)

    ret.pttext_b = _extract_attribute(root, 'pttext_b', str, ret.pttext_b)

    ret.roi_id_a = _extract_attribute(root, 'roi_id_a', str, ret.roi_id_a)

    ret.roi_id_b = _extract_attribute(root, 'roi_id_b', str, ret.roi_id_b)

    ret.section = _extract_attribute(root, 'section', str, ret.section)

    ret.start_index = _extract_attribute(root, 'start_index', int, ret.start_index)

    ret.subcategory = _extract_attribute(root, 'subcategory', str, ret.subcategory)

    ret.table_column = _extract_attribute(root, 'table_column', str, ret.table_column)

    ret.table_row = _extract_attribute(root, 'table_row', str, ret.table_row)

    ret.text_a = _extract_attribute(root, 'text_a', str, ret.text_a)

    ret.text_b = _extract_attribute(root, 'text_b', str, ret.text_b)

    ret.text_length = _extract_attribute(root, 'text_length', int, ret.text_length)
    return ret


def _readFromXmlToIQVDiffRecordList(branch: ET.ElementTree):
    """
    Read from XML and load memory object, for list of objects
    """
    root = branch
    ret = []
    for child in root:
        if (child.tag == 'IQVDiffRecord'):
            try:
                ret.append(_readFromXmlToIQVDiffRecord(child))
            except Exception as e:
                # log
                logger.info('Failed to import field ' + child.tag)
    return ret


def _readFromXmlToIQVDiffRecordSOA(branch):
    """
    Read from XML and load memory object
    """

    # get root element
    root = branch

    # initialize IQVDiffRecordSOA
    ret = IQVDiffRecordSOA()

    ret.assessment = _extract_attribute(root, 'assessment', str, ret.assessment)

    ret.category = _extract_attribute(root, 'category', str, ret.category)

    ret.cycle = _extract_attribute(root, 'cycle', str, ret.cycle)

    ret.day = _extract_attribute(root, 'day', str, ret.day)

    ret.diff_string = _extract_attribute(root, 'diff_string', str, ret.diff_string)

    ret.diff_type = _extract_attribute(root, 'diff_type', str, ret.diff_type)

    ret.doc_id_a = _extract_attribute(root, 'doc_id_a', str, ret.doc_id_a)

    ret.doc_id_b = _extract_attribute(root, 'doc_id_b', str, ret.doc_id_b)

    ret.dts = _extract_attribute(root, 'dts', str, ret.dts)

    ret.epoch = _extract_attribute(root, 'epoch', str, ret.epoch)

    ret.id = _extract_attribute(root, 'id', str, ret.id)

    ret.month = _extract_attribute(root, 'month', str, ret.month)

    ret.pname_a = _extract_attribute(root, 'pname_a', str, ret.pname_a)

    ret.pname_b = _extract_attribute(root, 'pname_b', str, ret.pname_b)

    ret.procedure = _extract_attribute(root, 'procedure', str, ret.procedure)

    ret.ProcessMachineName = _extract_attribute(root, 'ProcessMachineName', str, ret.ProcessMachineName)

    ret.ProcessVersion = _extract_attribute(root, 'ProcessVersion', str, ret.ProcessVersion)

    ret.roi_id_a = _extract_attribute(root, 'roi_id_a', str, ret.roi_id_a)

    ret.roi_id_b = _extract_attribute(root, 'roi_id_b', str, ret.roi_id_b)

    ret.section = _extract_attribute(root, 'section', str, ret.section)

    ret.start_index = _extract_attribute(root, 'start_index', int, ret.start_index)

    ret.subcategory = _extract_attribute(root, 'subcategory', str, ret.subcategory)

    ret.table_column = _extract_attribute(root, 'table_column', str, ret.table_column)

    ret.table_row = _extract_attribute(root, 'table_row', str, ret.table_row)

    ret.text_a = _extract_attribute(root, 'text_a', str, ret.text_a)

    ret.text_b = _extract_attribute(root, 'text_b', str, ret.text_b)

    ret.text_length = _extract_attribute(root, 'text_length', int, ret.text_length)

    ret.visit = _extract_attribute(root, 'visit', str, ret.visit)

    ret.week = _extract_attribute(root, 'week', str, ret.week)

    ret.window = _extract_attribute(root, 'window', str, ret.window)

    ret.year = _extract_attribute(root, 'year', str, ret.year)
    return ret


def _readFromXmlToIQVDiffRecordSOAList(branch: ET.ElementTree):
    """
    Read from XML and load memory object, for list of objects
    """
    root = branch
    ret = []
    for child in root:
        if (child.tag == 'IQVDiffRecordSOA'):
            try:
                ret.append(_readFromXmlToIQVDiffRecordSOA(child))
            except Exception as e:
                # log
                logger.info('Failed to import field ' + child.tag)
    return ret


def _readFromXmlToIQVAssessmentVisitRecord(branch):
    """
    Read from XML and load memory object
    """

    # get root element
    root = branch

    # initialize IQVAssessmentVisitRecord
    ret = IQVAssessmentVisitRecord()

    ret.assessment = _extract_attribute(root, 'assessment', str, ret.assessment)

    ret.assessment_text = _extract_attribute(root, 'assessment_text', str, ret.assessment_text)

    ret.cycle_timepoint = _extract_attribute(root, 'cycle_timepoint', str, ret.cycle_timepoint)

    ret.day_timepoint = _extract_attribute(root, 'day_timepoint', str, ret.day_timepoint)

    ret.doc_id = _extract_attribute(root, 'doc_id', str, ret.doc_id)

    ret.DocumentSequenceIndex = _extract_attribute(root, 'DocumentSequenceIndex', int, ret.DocumentSequenceIndex)

    ret.dts = _extract_attribute(root, 'dts', str, ret.dts)

    ret.epoch_timepoint = _extract_attribute(root, 'epoch_timepoint', str, ret.epoch_timepoint)

    ret.footnotes = _extract_attribute_list(root, 'footnotes', _readFromXmlToStringList, ret.footnotes)

    ret.id = _extract_attribute(root, 'id', str, ret.id)

    ret.indicator_text = _extract_attribute(root, 'indicator_text', str, ret.indicator_text)

    ret.month_timepoint = _extract_attribute(root, 'month_timepoint', str, ret.month_timepoint)

    ret.pname = _extract_attribute(root, 'pname', str, ret.pname)

    ret.procedure = _extract_attribute(root, 'procedure', str, ret.procedure)

    ret.procedure_text = _extract_attribute(root, 'procedure_text', str, ret.procedure_text)

    ret.ProcessMachineName = _extract_attribute(root, 'ProcessMachineName', str, ret.ProcessMachineName)

    ret.ProcessVersion = _extract_attribute(root, 'ProcessVersion', str, ret.ProcessVersion)

    ret.roi_id = _extract_attribute(root, 'roi_id', str, ret.roi_id)

    ret.run_id = _extract_attribute(root, 'run_id', str, ret.run_id)

    ret.section = _extract_attribute(root, 'section', str, ret.section)

    ret.study_cohort = _extract_attribute(root, 'study_cohort', str, ret.study_cohort)

    ret.table_column_id = _extract_attribute(root, 'table_column_id', str, ret.table_column_id)

    ret.table_link_text = _extract_attribute(root, 'table_link_text', str, ret.table_link_text)

    ret.table_roi_id = _extract_attribute(root, 'table_roi_id', str, ret.table_roi_id)

    ret.table_sequence_index = _extract_attribute(root, 'table_sequence_index', int, ret.table_sequence_index)

    ret.visit_timepoint = _extract_attribute(root, 'visit_timepoint', str, ret.visit_timepoint)

    ret.week_timepoint = _extract_attribute(root, 'week_timepoint', str, ret.week_timepoint)

    ret.window_timepoint = _extract_attribute(root, 'window_timepoint', str, ret.window_timepoint)

    ret.year_timepoint = _extract_attribute(root, 'year_timepoint', str, ret.year_timepoint)
    return ret


def _readFromXmlToIQVAssessmentVisitRecordList(branch: ET.ElementTree):
    """
    Read from XML and load memory object, for list of objects
    """
    root = branch
    ret = []
    for child in root:
        if (child.tag == 'IQVAssessmentVisitRecord'):
            try:
                ret.append(_readFromXmlToIQVAssessmentVisitRecord(child))
            except Exception as e:
                # log
                logger.info('Failed to import field ' + child.tag)
    return ret


def _readFromXmlToIQVAssessmentRecord(branch):
    """
    Read from XML and load memory object
    """

    # get root element
    root = branch

    # initialize IQVAssessmentRecord
    ret = IQVAssessmentRecord()

    ret.assessment = _extract_attribute(root, 'assessment', str, ret.assessment)

    ret.assessment_text = _extract_attribute(root, 'assessment_text', str, ret.assessment_text)

    ret.doc_id = _extract_attribute(root, 'doc_id', str, ret.doc_id)

    ret.DocumentSequenceIndex = _extract_attribute(root, 'DocumentSequenceIndex', int, ret.DocumentSequenceIndex)

    ret.dts = _extract_attribute(root, 'dts', str, ret.dts)

    ret.footnotes = _extract_attribute_list(root, 'footnotes', _readFromXmlToStringList, ret.footnotes)

    ret.id = _extract_attribute(root, 'id', str, ret.id)

    ret.num_visits = _extract_attribute(root, 'num_visits', int, ret.num_visits)

    ret.pname = _extract_attribute(root, 'pname', str, ret.pname)

    ret.procedure = _extract_attribute(root, 'procedure', str, ret.procedure)

    ret.procedure_text = _extract_attribute(root, 'procedure_text', str, ret.procedure_text)

    ret.ProcessMachineName = _extract_attribute(root, 'ProcessMachineName', str, ret.ProcessMachineName)

    ret.ProcessVersion = _extract_attribute(root, 'ProcessVersion', str, ret.ProcessVersion)

    ret.roi_id = _extract_attribute(root, 'roi_id', str, ret.roi_id)

    ret.run_id = _extract_attribute(root, 'run_id', str, ret.run_id)

    ret.section = _extract_attribute(root, 'section', str, ret.section)

    ret.study_cohort = _extract_attribute(root, 'study_cohort', str, ret.study_cohort)

    ret.table_column_id = _extract_attribute(root, 'table_column_id', str, ret.table_column_id)

    ret.table_link_text = _extract_attribute(root, 'table_link_text', str, ret.table_link_text)

    ret.table_roi_id = _extract_attribute(root, 'table_roi_id', str, ret.table_roi_id)

    ret.table_sequence_index = _extract_attribute(root, 'table_sequence_index', int, ret.table_sequence_index)
    return ret


def _readFromXmlToIQVAssessmentRecordList(branch: ET.ElementTree):
    """
    Read from XML and load memory object, for list of objects
    """
    root = branch
    ret = []
    for child in root:
        if (child.tag == 'IQVAssessmentRecord'):
            try:
                ret.append(_readFromXmlToIQVAssessmentRecord(child))
            except Exception as e:
                # log
                logger.info('Failed to import field ' + child.tag)
    return ret


def _readFromXmlToIQVLabParameterRecord(branch):
    """
    Read from XML and load memory object
    """

    # get root element
    root = branch

    # initialize IQVLabParameterRecord
    ret = IQVLabParameterRecord()

    ret.assessment = _extract_attribute(root, 'assessment', str, ret.assessment)

    ret.doc_id = _extract_attribute(root, 'doc_id', str, ret.doc_id)

    ret.dts = _extract_attribute(root, 'dts', str, ret.dts)

    ret.id = _extract_attribute(root, 'id', str, ret.id)

    ret.parameter = _extract_attribute(root, 'parameter', str, ret.parameter)

    ret.parameter_text = _extract_attribute(root, 'parameter_text', str, ret.parameter_text)

    ret.pname = _extract_attribute(root, 'pname', str, ret.pname)

    ret.procedure_panel = _extract_attribute(root, 'procedure_panel', str, ret.procedure_panel)

    ret.procedure_panel_text = _extract_attribute(root, 'procedure_panel_text', str, ret.procedure_panel_text)

    ret.ProcessMachineName = _extract_attribute(root, 'ProcessMachineName', str, ret.ProcessMachineName)

    ret.ProcessVersion = _extract_attribute(root, 'ProcessVersion', str, ret.ProcessVersion)

    ret.roi_id = _extract_attribute(root, 'roi_id', str, ret.roi_id)

    ret.run_id = _extract_attribute(root, 'run_id', str, ret.run_id)

    ret.section = _extract_attribute(root, 'section', str, ret.section)

    ret.table_link_text = _extract_attribute(root, 'table_link_text', str, ret.table_link_text)

    ret.table_roi_id = _extract_attribute(root, 'table_roi_id', str, ret.table_roi_id)

    ret.table_sequence_index = _extract_attribute(root, 'table_sequence_index', int, ret.table_sequence_index)
    return ret


def _readFromXmlToIQVLabParameterRecordList(branch: ET.ElementTree):
    """
    Read from XML and load memory object, for list of objects
    """
    root = branch
    ret = []
    for child in root:
        if (child.tag == 'IQVLabParameterRecord'):
            try:
                ret.append(_readFromXmlToIQVLabParameterRecord(child))
            except Exception as e:
                # log
                logger.info('Failed to import field ' + child.tag)
    return ret


def _readFromXmlToIQVVisitRecord(branch):
    """
    Read from XML and load memory object
    """

    # get root element
    root = branch

    # initialize IQVVisitRecord
    ret = IQVVisitRecord()

    ret.cycle_timepoint = _extract_attribute(root, 'cycle_timepoint', str, ret.cycle_timepoint)

    ret.day_timepoint = _extract_attribute(root, 'day_timepoint', str, ret.day_timepoint)

    ret.doc_id = _extract_attribute(root, 'doc_id', str, ret.doc_id)

    ret.DocumentSequenceIndex = _extract_attribute(root, 'DocumentSequenceIndex', int, ret.DocumentSequenceIndex)

    ret.dts = _extract_attribute(root, 'dts', str, ret.dts)

    ret.epoch_timepoint = _extract_attribute(root, 'epoch_timepoint', str, ret.epoch_timepoint)

    ret.footnotes = _extract_attribute_list(root, 'footnotes', _readFromXmlToStringList, ret.footnotes)

    ret.id = _extract_attribute(root, 'id', str, ret.id)

    ret.month_timepoint = _extract_attribute(root, 'month_timepoint', str, ret.month_timepoint)

    ret.num_assessments = _extract_attribute(root, 'num_assessments', int, ret.num_assessments)

    ret.pname = _extract_attribute(root, 'pname', str, ret.pname)

    ret.ProcessMachineName = _extract_attribute(root, 'ProcessMachineName', str, ret.ProcessMachineName)

    ret.ProcessVersion = _extract_attribute(root, 'ProcessVersion', str, ret.ProcessVersion)

    ret.run_id = _extract_attribute(root, 'run_id', str, ret.run_id)

    ret.study_cohort = _extract_attribute(root, 'study_cohort', str, ret.study_cohort)

    ret.table_column_id = _extract_attribute(root, 'table_column_id', str, ret.table_column_id)

    ret.table_link_text = _extract_attribute(root, 'table_link_text', str, ret.table_link_text)

    ret.table_roi_id = _extract_attribute(root, 'table_roi_id', str, ret.table_roi_id)

    ret.table_sequence_index = _extract_attribute(root, 'table_sequence_index', int, ret.table_sequence_index)

    ret.visit_timepoint = _extract_attribute(root, 'visit_timepoint', str, ret.visit_timepoint)

    ret.week_timepoint = _extract_attribute(root, 'week_timepoint', str, ret.week_timepoint)

    ret.window_timepoint = _extract_attribute(root, 'window_timepoint', str, ret.window_timepoint)

    ret.year_timepoint = _extract_attribute(root, 'year_timepoint', str, ret.year_timepoint)
    return ret


def _readFromXmlToIQVVisitRecordList(branch: ET.ElementTree):
    """
    Read from XML and load memory object, for list of objects
    """
    root = branch
    ret = []
    for child in root:
        if (child.tag == 'IQVVisitRecord'):
            try:
                ret.append(_readFromXmlToIQVVisitRecord(child))
            except Exception as e:
                # log
                logger.info('Failed to import field ' + child.tag)
    return ret


def _readFromXmlToIQVIECriteriaRecord(branch):
    """
    Read from XML and load memory object
    """

    # get root element
    root = branch

    # initialize IQVIECriteriaRecord
    ret = IQVIECriteriaRecord()

    ret.doc_id = _extract_attribute(root, 'doc_id', str, ret.doc_id)

    ret.DocumentSequenceIndex = _extract_attribute(root, 'DocumentSequenceIndex', int, ret.DocumentSequenceIndex)

    ret.dts = _extract_attribute(root, 'dts', str, ret.dts)

    ret.footnotes = _extract_attribute_list(root, 'footnotes', _readFromXmlToStringList, ret.footnotes)

    ret.id = _extract_attribute(root, 'id', str, ret.id)

    ret.ie_type = _extract_attribute(root, 'ie_type', str, ret.ie_type)

    ret.item_text = _extract_attribute(root, 'item_text', str, ret.item_text)

    ret.link_text = _extract_attribute(root, 'link_text', str, ret.link_text)

    ret.pname = _extract_attribute(root, 'pname', str, ret.pname)

    ret.procedure = _extract_attribute(root, 'procedure', str, ret.procedure)

    ret.procedure_text = _extract_attribute(root, 'procedure_text', str, ret.procedure_text)

    ret.ProcessMachineName = _extract_attribute(root, 'ProcessMachineName', str, ret.ProcessMachineName)

    ret.ProcessVersion = _extract_attribute(root, 'ProcessVersion', str, ret.ProcessVersion)

    ret.roi_id = _extract_attribute(root, 'roi_id', str, ret.roi_id)

    ret.section = _extract_attribute(root, 'section', str, ret.section)

    ret.study_cohort = _extract_attribute(root, 'study_cohort', str, ret.study_cohort)
    return ret


def _readFromXmlToIQVIECriteriaRecordList(branch: ET.ElementTree):
    """
    Read from XML and load memory object, for list of objects
    """
    root = branch
    ret = []
    for child in root:
        if (child.tag == 'IQVIECriteriaRecord'):
            try:
                ret.append(_readFromXmlToIQVIECriteriaRecord(child))
            except Exception as e:
                # log
                logger.info('Failed to import field ' + child.tag)
    return ret


def _readFromXmlToIQVGxPElement(branch):
    """
    Read from XML and load memory object
    """

    # get root element
    root = branch

    # initialize IQVGxPElement
    ret = IQVGxPElement()

    ret.code_source = _extract_attribute(root, 'code_source', str, ret.code_source)

    ret.code_source_repo = _extract_attribute(root, 'code_source_repo', str, ret.code_source_repo)

    ret.creator = _extract_attribute(root, 'creator', str, ret.creator)

    ret.creator_organization = _extract_attribute(root, 'creator_organization', str, ret.creator_organization)

    ret.date_time_stamp = _extract_attribute(root, 'date_time_stamp', str, ret.date_time_stamp)

    ret.description = _extract_attribute(root, 'description', str, ret.description)

    ret.element_namespace = _extract_attribute(root, 'element_namespace', str, ret.element_namespace)

    ret.element_type = _extract_attribute(root, 'element_type', str, ret.element_type)

    ret.element_version = _extract_attribute(root, 'element_version', str, ret.element_version)

    ret.elements = _extract_attribute_list(root, 'elements', _readFromXmlToIQVGxPElementList, ret.elements)

    ret.environment = _extract_attribute(root, 'environment', str, ret.environment)

    ret.id = _extract_attribute(root, 'id', str, ret.id)

    ret.item_ids = _extract_attribute_list(root, 'item_ids', _readFromXmlToStringList, ret.item_ids)

    ret.item_ids_location = _extract_attribute(root, 'item_ids_location', str, ret.item_ids_location)

    ret.label = _extract_attribute(root, 'label', str, ret.label)

    ret.project_id = _extract_attribute(root, 'project_id', str, ret.project_id)

    ret.Properties = _extract_attribute_list(root, 'Properties', _readFromXmlToIQVKeyValueSetList, ret.Properties)

    ret.source_repo_id = _extract_attribute(root, 'source_repo_id', str, ret.source_repo_id)

    ret.source_system = _extract_attribute(root, 'source_system', str, ret.source_system)

    ret.technical_notes = _extract_attribute_list(root, 'technical_notes', _readFromXmlToStringList,
                                                  ret.technical_notes)

    ret.user_id = _extract_attribute(root, 'user_id', str, ret.user_id)
    return ret


def _readFromXmlToIQVGxPElementList(branch: ET.ElementTree):
    """
    Read from XML and load memory object, for list of objects
    """
    root = branch
    ret = []
    for child in root:
        if (child.tag == 'IQVGxPElement'):
            try:
                ret.append(_readFromXmlToIQVGxPElement(child))
            except Exception as e:
                # log
                logger.info('Failed to import field ' + child.tag)
    return ret


def _readFromXmlToIQVDocumentDiffGenericDisplayCellItem(branch):
    """
    Read from XML and load memory object
    """

    # get root element
    root = branch

    # initialize IQVDocumentDiffGenericDisplayCellItem
    ret = IQVDocumentDiffGenericDisplayCellItem()

    ret.ChildItems = _extract_attribute_list(root, 'ChildItems',
                                             _readFromXmlToIQVDocumentDiffGenericDisplayCellItemList, ret.ChildItems)

    ret.diff_types = _extract_attribute_list(root, 'diff_types', _readFromXmlToStringList, ret.diff_types)

    ret.id = _extract_attribute(root, 'id', str, ret.id)

    ret.indent = _extract_attribute(root, 'indent', int, ret.indent)

    ret.item_type = _extract_attribute(root, 'item_type', str, ret.item_type)

    ret.sequence = _extract_attribute(root, 'sequence', int, ret.sequence)

    ret.strs = _extract_attribute_list(root, 'strs', _readFromXmlToStringList, ret.strs)
    return ret


def _readFromXmlToIQVDocumentDiffGenericDisplayCellItemList(branch: ET.ElementTree):
    """
    Read from XML and load memory object, for list of objects
    """
    root = branch
    ret = []
    for child in root:
        if (child.tag == 'IQVDocumentDiffGenericDisplayCellItem'):
            try:
                ret.append(_readFromXmlToIQVDocumentDiffGenericDisplayCellItem(child))
            except Exception as e:
                # log
                logger.info('Failed to import field ' + child.tag)
    return ret


def _readFromXmlToIQVDocumentDiffGenericDisplayCell(branch):
    """
    Read from XML and load memory object
    """

    # get root element
    root = branch

    # initialize IQVDocumentDiffGenericDisplayCell
    ret = IQVDocumentDiffGenericDisplayCell()

    ret.cellItems = _extract_attribute_list(root, 'cellItems',
                                            _readFromXmlToIQVDocumentDiffGenericDisplayCellItemList, ret.cellItems)

    ret.colIndex = _extract_attribute(root, 'colIndex', int, ret.colIndex)

    ret.diff_types = _extract_attribute_list(root, 'diff_types', _readFromXmlToIQVDocumentDiffTypeList, ret.diff_types)

    ret.id = _extract_attribute(root, 'id', str, ret.id)

    ret.rowIndex = _extract_attribute(root, 'rowIndex', int, ret.rowIndex)
    return ret


def _readFromXmlToIQVDocumentDiffGenericDisplayCellList(branch: ET.ElementTree):
    """
    Read from XML and load memory object, for list of objects
    """
    root = branch
    ret = []
    for child in root:
        if (child.tag == 'IQVDocumentDiffGenericDisplayCell'):
            try:
                ret.append(_readFromXmlToIQVDocumentDiffGenericDisplayCell(child))
            except Exception as e:
                # log
                logger.info('Failed to import field ' + child.tag)
    return ret


def _readFromXmlToIQVDocumentDiffGenericDisplayRow(branch):
    """
    Read from XML and load memory object
    """

    # get root element
    root = branch

    # initialize IQVDocumentDiffGenericDisplayRow
    ret = IQVDocumentDiffGenericDisplayRow()

    ret.cells = _extract_attribute_list(root, 'cells', _readFromXmlToIQVDocumentDiffGenericDisplayCellList, ret.cells)

    ret.ChildRows = _extract_attribute_list(root, 'ChildRows', _readFromXmlToIQVDocumentDiffGenericDisplayRowList,
                                            ret.ChildRows)

    ret.headerType = _extract_attribute(root, 'headerType', int, ret.headerType)

    ret.id = _extract_attribute(root, 'id', str, ret.id)

    ret.rowIndex = _extract_attribute(root, 'rowIndex', int, ret.rowIndex)
    return ret


def _readFromXmlToIQVDocumentDiffGenericDisplayRowList(branch: ET.ElementTree):
    """
    Read from XML and load memory object, for list of objects
    """
    root = branch
    ret = []
    for child in root:
        if (child.tag == 'IQVDocumentDiffGenericDisplayRow'):
            try:
                ret.append(_readFromXmlToIQVDocumentDiffGenericDisplayRow(child))
            except Exception as e:
                # log
                logger.info('Failed to import field ' + child.tag)
    return ret


def _readFromXmlToIQVDocumentDiffGenericDisplayTable(branch):
    """
    Read from XML and load memory object
    """

    # get root element
    root = branch

    # initialize IQVDocumentDiffGenericDisplayTable
    ret = IQVDocumentDiffGenericDisplayTable()

    ret.id = _extract_attribute(root, 'id', str, ret.id)

    ret.rowGroups = _extract_attribute_list(root, 'rowGroups', _readFromXmlToIQVDocumentDiffGenericDisplayRowList,
                                            ret.rowGroups)

    ret.rows = _extract_attribute_list(root, 'rows', _readFromXmlToIQVDocumentDiffGenericDisplayRowList, ret.rows)

    ret.tableType = _extract_attribute(root, 'tableType', str, ret.tableType)
    return ret


def _readFromXmlToIQVDocumentDiffGenericDisplayTableList(branch: ET.ElementTree):
    """
    Read from XML and load memory object, for list of objects
    """
    root = branch
    ret = []
    for child in root:
        if (child.tag == 'IQVDocumentDiffGenericDisplayTable'):
            try:
                ret.append(_readFromXmlToIQVDocumentDiffGenericDisplayTable(child))
            except Exception as e:
                # log
                logger.info('Failed to import field ' + child.tag)
    return ret


def _readFromXmlToIQVDocumentDiffGenericDisplayDocument(branch):
    """
    Read from XML and load memory object
    """

    # get root element
    root = branch

    # initialize IQVDocumentDiffGenericDisplayDocument
    ret = IQVDocumentDiffGenericDisplayDocument()

    fieldName = 'diff_table_other'
    try:
        item = root.find(fieldName)
        if item is not None:
            subbranch = item
            ret.diff_table_other = _readFromXmlToIQVDocumentDiffGenericDisplayTable(subbranch)
        else:
            pass
    except Exception as e:
        logger.info('Failed to import field ' + fieldName)

    fieldName = 'diff_table_soa'
    try:
        item = root.find(fieldName)
        if item is not None:
            subbranch = item
            ret.diff_table_soa = _readFromXmlToIQVDocumentDiffGenericDisplayTable(subbranch)
        else:
            pass
    except Exception as e:
        logger.info('Failed to import field ' + fieldName)

    fieldName = 'diff_table_toc'
    try:
        item = root.find(fieldName)
        if item is not None:
            subbranch = item
            ret.diff_table_toc = _readFromXmlToIQVDocumentDiffGenericDisplayTable(subbranch)
        else:
            pass
    except Exception as e:
        logger.info('Failed to import field ' + fieldName)

    ret.id = _extract_attribute(root, 'id', str, ret.id)

    ret.Properties = _extract_attribute_list(root, 'Properties', _readFromXmlToIQVKeyValueSetList, ret.Properties)
    return ret


def _readFromXmlToIQVDocumentDiffGenericDisplayDocumentList(branch: ET.ElementTree):
    """
    Read from XML and load memory object, for list of objects
    """
    root = branch
    ret = []
    for child in root:
        if (child.tag == 'IQVDocumentDiffGenericDisplayDocument'):
            try:
                ret.append(_readFromXmlToIQVDocumentDiffGenericDisplayDocument(child))
            except Exception as e:
                # log
                logger.info('Failed to import field ' + child.tag)
    return ret


def _readFromXmlToIQVDocumentDataItemQC(branch):
    """
    Read from XML and load memory object
    """

    # get root element
    root = branch

    # initialize IQVDocumentDataItemQC
    ret = IQVDocumentDataItemQC()

    ret.bIsTableCell = _extract_attribute(root, 'bIsTableCell', _str2bool, ret.bIsTableCell)

    ret.childbox_id = _extract_attribute(root, 'childbox_id', str, ret.childbox_id)

    ret.column_roi_id = _extract_attribute(root, 'column_roi_id', str, ret.column_roi_id)

    ret.content = _extract_attribute(root, 'content', str, ret.content)

    ret.CPT_section = _extract_attribute(root, 'CPT_section', str, ret.CPT_section)

    ret.datacell_roi_id = _extract_attribute(root, 'datacell_roi_id', str, ret.datacell_roi_id)

    ret.dataType = _extract_attribute(root, 'dataType', str, ret.dataType)

    ret.entities = _extract_attribute_list(root, 'entities', _readFromXmlToNLP_EntityList, ret.entities)

    ret.file_section = _extract_attribute(root, 'file_section', str, ret.file_section)

    ret.file_section_level = _extract_attribute(root, 'file_section_level', int, ret.file_section_level)

    ret.file_section_num = _extract_attribute(root, 'file_section_num', str, ret.file_section_num)

    fieldName = 'fontInfo'
    try:
        item = root.find(fieldName)
        if item is not None:
            subbranch = item
            ret.fontInfo = _readFromXmlToFontInfo(subbranch)
        else:
            pass
    except Exception as e:
        logger.info('Failed to import field ' + fieldName)

    ret.level_1_CPT_section = _extract_attribute(root, 'level_1_CPT_section', str, ret.level_1_CPT_section)

    ret.para_id = _extract_attribute(root, 'para_id', str, ret.para_id)

    ret.qc_change_type = _extract_attribute(root, 'qc_change_type', str, ret.qc_change_type)

    ret.roi_id = _extract_attribute(root, 'roi_id', str, ret.roi_id)

    ret.row_roi_id = _extract_attribute(root, 'row_roi_id', str, ret.row_roi_id)

    ret.section_level = _extract_attribute(root, 'section_level', str, ret.section_level)

    ret.seq_num = _extract_attribute(root, 'seq_num', str, ret.seq_num)

    ret.subtext_id = _extract_attribute(root, 'subtext_id', str, ret.subtext_id)

    ret.table_roi_id = _extract_attribute(root, 'table_roi_id', str, ret.table_roi_id)
    return ret


def _readFromXmlToIQVDocumentDataItemQCList(branch: ET.ElementTree):
    """
    Read from XML and load memory object, for list of objects
    """
    root = branch
    ret = []
    for child in root:
        if (child.tag == 'IQVDocumentDataItemQC'):
            try:
                ret.append(_readFromXmlToIQVDocumentDataItemQC(child))
            except Exception as e:
                # log
                logger.info('Failed to import field ' + child.tag)
    return ret


def _readFromXmlToIQVDocumentDataFeedbackQC(branch):
    """
    Read from XML and load memory object
    """

    # get root element
    root = branch

    # initialize IQVDocumentDataFeedbackQC
    ret = IQVDocumentDataFeedbackQC()

    ret.columns = _extract_attribute_list(root, 'columns', _readFromXmlToStringList, ret.columns)

    ret.data = _extract_attribute_list(root, 'data', _readFromXmlToIQVDocumentDataItemQCList, ret.data)

    ret.index = _extract_attribute_list(root, 'index', _readFromXmlToIntList, ret.index)

    ret.metadata = _extract_attribute_list(root, 'metadata', _readFromXmlToIQVKeyValueSetList, ret.metadata)
    return ret


def _readFromXmlToIQVDocumentDataFeedbackQCList(branch: ET.ElementTree):
    """
    Read from XML and load memory object, for list of objects
    """
    root = branch
    ret = []
    for child in root:
        if (child.tag == 'IQVDocumentDataFeedbackQC'):
            try:
                ret.append(_readFromXmlToIQVDocumentDataFeedbackQC(child))
            except Exception as e:
                # log
                logger.info('Failed to import field ' + child.tag)
    return ret


def _readFromXmlToIQVDocumentFeedbackQC(branch):
    """
    Read from XML and load memory object
    """

    # get root element
    root = branch

    # initialize IQVDocumentFeedbackQC
    ret = IQVDocumentFeedbackQC()

    ret.bIsActive = _extract_attribute(root, 'bIsActive', _str2bool, ret.bIsActive)

    ret.doc_id = _extract_attribute(root, 'doc_id', str, ret.doc_id)

    ret.documentFilePath = _extract_attribute(root, 'documentFilePath', str, ret.documentFilePath)

    ret.fileName = _extract_attribute(root, 'fileName', str, ret.fileName)

    ret.group_type = _extract_attribute(root, 'group_type', str, ret.group_type)

    ret.hierarchy = _extract_attribute(root, 'hierarchy', str, ret.hierarchy)

    ret.id = _extract_attribute(root, 'id', str, ret.id)

    ret.iqv_standard_term = _extract_attribute(root, 'iqv_standard_term', str, ret.iqv_standard_term)

    fieldName = 'iqvdata'
    try:
        item = root.find(fieldName)
        if item is not None:
            subbranch = item
            ret.iqvdata = _readFromXmlToIQVDocumentDataFeedbackQC(subbranch)
        else:
            pass
    except Exception as e:
        logger.info('Failed to import field ' + fieldName)

    fieldName = 'iqvdataSoa'
    try:
        item = root.find(fieldName)
        if item is not None:
            subbranch = item
            ret.iqvdataSoa = _readFromXmlToIQVDocumentDataFeedbackQC(subbranch)
        else:
            pass
    except Exception as e:
        logger.info('Failed to import field ' + fieldName)

    fieldName = 'iqvdataSoaStd'
    try:
        item = root.find(fieldName)
        if item is not None:
            subbranch = item
            ret.iqvdataSoaStd = _readFromXmlToIQVDocumentDataFeedbackQC(subbranch)
        else:
            pass
    except Exception as e:
        logger.info('Failed to import field ' + fieldName)

    fieldName = 'iqvdataSummary'
    try:
        item = root.find(fieldName)
        if item is not None:
            subbranch = item
            ret.iqvdataSummary = _readFromXmlToIQVDocumentDataFeedbackQC(subbranch)
        else:
            pass
    except Exception as e:
        logger.info('Failed to import field ' + fieldName)

    fieldName = 'iqvdataToc'
    try:
        item = root.find(fieldName)
        if item is not None:
            subbranch = item
            ret.iqvdataToc = _readFromXmlToIQVDocumentDataFeedbackQC(subbranch)
        else:
            pass
    except Exception as e:
        logger.info('Failed to import field ' + fieldName)

    ret.link_id = _extract_attribute(root, 'link_id', str, ret.link_id)

    ret.link_id_level2 = _extract_attribute(root, 'link_id_level2', str, ret.link_id_level2)

    ret.link_id_level3 = _extract_attribute(root, 'link_id_level3', str, ret.link_id_level3)

    ret.link_id_level4 = _extract_attribute(root, 'link_id_level4', str, ret.link_id_level4)

    ret.link_id_level5 = _extract_attribute(root, 'link_id_level5', str, ret.link_id_level5)

    ret.link_id_level6 = _extract_attribute(root, 'link_id_level6', str, ret.link_id_level6)

    ret.link_id_subsection1 = _extract_attribute(root, 'link_id_subsection1', str, ret.link_id_subsection1)

    ret.link_id_subsection2 = _extract_attribute(root, 'link_id_subsection2', str, ret.link_id_subsection2)

    ret.link_id_subsection3 = _extract_attribute(root, 'link_id_subsection3', str, ret.link_id_subsection3)

    ret.parent_id = _extract_attribute(root, 'parent_id', str, ret.parent_id)

    ret.source_system = _extract_attribute(root, 'source_system', str, ret.source_system)

    ret.timeCreated = _extract_attribute(root, 'timeCreated', str, ret.timeCreated)

    ret.timeUpdated = _extract_attribute(root, 'timeUpdated', str, ret.timeUpdated)

    ret.userId = _extract_attribute(root, 'userId', str, ret.userId)
    return ret


def _readFromXmlToIQVDocumentFeedbackQCList(branch: ET.ElementTree):
    """
    Read from XML and load memory object, for list of objects
    """
    root = branch
    ret = []
    for child in root:
        if (child.tag == 'IQVDocumentFeedbackQC'):
            try:
                ret.append(_readFromXmlToIQVDocumentFeedbackQC(child))
            except Exception as e:
                # log
                logger.info('Failed to import field ' + child.tag)
    return ret


def _readFromXmlToIQVClassifierModel(branch):
    """
    Read from XML and load memory object
    """

    # get root element
    root = branch

    # initialize IQVClassifierModel
    ret = IQVClassifierModel()

    ret.Base_Model_Version = _extract_attribute(root, 'Base_Model_Version', str, ret.Base_Model_Version)

    ret.Country = _extract_attribute(root, 'Country', str, ret.Country)

    ret.Doc_Class = _extract_attribute(root, 'Doc_Class', str, ret.Doc_Class)

    ret.Full_Classification_List = _extract_attribute_list(root, 'Full_Classification_List', _readFromXmlToStringList,
                                                           ret.Full_Classification_List)

    ret.id = _extract_attribute(root, 'id', str, ret.id)

    ret.Language = _extract_attribute(root, 'Language', str, ret.Language)

    ret.Model_Directory = _extract_attribute(root, 'Model_Directory', str, ret.Model_Directory)

    ret.Model_Index = _extract_attribute(root, 'Model_Index', str, ret.Model_Index)

    ret.Model_Label = _extract_attribute(root, 'Model_Label', str, ret.Model_Label)

    ret.Model_Name = _extract_attribute(root, 'Model_Name', str, ret.Model_Name)

    ret.Model_Sequence = _extract_attribute(root, 'Model_Sequence', str, ret.Model_Sequence)
    return ret


def _readFromXmlToIQVClassifierModelList(branch: ET.ElementTree):
    """
    Read from XML and load memory object, for list of objects
    """
    root = branch
    ret = []
    for child in root:
        if (child.tag == 'IQVClassifierModel'):
            try:
                ret.append(_readFromXmlToIQVClassifierModel(child))
            except Exception as e:
                # log
                logger.info('Failed to import field ' + child.tag)
    return ret


def _readFromXmlToIQVFormularyItem(branch):
    """
    Read from XML and load memory object
    """

    # get root element
    root = branch

    # initialize IQVFormularyItem
    ret = IQVFormularyItem()

    ret.Client = _extract_attribute(root, 'Client', str, ret.Client)

    ret.DrugName = _extract_attribute(root, 'DrugName', str, ret.DrugName)

    ret.DrugSpecialCode = _extract_attribute(root, 'DrugSpecialCode', str, ret.DrugSpecialCode)

    ret.DrugTier = _extract_attribute(root, 'DrugTier', str, ret.DrugTier)

    ret.id = _extract_attribute(root, 'id', str, ret.id)

    ret.PBM = _extract_attribute(root, 'PBM', str, ret.PBM)

    ret.Properties = _extract_attribute_list(root, 'Properties', _readFromXmlToIQVKeyValueSetList, ret.Properties)

    ret.Source = _extract_attribute(root, 'Source', str, ret.Source)

    ret.source_system = _extract_attribute(root, 'source_system', str, ret.source_system)

    ret.SourceDate = _extract_attribute(root, 'SourceDate', str, ret.SourceDate)
    return ret


def _readFromXmlToIQVFormularyItemList(branch: ET.ElementTree):
    """
    Read from XML and load memory object, for list of objects
    """
    root = branch
    ret = []
    for child in root:
        if (child.tag == 'IQVFormularyItem'):
            try:
                ret.append(_readFromXmlToIQVFormularyItem(child))
            except Exception as e:
                # log
                logger.info('Failed to import field ' + child.tag)
    return ret


def _writeToXmlFromLanguageCode(db: LanguageCode):
    """
    Get the ET Element LanguageCode with all of its subelements
    """

    try:
        root = ET.Element("LanguageCode")
        ##############################################################
        #
        # Start of fields
        #
        ##############################################################
        _write_attribute(root, 'code', str(db.code))
        _write_attribute(root, 'description', str(db.description))
        _write_attribute(root, 'eTMFCode', str(db.eTMFCode))
        _write_attribute(root, 'fourLetterCode', str(db.fourLetterCode))
        _write_attribute(root, 'id', str(db.id))
        _write_attribute(root, 'ReleaseVersionAvailability', str(db.ReleaseVersionAvailability))
        _write_attribute(root, 'tesseractCode', str(db.tesseractCode))
        ##############################################################
        #
        # End of fields
        #
        ##############################################################
        return root
    except Exception as e:
        logger.error('Failed to write LanguageCode to root')


def _writeToXmlFromIQVDocumentMapping(db: IQVDocumentMapping):
    """
    Get the ET Element IQVDocumentMapping with all of its subelements
    """

    try:
        root = ET.Element("IQVDocumentMapping")
        ##############################################################
        #
        # Start of fields
        #
        ##############################################################
        _write_attribute(root, 'Additional_instructions', str(db.Additional_instructions))

        fieldName = 'AdditionalAttributesList'
        try:
            subelement = ET.SubElement(root, fieldName)
            for xelm in db.AdditionalAttributesList:
                subelement.append(_writeToXmlFromIQVKeyValueSet(xelm))
        except Exception as e:
            logger.info('Failed to export field ' + fieldName)

        fieldName = 'AdditionalInstructionsList'
        try:
            subelement = ET.SubElement(root, fieldName)
            for xelm in db.AdditionalInstructionsList:
                subelement.append(_writeToXmlFromIQVKeyValueSet(xelm))
        except Exception as e:
            logger.info('Failed to export field ' + fieldName)
        _write_attribute(root, 'CONTENT_TYPE', str(db.CONTENT_TYPE))
        _write_attribute(root, 'DateGuidance', str(db.DateGuidance))
        _write_attribute(root, 'DateGuidanceSecondary', str(db.DateGuidanceSecondary))

        fieldName = 'DerivedMappings'
        try:
            subelement = ET.SubElement(root, fieldName)
            for xelm in db.DerivedMappings:
                subelement.append(_writeToXmlFromIQVDocumentMapping(xelm))
        except Exception as e:
            logger.info('Failed to export field ' + fieldName)
        _write_attribute(root, 'DIA_KEY', str(db.DIA_KEY))
        _write_attribute(root, 'DOC_ABBREVIATION', str(db.DOC_ABBREVIATION))
        _write_attribute(root, 'DOC_ARTIFACT', str(db.DOC_ARTIFACT))
        _write_attribute(root, 'DOC_CLASS', str(db.DOC_CLASS))
        _write_attribute(root, 'DOC_COUNT', str(db.DOC_COUNT))
        _write_attribute(root, 'DOC_COUNT_CURRENT', str(db.DOC_COUNT_CURRENT))
        _write_attribute(root, 'DOC_SECTION', str(db.DOC_SECTION))
        _write_attribute(root, 'DOC_ZONE', str(db.DOC_ZONE))
        _write_attribute(root, 'Document_Description', str(db.Document_Description))
        _write_attribute(root, 'ExpirationDateExpected', str(db.ExpirationDateExpected))
        _write_attribute(root, 'Full_Classification_Historical', str(db.Full_Classification_Historical))
        _write_attribute(root, 'Full_Classification_Wingspan', str(db.Full_Classification_Wingspan))
        _write_attribute(root, 'id', str(db.id))
        _write_attribute(root, 'MLClassificationGroup', str(db.MLClassificationGroup))
        _write_attribute(root, 'MLClassificationRole', str(db.MLClassificationRole))
        _write_attribute(root, 'MLConfusionCluster', str(db.MLConfusionCluster))
        _write_attribute(root, 'Subject', str(db.Subject))
        _write_attribute(root, 'Subtype', str(db.Subtype))
        _write_attribute(root, 'TargetSystemName', str(db.TargetSystemName))
        _write_attribute(root, 'TargetSystemVersion', str(db.TargetSystemVersion))
        _write_attribute(root, 'Wingspan_DIA', str(db.Wingspan_DIA))
        _write_attribute(root, 'Wingspan_Doc_ID', str(db.Wingspan_Doc_ID))
        _write_attribute(root, 'Wingspan_doc_type', str(db.Wingspan_doc_type))
        ##############################################################
        #
        # End of fields
        #
        ##############################################################
        return root
    except Exception as e:
        logger.error('Failed to write IQVDocumentMapping to root')


def _writeToXmlFromIQVDocumentProcess(db: IQVDocumentProcess):
    """
    Get the ET Element IQVDocumentProcess with all of its subelements
    """

    try:
        root = ET.Element("IQVDocumentProcess")
        ##############################################################
        #
        # Start of fields
        #
        ##############################################################
        _write_attribute(root, 'bProcessRequired', _bool2str(db.bProcessRequired))
        _write_attribute(root, 'doc_id', str(db.doc_id))
        _write_attribute(root, 'group_type', str(db.group_type))
        _write_attribute(root, 'hierarchy', str(db.hierarchy))
        _write_attribute(root, 'id', str(db.id))
        _write_attribute(root, 'iqv_standard_term', str(db.iqv_standard_term))

        fieldName = 'KeyValues'
        try:
            subelement = ET.SubElement(root, fieldName)
            for xelm in db.KeyValues:
                subelement.append(_writeToXmlFromIQVKeyValueSet(xelm))
        except Exception as e:
            logger.info('Failed to export field ' + fieldName)
        _write_attribute(root, 'link_id', str(db.link_id))
        _write_attribute(root, 'link_id_level2', str(db.link_id_level2))
        _write_attribute(root, 'link_id_level3', str(db.link_id_level3))
        _write_attribute(root, 'link_id_level4', str(db.link_id_level4))
        _write_attribute(root, 'link_id_level5', str(db.link_id_level5))
        _write_attribute(root, 'link_id_level6', str(db.link_id_level6))
        _write_attribute(root, 'link_id_subsection1', str(db.link_id_subsection1))
        _write_attribute(root, 'link_id_subsection2', str(db.link_id_subsection2))
        _write_attribute(root, 'link_id_subsection3', str(db.link_id_subsection3))
        _write_attribute(root, 'parent_id', str(db.parent_id))
        _write_attribute(root, 'ProcessEnvironment', str(db.ProcessEnvironment))
        _write_attribute(root, 'ProcessFinishTime', str(db.ProcessFinishTime))
        _write_attribute(root, 'ProcessMachineName', str(db.ProcessMachineName))
        _write_attribute(root, 'ProcessName', str(db.ProcessName))
        _write_attribute(root, 'ProcessStartTime', str(db.ProcessStartTime))
        _write_attribute(root, 'ProcessType', str(db.ProcessType))
        _write_attribute(root, 'ProcessUserID', str(db.ProcessUserID))
        _write_attribute(root, 'ProcessVersion', str(db.ProcessVersion))
        _write_attribute(root, 'ProcessVersionHash', str(db.ProcessVersionHash))
        ##############################################################
        #
        # End of fields
        #
        ##############################################################
        return root
    except Exception as e:
        logger.error('Failed to write IQVDocumentProcess to root')


def _writeToXmlFromIQVQCUpdateTracking(db: IQVQCUpdateTracking):
    """
    Get the ET Element IQVQCUpdateTracking with all of its subelements
    """

    try:
        root = ET.Element("IQVQCUpdateTracking")
        ##############################################################
        #
        # Start of fields
        #
        ##############################################################
        _write_attribute(root, 'doc_id', str(db.doc_id))
        _write_attribute(root, 'dts', str(db.dts))
        _write_attribute(root, 'group_type', str(db.group_type))
        _write_attribute(root, 'hierarchy', str(db.hierarchy))
        _write_attribute(root, 'id', str(db.id))
        _write_attribute(root, 'iqv_standard_term', str(db.iqv_standard_term))
        _write_attribute(root, 'ItemDataType', str(db.ItemDataType))
        _write_attribute(root, 'link_id', str(db.link_id))
        _write_attribute(root, 'link_id_level2', str(db.link_id_level2))
        _write_attribute(root, 'link_id_level3', str(db.link_id_level3))
        _write_attribute(root, 'link_id_level4', str(db.link_id_level4))
        _write_attribute(root, 'link_id_level5', str(db.link_id_level5))
        _write_attribute(root, 'link_id_level6', str(db.link_id_level6))
        _write_attribute(root, 'link_id_subsection1', str(db.link_id_subsection1))
        _write_attribute(root, 'link_id_subsection2', str(db.link_id_subsection2))
        _write_attribute(root, 'link_id_subsection3', str(db.link_id_subsection3))
        _write_attribute(root, 'OriginalText', str(db.OriginalText))
        _write_attribute(root, 'parent_id', str(db.parent_id))

        fieldName = 'Properties'
        try:
            subelement = ET.SubElement(root, fieldName)
            for xelm in db.Properties:
                subelement.append(_writeToXmlFromIQVKeyValueSet(xelm))
        except Exception as e:
            logger.info('Failed to export field ' + fieldName)
        _write_attribute(root, 'QC_id', str(db.QC_id))
        _write_attribute(root, 'QCType', str(db.QCType))
        _write_attribute(root, 'roi_id', str(db.roi_id))
        _write_attribute(root, 'seq_num', str(db.seq_num))
        _write_attribute(root, 'source_system', str(db.source_system))
        _write_attribute(root, 'UpdatedText', str(db.UpdatedText))
        _write_attribute(root, 'user_id', str(db.user_id))
        ##############################################################
        #
        # End of fields
        #
        ##############################################################
        return root
    except Exception as e:
        logger.error('Failed to write IQVQCUpdateTracking to root')


def _writeToXmlFromIQVTM_DocClassLite(db: IQVTM_DocClassLite):
    """
    Get the ET Element IQVTM_DocClassLite with all of its subelements
    """

    try:
        root = ET.Element("IQVTM_DocClassLite")
        ##############################################################
        #
        # Start of fields
        #
        ##############################################################
        _write_attribute(root, 'DocumentCount', str(db.DocumentCount))
        _write_attribute(root, 'Index', str(db.Index))
        ##############################################################
        #
        # End of fields
        #
        ##############################################################
        return root
    except Exception as e:
        logger.error('Failed to write IQVTM_DocClassLite to root')


def _writeToXmlFromIQVTableColumnHeader(db: IQVTableColumnHeader):
    """
    Get the ET Element IQVTableColumnHeader with all of its subelements
    """

    try:
        root = ET.Element("IQVTableColumnHeader")
        ##############################################################
        #
        # Start of fields
        #
        ##############################################################
        _write_attribute(root, 'doc_id', str(db.doc_id))
        _write_attribute(root, 'group_type', str(db.group_type))
        _write_attribute(root, 'hierarchy', str(db.hierarchy))
        _write_attribute(root, 'id', str(db.id))
        _write_attribute(root, 'iqv_standard_term', str(db.iqv_standard_term))
        _write_attribute(root, 'link_id', str(db.link_id))
        _write_attribute(root, 'link_id_level2', str(db.link_id_level2))
        _write_attribute(root, 'link_id_level3', str(db.link_id_level3))
        _write_attribute(root, 'link_id_level4', str(db.link_id_level4))
        _write_attribute(root, 'link_id_level5', str(db.link_id_level5))
        _write_attribute(root, 'link_id_level6', str(db.link_id_level6))
        _write_attribute(root, 'link_id_subsection1', str(db.link_id_subsection1))
        _write_attribute(root, 'link_id_subsection2', str(db.link_id_subsection2))
        _write_attribute(root, 'link_id_subsection3', str(db.link_id_subsection3))
        _write_attribute(root, 'OriginalText', str(db.OriginalText))
        _write_attribute(root, 'parent_id', str(db.parent_id))

        fieldName = 'Properties'
        try:
            subelement = ET.SubElement(root, fieldName)
            for xelm in db.Properties:
                subelement.append(_writeToXmlFromIQVKeyValueSet(xelm))
        except Exception as e:
            logger.info('Failed to export field ' + fieldName)
        _write_attribute(root, 'roi_id', str(db.roi_id))
        _write_attribute(root, 'rowIndex', str(db.rowIndex))
        _write_attribute(root, 'rowRef', str(db.rowRef))
        ##############################################################
        #
        # End of fields
        #
        ##############################################################
        return root
    except Exception as e:
        logger.error('Failed to write IQVTableColumnHeader to root')


def _writeToXmlFromIQVTableColumn(db: IQVTableColumn):
    """
    Get the ET Element IQVTableColumn with all of its subelements
    """

    try:
        root = ET.Element("IQVTableColumn")
        ##############################################################
        #
        # Start of fields
        #
        ##############################################################
        _write_attribute(root, 'doc_id', str(db.doc_id))
        _write_attribute(root, 'group_type', str(db.group_type))

        fieldName = 'headers'
        try:
            subelement = ET.SubElement(root, fieldName)
            for xelm in db.headers:
                subelement.append(_writeToXmlFromIQVTableColumnHeader(xelm))
        except Exception as e:
            logger.info('Failed to export field ' + fieldName)
        _write_attribute(root, 'hierarchy', str(db.hierarchy))
        _write_attribute(root, 'id', str(db.id))
        _write_attribute(root, 'iqv_standard_term', str(db.iqv_standard_term))
        _write_attribute(root, 'link_id', str(db.link_id))
        _write_attribute(root, 'link_id_level2', str(db.link_id_level2))
        _write_attribute(root, 'link_id_level3', str(db.link_id_level3))
        _write_attribute(root, 'link_id_level4', str(db.link_id_level4))
        _write_attribute(root, 'link_id_level5', str(db.link_id_level5))
        _write_attribute(root, 'link_id_level6', str(db.link_id_level6))
        _write_attribute(root, 'link_id_subsection1', str(db.link_id_subsection1))
        _write_attribute(root, 'link_id_subsection2', str(db.link_id_subsection2))
        _write_attribute(root, 'link_id_subsection3', str(db.link_id_subsection3))
        _write_attribute(root, 'maxX', str(db.maxX))
        _write_attribute(root, 'minX', str(db.minX))
        _write_attribute(root, 'parent_id', str(db.parent_id))

        fieldName = 'Properties'
        try:
            subelement = ET.SubElement(root, fieldName)
            for xelm in db.Properties:
                subelement.append(_writeToXmlFromIQVKeyValueSet(xelm))
        except Exception as e:
            logger.info('Failed to export field ' + fieldName)
        _write_attribute(root, 'table_roi_id', str(db.table_roi_id))
        _write_attribute(root, 'tableColumnIndex', str(db.tableColumnIndex))
        _write_attribute(root, 'tableColumnRef', str(db.tableColumnRef))
        _write_attribute(root, 'tableIndex', str(db.tableIndex))
        ##############################################################
        #
        # End of fields
        #
        ##############################################################
        return root
    except Exception as e:
        logger.error('Failed to write IQVTableColumn to root')


def _writeToXmlFromIQVTableRow(db: IQVTableRow):
    """
    Get the ET Element IQVTableRow with all of its subelements
    """

    try:
        root = ET.Element("IQVTableRow")
        ##############################################################
        #
        # Start of fields
        #
        ##############################################################
        _write_attribute(root, 'doc_id', str(db.doc_id))
        _write_attribute(root, 'group_type', str(db.group_type))
        _write_attribute(root, 'header', str(db.header))
        _write_attribute(root, 'hierarchy', str(db.hierarchy))
        _write_attribute(root, 'id', str(db.id))
        _write_attribute(root, 'iqv_standard_term', str(db.iqv_standard_term))
        _write_attribute(root, 'link_id', str(db.link_id))
        _write_attribute(root, 'link_id_level2', str(db.link_id_level2))
        _write_attribute(root, 'link_id_level3', str(db.link_id_level3))
        _write_attribute(root, 'link_id_level4', str(db.link_id_level4))
        _write_attribute(root, 'link_id_level5', str(db.link_id_level5))
        _write_attribute(root, 'link_id_level6', str(db.link_id_level6))
        _write_attribute(root, 'link_id_subsection1', str(db.link_id_subsection1))
        _write_attribute(root, 'link_id_subsection2', str(db.link_id_subsection2))
        _write_attribute(root, 'link_id_subsection3', str(db.link_id_subsection3))
        _write_attribute(root, 'maxY', str(db.maxY))
        _write_attribute(root, 'minY', str(db.minY))
        _write_attribute(root, 'parent_id', str(db.parent_id))
        _write_attribute(root, 'tableIndex', str(db.tableIndex))
        _write_attribute(root, 'tableRowIndex', str(db.tableRowIndex))
        _write_attribute(root, 'tableRowRef', str(db.tableRowRef))
        ##############################################################
        #
        # End of fields
        #
        ##############################################################
        return root
    except Exception as e:
        logger.error('Failed to write IQVTableRow to root')


def _writeToXmlFromIQVExternalLink(db: IQVExternalLink):
    """
    Get the ET Element IQVExternalLink with all of its subelements
    """

    try:
        root = ET.Element("IQVExternalLink")
        ##############################################################
        #
        # Start of fields
        #
        ##############################################################
        _write_attribute(root, 'connection_type', str(db.connection_type))
        _write_attribute(root, 'destination_link_id', str(db.destination_link_id))
        _write_attribute(root, 'destination_link_prefix', str(db.destination_link_prefix))
        _write_attribute(root, 'destination_link_text', str(db.destination_link_text))
        _write_attribute(root, 'destination_url', str(db.destination_url))
        _write_attribute(root, 'doc_id', str(db.doc_id))

        fieldName = 'Elements'
        try:
            subelement = ET.SubElement(root, fieldName)
            for xelm in db.Elements:
                subelement.append(_writeToXmlFromIQVExternalLinkElement(xelm))
        except Exception as e:
            logger.info('Failed to export field ' + fieldName)
        _write_attribute(root, 'group_type', str(db.group_type))
        _write_attribute(root, 'hierarchy', str(db.hierarchy))
        _write_attribute(root, 'id', str(db.id))
        _write_attribute(root, 'iqv_standard_term', str(db.iqv_standard_term))
        _write_attribute(root, 'length', str(db.length))
        _write_attribute(root, 'link_id', str(db.link_id))
        _write_attribute(root, 'link_id_level2', str(db.link_id_level2))
        _write_attribute(root, 'link_id_level3', str(db.link_id_level3))
        _write_attribute(root, 'link_id_level4', str(db.link_id_level4))
        _write_attribute(root, 'link_id_level5', str(db.link_id_level5))
        _write_attribute(root, 'link_id_level6', str(db.link_id_level6))
        _write_attribute(root, 'link_id_subsection1', str(db.link_id_subsection1))
        _write_attribute(root, 'link_id_subsection2', str(db.link_id_subsection2))
        _write_attribute(root, 'link_id_subsection3', str(db.link_id_subsection3))
        _write_attribute(root, 'link_text', str(db.link_text))
        _write_attribute(root, 'parent_id', str(db.parent_id))

        fieldName = 'Properties'
        try:
            subelement = ET.SubElement(root, fieldName)
            for xelm in db.Properties:
                subelement.append(_writeToXmlFromIQVKeyValueSet(xelm))
        except Exception as e:
            logger.info('Failed to export field ' + fieldName)
        _write_attribute(root, 'source_text', str(db.source_text))
        _write_attribute(root, 'startIndex', str(db.startIndex))
        ##############################################################
        #
        # End of fields
        #
        ##############################################################
        return root
    except Exception as e:
        logger.error('Failed to write IQVExternalLink to root')


def _writeToXmlFromIQVExternalLinkElement(db: IQVExternalLinkElement):
    """
    Get the ET Element IQVExternalLinkElement with all of its subelements
    """

    try:
        root = ET.Element("IQVExternalLinkElement")
        ##############################################################
        #
        # Start of fields
        #
        ##############################################################
        _write_attribute(root, 'doc_id', str(db.doc_id))
        _write_attribute(root, 'group_type', str(db.group_type))
        _write_attribute(root, 'hierarchy', str(db.hierarchy))
        _write_attribute(root, 'id', str(db.id))
        _write_attribute(root, 'iqv_standard_term', str(db.iqv_standard_term))
        _write_attribute(root, 'length', str(db.length))
        _write_attribute(root, 'link_id', str(db.link_id))
        _write_attribute(root, 'link_id_level2', str(db.link_id_level2))
        _write_attribute(root, 'link_id_level3', str(db.link_id_level3))
        _write_attribute(root, 'link_id_level4', str(db.link_id_level4))
        _write_attribute(root, 'link_id_level5', str(db.link_id_level5))
        _write_attribute(root, 'link_id_level6', str(db.link_id_level6))
        _write_attribute(root, 'link_id_subsection1', str(db.link_id_subsection1))
        _write_attribute(root, 'link_id_subsection2', str(db.link_id_subsection2))
        _write_attribute(root, 'link_id_subsection3', str(db.link_id_subsection3))

        fieldName = 'NLP_Entities'
        try:
            subelement = ET.SubElement(root, fieldName)
            for xelm in db.NLP_Entities:
                subelement.append(_writeToXmlFromNLP_Entity(xelm))
        except Exception as e:
            logger.info('Failed to export field ' + fieldName)
        _write_attribute(root, 'parent_id', str(db.parent_id))
        _write_attribute(root, 'startIndex', str(db.startIndex))
        _write_attribute(root, 'text', str(db.text))
        ##############################################################
        #
        # End of fields
        #
        ##############################################################
        return root
    except Exception as e:
        logger.error('Failed to write IQVExternalLinkElement to root')


def _writeToXmlFromIQVNumberingGroup(db: IQVNumberingGroup):
    """
    Get the ET Element IQVNumberingGroup with all of its subelements
    """

    try:
        root = ET.Element("IQVNumberingGroup")
        ##############################################################
        #
        # Start of fields
        #
        ##############################################################
        _write_attribute(root, 'abstractNumId', str(db.abstractNumId))
        _write_attribute(root, 'countItems', str(db.countItems))
        _write_attribute(root, 'doc_id', str(db.doc_id))
        _write_attribute(root, 'group_type', str(db.group_type))
        _write_attribute(root, 'hierarchy', str(db.hierarchy))
        _write_attribute(root, 'id', str(db.id))
        _write_attribute(root, 'iqv_standard_term', str(db.iqv_standard_term))
        _write_attribute(root, 'link_id', str(db.link_id))
        _write_attribute(root, 'link_id_level2', str(db.link_id_level2))
        _write_attribute(root, 'link_id_level3', str(db.link_id_level3))
        _write_attribute(root, 'link_id_level4', str(db.link_id_level4))
        _write_attribute(root, 'link_id_level5', str(db.link_id_level5))
        _write_attribute(root, 'link_id_level6', str(db.link_id_level6))
        _write_attribute(root, 'link_id_subsection1', str(db.link_id_subsection1))
        _write_attribute(root, 'link_id_subsection2', str(db.link_id_subsection2))
        _write_attribute(root, 'link_id_subsection3', str(db.link_id_subsection3))

        fieldName = 'numberingLevels'
        try:
            subelement = ET.SubElement(root, fieldName)
            for xelm in db.numberingLevels:
                subelement.append(_writeToXmlFromIQVNumberingLevel(xelm))
        except Exception as e:
            logger.info('Failed to export field ' + fieldName)
        _write_attribute(root, 'numId', str(db.numId))
        _write_attribute(root, 'paraEndIndex', str(db.paraEndIndex))

        fieldName = 'paraIds'
        try:
            subelement = ET.SubElement(root, fieldName)
            for xelm in db.paraIds:
                subelement.append(_writeToXmlFromString(xelm))
        except Exception as e:
            logger.info('Failed to export field ' + fieldName)
        _write_attribute(root, 'paraIds_list', str(db.paraIds_list))
        _write_attribute(root, 'paraStartIndex', str(db.paraStartIndex))
        _write_attribute(root, 'parent_id', str(db.parent_id))
        ##############################################################
        #
        # End of fields
        #
        ##############################################################
        return root
    except Exception as e:
        logger.error('Failed to write IQVNumberingGroup to root')


def _writeToXmlFromIQVNumberingLevel(db: IQVNumberingLevel):
    """
    Get the ET Element IQVNumberingLevel with all of its subelements
    """

    try:
        root = ET.Element("IQVNumberingLevel")
        ##############################################################
        #
        # Start of fields
        #
        ##############################################################
        _write_attribute(root, 'doc_id', str(db.doc_id))
        _write_attribute(root, 'group_type', str(db.group_type))
        _write_attribute(root, 'hierarchy', str(db.hierarchy))
        _write_attribute(root, 'id', str(db.id))
        _write_attribute(root, 'ilvl', str(db.ilvl))
        _write_attribute(root, 'iqv_standard_term', str(db.iqv_standard_term))
        _write_attribute(root, 'link_id', str(db.link_id))
        _write_attribute(root, 'link_id_level2', str(db.link_id_level2))
        _write_attribute(root, 'link_id_level3', str(db.link_id_level3))
        _write_attribute(root, 'link_id_level4', str(db.link_id_level4))
        _write_attribute(root, 'link_id_level5', str(db.link_id_level5))
        _write_attribute(root, 'link_id_level6', str(db.link_id_level6))
        _write_attribute(root, 'link_id_subsection1', str(db.link_id_subsection1))
        _write_attribute(root, 'link_id_subsection2', str(db.link_id_subsection2))
        _write_attribute(root, 'link_id_subsection3', str(db.link_id_subsection3))
        _write_attribute(root, 'lvlText', str(db.lvlText))
        _write_attribute(root, 'numFmt', str(db.numFmt))
        _write_attribute(root, 'parent_id', str(db.parent_id))
        _write_attribute(root, 'start', str(db.start))
        ##############################################################
        #
        # End of fields
        #
        ##############################################################
        return root
    except Exception as e:
        logger.error('Failed to write IQVNumberingLevel to root')


def _writeToXmlFromPredictedItem(db: PredictedItem):
    """
    Get the ET Element PredictedItem with all of its subelements
    """

    try:
        root = ET.Element("PredictedItem")
        ##############################################################
        #
        # Start of fields
        #
        ##############################################################
        _write_attribute(root, 'AttributeKey', str(db.AttributeKey))
        _write_attribute(root, 'DocumentType', str(db.DocumentType))
        _write_attribute(root, 'Full_Classification_Historical', str(db.Full_Classification_Historical))
        _write_attribute(root, 'Predicted_TestConfidence', str(db.Predicted_TestConfidence))
        _write_attribute(root, 'Predicted_TestCorrect', str(db.Predicted_TestCorrect))
        _write_attribute(root, 'PredictedItem_RawScore', str(db.PredictedItem_RawScore))
        _write_attribute(root, 'PredictedItem_TestCount', str(db.PredictedItem_TestCount))
        ##############################################################
        #
        # End of fields
        #
        ##############################################################
        return root
    except Exception as e:
        logger.error('Failed to write PredictedItem to root')


def _writeToXmlFromIQVConfidenceTracker(db: IQVConfidenceTracker):
    """
    Get the ET Element IQVConfidenceTracker with all of its subelements
    """

    try:
        root = ET.Element("IQVConfidenceTracker")
        ##############################################################
        #
        # Start of fields
        #
        ##############################################################
        _write_attribute(root, 'AttributeKey', str(db.AttributeKey))

        fieldName = 'PredictedItems'
        try:
            subelement = ET.SubElement(root, fieldName)
            for xelm in db.PredictedItems:
                subelement.append(_writeToXmlFromPredictedItem(xelm))
        except Exception as e:
            logger.info('Failed to export field ' + fieldName)
        ##############################################################
        #
        # End of fields
        #
        ##############################################################
        return root
    except Exception as e:
        logger.error('Failed to write IQVConfidenceTracker to root')


def _writeToXmlFromIQVLanguageMapping(db: IQVLanguageMapping):
    """
    Get the ET Element IQVLanguageMapping with all of its subelements
    """

    try:
        root = ET.Element("IQVLanguageMapping")
        ##############################################################
        #
        # Start of fields
        #
        ##############################################################
        _write_attribute(root, 'HistoricalCount', str(db.HistoricalCount))
        _write_attribute(root, 'HistoricalCountWeight', str(db.HistoricalCountWeight))
        _write_attribute(root, 'id', str(db.id))

        fieldName = 'languageCode'
        try:
            subelement = _writeToXmlFromLanguageCode(db.languageCode)
            subelement.tag = fieldName
            root.append(subelement)
        except Exception as e:
            logger.info('Failed to export field ' + fieldName)
        _write_attribute(root, 'script_list', str(db.script_list))

        fieldName = 'scripts'
        try:
            subelement = ET.SubElement(root, fieldName)
            for xelm in db.scripts:
                subelement.append(_writeToXmlFromString(xelm))
        except Exception as e:
            logger.info('Failed to export field ' + fieldName)
        ##############################################################
        #
        # End of fields
        #
        ##############################################################
        return root
    except Exception as e:
        logger.error('Failed to write IQVLanguageMapping to root')


def _writeToXmlFromIQVCountryMapping(db: IQVCountryMapping):
    """
    Get the ET Element IQVCountryMapping with all of its subelements
    """

    try:
        root = ET.Element("IQVCountryMapping")
        ##############################################################
        #
        # Start of fields
        #
        ##############################################################
        _write_attribute(root, 'Country', str(db.Country))

        fieldName = 'DateFormats'
        try:
            subelement = ET.SubElement(root, fieldName)
            for xelm in db.DateFormats:
                subelement.append(_writeToXmlFromString(xelm))
        except Exception as e:
            logger.info('Failed to export field ' + fieldName)
        _write_attribute(root, 'id', str(db.id))

        fieldName = 'iqvLanguageMappings'
        try:
            subelement = ET.SubElement(root, fieldName)
            for xelm in db.iqvLanguageMappings:
                subelement.append(_writeToXmlFromIQVLanguageMapping(xelm))
        except Exception as e:
            logger.info('Failed to export field ' + fieldName)
        ##############################################################
        #
        # End of fields
        #
        ##############################################################
        return root
    except Exception as e:
        logger.error('Failed to write IQVCountryMapping to root')


def _writeToXmlFromIQVAttributeCandidate(db: IQVAttributeCandidate):
    """
    Get the ET Element IQVAttributeCandidate with all of its subelements
    """

    try:
        root = ET.Element("IQVAttributeCandidate")
        ##############################################################
        #
        # Start of fields
        #
        ##############################################################
        _write_attribute(root, 'AttributeKey', str(db.AttributeKey))
        _write_attribute(root, 'AttributeValue', str(db.AttributeValue))
        _write_attribute(root, 'CandidateSelected', str(db.CandidateSelected))
        _write_attribute(root, 'doc_id', str(db.doc_id))

        fieldName = 'Features'
        try:
            subelement = ET.SubElement(root, fieldName)
            for xelm in db.Features:
                subelement.append(_writeToXmlFromIQVKeyValueSet(xelm))
        except Exception as e:
            logger.info('Failed to export field ' + fieldName)
        _write_attribute(root, 'group_type', str(db.group_type))
        _write_attribute(root, 'hierarchy', str(db.hierarchy))
        _write_attribute(root, 'id', str(db.id))
        _write_attribute(root, 'iqv_standard_term', str(db.iqv_standard_term))
        _write_attribute(root, 'link_id', str(db.link_id))
        _write_attribute(root, 'link_id_level2', str(db.link_id_level2))
        _write_attribute(root, 'link_id_level3', str(db.link_id_level3))
        _write_attribute(root, 'link_id_level4', str(db.link_id_level4))
        _write_attribute(root, 'link_id_level5', str(db.link_id_level5))
        _write_attribute(root, 'link_id_level6', str(db.link_id_level6))
        _write_attribute(root, 'link_id_subsection1', str(db.link_id_subsection1))
        _write_attribute(root, 'link_id_subsection2', str(db.link_id_subsection2))
        _write_attribute(root, 'link_id_subsection3', str(db.link_id_subsection3))
        _write_attribute(root, 'parent_id', str(db.parent_id))
        _write_attribute(root, 'RawProbabilitiyScore', str(db.RawProbabilitiyScore))
        _write_attribute(root, 'roi_id', str(db.roi_id))
        ##############################################################
        #
        # End of fields
        #
        ##############################################################
        return root
    except Exception as e:
        logger.error('Failed to write IQVAttributeCandidate to root')


def _writeToXmlFromIQVBigram(db: IQVBigram):
    """
    Get the ET Element IQVBigram with all of its subelements
    """

    try:
        root = ET.Element("IQVBigram")
        ##############################################################
        #
        # Start of fields
        #
        ##############################################################
        _write_attribute(root, 'bDutch', _bool2str(db.bDutch))
        _write_attribute(root, 'bEnglish', _bool2str(db.bEnglish))
        _write_attribute(root, 'bFrench', _bool2str(db.bFrench))
        _write_attribute(root, 'bGerman', _bool2str(db.bGerman))
        _write_attribute(root, 'bSpanish', _bool2str(db.bSpanish))
        _write_attribute(root, 'languageCode', str(db.languageCode))
        _write_attribute(root, 's1', str(db.s1))
        _write_attribute(root, 's2', str(db.s2))
        ##############################################################
        #
        # End of fields
        #
        ##############################################################
        return root
    except Exception as e:
        logger.error('Failed to write IQVBigram to root')


def _writeToXmlFromRectangleD(db: RectangleD):
    """
    Get the ET Element RectangleD with all of its subelements
    """

    try:
        root = ET.Element("RectangleD")
        ##############################################################
        #
        # Start of fields
        #
        ##############################################################
        _write_attribute(root, 'Height', str(db.Height))
        _write_attribute(root, 'Width', str(db.Width))
        _write_attribute(root, 'X', str(db.X))
        _write_attribute(root, 'Y', str(db.Y))
        ##############################################################
        #
        # End of fields
        #
        ##############################################################
        return root
    except Exception as e:
        logger.error('Failed to write RectangleD to root')


def _writeToXmlFromFontInfo(db: FontInfo):
    """
    Get the ET Element FontInfo with all of its subelements
    """

    try:
        root = ET.Element("FontInfo")
        ##############################################################
        #
        # Start of fields
        #
        ##############################################################
        _write_attribute(root, 'Bold', _bool2str(db.Bold))
        _write_attribute(root, 'Caps', _bool2str(db.Caps))
        _write_attribute(root, 'ColorRGB', str(db.ColorRGB))
        _write_attribute(root, 'doc_id', str(db.doc_id))
        _write_attribute(root, 'DStrike', _bool2str(db.DStrike))
        _write_attribute(root, 'Emboss', _bool2str(db.Emboss))
        _write_attribute(root, 'group_type', str(db.group_type))
        _write_attribute(root, 'hierarchy', str(db.hierarchy))
        _write_attribute(root, 'Highlight', str(db.Highlight))
        _write_attribute(root, 'id', str(db.id))
        _write_attribute(root, 'Imprint', _bool2str(db.Imprint))
        _write_attribute(root, 'iqv_standard_term', str(db.iqv_standard_term))
        _write_attribute(root, 'Italics', _bool2str(db.Italics))
        _write_attribute(root, 'link_id', str(db.link_id))
        _write_attribute(root, 'link_id_level2', str(db.link_id_level2))
        _write_attribute(root, 'link_id_level3', str(db.link_id_level3))
        _write_attribute(root, 'link_id_level4', str(db.link_id_level4))
        _write_attribute(root, 'link_id_level5', str(db.link_id_level5))
        _write_attribute(root, 'link_id_level6', str(db.link_id_level6))
        _write_attribute(root, 'link_id_subsection1', str(db.link_id_subsection1))
        _write_attribute(root, 'link_id_subsection2', str(db.link_id_subsection2))
        _write_attribute(root, 'link_id_subsection3', str(db.link_id_subsection3))
        _write_attribute(root, 'Outline', _bool2str(db.Outline))
        _write_attribute(root, 'parent_id', str(db.parent_id))
        _write_attribute(root, 'rFonts', str(db.rFonts))
        _write_attribute(root, 'rStyle', str(db.rStyle))
        _write_attribute(root, 'Shadow', _bool2str(db.Shadow))
        _write_attribute(root, 'Size', str(db.Size))
        _write_attribute(root, 'SmallCaps', _bool2str(db.SmallCaps))
        _write_attribute(root, 'Strike', _bool2str(db.Strike))
        _write_attribute(root, 'Underline', str(db.Underline))
        _write_attribute(root, 'Vanish', _bool2str(db.Vanish))
        _write_attribute(root, 'VertAlign', str(db.VertAlign))
        ##############################################################
        #
        # End of fields
        #
        ##############################################################
        return root
    except Exception as e:
        logger.error('Failed to write FontInfo to root')


def _writeToXmlFromConfig(db: Config):
    """
    Get the ET Element Config with all of its subelements
    """

    try:
        root = ET.Element("Config")
        ##############################################################
        #
        # Start of fields
        #
        ##############################################################
        _write_attribute(root, 'AIDocQueue_IsAdmin', str(db.AIDocQueue_IsAdmin))
        _write_attribute(root, 'AIDocQueue_IsWorker', str(db.AIDocQueue_IsWorker))
        _write_attribute(root, 'AIDocQueue_NumWorkers', str(db.AIDocQueue_NumWorkers))
        _write_attribute(root, 'API_Endpoint', str(db.API_Endpoint))
        _write_attribute(root, 'API_Key', str(db.API_Key))
        _write_attribute(root, 'bClearWorkingDirectory', str(db.bClearWorkingDirectory))
        _write_attribute(root, 'bCorrectRotation', str(db.bCorrectRotation))
        _write_attribute(root, 'bDeleteAllFilesExceptFinalizerOutputFile',
                         _bool2str(db.bDeleteAllFilesExceptFinalizerOutputFile))
        _write_attribute(root, 'bDeleteInputSourceFile', _bool2str(db.bDeleteInputSourceFile))
        _write_attribute(root, 'bDeleteWorkingTempDirOnSuccessComplete', str(db.bDeleteWorkingTempDirOnSuccessComplete))
        _write_attribute(root, 'bDictionaryBernoulliSingleCounts', str(db.bDictionaryBernoulliSingleCounts))
        _write_attribute(root, 'bDocumentManagerEXE_CloseAfterProcessDocument',
                         str(db.bDocumentManagerEXE_CloseAfterProcessDocument))
        _write_attribute(root, 'bELK_EnableLogging', str(db.bELK_EnableLogging))
        _write_attribute(root, 'bMSG_EnableMessaging', str(db.bMSG_EnableMessaging))
        _write_attribute(root, 'bMSG_EnableMessaging_CompareProcessing', str(db.bMSG_EnableMessaging_CompareProcessing))
        _write_attribute(root, 'bMSG_EnableMessaging_Digitizer2Processing',
                         str(db.bMSG_EnableMessaging_Digitizer2Processing))
        _write_attribute(root, 'bMSG_EnableMessaging_NormSOAGenerate', str(db.bMSG_EnableMessaging_NormSOAGenerate))
        _write_attribute(root, 'bMSG_EnableMessaging_OMOPGenerate', str(db.bMSG_EnableMessaging_OMOPGenerate))
        _write_attribute(root, 'bMSG_EnableMessaging_OMOPProcessing', str(db.bMSG_EnableMessaging_OMOPProcessing))
        _write_attribute(root, 'bMSG_EnableMessaging_QCFeedbackProcessing',
                         str(db.bMSG_EnableMessaging_QCFeedbackProcessing))
        _write_attribute(root, 'bNoiseGenGreyscale', _bool2str(db.bNoiseGenGreyscale))
        _write_attribute(root, 'bNoiseGenLegibility', _bool2str(db.bNoiseGenLegibility))
        _write_attribute(root, 'bNoiseGenPageBlanks', _bool2str(db.bNoiseGenPageBlanks))
        _write_attribute(root, 'bNoiseGenPageOrientation', _bool2str(db.bNoiseGenPageOrientation))
        _write_attribute(root, 'bNoiseGenPageSequence', _bool2str(db.bNoiseGenPageSequence))
        _write_attribute(root, 'bOCRRaiseErrorIfScan', str(db.bOCRRaiseErrorIfScan))
        _write_attribute(root, 'bOutput_OmopPrefixText', str(db.bOutput_OmopPrefixText))
        _write_attribute(root, 'bOutput_PrefixText', str(db.bOutput_PrefixText))
        _write_attribute(root, 'bOutput_QCFeedbackPrefixText', str(db.bOutput_QCFeedbackPrefixText))
        _write_attribute(root, 'bOutput_ToMetricsDir', str(db.bOutput_ToMetricsDir))
        _write_attribute(root, 'bProvideRemoteService', str(db.bProvideRemoteService))
        _write_attribute(root, 'bRunInternalOCRProcesses', str(db.bRunInternalOCRProcesses))
        _write_attribute(root, 'bRunPyIPOCRProcesses', str(db.bRunPyIPOCRProcesses))
        _write_attribute(root, 'bTMFGTOutputConstrained', _bool2str(db.bTMFGTOutputConstrained))
        _write_attribute(root, 'bUseDBConnection', str(db.bUseDBConnection))
        _write_attribute(root, 'bUseMTServer', str(db.bUseMTServer))
        _write_attribute(root, 'bUseSegServer', str(db.bUseSegServer))
        _write_attribute(root, 'bWatchLog_EnableWebserverRequests', str(db.bWatchLog_EnableWebserverRequests))
        _write_attribute(root, 'ClfCodePathFilename', str(db.ClfCodePathFilename))
        _write_attribute(root, 'ConfigFilename', str(db.ConfigFilename))
        _write_attribute(root, 'CorpusLevel', str(db.CorpusLevel))
        _write_attribute(root, 'CorrectRotation_RotationIncrementDegrees',
                         str(db.CorrectRotation_RotationIncrementDegrees))
        _write_attribute(root, 'CorrectRotation_RotationRangeDegrees', str(db.CorrectRotation_RotationRangeDegrees))
        _write_attribute(root, 'Country', str(db.Country))
        _write_attribute(root, 'CountryMappingFilename', str(db.CountryMappingFilename))
        _write_attribute(root, 'CustomHostName', str(db.CustomHostName))
        _write_attribute(root, 'DataSplit_TestPercent', str(db.DataSplit_TestPercent))
        _write_attribute(root, 'DataSplit_TrainingPercent', str(db.DataSplit_TrainingPercent))
        _write_attribute(root, 'DBConn_Database', str(db.DBConn_Database))
        _write_attribute(root, 'DBConn_Login', str(db.DBConn_Login))
        _write_attribute(root, 'DBConn_Password', str(db.DBConn_Password))
        _write_attribute(root, 'DBConn_Server', str(db.DBConn_Server))
        _write_attribute(root, 'DebugMode', str(db.DebugMode))
        _write_attribute(root, 'DebugType', str(db.DebugType))
        _write_attribute(root, 'DefaultRotation', str(db.DefaultRotation))
        _write_attribute(root, 'DictionarybRemoveCommonTerms', str(db.DictionarybRemoveCommonTerms))
        _write_attribute(root, 'DictionarybRemoveSparseTerms', str(db.DictionarybRemoveSparseTerms))
        _write_attribute(root, 'DictionaryIncludeAdditionalFeatures', str(db.DictionaryIncludeAdditionalFeatures))
        _write_attribute(root, 'DictionaryIncludeBigrams', str(db.DictionaryIncludeBigrams))
        _write_attribute(root, 'DictionaryIncludeLines', str(db.DictionaryIncludeLines))
        _write_attribute(root, 'DictionaryIncludeStopWords', str(db.DictionaryIncludeStopWords))
        _write_attribute(root, 'DictionaryIncludeTrigrams', str(db.DictionaryIncludeTrigrams))
        _write_attribute(root, 'DictionaryRemoveCommonTerms_MaxDocCount',
                         str(db.DictionaryRemoveCommonTerms_MaxDocCount))
        _write_attribute(root, 'DictionaryRemoveSparseTerms_MinDocCount',
                         str(db.DictionaryRemoveSparseTerms_MinDocCount))
        _write_attribute(root, 'Dig1CodePathFilename', str(db.Dig1CodePathFilename))
        _write_attribute(root, 'Dig1DocID', str(db.Dig1DocID))
        _write_attribute(root, 'DisplayLabel', str(db.DisplayLabel))
        _write_attribute(root, 'doc_id', str(db.doc_id))
        _write_attribute(root, 'DOCANALYSIS_TrainedNaiveBayesLibFilename',
                         str(db.DOCANALYSIS_TrainedNaiveBayesLibFilename))
        _write_attribute(root, 'DocID', str(db.DocID))
        _write_attribute(root, 'DocID1', str(db.DocID1))
        _write_attribute(root, 'DocID2', str(db.DocID2))
        _write_attribute(root, 'DocumentManagerEXE', str(db.DocumentManagerEXE))
        _write_attribute(root, 'DocumentManagerVersion', str(db.DocumentManagerVersion))
        _write_attribute(root, 'DropBox1Dir', str(db.DropBox1Dir))
        _write_attribute(root, 'DropBoxWebUI', str(db.DropBoxWebUI))
        _write_attribute(root, 'ELK_HostName', str(db.ELK_HostName))
        _write_attribute(root, 'ELK_Port', str(db.ELK_Port))
        _write_attribute(root, 'ETMFDocumentSource', str(db.ETMFDocumentSource))
        _write_attribute(root, 'ETMFOutputDir', str(db.ETMFOutputDir))
        _write_attribute(root, 'ExcelTemplate_SOA', str(db.ExcelTemplate_SOA))
        _write_attribute(root, 'EXE_CompareRunner', str(db.EXE_CompareRunner))
        _write_attribute(root, 'EXE_FeedbackUpdate', str(db.EXE_FeedbackUpdate))
        _write_attribute(root, 'EXE_NormSOA', str(db.EXE_NormSOA))
        _write_attribute(root, 'EXE_OMOPGenerate', str(db.EXE_OMOPGenerate))
        _write_attribute(root, 'EXE_OMOPIngester', str(db.EXE_OMOPIngester))
        _write_attribute(root, 'FileDownloadStartIndex', str(db.FileDownloadStartIndex))
        _write_attribute(root, 'flow_id', str(db.flow_id))
        _write_attribute(root, 'flow_name', str(db.flow_name))
        _write_attribute(root, 'GenerateNoise', str(db.GenerateNoise))
        _write_attribute(root, 'GhostscriptEXEFilename', str(db.GhostscriptEXEFilename))
        _write_attribute(root, 'GroundTruthMasterFilename', str(db.GroundTruthMasterFilename))
        _write_attribute(root, 'GroundTruthOutputDirectory', str(db.GroundTruthOutputDirectory))
        _write_attribute(root, 'id', str(db.id))
        _write_attribute(root, 'ImageProc_BulletImagesDir', str(db.ImageProc_BulletImagesDir))
        _write_attribute(root, 'ImageQC_GreyscaleThreshold', str(db.ImageQC_GreyscaleThreshold))
        _write_attribute(root, 'ImageQC_LegibilityThreshold', str(db.ImageQC_LegibilityThreshold))
        _write_attribute(root, 'ImagesDirectory', str(db.ImagesDirectory))
        _write_attribute(root, 'InputDataDirectory', str(db.InputDataDirectory))
        _write_attribute(root, 'InputImageFilename', str(db.InputImageFilename))
        _write_attribute(root, 'InputRawFilename', str(db.InputRawFilename))
        _write_attribute(root, 'InputSourceMasterFilename', str(db.InputSourceMasterFilename))
        _write_attribute(root, 'InputWorkingMasterFilename', str(db.InputWorkingMasterFilename))
        _write_attribute(root, 'IQVDocumentMappingFilename', str(db.IQVDocumentMappingFilename))
        _write_attribute(root, 'IQVEnvironment', str(db.IQVEnvironment))
        _write_attribute(root, 'IQVMeasurementProcedureLUTFilename', str(db.IQVMeasurementProcedureLUTFilename))
        _write_attribute(root, 'IQVXML_DBConn_bUseDBConnection', str(db.IQVXML_DBConn_bUseDBConnection))
        _write_attribute(root, 'IQVXML_DBConn_bUseDBConnection_PostDig2',
                         str(db.IQVXML_DBConn_bUseDBConnection_PostDig2))
        _write_attribute(root, 'IQVXML_DBConn_bUseDBConnection_PostOU', str(db.IQVXML_DBConn_bUseDBConnection_PostOU))
        _write_attribute(root, 'IQVXML_DBConn_Database', str(db.IQVXML_DBConn_Database))
        _write_attribute(root, 'IQVXML_DBConn_Login', str(db.IQVXML_DBConn_Login))
        _write_attribute(root, 'IQVXML_DBConn_Password', str(db.IQVXML_DBConn_Password))
        _write_attribute(root, 'IQVXML_DBConn_Port', str(db.IQVXML_DBConn_Port))
        _write_attribute(root, 'IQVXML_DBConn_Server', str(db.IQVXML_DBConn_Server))
        _write_attribute(root, 'IQVXMLInputFilename', str(db.IQVXMLInputFilename))
        _write_attribute(root, 'IQVXMLInputFilename2', str(db.IQVXMLInputFilename2))
        _write_attribute(root, 'LanguageAnalysisLib', str(db.LanguageAnalysisLib))
        _write_attribute(root, 'LocalTopLevelDataDir', str(db.LocalTopLevelDataDir))
        _write_attribute(root, 'LogDirectory', str(db.LogDirectory))
        _write_attribute(root, 'LogFilename', str(db.LogFilename))
        _write_attribute(root, 'MasterFile', str(db.MasterFile))
        _write_attribute(root, 'MasterIQVDocumentListFilename', str(db.MasterIQVDocumentListFilename))
        _write_attribute(root, 'MatrixFile', str(db.MatrixFile))
        _write_attribute(root, 'MaxCellsPerPage', str(db.MaxCellsPerPage))
        _write_attribute(root, 'MaxNumDocsToProcess', str(db.MaxNumDocsToProcess))
        _write_attribute(root, 'MaxPagesCoreProcessing_BackSection', str(db.MaxPagesCoreProcessing_BackSection))
        _write_attribute(root, 'MaxPagesCoreProcessing_FrontSection', str(db.MaxPagesCoreProcessing_FrontSection))
        _write_attribute(root, 'MaxPagesToProcess', str(db.MaxPagesToProcess))
        _write_attribute(root, 'MaxPagesToProcessIQVTM', str(db.MaxPagesToProcessIQVTM))
        _write_attribute(root, 'MaxTimeMinutesPerPage', str(db.MaxTimeMinutesPerPage))
        _write_attribute(root, 'MinPixelHeightForOCR', str(db.MinPixelHeightForOCR))
        _write_attribute(root, 'MinPixelHeightForValidImage', str(db.MinPixelHeightForValidImage))
        _write_attribute(root, 'MinPixelWidthForOCR', str(db.MinPixelWidthForOCR))
        _write_attribute(root, 'MinPixelWidthForValidImage', str(db.MinPixelWidthForValidImage))
        _write_attribute(root, 'MSG_ErrorLevelLowerBound', str(db.MSG_ErrorLevelLowerBound))
        _write_attribute(root, 'MSG_ExchangeIsDurable', str(db.MSG_ExchangeIsDurable))
        _write_attribute(root, 'MSG_HostName', str(db.MSG_HostName))
        _write_attribute(root, 'MSG_MaxCPU', str(db.MSG_MaxCPU))
        _write_attribute(root, 'MSG_MaxRAM', str(db.MSG_MaxRAM))
        _write_attribute(root, 'MSG_Password', str(db.MSG_Password))
        _write_attribute(root, 'MSG_Port', str(db.MSG_Port))
        _write_attribute(root, 'MSG_QueueIsDurable', str(db.MSG_QueueIsDurable))
        _write_attribute(root, 'MSG_User', str(db.MSG_User))
        _write_attribute(root, 'MSG_VirtualHost', str(db.MSG_VirtualHost))
        _write_attribute(root, 'MTServer_Endpoint', str(db.MTServer_Endpoint))
        _write_attribute(root, 'MTServer_LocalPathMapping', str(db.MTServer_LocalPathMapping))
        _write_attribute(root, 'MTServer_MachineName', str(db.MTServer_MachineName))
        _write_attribute(root, 'MTServer_Password', str(db.MTServer_Password))
        _write_attribute(root, 'MTServer_Port', str(db.MTServer_Port))
        _write_attribute(root, 'MTServer_SecureHTTP', str(db.MTServer_SecureHTTP))
        _write_attribute(root, 'MTServer_SharedDir', str(db.MTServer_SharedDir))
        _write_attribute(root, 'MTServer_User', str(db.MTServer_User))
        _write_attribute(root, 'NLP_CharMatrixDirectory', str(db.NLP_CharMatrixDirectory))
        _write_attribute(root, 'NLP_DictionaryDirectory', str(db.NLP_DictionaryDirectory))
        _write_attribute(root, 'NoiseGenMaxRecords', str(db.NoiseGenMaxRecords))
        _write_attribute(root, 'NoiseGenStartIndex', str(db.NoiseGenStartIndex))
        _write_attribute(root, 'NoiseType', str(db.NoiseType))
        _write_attribute(root, 'OCR_bUseSpellCheck', str(db.OCR_bUseSpellCheck))
        _write_attribute(root, 'OCR_SpellCheckDirectory', str(db.OCR_SpellCheckDirectory))
        _write_attribute(root, 'OCR_UserWordsDirectory', str(db.OCR_UserWordsDirectory))
        _write_attribute(root, 'OMOPUpdateFilename', str(db.OMOPUpdateFilename))
        _write_attribute(root, 'Output_OmopPrefixText', str(db.Output_OmopPrefixText))
        _write_attribute(root, 'Output_PrefixText', str(db.Output_PrefixText))
        _write_attribute(root, 'Output_QCFeedbackPrefixText', str(db.Output_QCFeedbackPrefixText))
        _write_attribute(root, 'Output_ToCompareDir', str(db.Output_ToCompareDir))
        _write_attribute(root, 'Output_ToMetricsDir', str(db.Output_ToMetricsDir))
        _write_attribute(root, 'OutputDirectory', str(db.OutputDirectory))
        _write_attribute(root, 'OutputFilename', str(db.OutputFilename))
        _write_attribute(root, 'OutputLevel', str(db.OutputLevel))
        _write_attribute(root, 'PageIndex', str(db.PageIndex))
        _write_attribute(root, 'PerformBatchDocClass', str(db.PerformBatchDocClass))
        _write_attribute(root, 'PerformDocumentDeconstruction', str(db.PerformDocumentDeconstruction))
        _write_attribute(root, 'PerformDocumentReconstruction', str(db.PerformDocumentReconstruction))
        _write_attribute(root, 'PerformDuplicateCheck', str(db.PerformDuplicateCheck))
        _write_attribute(root, 'PerformImageQC', str(db.PerformImageQC))
        _write_attribute(root, 'PerformMetadata', str(db.PerformMetadata))
        _write_attribute(root, 'PerformRotations', str(db.PerformRotations))
        _write_attribute(root, 'PerformXLIFFReceive', str(db.PerformXLIFFReceive))
        _write_attribute(root, 'PerformXLIFFSend', str(db.PerformXLIFFSend))
        _write_attribute(root, 'PerformXLIFFSourceCreation', str(db.PerformXLIFFSourceCreation))
        _write_attribute(root, 'Priority', str(db.Priority))
        _write_attribute(root, 'ProcessSource', str(db.ProcessSource))
        _write_attribute(root, 'PythonEnvironment', str(db.PythonEnvironment))
        _write_attribute(root, 'PythonEXEFilename', str(db.PythonEXEFilename))
        _write_attribute(root, 'QCFeedbackJSONFilename', str(db.QCFeedbackJSONFilename))
        _write_attribute(root, 'QCFeedbackRunId', str(db.QCFeedbackRunId))
        _write_attribute(root, 'Recon_bUseTemplateMatching', str(db.Recon_bUseTemplateMatching))
        _write_attribute(root, 'Recon_TemplateDirectory', str(db.Recon_TemplateDirectory))
        _write_attribute(root, 'Recon_TemplateFilename', str(db.Recon_TemplateFilename))
        _write_attribute(root, 'RedactionProfileID', str(db.RedactionProfileID))
        _write_attribute(root, 'RedactionProfileListingFilename', str(db.RedactionProfileListingFilename))
        _write_attribute(root, 'RedactionReplacementMethod', str(db.RedactionReplacementMethod))
        _write_attribute(root, 'RedactionTextMask', str(db.RedactionTextMask))
        _write_attribute(root, 'RedactionTextPrefix', str(db.RedactionTextPrefix))
        _write_attribute(root, 'RedactionTextSuffix', str(db.RedactionTextSuffix))
        _write_attribute(root, 'RemoteServer_MachineName', str(db.RemoteServer_MachineName))
        _write_attribute(root, 'RemoteServer_Port', str(db.RemoteServer_Port))
        _write_attribute(root, 'RemoteServer_ServerLocalDir', str(db.RemoteServer_ServerLocalDir))
        _write_attribute(root, 'RemoteServer_SharedDir', str(db.RemoteServer_SharedDir))
        _write_attribute(root, 'Rotation', str(db.Rotation))
        _write_attribute(root, 'RunRemote', _bool2str(db.RunRemote))
        _write_attribute(root, 'SegmentationType', str(db.SegmentationType))
        _write_attribute(root, 'SegServer_Endpoint', str(db.SegServer_Endpoint))
        _write_attribute(root, 'SegServer_LocalPathMapping', str(db.SegServer_LocalPathMapping))
        _write_attribute(root, 'SegServer_MachineName', str(db.SegServer_MachineName))
        _write_attribute(root, 'SegServer_Port', str(db.SegServer_Port))
        _write_attribute(root, 'SegServer_SecureHTTP', str(db.SegServer_SecureHTTP))
        _write_attribute(root, 'SegServer_SharedDir', str(db.SegServer_SharedDir))
        _write_attribute(root, 'ShowProgressForm', str(db.ShowProgressForm))
        _write_attribute(root, 'sofficeLocation', str(db.sofficeLocation))
        _write_attribute(root, 'SourceLanguage', str(db.SourceLanguage))
        _write_attribute(root, 'StandardTemplateIQVXML', str(db.StandardTemplateIQVXML))
        _write_attribute(root, 'TargetLanguage', str(db.TargetLanguage))
        _write_attribute(root, 'tessdataDir', str(db.tessdataDir))
        _write_attribute(root, 'TesseractEXEFilename', str(db.TesseractEXEFilename))
        _write_attribute(root, 'TMFGTOutputConstrained_AvgPages', str(db.TMFGTOutputConstrained_AvgPages))
        _write_attribute(root, 'TMFGTOutputConstrained_MinSamples', str(db.TMFGTOutputConstrained_MinSamples))
        _write_attribute(root, 'TMFRawDataSourceDirectory', str(db.TMFRawDataSourceDirectory))
        _write_attribute(root, 'TMSServer_Endpoint', str(db.TMSServer_Endpoint))
        _write_attribute(root, 'TMSServer_Info', str(db.TMSServer_Info))
        _write_attribute(root, 'TMSServer_MachineName', str(db.TMSServer_MachineName))
        _write_attribute(root, 'TMSServer_Port', str(db.TMSServer_Port))

        fieldName = 'TMSSharedDirectoryList'
        try:
            subelement = ET.SubElement(root, fieldName)
            for xelm in db.TMSSharedDirectoryList:
                subelement.append(_writeToXmlFromString(xelm))
        except Exception as e:
            logger.info('Failed to export field ' + fieldName)
        _write_attribute(root, 'UserEmail', str(db.UserEmail))
        _write_attribute(root, 'UserID', str(db.UserID))
        _write_attribute(root, 'WatchLogCheckIntervalSeconds', str(db.WatchLogCheckIntervalSeconds))
        _write_attribute(root, 'WatchLogFilename', str(db.WatchLogFilename))
        _write_attribute(root, 'WatchLogOutputDir', str(db.WatchLogOutputDir))
        _write_attribute(root, 'WatchLogOutputDirPermanentStorage', str(db.WatchLogOutputDirPermanentStorage))
        _write_attribute(root, 'WorkingDirectory', str(db.WorkingDirectory))
        _write_attribute(root, 'XLIFFInputFilename', str(db.XLIFFInputFilename))
        _write_attribute(root, 'XLIFFMarkupVersion', str(db.XLIFFMarkupVersion))
        ##############################################################
        #
        # End of fields
        #
        ##############################################################
        return root
    except Exception as e:
        logger.error('Failed to write Config to root')


def _writeToXmlFromIQVSubText(db: IQVSubText):
    """
    Get the ET Element IQVSubText with all of its subelements
    """

    try:
        root = ET.Element("IQVSubText")
        ##############################################################
        #
        # Start of fields
        #
        ##############################################################

        fieldName = 'Attributes'
        try:
            subelement = ET.SubElement(root, fieldName)
            for xelm in db.Attributes:
                subelement.append(_writeToXmlFromIQVAttribute(xelm))
        except Exception as e:
            logger.info('Failed to export field ' + fieldName)
        _write_attribute(root, 'bNoTranslate', _bool2str(db.bNoTranslate))
        _write_attribute(root, 'doc_id', str(db.doc_id))
        _write_attribute(root, 'DocumentSequenceIndex', str(db.DocumentSequenceIndex))

        fieldName = 'fontInfo'
        try:
            subelement = _writeToXmlFromFontInfo(db.fontInfo)
            subelement.tag = fieldName
            root.append(subelement)
        except Exception as e:
            logger.info('Failed to export field ' + fieldName)
        _write_attribute(root, 'group_type', str(db.group_type))
        _write_attribute(root, 'hierarchy', str(db.hierarchy))
        _write_attribute(root, 'id', str(db.id))
        _write_attribute(root, 'iqv_standard_term', str(db.iqv_standard_term))
        _write_attribute(root, 'link_id', str(db.link_id))
        _write_attribute(root, 'link_id_level2', str(db.link_id_level2))
        _write_attribute(root, 'link_id_level3', str(db.link_id_level3))
        _write_attribute(root, 'link_id_level4', str(db.link_id_level4))
        _write_attribute(root, 'link_id_level5', str(db.link_id_level5))
        _write_attribute(root, 'link_id_level6', str(db.link_id_level6))
        _write_attribute(root, 'link_id_subsection1', str(db.link_id_subsection1))
        _write_attribute(root, 'link_id_subsection2', str(db.link_id_subsection2))
        _write_attribute(root, 'link_id_subsection3', str(db.link_id_subsection3))

        fieldName = 'NLP_Attributes'
        try:
            subelement = ET.SubElement(root, fieldName)
            for xelm in db.NLP_Attributes:
                subelement.append(_writeToXmlFromNLP_Attribute(xelm))
        except Exception as e:
            logger.info('Failed to export field ' + fieldName)

        fieldName = 'NLP_Entities'
        try:
            subelement = ET.SubElement(root, fieldName)
            for xelm in db.NLP_Entities:
                subelement.append(_writeToXmlFromNLP_Entity(xelm))
        except Exception as e:
            logger.info('Failed to export field ' + fieldName)
        _write_attribute(root, 'OuterXml', str(db.OuterXml))
        _write_attribute(root, 'parent_id', str(db.parent_id))
        _write_attribute(root, 'parent2LocalName', str(db.parent2LocalName))

        fieldName = 'parentAttributes'
        try:
            subelement = ET.SubElement(root, fieldName)
            for xelm in db.parentAttributes:
                subelement.append(_writeToXmlFromIQVAttribute(xelm))
        except Exception as e:
            logger.info('Failed to export field ' + fieldName)

        fieldName = 'postTags'
        try:
            subelement = ET.SubElement(root, fieldName)
            for xelm in db.postTags:
                subelement.append(_writeToXmlFromString(xelm))
        except Exception as e:
            logger.info('Failed to export field ' + fieldName)

        fieldName = 'postTexts'
        try:
            subelement = ET.SubElement(root, fieldName)
            for xelm in db.postTexts:
                subelement.append(_writeToXmlFromint(xelm))
        except Exception as e:
            logger.info('Failed to export field ' + fieldName)

        fieldName = 'preTags'
        try:
            subelement = ET.SubElement(root, fieldName)
            for xelm in db.preTags:
                subelement.append(_writeToXmlFromString(xelm))
        except Exception as e:
            logger.info('Failed to export field ' + fieldName)

        fieldName = 'preTexts'
        try:
            subelement = ET.SubElement(root, fieldName)
            for xelm in db.preTexts:
                subelement.append(_writeToXmlFromint(xelm))
        except Exception as e:
            logger.info('Failed to export field ' + fieldName)

        fieldName = 'QCUpdates'
        try:
            subelement = ET.SubElement(root, fieldName)
            for xelm in db.QCUpdates:
                subelement.append(_writeToXmlFromIQVQCUpdateTracking(xelm))
        except Exception as e:
            logger.info('Failed to export field ' + fieldName)

        fieldName = 'rawSegments'
        try:
            subelement = ET.SubElement(root, fieldName)
            for xelm in db.rawSegments:
                subelement.append(_writeToXmlFromString(xelm))
        except Exception as e:
            logger.info('Failed to export field ' + fieldName)
        _write_attribute(root, 'reservedTypeVal', str(db.reservedTypeVal))
        _write_attribute(root, 'runElementName', str(db.runElementName))
        _write_attribute(root, 'sequence', str(db.sequence))
        _write_attribute(root, 'startCharIndex', str(db.startCharIndex))
        _write_attribute(root, 'strText', str(db.strText))
        _write_attribute(root, 'strTranslatedText', str(db.strTranslatedText))
        _write_attribute(root, 'Value', str(db.Value))
        ##############################################################
        #
        # End of fields
        #
        ##############################################################
        return root
    except Exception as e:
        logger.error('Failed to write IQVSubText to root')


def _writeToXmlFromIQVCharacter(db: IQVCharacter):
    """
    Get the ET Element IQVCharacter with all of its subelements
    """

    try:
        root = ET.Element("IQVCharacter")
        ##############################################################
        #
        # Start of fields
        #
        ##############################################################
        _write_attribute(root, 'Bottom', str(db.Bottom))
        _write_attribute(root, 'doc_id', str(db.doc_id))
        _write_attribute(root, 'group_type', str(db.group_type))
        _write_attribute(root, 'hierarchy', str(db.hierarchy))
        _write_attribute(root, 'id', str(db.id))
        _write_attribute(root, 'iqv_standard_term', str(db.iqv_standard_term))
        _write_attribute(root, 'Left', str(db.Left))
        _write_attribute(root, 'link_id', str(db.link_id))
        _write_attribute(root, 'link_id_level2', str(db.link_id_level2))
        _write_attribute(root, 'link_id_level3', str(db.link_id_level3))
        _write_attribute(root, 'link_id_level4', str(db.link_id_level4))
        _write_attribute(root, 'link_id_level5', str(db.link_id_level5))
        _write_attribute(root, 'link_id_level6', str(db.link_id_level6))
        _write_attribute(root, 'link_id_subsection1', str(db.link_id_subsection1))
        _write_attribute(root, 'link_id_subsection2', str(db.link_id_subsection2))
        _write_attribute(root, 'link_id_subsection3', str(db.link_id_subsection3))
        _write_attribute(root, 'parent_id', str(db.parent_id))
        _write_attribute(root, 'Right', str(db.Right))
        _write_attribute(root, 'Tag', str(db.Tag))
        _write_attribute(root, 'Top', str(db.Top))
        _write_attribute(root, 'Value', str(db.Value))
        ##############################################################
        #
        # End of fields
        #
        ##############################################################
        return root
    except Exception as e:
        logger.error('Failed to write IQVCharacter to root')


def _writeToXmlFromIQVWord(db: IQVWord):
    """
    Get the ET Element IQVWord with all of its subelements
    """

    try:
        root = ET.Element("IQVWord")
        ##############################################################
        #
        # Start of fields
        #
        ##############################################################
        _write_attribute(root, 'Blanks', str(db.Blanks))
        _write_attribute(root, 'BlockIndex', str(db.BlockIndex))
        _write_attribute(root, 'Bottom', str(db.Bottom))

        fieldName = 'CharList'
        try:
            subelement = ET.SubElement(root, fieldName)
            for xelm in db.CharList:
                subelement.append(_writeToXmlFromIQVCharacter(xelm))
        except Exception as e:
            logger.info('Failed to export field ' + fieldName)
        _write_attribute(root, 'Class', str(db.Class))
        _write_attribute(root, 'Confidence', str(db.Confidence))
        _write_attribute(root, 'doc_id', str(db.doc_id))

        fieldName = 'FeedbackItems'
        try:
            subelement = ET.SubElement(root, fieldName)
            for xelm in db.FeedbackItems:
                subelement.append(_writeToXmlFromIQVKeyValueSet(xelm))
        except Exception as e:
            logger.info('Failed to export field ' + fieldName)
        _write_attribute(root, 'FontIndex', str(db.FontIndex))
        _write_attribute(root, 'FontName', str(db.FontName))
        _write_attribute(root, 'Formating', str(db.Formating))
        _write_attribute(root, 'group_type', str(db.group_type))
        _write_attribute(root, 'GT_ScoreMatch', str(db.GT_ScoreMatch))
        _write_attribute(root, 'GT_TextMatch', str(db.GT_TextMatch))
        _write_attribute(root, 'hierarchy', str(db.hierarchy))
        _write_attribute(root, 'id', str(db.id))
        _write_attribute(root, 'iqv_standard_term', str(db.iqv_standard_term))
        _write_attribute(root, 'Left', str(db.Left))
        _write_attribute(root, 'LineIndex', str(db.LineIndex))
        _write_attribute(root, 'link_id', str(db.link_id))
        _write_attribute(root, 'link_id_level2', str(db.link_id_level2))
        _write_attribute(root, 'link_id_level3', str(db.link_id_level3))
        _write_attribute(root, 'link_id_level4', str(db.link_id_level4))
        _write_attribute(root, 'link_id_level5', str(db.link_id_level5))
        _write_attribute(root, 'link_id_level6', str(db.link_id_level6))
        _write_attribute(root, 'link_id_subsection1', str(db.link_id_subsection1))
        _write_attribute(root, 'link_id_subsection2', str(db.link_id_subsection2))
        _write_attribute(root, 'link_id_subsection3', str(db.link_id_subsection3))
        _write_attribute(root, 'NLP_ScoreMatch', str(db.NLP_ScoreMatch))
        _write_attribute(root, 'NLP_TextMatch', str(db.NLP_TextMatch))
        _write_attribute(root, 'NLP_TextMatchReconstructed', str(db.NLP_TextMatchReconstructed))
        _write_attribute(root, 'parent_id', str(db.parent_id))
        _write_attribute(root, 'PointSize', str(db.PointSize))
        _write_attribute(root, 'Right', str(db.Right))
        _write_attribute(root, 'Tag', str(db.Tag))
        _write_attribute(root, 'Text', str(db.Text))
        _write_attribute(root, 'textangle', str(db.textangle))
        _write_attribute(root, 'TextDerivedCase', str(db.TextDerivedCase))
        _write_attribute(root, 'TextDerivedDeconstructed', str(db.TextDerivedDeconstructed))
        _write_attribute(root, 'TextDerivedIsNumeric', str(db.TextDerivedIsNumeric))
        _write_attribute(root, 'TextDerivedPrefix', str(db.TextDerivedPrefix))
        _write_attribute(root, 'TextDerivedSuffix', str(db.TextDerivedSuffix))
        _write_attribute(root, 'TextLanguage', str(db.TextLanguage))
        _write_attribute(root, 'Top', str(db.Top))
        _write_attribute(root, 'WordIndex', str(db.WordIndex))
        ##############################################################
        #
        # End of fields
        #
        ##############################################################
        return root
    except Exception as e:
        logger.error('Failed to write IQVWord to root')


def _writeToXmlFromIQVKeyValueSet(db: IQVKeyValueSet):
    """
    Get the ET Element IQVKeyValueSet with all of its subelements
    """

    try:
        root = ET.Element("IQVKeyValueSet")
        ##############################################################
        #
        # Start of fields
        #
        ##############################################################
        _write_attribute(root, 'confidence', str(db.confidence))
        _write_attribute(root, 'doc_id', str(db.doc_id))
        _write_attribute(root, 'group_type', str(db.group_type))
        _write_attribute(root, 'hierarchy', str(db.hierarchy))
        _write_attribute(root, 'id', str(db.id))
        _write_attribute(root, 'iqv_standard_term', str(db.iqv_standard_term))
        _write_attribute(root, 'key', str(db.key))
        _write_attribute(root, 'link_id', str(db.link_id))
        _write_attribute(root, 'link_id_level2', str(db.link_id_level2))
        _write_attribute(root, 'link_id_level3', str(db.link_id_level3))
        _write_attribute(root, 'link_id_level4', str(db.link_id_level4))
        _write_attribute(root, 'link_id_level5', str(db.link_id_level5))
        _write_attribute(root, 'link_id_level6', str(db.link_id_level6))
        _write_attribute(root, 'link_id_subsection1', str(db.link_id_subsection1))
        _write_attribute(root, 'link_id_subsection2', str(db.link_id_subsection2))
        _write_attribute(root, 'link_id_subsection3', str(db.link_id_subsection3))

        fieldName = 'NLP_Attributes'
        try:
            subelement = ET.SubElement(root, fieldName)
            for xelm in db.NLP_Attributes:
                subelement.append(_writeToXmlFromNLP_Attribute(xelm))
        except Exception as e:
            logger.info('Failed to export field ' + fieldName)

        fieldName = 'NLP_Entities'
        try:
            subelement = ET.SubElement(root, fieldName)
            for xelm in db.NLP_Entities:
                subelement.append(_writeToXmlFromNLP_Entity(xelm))
        except Exception as e:
            logger.info('Failed to export field ' + fieldName)
        _write_attribute(root, 'parent_id', str(db.parent_id))

        fieldName = 'QCUpdates'
        try:
            subelement = ET.SubElement(root, fieldName)
            for xelm in db.QCUpdates:
                subelement.append(_writeToXmlFromIQVQCUpdateTracking(xelm))
        except Exception as e:
            logger.info('Failed to export field ' + fieldName)
        _write_attribute(root, 'rawScore', str(db.rawScore))
        _write_attribute(root, 'source_system', str(db.source_system))
        _write_attribute(root, 'value', str(db.value))
        ##############################################################
        #
        # End of fields
        #
        ##############################################################
        return root
    except Exception as e:
        logger.error('Failed to write IQVKeyValueSet to root')


def _writeToXmlFromQ_EVENT_LOG_ENTRY(db: Q_EVENT_LOG_ENTRY):
    """
    Get the ET Element Q_EVENT_LOG_ENTRY with all of its subelements
    """

    try:
        root = ET.Element("Q_EVENT_LOG_ENTRY")
        ##############################################################
        #
        # Start of fields
        #
        ##############################################################
        _write_attribute(root, 'bHandled', _bool2str(db.bHandled))
        _write_attribute(root, 'ClassMapping', str(db.ClassMapping))
        _write_attribute(root, 'CountReplace', str(db.CountReplace))
        _write_attribute(root, 'doc_id', str(db.doc_id))
        _write_attribute(root, 'DocumentID', str(db.DocumentID))
        _write_attribute(root, 'DocumentName', str(db.DocumentName))
        _write_attribute(root, 'DocumentPage', str(db.DocumentPage))
        _write_attribute(root, 'ErrorLevelVal', str(db.ErrorLevelVal))
        _write_attribute(root, 'EventTypeVal', str(db.EventTypeVal))
        _write_attribute(root, 'FieldMapping', str(db.FieldMapping))
        _write_attribute(root, 'id', str(db.id))

        fieldName = 'KeyValues'
        try:
            subelement = ET.SubElement(root, fieldName)
            for xelm in db.KeyValues:
                subelement.append(_writeToXmlFromIQVKeyValueSet(xelm))
        except Exception as e:
            logger.info('Failed to export field ' + fieldName)
        _write_attribute(root, 'm_DateTimeStampVal', str(db.m_DateTimeStampVal))
        _write_attribute(root, 'Message', str(db.Message))
        _write_attribute(root, 'StackTrace', str(db.StackTrace))
        _write_attribute(root, 'UserEmail', str(db.UserEmail))
        _write_attribute(root, 'UserID', str(db.UserID))
        _write_attribute(root, 'UserInputMessage', str(db.UserInputMessage))
        _write_attribute(root, 'Value', str(db.Value))
        ##############################################################
        #
        # End of fields
        #
        ##############################################################
        return root
    except Exception as e:
        logger.error('Failed to write Q_EVENT_LOG_ENTRY to root')


def _writeToXmlFromIQVLine(db: IQVLine):
    """
    Get the ET Element IQVLine with all of its subelements
    """

    try:
        root = ET.Element("IQVLine")
        ##############################################################
        #
        # Start of fields
        #
        ##############################################################
        _write_attribute(root, 'BackgroundToForeground', _bool2str(db.BackgroundToForeground))
        _write_attribute(root, 'bIncludedInBox', _bool2str(db.bIncludedInBox))
        _write_attribute(root, 'bIsHorizontal', _bool2str(db.bIsHorizontal))
        _write_attribute(root, 'doc_id', str(db.doc_id))
        _write_attribute(root, 'ForegroundToBackground', _bool2str(db.ForegroundToBackground))
        _write_attribute(root, 'group_type', str(db.group_type))
        _write_attribute(root, 'hierarchy', str(db.hierarchy))
        _write_attribute(root, 'id', str(db.id))

        fieldName = 'intersections'
        try:
            subelement = ET.SubElement(root, fieldName)
            for xelm in db.intersections:
                subelement.append(_writeToXmlFromIQVIntersection(xelm))
        except Exception as e:
            logger.info('Failed to export field ' + fieldName)
        _write_attribute(root, 'iqv_standard_term', str(db.iqv_standard_term))
        _write_attribute(root, 'link_id', str(db.link_id))
        _write_attribute(root, 'link_id_level2', str(db.link_id_level2))
        _write_attribute(root, 'link_id_level3', str(db.link_id_level3))
        _write_attribute(root, 'link_id_level4', str(db.link_id_level4))
        _write_attribute(root, 'link_id_level5', str(db.link_id_level5))
        _write_attribute(root, 'link_id_level6', str(db.link_id_level6))
        _write_attribute(root, 'link_id_subsection1', str(db.link_id_subsection1))
        _write_attribute(root, 'link_id_subsection2', str(db.link_id_subsection2))
        _write_attribute(root, 'link_id_subsection3', str(db.link_id_subsection3))
        _write_attribute(root, 'parent_id', str(db.parent_id))
        _write_attribute(root, 'ParentID', str(db.ParentID))
        _write_attribute(root, 'SequenceID', str(db.SequenceID))
        _write_attribute(root, 'Thickness', str(db.Thickness))
        _write_attribute(root, 'ThicknessUnit', str(db.ThicknessUnit))
        _write_attribute(root, 'TopParentID', str(db.TopParentID))
        _write_attribute(root, 'X1', str(db.X1))
        _write_attribute(root, 'X1Right', str(db.X1Right))
        _write_attribute(root, 'X2', str(db.X2))
        _write_attribute(root, 'X2Right', str(db.X2Right))
        _write_attribute(root, 'Y1', str(db.Y1))
        _write_attribute(root, 'Y1Lower', str(db.Y1Lower))
        _write_attribute(root, 'Y2', str(db.Y2))
        _write_attribute(root, 'Y2Lower', str(db.Y2Lower))
        ##############################################################
        #
        # End of fields
        #
        ##############################################################
        return root
    except Exception as e:
        logger.error('Failed to write IQVLine to root')


def _writeToXmlFromIQVIntersection(db: IQVIntersection):
    """
    Get the ET Element IQVIntersection with all of its subelements
    """

    try:
        root = ET.Element("IQVIntersection")
        ##############################################################
        #
        # Start of fields
        #
        ##############################################################
        _write_attribute(root, 'hline_id', str(db.hline_id))
        _write_attribute(root, 'id', str(db.id))
        _write_attribute(root, 'vline_id', str(db.vline_id))
        _write_attribute(root, 'X', str(db.X))
        _write_attribute(root, 'Y', str(db.Y))
        ##############################################################
        #
        # End of fields
        #
        ##############################################################
        return root
    except Exception as e:
        logger.error('Failed to write IQVIntersection to root')


def _writeToXmlFromIQVForm(db: IQVForm):
    """
    Get the ET Element IQVForm with all of its subelements
    """

    try:
        root = ET.Element("IQVForm")
        ##############################################################
        #
        # Start of fields
        #
        ##############################################################
        _write_attribute(root, 'Chapter', str(db.Chapter))

        fieldName = 'Children'
        try:
            subelement = ET.SubElement(root, fieldName)
            for xelm in db.Children:
                subelement.append(_writeToXmlFromIQVForm(xelm))
        except Exception as e:
            logger.info('Failed to export field ' + fieldName)
        _write_attribute(root, 'FormName', str(db.FormName))
        _write_attribute(root, 'id', str(db.id))

        fieldName = 'PrimaryKeyValue'
        try:
            subelement = ET.SubElement(root, fieldName)
            for xelm in db.PrimaryKeyValue:
                subelement.append(_writeToXmlFromIQVKeyValueSet(xelm))
        except Exception as e:
            logger.info('Failed to export field ' + fieldName)
        ##############################################################
        #
        # End of fields
        #
        ##############################################################
        return root
    except Exception as e:
        logger.error('Failed to write IQVForm to root')


def _writeToXmlFromIQVDocumentPage(db: IQVDocumentPage):
    """
    Get the ET Element IQVDocumentPage with all of its subelements
    """

    try:
        root = ET.Element("IQVDocumentPage")
        ##############################################################
        #
        # Start of fields
        #
        ##############################################################
        _write_attribute(root, 'bIsScannedPage', _bool2str(db.bIsScannedPage))
        _write_attribute(root, 'bNeedsToBeBinarized', _bool2str(db.bNeedsToBeBinarized))

        fieldName = 'Boxes'
        try:
            subelement = ET.SubElement(root, fieldName)
            for xelm in db.Boxes:
                subelement.append(_writeToXmlFromIQVPageROI(xelm))
        except Exception as e:
            logger.info('Failed to export field ' + fieldName)
        _write_attribute(root, 'FooterText', str(db.FooterText))
        _write_attribute(root, 'HeaderText', str(db.HeaderText))

        fieldName = 'Hyperlinks'
        try:
            subelement = ET.SubElement(root, fieldName)
            for xelm in db.Hyperlinks:
                subelement.append(_writeToXmlFromString(xelm))
        except Exception as e:
            logger.info('Failed to export field ' + fieldName)
        _write_attribute(root, 'id', str(db.id))

        fieldName = 'ImageLocationsOnPage'
        try:
            subelement = ET.SubElement(root, fieldName)
            for xelm in db.ImageLocationsOnPage:
                subelement.append(_writeToXmlFromRectangleD(xelm))
        except Exception as e:
            logger.info('Failed to export field ' + fieldName)

        fieldName = 'ImageNames'
        try:
            subelement = ET.SubElement(root, fieldName)
            for xelm in db.ImageNames:
                subelement.append(_writeToXmlFromString(xelm))
        except Exception as e:
            logger.info('Failed to export field ' + fieldName)
        _write_attribute(root, 'ImageQCError', str(db.ImageQCError))
        _write_attribute(root, 'ImageQCGT', str(db.ImageQCGT))
        _write_attribute(root, 'ImageQCScore', str(db.ImageQCScore))
        _write_attribute(root, 'ImageQCScore_Blank', str(db.ImageQCScore_Blank))
        _write_attribute(root, 'ImageQCScore_Greyscale', str(db.ImageQCScore_Greyscale))
        _write_attribute(root, 'ImageQCScore_Legibility', str(db.ImageQCScore_Legibility))
        _write_attribute(root, 'ImageQCScore_Orientation', str(db.ImageQCScore_Orientation))
        _write_attribute(root, 'ImageQCScore_Pages', str(db.ImageQCScore_Pages))
        _write_attribute(root, 'in_image_filename', str(db.in_image_filename))
        _write_attribute(root, 'in_raw_filename', str(db.in_raw_filename))
        _write_attribute(root, 'MeanOffsetAngleInRadians', str(db.MeanOffsetAngleInRadians))
        _write_attribute(root, 'OffsetXInches', str(db.OffsetXInches))
        _write_attribute(root, 'OffsetYInches', str(db.OffsetYInches))
        _write_attribute(root, 'OrientationIsPortrait', _bool2str(db.OrientationIsPortrait))
        _write_attribute(root, 'out_filename', str(db.out_filename))
        _write_attribute(root, 'PageSequenceIndex', str(db.PageSequenceIndex))

        fieldName = 'PageSizeRectangle'
        try:
            subelement = _writeToXmlFromRectangleD(db.PageSizeRectangle)
            subelement.tag = fieldName
            root.append(subelement)
        except Exception as e:
            logger.info('Failed to export field ' + fieldName)

        fieldName = 'PageSizeWithRotationRectangle'
        try:
            subelement = _writeToXmlFromRectangleD(db.PageSizeWithRotationRectangle)
            subelement.tag = fieldName
            root.append(subelement)
        except Exception as e:
            logger.info('Failed to export field ' + fieldName)
        _write_attribute(root, 'PDFDocumentPageText', str(db.PDFDocumentPageText))
        _write_attribute(root, 'PDFDocumentPageTextNumChars', str(db.PDFDocumentPageTextNumChars))
        _write_attribute(root, 'PDFDocumentPageTextNumWords', str(db.PDFDocumentPageTextNumWords))
        _write_attribute(root, 'ProcessFinishTime', str(db.ProcessFinishTime))
        _write_attribute(root, 'ProcessStartTime', str(db.ProcessStartTime))
        _write_attribute(root, 'Rotation', str(db.Rotation))
        _write_attribute(root, 'Rotation_MajorAxis', str(db.Rotation_MajorAxis))
        _write_attribute(root, 'ScannedImageID', str(db.ScannedImageID))
        _write_attribute(root, 'textFromReader', str(db.textFromReader))
        _write_attribute(root, 'TitleText', str(db.TitleText))
        ##############################################################
        #
        # End of fields
        #
        ##############################################################
        return root
    except Exception as e:
        logger.error('Failed to write IQVDocumentPage to root')


def _writeToXmlFromIQVAttribute(db: IQVAttribute):
    """
    Get the ET Element IQVAttribute with all of its subelements
    """

    try:
        root = ET.Element("IQVAttribute")
        ##############################################################
        #
        # Start of fields
        #
        ##############################################################
        _write_attribute(root, 'doc_id', str(db.doc_id))
        _write_attribute(root, 'group_type', str(db.group_type))
        _write_attribute(root, 'hierarchy', str(db.hierarchy))
        _write_attribute(root, 'id', str(db.id))
        _write_attribute(root, 'iqv_standard_term', str(db.iqv_standard_term))
        _write_attribute(root, 'link_id', str(db.link_id))
        _write_attribute(root, 'link_id_level2', str(db.link_id_level2))
        _write_attribute(root, 'link_id_level3', str(db.link_id_level3))
        _write_attribute(root, 'link_id_level4', str(db.link_id_level4))
        _write_attribute(root, 'link_id_level5', str(db.link_id_level5))
        _write_attribute(root, 'link_id_level6', str(db.link_id_level6))
        _write_attribute(root, 'link_id_subsection1', str(db.link_id_subsection1))
        _write_attribute(root, 'link_id_subsection2', str(db.link_id_subsection2))
        _write_attribute(root, 'link_id_subsection3', str(db.link_id_subsection3))
        _write_attribute(root, 'LocalName', str(db.LocalName))
        _write_attribute(root, 'Name', str(db.Name))
        _write_attribute(root, 'parent_id', str(db.parent_id))
        _write_attribute(root, 'Value', str(db.Value))
        ##############################################################
        #
        # End of fields
        #
        ##############################################################
        return root
    except Exception as e:
        logger.error('Failed to write IQVAttribute to root')


def _writeToXmlFromRotationCheck(db: RotationCheck):
    """
    Get the ET Element RotationCheck with all of its subelements
    """

    try:
        root = ET.Element("RotationCheck")
        ##############################################################
        #
        # Start of fields
        #
        ##############################################################
        _write_attribute(root, 'degree', str(db.degree))
        _write_attribute(root, 'filenameVar', str(db.filenameVar))
        _write_attribute(root, 'maxVariance', str(db.maxVariance))
        ##############################################################
        #
        # End of fields
        #
        ##############################################################
        return root
    except Exception as e:
        logger.error('Failed to write RotationCheck to root')


def _writeToXmlFromValueI(db: ValueI):
    """
    Get the ET Element ValueI with all of its subelements
    """

    try:
        root = ET.Element("ValueI")
        ##############################################################
        #
        # Start of fields
        #
        ##############################################################
        _write_attribute(root, 'key', str(db.key))
        _write_attribute(root, 'value', str(db.value))
        ##############################################################
        #
        # End of fields
        #
        ##############################################################
        return root
    except Exception as e:
        logger.error('Failed to write ValueI to root')


def _writeToXmlFromLineBoundaries(db: LineBoundaries):
    """
    Get the ET Element LineBoundaries with all of its subelements
    """

    try:
        root = ET.Element("LineBoundaries")
        ##############################################################
        #
        # Start of fields
        #
        ##############################################################
        _write_attribute(root, 'bIsVertical', _bool2str(db.bIsVertical))

        fieldName = 'Lines'
        try:
            subelement = ET.SubElement(root, fieldName)
            for xelm in db.Lines:
                subelement.append(_writeToXmlFromIQVLine(xelm))
        except Exception as e:
            logger.info('Failed to export field ' + fieldName)
        _write_attribute(root, 'RecursiveLevel', str(db.RecursiveLevel))
        ##############################################################
        #
        # End of fields
        #
        ##############################################################
        return root
    except Exception as e:
        logger.error('Failed to write LineBoundaries to root')


def _writeToXmlFromTextMatch(db: TextMatch):
    """
    Get the ET Element TextMatch with all of its subelements
    """

    try:
        root = ET.Element("TextMatch")
        ##############################################################
        #
        # Start of fields
        #
        ##############################################################
        _write_attribute(root, 'index', str(db.index))
        _write_attribute(root, 'Score', str(db.Score))
        _write_attribute(root, 'text', str(db.text))
        ##############################################################
        #
        # End of fields
        #
        ##############################################################
        return root
    except Exception as e:
        logger.error('Failed to write TextMatch to root')


def _writeToXmlFromIQVDocumentFeedbackItem(db: IQVDocumentFeedbackItem):
    """
    Get the ET Element IQVDocumentFeedbackItem with all of its subelements
    """

    try:
        root = ET.Element("IQVDocumentFeedbackItem")
        ##############################################################
        #
        # Start of fields
        #
        ##############################################################
        _write_attribute(root, 'CheckboxValue', str(db.CheckboxValue))
        _write_attribute(root, 'date_time_stamp', str(db.date_time_stamp))
        _write_attribute(root, 'document_composite_confidence', str(db.document_composite_confidence))
        _write_attribute(root, 'document_date', str(db.document_date))
        _write_attribute(root, 'environment', str(db.environment))
        _write_attribute(root, 'feedback_source', str(db.feedback_source))
        _write_attribute(root, 'feedback_source_version', str(db.feedback_source_version))
        _write_attribute(root, 'id', str(db.id))

        fieldName = 'Properties'
        try:
            subelement = ET.SubElement(root, fieldName)
            for xelm in db.Properties:
                subelement.append(_writeToXmlFromIQVKeyValueSet(xelm))
        except Exception as e:
            logger.info('Failed to export field ' + fieldName)
        _write_attribute(root, 'source_system', str(db.source_system))
        _write_attribute(root, 'user_id', str(db.user_id))
        ##############################################################
        #
        # End of fields
        #
        ##############################################################
        return root
    except Exception as e:
        logger.error('Failed to write IQVDocumentFeedbackItem to root')


def _writeToXmlFromIQVDocumentFeedbackResults(db: IQVDocumentFeedbackResults):
    """
    Get the ET Element IQVDocumentFeedbackResults with all of its subelements
    """

    try:
        root = ET.Element("IQVDocumentFeedbackResults")
        ##############################################################
        #
        # Start of fields
        #
        ##############################################################
        _write_attribute(root, 'alcoac_check_composite_score', str(db.alcoac_check_composite_score))
        _write_attribute(root, 'alcoac_check_composite_score_confidence',
                         str(db.alcoac_check_composite_score_confidence))

        fieldName = 'alcoac_check_error'
        try:
            subelement = ET.SubElement(root, fieldName)
            for xelm in db.alcoac_check_error:
                subelement.append(_writeToXmlFromIQVAttributeCandidate(xelm))
        except Exception as e:
            logger.info('Failed to export field ' + fieldName)
        _write_attribute(root, 'amendment_number', str(db.amendment_number))

        fieldName = 'attribute_auxiliary_list'
        try:
            subelement = ET.SubElement(root, fieldName)
            for xelm in db.attribute_auxiliary_list:
                subelement.append(_writeToXmlFromIQVKeyValueSet(xelm))
        except Exception as e:
            logger.info('Failed to export field ' + fieldName)
        _write_attribute(root, 'blinded', _bool2str(db.blinded))
        _write_attribute(root, 'country', str(db.country))
        _write_attribute(root, 'customer', str(db.customer))
        _write_attribute(root, 'date_time_stamp', str(db.date_time_stamp))
        _write_attribute(root, 'DateTimeCreated', str(db.DateTimeCreated))
        _write_attribute(root, 'doc_id', str(db.doc_id))
        _write_attribute(root, 'document_class', str(db.document_class))

        fieldName = 'document_classification'
        try:
            subelement = ET.SubElement(root, fieldName)
            for xelm in db.document_classification:
                subelement.append(_writeToXmlFromString(xelm))
        except Exception as e:
            logger.info('Failed to export field ' + fieldName)

        fieldName = 'document_classification_confidence'
        try:
            subelement = ET.SubElement(root, fieldName)
            for xelm in db.document_classification_confidence:
                subelement.append(_writeToXmlFromDouble(xelm))
        except Exception as e:
            logger.info('Failed to export field ' + fieldName)
        _write_attribute(root, 'document_composite_confidence', str(db.document_composite_confidence))
        _write_attribute(root, 'document_date', str(db.document_date))
        _write_attribute(root, 'document_date_confidence', str(db.document_date_confidence))

        fieldName = 'document_date_list'
        try:
            subelement = ET.SubElement(root, fieldName)
            for xelm in db.document_date_list:
                subelement.append(_writeToXmlFromIQVKeyValueSet(xelm))
        except Exception as e:
            logger.info('Failed to export field ' + fieldName)
        _write_attribute(root, 'document_date_type', str(db.document_date_type))
        _write_attribute(root, 'document_id', str(db.document_id))

        fieldName = 'document_native_classification'
        try:
            subelement = ET.SubElement(root, fieldName)
            for xelm in db.document_native_classification:
                subelement.append(_writeToXmlFromString(xelm))
        except Exception as e:
            logger.info('Failed to export field ' + fieldName)

        fieldName = 'document_native_classification_confidence'
        try:
            subelement = ET.SubElement(root, fieldName)
            for xelm in db.document_native_classification_confidence:
                subelement.append(_writeToXmlFromDouble(xelm))
        except Exception as e:
            logger.info('Failed to export field ' + fieldName)
        _write_attribute(root, 'document_rejected', str(db.document_rejected))
        _write_attribute(root, 'document_status', str(db.document_status))

        fieldName = 'document_subclassification'
        try:
            subelement = ET.SubElement(root, fieldName)
            for xelm in db.document_subclassification:
                subelement.append(_writeToXmlFromString(xelm))
        except Exception as e:
            logger.info('Failed to export field ' + fieldName)

        fieldName = 'document_subclassification_confidence'
        try:
            subelement = ET.SubElement(root, fieldName)
            for xelm in db.document_subclassification_confidence:
                subelement.append(_writeToXmlFromDouble(xelm))
        except Exception as e:
            logger.info('Failed to export field ' + fieldName)
        _write_attribute(root, 'draft_number', str(db.draft_number))
        _write_attribute(root, 'environment', str(db.environment))
        _write_attribute(root, 'expiry_date', str(db.expiry_date))
        _write_attribute(root, 'expiry_date_confidence', str(db.expiry_date_confidence))
        _write_attribute(root, 'feedback_source', str(db.feedback_source))
        _write_attribute(root, 'feedback_source_version', str(db.feedback_source_version))
        _write_attribute(root, 'group_type', str(db.group_type))
        _write_attribute(root, 'hierarchy', str(db.hierarchy))
        _write_attribute(root, 'id', str(db.id))
        _write_attribute(root, 'indication', str(db.indication))
        _write_attribute(root, 'iqv_standard_term', str(db.iqv_standard_term))
        _write_attribute(root, 'iqvdata', str(db.iqvdata))
        _write_attribute(root, 'language', str(db.language))
        _write_attribute(root, 'language_confidence', str(db.language_confidence))
        _write_attribute(root, 'link_id', str(db.link_id))
        _write_attribute(root, 'link_id_level2', str(db.link_id_level2))
        _write_attribute(root, 'link_id_level3', str(db.link_id_level3))
        _write_attribute(root, 'link_id_level4', str(db.link_id_level4))
        _write_attribute(root, 'link_id_level5', str(db.link_id_level5))
        _write_attribute(root, 'link_id_level6', str(db.link_id_level6))
        _write_attribute(root, 'link_id_subsection1', str(db.link_id_subsection1))
        _write_attribute(root, 'link_id_subsection2', str(db.link_id_subsection2))
        _write_attribute(root, 'link_id_subsection3', str(db.link_id_subsection3))
        _write_attribute(root, 'molecule_device', str(db.molecule_device))
        _write_attribute(root, 'name', str(db.name))
        _write_attribute(root, 'name_confidence', str(db.name_confidence))
        _write_attribute(root, 'parent_id', str(db.parent_id))
        _write_attribute(root, 'post_data', str(db.post_data))
        _write_attribute(root, 'priority', str(db.priority))
        _write_attribute(root, 'project_id', str(db.project_id))
        _write_attribute(root, 'protocol', str(db.protocol))
        _write_attribute(root, 'received_date', str(db.received_date))
        _write_attribute(root, 'ref_id', str(db.ref_id))
        _write_attribute(root, 'ref_id_type', str(db.ref_id_type))
        _write_attribute(root, 'site', str(db.site))

        fieldName = 'site_personnel_list'
        try:
            subelement = ET.SubElement(root, fieldName)
            for xelm in db.site_personnel_list:
                subelement.append(_writeToXmlFromIQVAttribute(xelm))
        except Exception as e:
            logger.info('Failed to export field ' + fieldName)
        _write_attribute(root, 'source_filename', str(db.source_filename))
        _write_attribute(root, 'source_system', str(db.source_system))
        _write_attribute(root, 'sponsor', str(db.sponsor))
        _write_attribute(root, 'study_status', str(db.study_status))
        _write_attribute(root, 'subject', str(db.subject))
        _write_attribute(root, 'subject_confidence', str(db.subject_confidence))
        _write_attribute(root, 'tmf_environment', str(db.tmf_environment))
        _write_attribute(root, 'tmf_ibr', str(db.tmf_ibr))
        _write_attribute(root, 'user_id', str(db.user_id))
        _write_attribute(root, 'version_number', str(db.version_number))
        ##############################################################
        #
        # End of fields
        #
        ##############################################################
        return root
    except Exception as e:
        logger.error('Failed to write IQVDocumentFeedbackResults to root')


def _writeToXmlFromIQVDocumentGroundTruth(db: IQVDocumentGroundTruth):
    """
    Get the ET Element IQVDocumentGroundTruth with all of its subelements
    """

    try:
        root = ET.Element("IQVDocumentGroundTruth")
        ##############################################################
        #
        # Start of fields
        #
        ##############################################################

        fieldName = 'AdditionalInstructionsList'
        try:
            subelement = ET.SubElement(root, fieldName)
            for xelm in db.AdditionalInstructionsList:
                subelement.append(_writeToXmlFromIQVKeyValueSet(xelm))
        except Exception as e:
            logger.info('Failed to export field ' + fieldName)
        _write_attribute(root, 'AIDocLocation', str(db.AIDocLocation))
        _write_attribute(root, 'AIDocLocationOriginal', str(db.AIDocLocationOriginal))
        _write_attribute(root, 'Artifact', str(db.Artifact))
        _write_attribute(root, 'Batch_Home_Location', str(db.Batch_Home_Location))
        _write_attribute(root, 'bReservedForSVT', str(db.bReservedForSVT))
        _write_attribute(root, 'Certification_Date', str(db.Certification_Date))
        _write_attribute(root, 'Certification_Meaning', str(db.Certification_Meaning))
        _write_attribute(root, 'Certification_User', str(db.Certification_User))
        _write_attribute(root, 'Country', str(db.Country))
        _write_attribute(root, 'Country_Code', str(db.Country_Code))
        _write_attribute(root, 'dataset', str(db.dataset))
        _write_attribute(root, 'dataset_source', str(db.dataset_source))
        _write_attribute(root, 'Date_Created', str(db.Date_Created))
        _write_attribute(root, 'Date_Created14', str(db.Date_Created14))
        _write_attribute(root, 'Date_Identifier', str(db.Date_Identifier))
        _write_attribute(root, 'DateID_Index', str(db.DateID_Index))
        _write_attribute(root, 'Description', str(db.Description))
        _write_attribute(root, 'DIA_Key', str(db.DIA_Key))
        _write_attribute(root, 'doc_id', str(db.doc_id))
        _write_attribute(root, 'doc_type_wingspan', str(db.doc_type_wingspan))
        _write_attribute(root, 'Document_Abbreviation', str(db.Document_Abbreviation))
        _write_attribute(root, 'Document_Abbreviation_Index', str(db.Document_Abbreviation_Index))
        _write_attribute(root, 'Document_Class', str(db.Document_Class))
        _write_attribute(root, 'Document_Date', str(db.Document_Date))
        _write_attribute(root, 'Document_Date_FromNamingConvention', str(db.Document_Date_FromNamingConvention))
        _write_attribute(root, 'Document_Date_Index', str(db.Document_Date_Index))
        _write_attribute(root, 'Document_Date14', str(db.Document_Date14))
        _write_attribute(root, 'Document_Identifier', str(db.Document_Identifier))
        _write_attribute(root, 'Document_Identifier_Index', str(db.Document_Identifier_Index))
        _write_attribute(root, 'document_instructions', str(db.document_instructions))
        _write_attribute(root, 'Document_Language', str(db.Document_Language))
        _write_attribute(root, 'Document_Naming_Convention', str(db.Document_Naming_Convention))
        _write_attribute(root, 'Document_Sequence_ID', str(db.Document_Sequence_ID))
        _write_attribute(root, 'Document_Status', str(db.Document_Status))
        _write_attribute(root, 'Document_Type_Unique_Identifier', str(db.Document_Type_Unique_Identifier))

        fieldName = 'DocumentImages'
        try:
            subelement = ET.SubElement(root, fieldName)
            for xelm in db.DocumentImages:
                subelement.append(_writeToXmlFromIQVPageROI(xelm))
        except Exception as e:
            logger.info('Failed to export field ' + fieldName)
        _write_attribute(root, 'DocumentNumChars', str(db.DocumentNumChars))
        _write_attribute(root, 'DocumentNumImages', str(db.DocumentNumImages))
        _write_attribute(root, 'DocumentNumPages', str(db.DocumentNumPages))
        _write_attribute(root, 'DocumentNumWords', str(db.DocumentNumWords))
        _write_attribute(root, 'DocumentPageLevel', str(db.DocumentPageLevel))
        _write_attribute(root, 'DocumentPathFilename', str(db.DocumentPathFilename))
        _write_attribute(root, 'DocumentType', str(db.DocumentType))
        _write_attribute(root, 'Drug_Type', str(db.Drug_Type))
        _write_attribute(root, 'Drug_Type_Index', str(db.Drug_Type_Index))
        _write_attribute(root, 'EEL_Batch_ID', str(db.EEL_Batch_ID))
        _write_attribute(root, 'EEL_Batch_Type', str(db.EEL_Batch_Type))
        _write_attribute(root, 'Email_FROM', str(db.Email_FROM))
        _write_attribute(root, 'Email_Receive_Date', str(db.Email_Receive_Date))
        _write_attribute(root, 'Email_Send_Date', str(db.Email_Send_Date))
        _write_attribute(root, 'Email_Subject', str(db.Email_Subject))
        _write_attribute(root, 'Email_TO', str(db.Email_TO))
        _write_attribute(root, 'Event_Identifier', str(db.Event_Identifier))
        _write_attribute(root, 'Export_File_Name', str(db.Export_File_Name))
        _write_attribute(root, 'Export_Path', str(db.Export_Path))
        _write_attribute(root, 'File_MimeType', str(db.File_MimeType))
        _write_attribute(root, 'File_Name_Modified', str(db.File_Name_Modified))
        _write_attribute(root, 'File_Plan_Category_Number', str(db.File_Plan_Category_Number))
        _write_attribute(root, 'First_Name', str(db.First_Name))
        _write_attribute(root, 'GTArtifact_Code', str(db.GTArtifact_Code))
        _write_attribute(root, 'GTBatch', str(db.GTBatch))
        _write_attribute(root, 'GTDuplicate', str(db.GTDuplicate))
        _write_attribute(root, 'GTGreyscale', str(db.GTGreyscale))
        _write_attribute(root, 'GTIndex', str(db.GTIndex))
        _write_attribute(root, 'GTLegibility', str(db.GTLegibility))
        _write_attribute(root, 'GTPages', str(db.GTPages))
        _write_attribute(root, 'GTSection_Code', str(db.GTSection_Code))
        _write_attribute(root, 'GTZone_Code', str(db.GTZone_Code))
        _write_attribute(root, 'GTZone_Section_Artifact_Code', str(db.GTZone_Section_Artifact_Code))
        _write_attribute(root, 'GTZone_Section_Code', str(db.GTZone_Section_Code))
        _write_attribute(root, 'id', str(db.id))
        _write_attribute(root, 'Inventory_Class', str(db.Inventory_Class))
        _write_attribute(root, 'Inventory_CountryName', str(db.Inventory_CountryName))
        _write_attribute(root, 'Investigator_Name', str(db.Investigator_Name))
        _write_attribute(root, 'IQV_XML_Filename', str(db.IQV_XML_Filename))
        _write_attribute(root, 'Issue', str(db.Issue))
        _write_attribute(root, 'IssueDescription', str(db.IssueDescription))
        _write_attribute(root, 'Language_Abbreviation', str(db.Language_Abbreviation))
        _write_attribute(root, 'Language_Abbreviation_Index', str(db.Language_Abbreviation_Index))
        _write_attribute(root, 'Language_ID_Index', str(db.Language_ID_Index))
        _write_attribute(root, 'Language_Identifier', str(db.Language_Identifier))
        _write_attribute(root, 'Last_Name', str(db.Last_Name))
        _write_attribute(root, 'LastNameFirstName_FromNamingConvention', str(db.LastNameFirstName_FromNamingConvention))
        _write_attribute(root, 'LastNameFirstName_Index', str(db.LastNameFirstName_Index))
        _write_attribute(root, 'LocalSubdirectory', str(db.LocalSubdirectory))
        _write_attribute(root, 'Mandatory_Retention', str(db.Mandatory_Retention))
        _write_attribute(root, 'Modify_Date', str(db.Modify_Date))
        _write_attribute(root, 'Name', str(db.Name))
        _write_attribute(root, 'NoisyPageIndex', str(db.NoisyPageIndex))
        _write_attribute(root, 'Object_ID', str(db.Object_ID))
        _write_attribute(root, 'Organization_ID', str(db.Organization_ID))
        _write_attribute(root, 'OrganizationID_Index', str(db.OrganizationID_Index))
        _write_attribute(root, 'Original_Inventory_Filename', str(db.Original_Inventory_Filename))
        _write_attribute(root, 'Original_Path', str(db.Original_Path))
        _write_attribute(root, 'OriginalSourceDataDirectory', str(db.OriginalSourceDataDirectory))
        _write_attribute(root, 'OriginalSourceDataZipFilename', str(db.OriginalSourceDataZipFilename))
        _write_attribute(root, 'PagePathFilenamePDF', str(db.PagePathFilenamePDF))
        _write_attribute(root, 'PageSequenceNumber', str(db.PageSequenceNumber))
        _write_attribute(root, 'Paper_Received_Date', str(db.Paper_Received_Date))
        _write_attribute(root, 'Phase', str(db.Phase))
        _write_attribute(root, 'Project_Code', str(db.Project_Code))
        _write_attribute(root, 'Protocol_Number', str(db.Protocol_Number))
        _write_attribute(root, 'ref_model_subtype_code', str(db.ref_model_subtype_code))
        _write_attribute(root, 'Report_Type', str(db.Report_Type))
        _write_attribute(root, 'Report_Version', str(db.Report_Version))
        _write_attribute(root, 'Section', str(db.Section))
        _write_attribute(root, 'Sequence_Number', str(db.Sequence_Number))
        _write_attribute(root, 'Sequence_Number_Index', str(db.Sequence_Number_Index))
        _write_attribute(root, 'Site_Name', str(db.Site_Name))
        _write_attribute(root, 'Source_System', str(db.Source_System))
        _write_attribute(root, 'Source_System_Version', str(db.Source_System_Version))
        _write_attribute(root, 'Study_Site_ID', str(db.Study_Site_ID))
        _write_attribute(root, 'Therapeutic_Area', str(db.Therapeutic_Area))
        _write_attribute(root, 'TMF', str(db.TMF))
        _write_attribute(root, 'Type', str(db.Type))
        _write_attribute(root, 'Type_Value', str(db.Type_Value))
        _write_attribute(root, 'Visit_Document_ID', str(db.Visit_Document_ID))
        _write_attribute(root, 'Visit_Type', str(db.Visit_Type))
        _write_attribute(root, 'VisitDocID_Index', str(db.VisitDocID_Index))
        _write_attribute(root, 'VisitType_Index', str(db.VisitType_Index))

        fieldName = 'XProperties'
        try:
            subelement = ET.SubElement(root, fieldName)
            for xelm in db.XProperties:
                subelement.append(_writeToXmlFromIQVKeyValueSet(xelm))
        except Exception as e:
            logger.info('Failed to export field ' + fieldName)
        _write_attribute(root, 'Zone', str(db.Zone))
        ##############################################################
        #
        # End of fields
        #
        ##############################################################
        return root
    except Exception as e:
        logger.error('Failed to write IQVDocumentGroundTruth to root')


def _writeToXmlFromIQVPageROI(db: IQVPageROI):
    """
    Get the ET Element IQVPageROI with all of its subelements
    """

    try:
        root = ET.Element("IQVPageROI")
        ##############################################################
        #
        # Start of fields
        #
        ##############################################################

        fieldName = 'Attachments'
        try:
            subelement = ET.SubElement(root, fieldName)
            for xelm in db.Attachments:
                subelement.append(_writeToXmlFromIQVPageROI(xelm))
        except Exception as e:
            logger.info('Failed to export field ' + fieldName)
        _write_attribute(root, 'bIsCheckbox', _bool2str(db.bIsCheckbox))
        _write_attribute(root, 'bIsChecked', _bool2str(db.bIsChecked))
        _write_attribute(root, 'bIsImage', _bool2str(db.bIsImage))
        _write_attribute(root, 'bIsSharedString', _bool2str(db.bIsSharedString))
        _write_attribute(root, 'bNoTranslate', _bool2str(db.bNoTranslate))
        _write_attribute(root, 'bOutputImageCreated', _bool2str(db.bOutputImageCreated))
        _write_attribute(root, 'bScannedOCR', _bool2str(db.bScannedOCR))
        _write_attribute(root, 'BulletIndentationLevel', str(db.BulletIndentationLevel))
        _write_attribute(root, 'BulletTypeVal', str(db.BulletTypeVal))
        _write_attribute(root, 'CheckboxFill', str(db.CheckboxFill))

        fieldName = 'ChildBoxes'
        try:
            subelement = ET.SubElement(root, fieldName)
            for xelm in db.ChildBoxes:
                subelement.append(_writeToXmlFromIQVPageROI(xelm))
        except Exception as e:
            logger.info('Failed to export field ' + fieldName)

        fieldName = 'ChildBoxesDeconstructedOCR'
        try:
            subelement = ET.SubElement(root, fieldName)
            for xelm in db.ChildBoxesDeconstructedOCR:
                subelement.append(_writeToXmlFromIQVPageROI(xelm))
        except Exception as e:
            logger.info('Failed to export field ' + fieldName)

        fieldName = 'childListIndexes'
        try:
            subelement = ET.SubElement(root, fieldName)
            for xelm in db.childListIndexes:
                subelement.append(_writeToXmlFromint(xelm))
        except Exception as e:
            logger.info('Failed to export field ' + fieldName)
        _write_attribute(root, 'contentTypeVal', str(db.contentTypeVal))

        fieldName = 'copyListIndexes'
        try:
            subelement = ET.SubElement(root, fieldName)
            for xelm in db.copyListIndexes:
                subelement.append(_writeToXmlFromint(xelm))
        except Exception as e:
            logger.info('Failed to export field ' + fieldName)
        _write_attribute(root, 'doc_id', str(db.doc_id))
        _write_attribute(root, 'DocumentRelId', str(db.DocumentRelId))
        _write_attribute(root, 'DocumentSequenceIndex', str(db.DocumentSequenceIndex))

        fieldName = 'ExternalLinks'
        try:
            subelement = ET.SubElement(root, fieldName)
            for xelm in db.ExternalLinks:
                subelement.append(_writeToXmlFromIQVExternalLink(xelm))
        except Exception as e:
            logger.info('Failed to export field ' + fieldName)

        fieldName = 'FeedbackItems'
        try:
            subelement = ET.SubElement(root, fieldName)
            for xelm in db.FeedbackItems:
                subelement.append(_writeToXmlFromIQVKeyValueSet(xelm))
        except Exception as e:
            logger.info('Failed to export field ' + fieldName)

        fieldName = 'fontInfo'
        try:
            subelement = _writeToXmlFromFontInfo(db.fontInfo)
            subelement.tag = fieldName
            root.append(subelement)
        except Exception as e:
            logger.info('Failed to export field ' + fieldName)
        _write_attribute(root, 'FooterSequence', str(db.FooterSequence))
        _write_attribute(root, 'group_type', str(db.group_type))
        _write_attribute(root, 'GT_ImageFilename', str(db.GT_ImageFilename))
        _write_attribute(root, 'GT_ScoreMatch', str(db.GT_ScoreMatch))
        _write_attribute(root, 'GT_TextMatch', str(db.GT_TextMatch))
        _write_attribute(root, 'hAlignmentVal', str(db.hAlignmentVal))
        _write_attribute(root, 'HeaderSequence', str(db.HeaderSequence))
        _write_attribute(root, 'hierarchy', str(db.hierarchy))
        _write_attribute(root, 'HorizontalResolution', str(db.HorizontalResolution))
        _write_attribute(root, 'htmlTagType', str(db.htmlTagType))
        _write_attribute(root, 'Hue', str(db.Hue))
        _write_attribute(root, 'id', str(db.id))
        _write_attribute(root, 'ImageFormatVal', str(db.ImageFormatVal))
        _write_attribute(root, 'ImageIndex', str(db.ImageIndex))
        _write_attribute(root, 'imagePaddingPixels', str(db.imagePaddingPixels))
        _write_attribute(root, 'imageScaling', str(db.imageScaling))
        _write_attribute(root, 'iqv_standard_term', str(db.iqv_standard_term))

        fieldName = 'IQVAttributeCandidates'
        try:
            subelement = ET.SubElement(root, fieldName)
            for xelm in db.IQVAttributeCandidates:
                subelement.append(_writeToXmlFromIQVAttributeCandidate(xelm))
        except Exception as e:
            logger.info('Failed to export field ' + fieldName)

        fieldName = 'IQVSubTextList'
        try:
            subelement = ET.SubElement(root, fieldName)
            for xelm in db.IQVSubTextList:
                subelement.append(_writeToXmlFromIQVSubText(xelm))
        except Exception as e:
            logger.info('Failed to export field ' + fieldName)

        fieldName = 'IQVSubTextListTranslated'
        try:
            subelement = ET.SubElement(root, fieldName)
            for xelm in db.IQVSubTextListTranslated:
                subelement.append(_writeToXmlFromIQVSubText(xelm))
        except Exception as e:
            logger.info('Failed to export field ' + fieldName)
        _write_attribute(root, 'IsCopyOfRoiId', str(db.IsCopyOfRoiId))
        _write_attribute(root, 'IsTableCell', _bool2str(db.IsTableCell))

        fieldName = 'lineBoundaries'
        try:
            subelement = _writeToXmlFromLineBoundaries(db.lineBoundaries)
            subelement.tag = fieldName
            root.append(subelement)
        except Exception as e:
            logger.info('Failed to export field ' + fieldName)

        fieldName = 'lineBoundariesParent'
        try:
            subelement = ET.SubElement(root, fieldName)
            for xelm in db.lineBoundariesParent:
                subelement.append(_writeToXmlFromLineBoundaries(xelm))
        except Exception as e:
            logger.info('Failed to export field ' + fieldName)
        _write_attribute(root, 'link_id', str(db.link_id))
        _write_attribute(root, 'link_id_level2', str(db.link_id_level2))
        _write_attribute(root, 'link_id_level3', str(db.link_id_level3))
        _write_attribute(root, 'link_id_level4', str(db.link_id_level4))
        _write_attribute(root, 'link_id_level5', str(db.link_id_level5))
        _write_attribute(root, 'link_id_level6', str(db.link_id_level6))
        _write_attribute(root, 'link_id_subsection1', str(db.link_id_subsection1))
        _write_attribute(root, 'link_id_subsection2', str(db.link_id_subsection2))
        _write_attribute(root, 'link_id_subsection3', str(db.link_id_subsection3))
        _write_attribute(root, 'm_PARENT_ROI_TYPEVal', str(db.m_PARENT_ROI_TYPEVal))
        _write_attribute(root, 'm_ROI_TYPEVal', str(db.m_ROI_TYPEVal))
        _write_attribute(root, 'm_WORD_LAYOUTVal', str(db.m_WORD_LAYOUTVal))

        fieldName = 'NLP_Attributes'
        try:
            subelement = ET.SubElement(root, fieldName)
            for xelm in db.NLP_Attributes:
                subelement.append(_writeToXmlFromNLP_Attribute(xelm))
        except Exception as e:
            logger.info('Failed to export field ' + fieldName)

        fieldName = 'NLP_Entities'
        try:
            subelement = ET.SubElement(root, fieldName)
            for xelm in db.NLP_Entities:
                subelement.append(_writeToXmlFromNLP_Entity(xelm))
        except Exception as e:
            logger.info('Failed to export field ' + fieldName)
        _write_attribute(root, 'OriginalROIHeightInches', str(db.OriginalROIHeightInches))
        _write_attribute(root, 'OriginalROIWidthInches', str(db.OriginalROIWidthInches))

        fieldName = 'OriginalSubTexts'
        try:
            subelement = ET.SubElement(root, fieldName)
            for xelm in db.OriginalSubTexts:
                subelement.append(_writeToXmlFromIQVSubText(xelm))
        except Exception as e:
            logger.info('Failed to export field ' + fieldName)
        _write_attribute(root, 'OutputImageFilename', str(db.OutputImageFilename))
        _write_attribute(root, 'OutputImageFilename_Cleaned', str(db.OutputImageFilename_Cleaned))
        _write_attribute(root, 'OutputImageFilename_FinalImageProcessingOutput',
                         str(db.OutputImageFilename_FinalImageProcessingOutput))
        _write_attribute(root, 'OutputImageFilename_FinalImageProcessingOutputToDropBox',
                         str(db.OutputImageFilename_FinalImageProcessingOutputToDropBox))
        _write_attribute(root, 'OutputImageFilename_OriginalSegment', str(db.OutputImageFilename_OriginalSegment))
        _write_attribute(root, 'OutputImageFilename_RotationCorrection', str(db.OutputImageFilename_RotationCorrection))
        _write_attribute(root, 'OutputImageFilename_RotationCorrectionToDropBox',
                         str(db.OutputImageFilename_RotationCorrectionToDropBox))
        _write_attribute(root, 'OutputImageFilename_Segments', str(db.OutputImageFilename_Segments))
        _write_attribute(root, 'OutputImageFilename_SegmentsToDropBox', str(db.OutputImageFilename_SegmentsToDropBox))
        _write_attribute(root, 'OutputImageFilenameT', str(db.OutputImageFilenameT))
        _write_attribute(root, 'OutputImageFilenameTDropBox', str(db.OutputImageFilenameTDropBox))
        _write_attribute(root, 'PageID', str(db.PageID))
        _write_attribute(root, 'PageSequenceIndex', str(db.PageSequenceIndex))
        _write_attribute(root, 'parent_id', str(db.parent_id))

        fieldName = 'parentRectangle'
        try:
            subelement = _writeToXmlFromRectangle(db.parentRectangle)
            subelement.tag = fieldName
            root.append(subelement)
        except Exception as e:
            logger.info('Failed to export field ' + fieldName)
        _write_attribute(root, 'parentrectangle_height', str(db.parentrectangle_height))
        _write_attribute(root, 'parentrectangle_width', str(db.parentrectangle_width))
        _write_attribute(root, 'parentrectangle_x', str(db.parentrectangle_x))
        _write_attribute(root, 'parentrectangle_y', str(db.parentrectangle_y))

        fieldName = 'postSubTexts'
        try:
            subelement = ET.SubElement(root, fieldName)
            for xelm in db.postSubTexts:
                subelement.append(_writeToXmlFromIQVSubText(xelm))
        except Exception as e:
            logger.info('Failed to export field ' + fieldName)

        fieldName = 'postTags'
        try:
            subelement = ET.SubElement(root, fieldName)
            for xelm in db.postTags:
                subelement.append(_writeToXmlFromString(xelm))
        except Exception as e:
            logger.info('Failed to export field ' + fieldName)

        fieldName = 'postTexts'
        try:
            subelement = ET.SubElement(root, fieldName)
            for xelm in db.postTexts:
                subelement.append(_writeToXmlFromint(xelm))
        except Exception as e:
            logger.info('Failed to export field ' + fieldName)

        fieldName = 'preSubTexts'
        try:
            subelement = ET.SubElement(root, fieldName)
            for xelm in db.preSubTexts:
                subelement.append(_writeToXmlFromIQVSubText(xelm))
        except Exception as e:
            logger.info('Failed to export field ' + fieldName)

        fieldName = 'preTags'
        try:
            subelement = ET.SubElement(root, fieldName)
            for xelm in db.preTags:
                subelement.append(_writeToXmlFromString(xelm))
        except Exception as e:
            logger.info('Failed to export field ' + fieldName)

        fieldName = 'preTexts'
        try:
            subelement = ET.SubElement(root, fieldName)
            for xelm in db.preTexts:
                subelement.append(_writeToXmlFromint(xelm))
        except Exception as e:
            logger.info('Failed to export field ' + fieldName)

        fieldName = 'ProcessingResults'
        try:
            subelement = ET.SubElement(root, fieldName)
            for xelm in db.ProcessingResults:
                subelement.append(_writeToXmlFromIQVKeyValueSet(xelm))
        except Exception as e:
            logger.info('Failed to export field ' + fieldName)

        fieldName = 'Properties'
        try:
            subelement = ET.SubElement(root, fieldName)
            for xelm in db.Properties:
                subelement.append(_writeToXmlFromIQVKeyValueSet(xelm))
        except Exception as e:
            logger.info('Failed to export field ' + fieldName)

        fieldName = 'QCUpdates'
        try:
            subelement = ET.SubElement(root, fieldName)
            for xelm in db.QCUpdates:
                subelement.append(_writeToXmlFromIQVQCUpdateTracking(xelm))
        except Exception as e:
            logger.info('Failed to export field ' + fieldName)

        fieldName = 'QWords'
        try:
            subelement = ET.SubElement(root, fieldName)
            for xelm in db.QWords:
                subelement.append(_writeToXmlFromIQVWord(xelm))
        except Exception as e:
            logger.info('Failed to export field ' + fieldName)

        fieldName = 'rectangle'
        try:
            subelement = _writeToXmlFromRectangle(db.rectangle)
            subelement.tag = fieldName
            root.append(subelement)
        except Exception as e:
            logger.info('Failed to export field ' + fieldName)
        _write_attribute(root, 'rectangle_height', str(db.rectangle_height))
        _write_attribute(root, 'rectangle_width', str(db.rectangle_width))
        _write_attribute(root, 'rectangle_x', str(db.rectangle_x))
        _write_attribute(root, 'rectangle_y', str(db.rectangle_y))

        fieldName = 'rectangleGlobalLocationOnPage'
        try:
            subelement = _writeToXmlFromRectangle(db.rectangleGlobalLocationOnPage)
            subelement.tag = fieldName
            root.append(subelement)
        except Exception as e:
            logger.info('Failed to export field ' + fieldName)
        _write_attribute(root, 'rectangleGlobalLocationOnPage_height', str(db.rectangleGlobalLocationOnPage_height))
        _write_attribute(root, 'rectangleGlobalLocationOnPage_width', str(db.rectangleGlobalLocationOnPage_width))
        _write_attribute(root, 'rectangleGlobalLocationOnPage_x', str(db.rectangleGlobalLocationOnPage_x))
        _write_attribute(root, 'rectangleGlobalLocationOnPage_y', str(db.rectangleGlobalLocationOnPage_y))
        _write_attribute(root, 'Rotation_MajorAxis', str(db.Rotation_MajorAxis))

        fieldName = 'RotationChecks'
        try:
            subelement = ET.SubElement(root, fieldName)
            for xelm in db.RotationChecks:
                subelement.append(_writeToXmlFromRotationCheck(xelm))
        except Exception as e:
            logger.info('Failed to export field ' + fieldName)
        _write_attribute(root, 'RotationCorrectionDegrees', str(db.RotationCorrectionDegrees))
        _write_attribute(root, 'scannedOCRCode', str(db.scannedOCRCode))
        _write_attribute(root, 'Score', str(db.Score))

        fieldName = 'SegmentationBreakIndexes'
        try:
            subelement = ET.SubElement(root, fieldName)
            for xelm in db.SegmentationBreakIndexes:
                subelement.append(_writeToXmlFromint(xelm))
        except Exception as e:
            logger.info('Failed to export field ' + fieldName)

        fieldName = 'SegmentationBreakStrings'
        try:
            subelement = ET.SubElement(root, fieldName)
            for xelm in db.SegmentationBreakStrings:
                subelement.append(_writeToXmlFromString(xelm))
        except Exception as e:
            logger.info('Failed to export field ' + fieldName)
        _write_attribute(root, 'SegmentationMethodVal', str(db.SegmentationMethodVal))
        _write_attribute(root, 'SegmentationType', str(db.SegmentationType))
        _write_attribute(root, 'SequenceID', str(db.SequenceID))
        _write_attribute(root, 'SlideIndex', str(db.SlideIndex))
        _write_attribute(root, 'SlideRelationshipId', str(db.SlideRelationshipId))
        _write_attribute(root, 'strText', str(db.strText))

        fieldName = 'strTexts'
        try:
            subelement = ET.SubElement(root, fieldName)
            for xelm in db.strTexts:
                subelement.append(_writeToXmlFromString(xelm))
        except Exception as e:
            logger.info('Failed to export field ' + fieldName)

        fieldName = 'strTextsOCRInitial'
        try:
            subelement = ET.SubElement(root, fieldName)
            for xelm in db.strTextsOCRInitial:
                subelement.append(_writeToXmlFromString(xelm))
        except Exception as e:
            logger.info('Failed to export field ' + fieldName)

        fieldName = 'strTextsOCRUpdated'
        try:
            subelement = ET.SubElement(root, fieldName)
            for xelm in db.strTextsOCRUpdated:
                subelement.append(_writeToXmlFromString(xelm))
        except Exception as e:
            logger.info('Failed to export field ' + fieldName)

        fieldName = 'strTextsTranslated'
        try:
            subelement = ET.SubElement(root, fieldName)
            for xelm in db.strTextsTranslated:
                subelement.append(_writeToXmlFromString(xelm))
        except Exception as e:
            logger.info('Failed to export field ' + fieldName)
        _write_attribute(root, 'strTextTranslated', str(db.strTextTranslated))
        _write_attribute(root, 'tableCell_colIndex', str(db.tableCell_colIndex))
        _write_attribute(root, 'tableCell_pageIndex', str(db.tableCell_pageIndex))
        _write_attribute(root, 'tableCell_rowIndex', str(db.tableCell_rowIndex))
        _write_attribute(root, 'tableCell_SharedStringIndex', str(db.tableCell_SharedStringIndex))
        _write_attribute(root, 'tableCell_SheetCellReference', str(db.tableCell_SheetCellReference))
        _write_attribute(root, 'tableCell_SheetColIndex', str(db.tableCell_SheetColIndex))
        _write_attribute(root, 'tableCell_SheetName', str(db.tableCell_SheetName))
        _write_attribute(root, 'tableCell_SheetRowIndex', str(db.tableCell_SheetRowIndex))

        fieldName = 'tableColumn'
        try:
            subelement = _writeToXmlFromIQVTableColumn(db.tableColumn)
            subelement.tag = fieldName
            root.append(subelement)
        except Exception as e:
            logger.info('Failed to export field ' + fieldName)

        fieldName = 'TableColumns'
        try:
            subelement = ET.SubElement(root, fieldName)
            for xelm in db.TableColumns:
                subelement.append(_writeToXmlFromIQVTableColumn(xelm))
        except Exception as e:
            logger.info('Failed to export field ' + fieldName)

        fieldName = 'textMatch'
        try:
            subelement = _writeToXmlFromTextMatch(db.textMatch)
            subelement.tag = fieldName
            root.append(subelement)
        except Exception as e:
            logger.info('Failed to export field ' + fieldName)
        _write_attribute(root, 'textTypeVal', str(db.textTypeVal))
        _write_attribute(root, 'TranslatedTextNoSegmentation', str(db.TranslatedTextNoSegmentation))
        _write_attribute(root, 'TranslationMatch', str(db.TranslationMatch))
        _write_attribute(root, 'TranslationMethod1', str(db.TranslationMethod1))
        _write_attribute(root, 'UncorrectedImageFilename', str(db.UncorrectedImageFilename))
        _write_attribute(root, 'Value', str(db.Value))

        fieldName = 'ValuesI'
        try:
            subelement = ET.SubElement(root, fieldName)
            for xelm in db.ValuesI:
                subelement.append(_writeToXmlFromValueI(xelm))
        except Exception as e:
            logger.info('Failed to export field ' + fieldName)
        _write_attribute(root, 'VerticalResolution', str(db.VerticalResolution))
        ##############################################################
        #
        # End of fields
        #
        ##############################################################
        return root
    except Exception as e:
        logger.error('Failed to write IQVPageROI to root')


def _writeToXmlFromIQVDocument(db: IQVDocument):
    """
    Get the ET Element IQVDocument with all of its subelements
    """

    try:
        root = ET.Element("IQVDocument")
        ##############################################################
        #
        # Start of fields
        #
        ##############################################################

        fieldName = 'alcoac_check_error'
        try:
            subelement = ET.SubElement(root, fieldName)
            for xelm in db.alcoac_check_error:
                subelement.append(_writeToXmlFromIQVAttributeCandidate(xelm))
        except Exception as e:
            logger.info('Failed to export field ' + fieldName)
        _write_attribute(root, 'bDeleteAllFilesExceptFinalizerOutputFile',
                         _bool2str(db.bDeleteAllFilesExceptFinalizerOutputFile))
        _write_attribute(root, 'bDeleteInputSourceFile', _bool2str(db.bDeleteInputSourceFile))
        _write_attribute(root, 'bDeleteWorkingTempDirectoryAfterCompletion',
                         str(db.bDeleteWorkingTempDirectoryAfterCompletion))
        _write_attribute(root, 'bIsFullDocumentScanned', _bool2str(db.bIsFullDocumentScanned))
        _write_attribute(root, 'bIsStandardForm', _bool2str(db.bIsStandardForm))
        _write_attribute(root, 'bIsVisibleInDocumentDisplay', _bool2str(db.bIsVisibleInDocumentDisplay))
        _write_attribute(root, 'CustomHostName', str(db.CustomHostName))
        _write_attribute(root, 'dateTimeLastModified', str(db.dateTimeLastModified))
        _write_attribute(root, 'dateTimeUploaded', str(db.dateTimeUploaded))
        _write_attribute(root, 'debugModeVal', str(db.debugModeVal))
        _write_attribute(root, 'displayLabel', str(db.displayLabel))
        _write_attribute(root, 'doc_id', str(db.doc_id))
        _write_attribute(root, 'DOCANALYSIS_DateID', str(db.DOCANALYSIS_DateID))
        _write_attribute(root, 'DOCANALYSIS_DateValue', str(db.DOCANALYSIS_DateValue))
        _write_attribute(root, 'DOCANALYSIS_DocumentClass', str(db.DOCANALYSIS_DocumentClass))
        _write_attribute(root, 'DOCANALYSIS_DocumentClassConfidence', str(db.DOCANALYSIS_DocumentClassConfidence))

        fieldName = 'DOCANALYSIS_DocumentClassConfidenceList'
        try:
            subelement = ET.SubElement(root, fieldName)
            for xelm in db.DOCANALYSIS_DocumentClassConfidenceList:
                subelement.append(_writeToXmlFromDouble(xelm))
        except Exception as e:
            logger.info('Failed to export field ' + fieldName)

        fieldName = 'DOCANALYSIS_DocumentClassList'
        try:
            subelement = ET.SubElement(root, fieldName)
            for xelm in db.DOCANALYSIS_DocumentClassList:
                subelement.append(_writeToXmlFromString(xelm))
        except Exception as e:
            logger.info('Failed to export field ' + fieldName)

        fieldName = 'DOCANALYSIS_DocumentClassList_Description'
        try:
            subelement = ET.SubElement(root, fieldName)
            for xelm in db.DOCANALYSIS_DocumentClassList_Description:
                subelement.append(_writeToXmlFromString(xelm))
        except Exception as e:
            logger.info('Failed to export field ' + fieldName)

        fieldName = 'DOCANALYSIS_DocumentClassList_DIACode'
        try:
            subelement = ET.SubElement(root, fieldName)
            for xelm in db.DOCANALYSIS_DocumentClassList_DIACode:
                subelement.append(_writeToXmlFromString(xelm))
        except Exception as e:
            logger.info('Failed to export field ' + fieldName)

        fieldName = 'DOCANALYSIS_DocumentClassRawScoreList'
        try:
            subelement = ET.SubElement(root, fieldName)
            for xelm in db.DOCANALYSIS_DocumentClassRawScoreList:
                subelement.append(_writeToXmlFromDouble(xelm))
        except Exception as e:
            logger.info('Failed to export field ' + fieldName)

        fieldName = 'DOCANALYSIS_DocumentMetadata'
        try:
            subelement = ET.SubElement(root, fieldName)
            for xelm in db.DOCANALYSIS_DocumentMetadata:
                subelement.append(_writeToXmlFromIQVKeyValueSet(xelm))
        except Exception as e:
            logger.info('Failed to export field ' + fieldName)

        fieldName = 'DocumentCompares'
        try:
            subelement = ET.SubElement(root, fieldName)
            for xelm in db.DocumentCompares:
                subelement.append(_writeToXmlFromIQVDocumentCompare(xelm))
        except Exception as e:
            logger.info('Failed to export field ' + fieldName)

        fieldName = 'DocumentFooters'
        try:
            subelement = ET.SubElement(root, fieldName)
            for xelm in db.DocumentFooters:
                subelement.append(_writeToXmlFromIQVPageROI(xelm))
        except Exception as e:
            logger.info('Failed to export field ' + fieldName)

        fieldName = 'DocumentFootnotes'
        try:
            subelement = ET.SubElement(root, fieldName)
            for xelm in db.DocumentFootnotes:
                subelement.append(_writeToXmlFromIQVPageROI(xelm))
        except Exception as e:
            logger.info('Failed to export field ' + fieldName)

        fieldName = 'DocumentGroundTruth'
        try:
            subelement = _writeToXmlFromIQVDocumentGroundTruth(db.DocumentGroundTruth)
            subelement.tag = fieldName
            root.append(subelement)
        except Exception as e:
            logger.info('Failed to export field ' + fieldName)

        fieldName = 'DocumentHeaders'
        try:
            subelement = ET.SubElement(root, fieldName)
            for xelm in db.DocumentHeaders:
                subelement.append(_writeToXmlFromIQVPageROI(xelm))
        except Exception as e:
            logger.info('Failed to export field ' + fieldName)

        fieldName = 'DocumentImages'
        try:
            subelement = ET.SubElement(root, fieldName)
            for xelm in db.DocumentImages:
                subelement.append(_writeToXmlFromIQVPageROI(xelm))
        except Exception as e:
            logger.info('Failed to export field ' + fieldName)

        fieldName = 'DocumentItems'
        try:
            subelement = ET.SubElement(root, fieldName)
            for xelm in db.DocumentItems:
                subelement.append(_writeToXmlFromIQVPageROI(xelm))
        except Exception as e:
            logger.info('Failed to export field ' + fieldName)

        fieldName = 'DocumentLinks'
        try:
            subelement = ET.SubElement(root, fieldName)
            for xelm in db.DocumentLinks:
                subelement.append(_writeToXmlFromIQVDocumentLink(xelm))
        except Exception as e:
            logger.info('Failed to export field ' + fieldName)

        fieldName = 'DocumentParagraphs'
        try:
            subelement = ET.SubElement(root, fieldName)
            for xelm in db.DocumentParagraphs:
                subelement.append(_writeToXmlFromIQVPageROI(xelm))
        except Exception as e:
            logger.info('Failed to export field ' + fieldName)

        fieldName = 'DocumentPartsList'
        try:
            subelement = ET.SubElement(root, fieldName)
            for xelm in db.DocumentPartsList:
                subelement.append(_writeToXmlFromString(xelm))
        except Exception as e:
            logger.info('Failed to export field ' + fieldName)

        fieldName = 'DocumentTables'
        try:
            subelement = ET.SubElement(root, fieldName)
            for xelm in db.DocumentTables:
                subelement.append(_writeToXmlFromIQVPageROI(xelm))
        except Exception as e:
            logger.info('Failed to export field ' + fieldName)
        _write_attribute(root, 'DocumentTypeVal', str(db.DocumentTypeVal))
        _write_attribute(root, 'DocumentTypeValOriginal', str(db.DocumentTypeValOriginal))
        _write_attribute(root, 'DropBoxDir', str(db.DropBoxDir))
        _write_attribute(root, 'DropBoxDirWebUI', str(db.DropBoxDirWebUI))
        _write_attribute(root, 'EndPage', str(db.EndPage))
        _write_attribute(root, 'id', str(db.id))
        _write_attribute(root, 'image_count', str(db.image_count))

        fieldName = 'InitialConfig'
        try:
            subelement = _writeToXmlFromConfig(db.InitialConfig)
            subelement.tag = fieldName
            root.append(subelement)
        except Exception as e:
            logger.info('Failed to export field ' + fieldName)

        fieldName = 'IQVAttributeCandidates'
        try:
            subelement = ET.SubElement(root, fieldName)
            for xelm in db.IQVAttributeCandidates:
                subelement.append(_writeToXmlFromIQVAttributeCandidate(xelm))
        except Exception as e:
            logger.info('Failed to export field ' + fieldName)

        fieldName = 'IQVDocumentFeedbackResultsList'
        try:
            subelement = ET.SubElement(root, fieldName)
            for xelm in db.IQVDocumentFeedbackResultsList:
                subelement.append(_writeToXmlFromIQVDocumentFeedbackResults(xelm))
        except Exception as e:
            logger.info('Failed to export field ' + fieldName)
        _write_attribute(root, 'IQVDocumentFilename_SourceXML', str(db.IQVDocumentFilename_SourceXML))
        _write_attribute(root, 'IQVDocumentFilename_TranslatedXML', str(db.IQVDocumentFilename_TranslatedXML))

        fieldName = 'IQVDocumentProcesses'
        try:
            subelement = ET.SubElement(root, fieldName)
            for xelm in db.IQVDocumentProcesses:
                subelement.append(_writeToXmlFromIQVDocumentProcess(xelm))
        except Exception as e:
            logger.info('Failed to export field ' + fieldName)

        fieldName = 'iqvForm'
        try:
            subelement = _writeToXmlFromIQVForm(db.iqvForm)
            subelement.tag = fieldName
            root.append(subelement)
        except Exception as e:
            logger.info('Failed to export field ' + fieldName)
        _write_attribute(root, 'IsDocInitialWorkflowCompleted', _bool2str(db.IsDocInitialWorkflowCompleted))
        _write_attribute(root, 'link_id', str(db.link_id))

        fieldName = 'LogEntries'
        try:
            subelement = ET.SubElement(root, fieldName)
            for xelm in db.LogEntries:
                subelement.append(_writeToXmlFromQ_EVENT_LOG_ENTRY(xelm))
        except Exception as e:
            logger.info('Failed to export field ' + fieldName)
        _write_attribute(root, 'logFilename', str(db.logFilename))
        _write_attribute(root, 'logFilenameDropBox', str(db.logFilenameDropBox))
        _write_attribute(root, 'MachineName', str(db.MachineName))

        fieldName = 'NLP_Attributes'
        try:
            subelement = ET.SubElement(root, fieldName)
            for xelm in db.NLP_Attributes:
                subelement.append(_writeToXmlFromNLP_Attribute(xelm))
        except Exception as e:
            logger.info('Failed to export field ' + fieldName)

        fieldName = 'NLP_Entities'
        try:
            subelement = ET.SubElement(root, fieldName)
            for xelm in db.NLP_Entities:
                subelement.append(_writeToXmlFromNLP_Entity(xelm))
        except Exception as e:
            logger.info('Failed to export field ' + fieldName)

        fieldName = 'NLP_Relations'
        try:
            subelement = ET.SubElement(root, fieldName)
            for xelm in db.NLP_Relations:
                subelement.append(_writeToXmlFromNLP_Relation(xelm))
        except Exception as e:
            logger.info('Failed to export field ' + fieldName)

        fieldName = 'numberingGroups'
        try:
            subelement = ET.SubElement(root, fieldName)
            for xelm in db.numberingGroups:
                subelement.append(_writeToXmlFromIQVNumberingGroup(xelm))
        except Exception as e:
            logger.info('Failed to export field ' + fieldName)
        _write_attribute(root, 'NumPDFPages', str(db.NumPDFPages))
        _write_attribute(root, 'NumSegments', str(db.NumSegments))
        _write_attribute(root, 'originalSourceFilename', str(db.originalSourceFilename))
        _write_attribute(root, 'outputHTMLFilename', str(db.outputHTMLFilename))
        _write_attribute(root, 'outputHTMLFilename_Cleaned', str(db.outputHTMLFilename_Cleaned))
        _write_attribute(root, 'outputHTMLFilename_OCRDig', str(db.outputHTMLFilename_OCRDig))
        _write_attribute(root, 'outputHTMLFilename_Orig', str(db.outputHTMLFilename_Orig))
        _write_attribute(root, 'outputHTMLFilename_Segmented', str(db.outputHTMLFilename_Segmented))
        _write_attribute(root, 'outputHTMLFilename_XMLSource', str(db.outputHTMLFilename_XMLSource))
        _write_attribute(root, 'outputHTMLFilename_XMLTrans', str(db.outputHTMLFilename_XMLTrans))
        _write_attribute(root, 'outputHTMLFilenameToDropBox', str(db.outputHTMLFilenameToDropBox))
        _write_attribute(root, 'outputHTMLFilenameToDropBox_Cleaned', str(db.outputHTMLFilenameToDropBox_Cleaned))
        _write_attribute(root, 'outputHTMLFilenameToDropBox_OCRDig', str(db.outputHTMLFilenameToDropBox_OCRDig))
        _write_attribute(root, 'outputHTMLFilenameToDropBox_Orig', str(db.outputHTMLFilenameToDropBox_Orig))
        _write_attribute(root, 'outputHTMLFilenameToDropBox_Segmented', str(db.outputHTMLFilenameToDropBox_Segmented))
        _write_attribute(root, 'outputHTMLFilenameToDropBox_XMLSource', str(db.outputHTMLFilenameToDropBox_XMLSource))
        _write_attribute(root, 'outputHTMLFilenameToDropBox_XMLTrans', str(db.outputHTMLFilenameToDropBox_XMLTrans))
        _write_attribute(root, 'outputHTMLFilenameTranslated', str(db.outputHTMLFilenameTranslated))
        _write_attribute(root, 'outputHTMLFilenameTranslatedToDropBox', str(db.outputHTMLFilenameTranslatedToDropBox))
        _write_attribute(root, 'outputHTMLFilenameWithID', str(db.outputHTMLFilenameWithID))
        _write_attribute(root, 'outputHTMLSideBySideFilename', str(db.outputHTMLSideBySideFilename))
        _write_attribute(root, 'outputHTMLSideBySideFilename_OCRDig_to_XMLSource',
                         str(db.outputHTMLSideBySideFilename_OCRDig_to_XMLSource))
        _write_attribute(root, 'outputHTMLSideBySideFilename_Orig_to_Cleaned',
                         str(db.outputHTMLSideBySideFilename_Orig_to_Cleaned))
        _write_attribute(root, 'outputHTMLSideBySideFilename_Orig_to_OCRDig',
                         str(db.outputHTMLSideBySideFilename_Orig_to_OCRDig))
        _write_attribute(root, 'outputHTMLSideBySideFilename_Segmented_to_OCRDig',
                         str(db.outputHTMLSideBySideFilename_Segmented_to_OCRDig))
        _write_attribute(root, 'outputHTMLSideBySideFilename_XMLSource_to_XMLTrans',
                         str(db.outputHTMLSideBySideFilename_XMLSource_to_XMLTrans))
        _write_attribute(root, 'outputHTMLSideBySideFilenameToDropBox', str(db.outputHTMLSideBySideFilenameToDropBox))
        _write_attribute(root, 'outputHTMLSideBySideFilenameToDropBox_OCRDig_to_XMLSource',
                         str(db.outputHTMLSideBySideFilenameToDropBox_OCRDig_to_XMLSource))
        _write_attribute(root, 'outputHTMLSideBySideFilenameToDropBox_Orig_to_Cleaned',
                         str(db.outputHTMLSideBySideFilenameToDropBox_Orig_to_Cleaned))
        _write_attribute(root, 'outputHTMLSideBySideFilenameToDropBox_Orig_to_OCRDig',
                         str(db.outputHTMLSideBySideFilenameToDropBox_Orig_to_OCRDig))
        _write_attribute(root, 'outputHTMLSideBySideFilenameToDropBox_Segmented_to_OCRDig',
                         str(db.outputHTMLSideBySideFilenameToDropBox_Segmented_to_OCRDig))
        _write_attribute(root, 'outputHTMLSideBySideFilenameToDropBox_XMLSource_to_XMLTrans',
                         str(db.outputHTMLSideBySideFilenameToDropBox_XMLSource_to_XMLTrans))
        _write_attribute(root, 'outputHTMLSideBySideOCRFilename', str(db.outputHTMLSideBySideOCRFilename))
        _write_attribute(root, 'outputHTMLSideBySideOCRFilenameToDropBox',
                         str(db.outputHTMLSideBySideOCRFilenameToDropBox))
        _write_attribute(root, 'outputImagesToDropBoxDir', str(db.outputImagesToDropBoxDir))
        _write_attribute(root, 'outputIQVXMLFilenameToDropBox', str(db.outputIQVXMLFilenameToDropBox))
        _write_attribute(root, 'OutputLevel', str(db.OutputLevel))
        _write_attribute(root, 'outputMetadataFilename', str(db.outputMetadataFilename))
        _write_attribute(root, 'outputMetatdataFilenameTranslated', str(db.outputMetatdataFilenameTranslated))
        _write_attribute(root, 'outputPDFFilename', str(db.outputPDFFilename))
        _write_attribute(root, 'outputPDFFilenameToDropBox', str(db.outputPDFFilenameToDropBox))
        _write_attribute(root, 'outputPDFFilenameTranslated', str(db.outputPDFFilenameTranslated))
        _write_attribute(root, 'outputPDFFilenameTranslatedToDropBox', str(db.outputPDFFilenameTranslatedToDropBox))
        _write_attribute(root, 'outputWordDocFilename', str(db.outputWordDocFilename))
        _write_attribute(root, 'outputWordDocFilenameDropBox', str(db.outputWordDocFilenameDropBox))
        _write_attribute(root, 'outputWordDocFilenameTranslated', str(db.outputWordDocFilenameTranslated))
        _write_attribute(root, 'outputWordDocFilenameTranslatedDropBox', str(db.outputWordDocFilenameTranslatedDropBox))
        _write_attribute(root, 'outputXLIFFFilename', str(db.outputXLIFFFilename))
        _write_attribute(root, 'outputXLIFFFilenameDropBox', str(db.outputXLIFFFilenameDropBox))
        _write_attribute(root, 'outputXLIFFFilenameT', str(db.outputXLIFFFilenameT))
        _write_attribute(root, 'outputXLIFFFilenameTDropBox', str(db.outputXLIFFFilenameTDropBox))

        fieldName = 'pages'
        try:
            subelement = ET.SubElement(root, fieldName)
            for xelm in db.pages:
                subelement.append(_writeToXmlFromIQVDocumentPage(xelm))
        except Exception as e:
            logger.info('Failed to export field ' + fieldName)
        _write_attribute(root, 'ProcessFinishTime', str(db.ProcessFinishTime))

        fieldName = 'ProcessingResults'
        try:
            subelement = ET.SubElement(root, fieldName)
            for xelm in db.ProcessingResults:
                subelement.append(_writeToXmlFromIQVKeyValueSet(xelm))
        except Exception as e:
            logger.info('Failed to export field ' + fieldName)
        _write_attribute(root, 'ProcessStartTime', str(db.ProcessStartTime))

        fieldName = 'Properties'
        try:
            subelement = ET.SubElement(root, fieldName)
            for xelm in db.Properties:
                subelement.append(_writeToXmlFromIQVKeyValueSet(xelm))
        except Exception as e:
            logger.info('Failed to export field ' + fieldName)
        _write_attribute(root, 'QDocumentWorkingDirectory', str(db.QDocumentWorkingDirectory))
        _write_attribute(root, 'QDocumentWorkingTempDirectory', str(db.QDocumentWorkingTempDirectory))

        fieldName = 'ReconDocumentFooters'
        try:
            subelement = ET.SubElement(root, fieldName)
            for xelm in db.ReconDocumentFooters:
                subelement.append(_writeToXmlFromIQVPageROI(xelm))
        except Exception as e:
            logger.info('Failed to export field ' + fieldName)

        fieldName = 'ReconDocumentHeaders'
        try:
            subelement = ET.SubElement(root, fieldName)
            for xelm in db.ReconDocumentHeaders:
                subelement.append(_writeToXmlFromIQVPageROI(xelm))
        except Exception as e:
            logger.info('Failed to export field ' + fieldName)

        fieldName = 'ReconDocumentImages'
        try:
            subelement = ET.SubElement(root, fieldName)
            for xelm in db.ReconDocumentImages:
                subelement.append(_writeToXmlFromIQVPageROI(xelm))
        except Exception as e:
            logger.info('Failed to export field ' + fieldName)

        fieldName = 'ReconDocumentItems'
        try:
            subelement = ET.SubElement(root, fieldName)
            for xelm in db.ReconDocumentItems:
                subelement.append(_writeToXmlFromIQVPageROI(xelm))
        except Exception as e:
            logger.info('Failed to export field ' + fieldName)

        fieldName = 'ReconDocumentParagraphs'
        try:
            subelement = ET.SubElement(root, fieldName)
            for xelm in db.ReconDocumentParagraphs:
                subelement.append(_writeToXmlFromIQVPageROI(xelm))
        except Exception as e:
            logger.info('Failed to export field ' + fieldName)

        fieldName = 'ReconDocumentTables'
        try:
            subelement = ET.SubElement(root, fieldName)
            for xelm in db.ReconDocumentTables:
                subelement.append(_writeToXmlFromIQVPageROI(xelm))
        except Exception as e:
            logger.info('Failed to export field ' + fieldName)
        _write_attribute(root, 'SegmentationFilename_PostSegmentation', str(db.SegmentationFilename_PostSegmentation))
        _write_attribute(root, 'SegmentationFilename_PreSegmentation', str(db.SegmentationFilename_PreSegmentation))
        _write_attribute(root, 'SelectedWordTemplateCode', str(db.SelectedWordTemplateCode))
        _write_attribute(root, 'SelectedWordTemplateFilename', str(db.SelectedWordTemplateFilename))
        _write_attribute(root, 'sourceFilename', str(db.sourceFilename))
        _write_attribute(root, 'sourceFilenameWorkingCopy', str(db.sourceFilenameWorkingCopy))
        _write_attribute(root, 'sourceFilenameWorkingCopyToDropBox', str(db.sourceFilenameWorkingCopyToDropBox))
        _write_attribute(root, 'SourceLanguage', str(db.SourceLanguage))
        _write_attribute(root, 'StandardForm', str(db.StandardForm))
        _write_attribute(root, 'StandardFormPageIndex', str(db.StandardFormPageIndex))
        _write_attribute(root, 'StartPage', str(db.StartPage))
        _write_attribute(root, 'SubmitterEmail', str(db.SubmitterEmail))
        _write_attribute(root, 'SubmitterID', str(db.SubmitterID))
        _write_attribute(root, 'TargetLanguage', str(db.TargetLanguage))
        _write_attribute(root, 'workingFilename', str(db.workingFilename))
        _write_attribute(root, 'workingFilename_NoiseGenerator', str(db.workingFilename_NoiseGenerator))
        ##############################################################
        #
        # End of fields
        #
        ##############################################################
        return root
    except Exception as e:
        logger.error('Failed to write IQVDocument to root')


def _writeToXmlFromIQVDocument_db(db: IQVDocument_db):
    """
    Get the ET Element IQVDocument_db with all of its subelements
    """

    try:
        root = ET.Element("IQVDocument_db")
        ##############################################################
        #
        # Start of fields
        #
        ##############################################################
        _write_attribute(root, 'bDeleteAllFilesExceptFinalizerOutputFile',
                         _bool2str(db.bDeleteAllFilesExceptFinalizerOutputFile))
        _write_attribute(root, 'bDeleteInputSourceFile', _bool2str(db.bDeleteInputSourceFile))
        _write_attribute(root, 'bDeleteWorkingTempDirectoryAfterCompletion',
                         str(db.bDeleteWorkingTempDirectoryAfterCompletion))
        _write_attribute(root, 'bIsFullDocumentScanned', _bool2str(db.bIsFullDocumentScanned))
        _write_attribute(root, 'bIsStandardForm', _bool2str(db.bIsStandardForm))
        _write_attribute(root, 'bIsVisibleInDocumentDisplay', _bool2str(db.bIsVisibleInDocumentDisplay))
        _write_attribute(root, 'CustomHostName', str(db.CustomHostName))
        _write_attribute(root, 'dateTimeLastModified', str(db.dateTimeLastModified))
        _write_attribute(root, 'dateTimeUploaded', str(db.dateTimeUploaded))
        _write_attribute(root, 'debugModeVal', str(db.debugModeVal))
        _write_attribute(root, 'displayLabel', str(db.displayLabel))
        _write_attribute(root, 'doc_id', str(db.doc_id))
        _write_attribute(root, 'DOCANALYSIS_DateID', str(db.DOCANALYSIS_DateID))
        _write_attribute(root, 'DOCANALYSIS_DateValue', str(db.DOCANALYSIS_DateValue))
        _write_attribute(root, 'DOCANALYSIS_DocumentClass', str(db.DOCANALYSIS_DocumentClass))
        _write_attribute(root, 'DOCANALYSIS_DocumentClassConfidence', str(db.DOCANALYSIS_DocumentClassConfidence))
        _write_attribute(root, 'DocumentTypeVal', str(db.DocumentTypeVal))
        _write_attribute(root, 'DocumentTypeValOriginal', str(db.DocumentTypeValOriginal))
        _write_attribute(root, 'DropBoxDir', str(db.DropBoxDir))
        _write_attribute(root, 'DropBoxDirWebUI', str(db.DropBoxDirWebUI))
        _write_attribute(root, 'EndPage', str(db.EndPage))
        _write_attribute(root, 'id', str(db.id))
        _write_attribute(root, 'image_count', str(db.image_count))
        _write_attribute(root, 'IQVDocumentFilename_SourceXML', str(db.IQVDocumentFilename_SourceXML))
        _write_attribute(root, 'IQVDocumentFilename_TranslatedXML', str(db.IQVDocumentFilename_TranslatedXML))
        _write_attribute(root, 'IsDocInitialWorkflowCompleted', _bool2str(db.IsDocInitialWorkflowCompleted))
        _write_attribute(root, 'link_id', str(db.link_id))
        _write_attribute(root, 'logFilename', str(db.logFilename))
        _write_attribute(root, 'logFilenameDropBox', str(db.logFilenameDropBox))
        _write_attribute(root, 'MachineName', str(db.MachineName))
        _write_attribute(root, 'NumPDFPages', str(db.NumPDFPages))
        _write_attribute(root, 'NumSegments', str(db.NumSegments))
        _write_attribute(root, 'originalSourceFilename', str(db.originalSourceFilename))
        _write_attribute(root, 'outputHTMLFilename', str(db.outputHTMLFilename))
        _write_attribute(root, 'outputHTMLFilename_Cleaned', str(db.outputHTMLFilename_Cleaned))
        _write_attribute(root, 'outputHTMLFilename_OCRDig', str(db.outputHTMLFilename_OCRDig))
        _write_attribute(root, 'outputHTMLFilename_Orig', str(db.outputHTMLFilename_Orig))
        _write_attribute(root, 'outputHTMLFilename_Segmented', str(db.outputHTMLFilename_Segmented))
        _write_attribute(root, 'outputHTMLFilename_XMLSource', str(db.outputHTMLFilename_XMLSource))
        _write_attribute(root, 'outputHTMLFilename_XMLTrans', str(db.outputHTMLFilename_XMLTrans))
        _write_attribute(root, 'outputHTMLFilenameToDropBox', str(db.outputHTMLFilenameToDropBox))
        _write_attribute(root, 'outputHTMLFilenameToDropBox_Cleaned', str(db.outputHTMLFilenameToDropBox_Cleaned))
        _write_attribute(root, 'outputHTMLFilenameToDropBox_OCRDig', str(db.outputHTMLFilenameToDropBox_OCRDig))
        _write_attribute(root, 'outputHTMLFilenameToDropBox_Orig', str(db.outputHTMLFilenameToDropBox_Orig))
        _write_attribute(root, 'outputHTMLFilenameToDropBox_Segmented', str(db.outputHTMLFilenameToDropBox_Segmented))
        _write_attribute(root, 'outputHTMLFilenameToDropBox_XMLSource', str(db.outputHTMLFilenameToDropBox_XMLSource))
        _write_attribute(root, 'outputHTMLFilenameToDropBox_XMLTrans', str(db.outputHTMLFilenameToDropBox_XMLTrans))
        _write_attribute(root, 'outputHTMLFilenameTranslated', str(db.outputHTMLFilenameTranslated))
        _write_attribute(root, 'outputHTMLFilenameTranslatedToDropBox', str(db.outputHTMLFilenameTranslatedToDropBox))
        _write_attribute(root, 'outputHTMLFilenameWithID', str(db.outputHTMLFilenameWithID))
        _write_attribute(root, 'outputHTMLSideBySideFilename', str(db.outputHTMLSideBySideFilename))
        _write_attribute(root, 'outputHTMLSideBySideFilename_OCRDig_to_XMLSource',
                         str(db.outputHTMLSideBySideFilename_OCRDig_to_XMLSource))
        _write_attribute(root, 'outputHTMLSideBySideFilename_Orig_to_Cleaned',
                         str(db.outputHTMLSideBySideFilename_Orig_to_Cleaned))
        _write_attribute(root, 'outputHTMLSideBySideFilename_Orig_to_OCRDig',
                         str(db.outputHTMLSideBySideFilename_Orig_to_OCRDig))
        _write_attribute(root, 'outputHTMLSideBySideFilename_Segmented_to_OCRDig',
                         str(db.outputHTMLSideBySideFilename_Segmented_to_OCRDig))
        _write_attribute(root, 'outputHTMLSideBySideFilename_XMLSource_to_XMLTrans',
                         str(db.outputHTMLSideBySideFilename_XMLSource_to_XMLTrans))
        _write_attribute(root, 'outputHTMLSideBySideFilenameToDropBox', str(db.outputHTMLSideBySideFilenameToDropBox))
        _write_attribute(root, 'outputHTMLSideBySideFilenameToDropBox_OCRDig_to_XMLSource',
                         str(db.outputHTMLSideBySideFilenameToDropBox_OCRDig_to_XMLSource))
        _write_attribute(root, 'outputHTMLSideBySideFilenameToDropBox_Orig_to_Cleaned',
                         str(db.outputHTMLSideBySideFilenameToDropBox_Orig_to_Cleaned))
        _write_attribute(root, 'outputHTMLSideBySideFilenameToDropBox_Orig_to_OCRDig',
                         str(db.outputHTMLSideBySideFilenameToDropBox_Orig_to_OCRDig))
        _write_attribute(root, 'outputHTMLSideBySideFilenameToDropBox_Segmented_to_OCRDig',
                         str(db.outputHTMLSideBySideFilenameToDropBox_Segmented_to_OCRDig))
        _write_attribute(root, 'outputHTMLSideBySideFilenameToDropBox_XMLSource_to_XMLTrans',
                         str(db.outputHTMLSideBySideFilenameToDropBox_XMLSource_to_XMLTrans))
        _write_attribute(root, 'outputHTMLSideBySideOCRFilename', str(db.outputHTMLSideBySideOCRFilename))
        _write_attribute(root, 'outputHTMLSideBySideOCRFilenameToDropBox',
                         str(db.outputHTMLSideBySideOCRFilenameToDropBox))
        _write_attribute(root, 'outputImagesToDropBoxDir', str(db.outputImagesToDropBoxDir))
        _write_attribute(root, 'outputIQVXMLFilenameToDropBox', str(db.outputIQVXMLFilenameToDropBox))
        _write_attribute(root, 'OutputLevel', str(db.OutputLevel))
        _write_attribute(root, 'outputMetadataFilename', str(db.outputMetadataFilename))
        _write_attribute(root, 'outputMetatdataFilenameTranslated', str(db.outputMetatdataFilenameTranslated))
        _write_attribute(root, 'outputPDFFilename', str(db.outputPDFFilename))
        _write_attribute(root, 'outputPDFFilenameToDropBox', str(db.outputPDFFilenameToDropBox))
        _write_attribute(root, 'outputPDFFilenameTranslated', str(db.outputPDFFilenameTranslated))
        _write_attribute(root, 'outputPDFFilenameTranslatedToDropBox', str(db.outputPDFFilenameTranslatedToDropBox))
        _write_attribute(root, 'outputWordDocFilename', str(db.outputWordDocFilename))
        _write_attribute(root, 'outputWordDocFilenameDropBox', str(db.outputWordDocFilenameDropBox))
        _write_attribute(root, 'outputWordDocFilenameTranslated', str(db.outputWordDocFilenameTranslated))
        _write_attribute(root, 'outputWordDocFilenameTranslatedDropBox', str(db.outputWordDocFilenameTranslatedDropBox))
        _write_attribute(root, 'outputXLIFFFilename', str(db.outputXLIFFFilename))
        _write_attribute(root, 'outputXLIFFFilenameDropBox', str(db.outputXLIFFFilenameDropBox))
        _write_attribute(root, 'outputXLIFFFilenameT', str(db.outputXLIFFFilenameT))
        _write_attribute(root, 'outputXLIFFFilenameTDropBox', str(db.outputXLIFFFilenameTDropBox))
        _write_attribute(root, 'ProcessFinishTime', str(db.ProcessFinishTime))
        _write_attribute(root, 'ProcessStartTime', str(db.ProcessStartTime))
        _write_attribute(root, 'QDocumentWorkingDirectory', str(db.QDocumentWorkingDirectory))
        _write_attribute(root, 'QDocumentWorkingTempDirectory', str(db.QDocumentWorkingTempDirectory))
        _write_attribute(root, 'SegmentationFilename_PostSegmentation', str(db.SegmentationFilename_PostSegmentation))
        _write_attribute(root, 'SegmentationFilename_PreSegmentation', str(db.SegmentationFilename_PreSegmentation))
        _write_attribute(root, 'SelectedWordTemplateCode', str(db.SelectedWordTemplateCode))
        _write_attribute(root, 'SelectedWordTemplateFilename', str(db.SelectedWordTemplateFilename))
        _write_attribute(root, 'sourceFilename', str(db.sourceFilename))
        _write_attribute(root, 'sourceFilenameWorkingCopy', str(db.sourceFilenameWorkingCopy))
        _write_attribute(root, 'sourceFilenameWorkingCopyToDropBox', str(db.sourceFilenameWorkingCopyToDropBox))
        _write_attribute(root, 'SourceLanguage', str(db.SourceLanguage))
        _write_attribute(root, 'StandardForm', str(db.StandardForm))
        _write_attribute(root, 'StandardFormPageIndex', str(db.StandardFormPageIndex))
        _write_attribute(root, 'StartPage', str(db.StartPage))
        _write_attribute(root, 'SubmitterEmail', str(db.SubmitterEmail))
        _write_attribute(root, 'SubmitterID', str(db.SubmitterID))
        _write_attribute(root, 'TargetLanguage', str(db.TargetLanguage))
        _write_attribute(root, 'workingFilename', str(db.workingFilename))
        _write_attribute(root, 'workingFilename_NoiseGenerator', str(db.workingFilename_NoiseGenerator))
        ##############################################################
        #
        # End of fields
        #
        ##############################################################
        return root
    except Exception as e:
        logger.error('Failed to write IQVDocument_db to root')


def _writeToXmlFromDocumentPartsList_db(db: DocumentPartsList_db):
    """
    Get the ET Element DocumentPartsList_db with all of its subelements
    """

    try:
        root = ET.Element("DocumentPartsList_db")
        ##############################################################
        #
        # Start of fields
        #
        ##############################################################
        _write_attribute(root, 'doc_id', str(db.doc_id))
        _write_attribute(root, 'group_type', str(db.group_type))
        _write_attribute(root, 'hierarchy', str(db.hierarchy))
        _write_attribute(root, 'id', str(db.id))
        _write_attribute(root, 'iqv_standard_term', str(db.iqv_standard_term))
        _write_attribute(root, 'link_id', str(db.link_id))
        _write_attribute(root, 'link_id_level2', str(db.link_id_level2))
        _write_attribute(root, 'link_id_level3', str(db.link_id_level3))
        _write_attribute(root, 'link_id_level4', str(db.link_id_level4))
        _write_attribute(root, 'link_id_level5', str(db.link_id_level5))
        _write_attribute(root, 'link_id_level6', str(db.link_id_level6))
        _write_attribute(root, 'link_id_subsection1', str(db.link_id_subsection1))
        _write_attribute(root, 'link_id_subsection2', str(db.link_id_subsection2))
        _write_attribute(root, 'link_id_subsection3', str(db.link_id_subsection3))
        _write_attribute(root, 'parent_id', str(db.parent_id))
        _write_attribute(root, 'sequence_id', str(db.sequence_id))
        ##############################################################
        #
        # End of fields
        #
        ##############################################################
        return root
    except Exception as e:
        logger.error('Failed to write DocumentPartsList_db to root')


def _writeToXmlFromIQVPageROI_db(db: IQVPageROI_db):
    """
    Get the ET Element IQVPageROI_db with all of its subelements
    """

    try:
        root = ET.Element("IQVPageROI_db")
        ##############################################################
        #
        # Start of fields
        #
        ##############################################################
        _write_attribute(root, 'bIsCheckbox', _bool2str(db.bIsCheckbox))
        _write_attribute(root, 'bIsChecked', _bool2str(db.bIsChecked))
        _write_attribute(root, 'bIsImage', _bool2str(db.bIsImage))
        _write_attribute(root, 'bIsSharedString', _bool2str(db.bIsSharedString))
        _write_attribute(root, 'bNoTranslate', _bool2str(db.bNoTranslate))
        _write_attribute(root, 'bOutputImageCreated', _bool2str(db.bOutputImageCreated))
        _write_attribute(root, 'bScannedOCR', _bool2str(db.bScannedOCR))
        _write_attribute(root, 'BulletIndentationLevel', str(db.BulletIndentationLevel))
        _write_attribute(root, 'BulletTypeVal', str(db.BulletTypeVal))
        _write_attribute(root, 'CheckboxFill', str(db.CheckboxFill))
        _write_attribute(root, 'contentTypeVal', str(db.contentTypeVal))
        _write_attribute(root, 'doc_id', str(db.doc_id))
        _write_attribute(root, 'DocumentRelId', str(db.DocumentRelId))
        _write_attribute(root, 'DocumentSequenceIndex', str(db.DocumentSequenceIndex))
        _write_attribute(root, 'FooterSequence', str(db.FooterSequence))
        _write_attribute(root, 'group_type', str(db.group_type))
        _write_attribute(root, 'GT_ImageFilename', str(db.GT_ImageFilename))
        _write_attribute(root, 'GT_ScoreMatch', str(db.GT_ScoreMatch))
        _write_attribute(root, 'GT_TextMatch', str(db.GT_TextMatch))
        _write_attribute(root, 'hAlignmentVal', str(db.hAlignmentVal))
        _write_attribute(root, 'HeaderSequence', str(db.HeaderSequence))
        _write_attribute(root, 'hierarchy', str(db.hierarchy))
        _write_attribute(root, 'HorizontalResolution', str(db.HorizontalResolution))
        _write_attribute(root, 'htmlTagType', str(db.htmlTagType))
        _write_attribute(root, 'Hue', str(db.Hue))
        _write_attribute(root, 'id', str(db.id))
        _write_attribute(root, 'ImageFormatVal', str(db.ImageFormatVal))
        _write_attribute(root, 'ImageIndex', str(db.ImageIndex))
        _write_attribute(root, 'imagePaddingPixels', str(db.imagePaddingPixels))
        _write_attribute(root, 'imageScaling', str(db.imageScaling))
        _write_attribute(root, 'iqv_standard_term', str(db.iqv_standard_term))
        _write_attribute(root, 'IsCopyOfRoiId', str(db.IsCopyOfRoiId))
        _write_attribute(root, 'IsTableCell', _bool2str(db.IsTableCell))
        _write_attribute(root, 'link_id', str(db.link_id))
        _write_attribute(root, 'link_id_level2', str(db.link_id_level2))
        _write_attribute(root, 'link_id_level3', str(db.link_id_level3))
        _write_attribute(root, 'link_id_level4', str(db.link_id_level4))
        _write_attribute(root, 'link_id_level5', str(db.link_id_level5))
        _write_attribute(root, 'link_id_level6', str(db.link_id_level6))
        _write_attribute(root, 'link_id_subsection1', str(db.link_id_subsection1))
        _write_attribute(root, 'link_id_subsection2', str(db.link_id_subsection2))
        _write_attribute(root, 'link_id_subsection3', str(db.link_id_subsection3))
        _write_attribute(root, 'm_PARENT_ROI_TYPEVal', str(db.m_PARENT_ROI_TYPEVal))
        _write_attribute(root, 'm_ROI_TYPEVal', str(db.m_ROI_TYPEVal))
        _write_attribute(root, 'm_WORD_LAYOUTVal', str(db.m_WORD_LAYOUTVal))
        _write_attribute(root, 'OriginalROIHeightInches', str(db.OriginalROIHeightInches))
        _write_attribute(root, 'OriginalROIWidthInches', str(db.OriginalROIWidthInches))
        _write_attribute(root, 'OutputImageFilename', str(db.OutputImageFilename))
        _write_attribute(root, 'OutputImageFilename_Cleaned', str(db.OutputImageFilename_Cleaned))
        _write_attribute(root, 'OutputImageFilename_FinalImageProcessingOutput',
                         str(db.OutputImageFilename_FinalImageProcessingOutput))
        _write_attribute(root, 'OutputImageFilename_FinalImageProcessingOutputToDropBox',
                         str(db.OutputImageFilename_FinalImageProcessingOutputToDropBox))
        _write_attribute(root, 'OutputImageFilename_OriginalSegment', str(db.OutputImageFilename_OriginalSegment))
        _write_attribute(root, 'OutputImageFilename_RotationCorrection', str(db.OutputImageFilename_RotationCorrection))
        _write_attribute(root, 'OutputImageFilename_RotationCorrectionToDropBox',
                         str(db.OutputImageFilename_RotationCorrectionToDropBox))
        _write_attribute(root, 'OutputImageFilename_Segments', str(db.OutputImageFilename_Segments))
        _write_attribute(root, 'OutputImageFilename_SegmentsToDropBox', str(db.OutputImageFilename_SegmentsToDropBox))
        _write_attribute(root, 'OutputImageFilenameT', str(db.OutputImageFilenameT))
        _write_attribute(root, 'OutputImageFilenameTDropBox', str(db.OutputImageFilenameTDropBox))
        _write_attribute(root, 'PageID', str(db.PageID))
        _write_attribute(root, 'PageSequenceIndex', str(db.PageSequenceIndex))
        _write_attribute(root, 'parent_id', str(db.parent_id))
        _write_attribute(root, 'parentrectangle_height', str(db.parentrectangle_height))
        _write_attribute(root, 'parentrectangle_width', str(db.parentrectangle_width))
        _write_attribute(root, 'parentrectangle_x', str(db.parentrectangle_x))
        _write_attribute(root, 'parentrectangle_y', str(db.parentrectangle_y))
        _write_attribute(root, 'rectangle_height', str(db.rectangle_height))
        _write_attribute(root, 'rectangle_width', str(db.rectangle_width))
        _write_attribute(root, 'rectangle_x', str(db.rectangle_x))
        _write_attribute(root, 'rectangle_y', str(db.rectangle_y))
        _write_attribute(root, 'rectangleGlobalLocationOnPage_height', str(db.rectangleGlobalLocationOnPage_height))
        _write_attribute(root, 'rectangleGlobalLocationOnPage_width', str(db.rectangleGlobalLocationOnPage_width))
        _write_attribute(root, 'rectangleGlobalLocationOnPage_x', str(db.rectangleGlobalLocationOnPage_x))
        _write_attribute(root, 'rectangleGlobalLocationOnPage_y', str(db.rectangleGlobalLocationOnPage_y))
        _write_attribute(root, 'Rotation_MajorAxis', str(db.Rotation_MajorAxis))
        _write_attribute(root, 'RotationCorrectionDegrees', str(db.RotationCorrectionDegrees))
        _write_attribute(root, 'scannedOCRCode', str(db.scannedOCRCode))
        _write_attribute(root, 'Score', str(db.Score))
        _write_attribute(root, 'SegmentationMethodVal', str(db.SegmentationMethodVal))
        _write_attribute(root, 'SegmentationType', str(db.SegmentationType))
        _write_attribute(root, 'SequenceID', str(db.SequenceID))
        _write_attribute(root, 'SlideIndex', str(db.SlideIndex))
        _write_attribute(root, 'SlideRelationshipId', str(db.SlideRelationshipId))
        _write_attribute(root, 'strText', str(db.strText))
        _write_attribute(root, 'strTextTranslated', str(db.strTextTranslated))
        _write_attribute(root, 'tableCell_colIndex', str(db.tableCell_colIndex))
        _write_attribute(root, 'tableCell_pageIndex', str(db.tableCell_pageIndex))
        _write_attribute(root, 'tableCell_rowIndex', str(db.tableCell_rowIndex))
        _write_attribute(root, 'tableCell_SharedStringIndex', str(db.tableCell_SharedStringIndex))
        _write_attribute(root, 'tableCell_SheetCellReference', str(db.tableCell_SheetCellReference))
        _write_attribute(root, 'tableCell_SheetColIndex', str(db.tableCell_SheetColIndex))
        _write_attribute(root, 'tableCell_SheetName', str(db.tableCell_SheetName))
        _write_attribute(root, 'tableCell_SheetRowIndex', str(db.tableCell_SheetRowIndex))
        _write_attribute(root, 'textTypeVal', str(db.textTypeVal))
        _write_attribute(root, 'TranslatedTextNoSegmentation', str(db.TranslatedTextNoSegmentation))
        _write_attribute(root, 'TranslationMatch', str(db.TranslationMatch))
        _write_attribute(root, 'TranslationMethod1', str(db.TranslationMethod1))
        _write_attribute(root, 'UncorrectedImageFilename', str(db.UncorrectedImageFilename))
        _write_attribute(root, 'Value', str(db.Value))
        _write_attribute(root, 'VerticalResolution', str(db.VerticalResolution))
        ##############################################################
        #
        # End of fields
        #
        ##############################################################
        return root
    except Exception as e:
        logger.error('Failed to write IQVPageROI_db to root')


def _writeToXmlFromIQVDocumentLink_db(db: IQVDocumentLink_db):
    """
    Get the ET Element IQVDocumentLink_db with all of its subelements
    """

    try:
        root = ET.Element("IQVDocumentLink_db")
        ##############################################################
        #
        # Start of fields
        #
        ##############################################################
        _write_attribute(root, 'doc_id', str(db.doc_id))
        _write_attribute(root, 'DocumentSequenceIndex', str(db.DocumentSequenceIndex))
        _write_attribute(root, 'group_type', str(db.group_type))
        _write_attribute(root, 'hierarchy', str(db.hierarchy))
        _write_attribute(root, 'id', str(db.id))
        _write_attribute(root, 'iqv_standard_term', str(db.iqv_standard_term))
        _write_attribute(root, 'link_id', str(db.link_id))
        _write_attribute(root, 'link_id_level2', str(db.link_id_level2))
        _write_attribute(root, 'link_id_level3', str(db.link_id_level3))
        _write_attribute(root, 'link_id_level4', str(db.link_id_level4))
        _write_attribute(root, 'link_id_level5', str(db.link_id_level5))
        _write_attribute(root, 'link_id_level6', str(db.link_id_level6))
        _write_attribute(root, 'link_id_subsection1', str(db.link_id_subsection1))
        _write_attribute(root, 'link_id_subsection2', str(db.link_id_subsection2))
        _write_attribute(root, 'link_id_subsection3', str(db.link_id_subsection3))
        _write_attribute(root, 'LinkLevel', str(db.LinkLevel))
        _write_attribute(root, 'LinkPage', str(db.LinkPage))
        _write_attribute(root, 'LinkPrefix', str(db.LinkPrefix))
        _write_attribute(root, 'LinkText', str(db.LinkText))
        _write_attribute(root, 'LinkType', str(db.LinkType))
        _write_attribute(root, 'parent_id', str(db.parent_id))
        ##############################################################
        #
        # End of fields
        #
        ##############################################################
        return root
    except Exception as e:
        logger.error('Failed to write IQVDocumentLink_db to root')


def _writeToXmlFromIQVKeyValueSet_db(db: IQVKeyValueSet_db):
    """
    Get the ET Element IQVKeyValueSet_db with all of its subelements
    """

    try:
        root = ET.Element("IQVKeyValueSet_db")
        ##############################################################
        #
        # Start of fields
        #
        ##############################################################
        _write_attribute(root, 'confidence', str(db.confidence))
        _write_attribute(root, 'doc_id', str(db.doc_id))
        _write_attribute(root, 'group_type', str(db.group_type))
        _write_attribute(root, 'hierarchy', str(db.hierarchy))
        _write_attribute(root, 'id', str(db.id))
        _write_attribute(root, 'iqv_standard_term', str(db.iqv_standard_term))
        _write_attribute(root, 'key', str(db.key))
        _write_attribute(root, 'link_id', str(db.link_id))
        _write_attribute(root, 'link_id_level2', str(db.link_id_level2))
        _write_attribute(root, 'link_id_level3', str(db.link_id_level3))
        _write_attribute(root, 'link_id_level4', str(db.link_id_level4))
        _write_attribute(root, 'link_id_level5', str(db.link_id_level5))
        _write_attribute(root, 'link_id_level6', str(db.link_id_level6))
        _write_attribute(root, 'link_id_subsection1', str(db.link_id_subsection1))
        _write_attribute(root, 'link_id_subsection2', str(db.link_id_subsection2))
        _write_attribute(root, 'link_id_subsection3', str(db.link_id_subsection3))
        _write_attribute(root, 'parent_id', str(db.parent_id))
        _write_attribute(root, 'rawScore', str(db.rawScore))
        _write_attribute(root, 'source_system', str(db.source_system))
        _write_attribute(root, 'value', str(db.value))
        ##############################################################
        #
        # End of fields
        #
        ##############################################################
        return root
    except Exception as e:
        logger.error('Failed to write IQVKeyValueSet_db to root')


def _writeToXmlFromIQVQCUpdateTracking_db(db: IQVQCUpdateTracking_db):
    """
    Get the ET Element IQVQCUpdateTracking_db with all of its subelements
    """

    try:
        root = ET.Element("IQVQCUpdateTracking_db")
        ##############################################################
        #
        # Start of fields
        #
        ##############################################################
        _write_attribute(root, 'doc_id', str(db.doc_id))
        _write_attribute(root, 'dts', str(db.dts))
        _write_attribute(root, 'group_type', str(db.group_type))
        _write_attribute(root, 'hierarchy', str(db.hierarchy))
        _write_attribute(root, 'id', str(db.id))
        _write_attribute(root, 'iqv_standard_term', str(db.iqv_standard_term))
        _write_attribute(root, 'ItemDataType', str(db.ItemDataType))
        _write_attribute(root, 'link_id', str(db.link_id))
        _write_attribute(root, 'link_id_level2', str(db.link_id_level2))
        _write_attribute(root, 'link_id_level3', str(db.link_id_level3))
        _write_attribute(root, 'link_id_level4', str(db.link_id_level4))
        _write_attribute(root, 'link_id_level5', str(db.link_id_level5))
        _write_attribute(root, 'link_id_level6', str(db.link_id_level6))
        _write_attribute(root, 'link_id_subsection1', str(db.link_id_subsection1))
        _write_attribute(root, 'link_id_subsection2', str(db.link_id_subsection2))
        _write_attribute(root, 'link_id_subsection3', str(db.link_id_subsection3))
        _write_attribute(root, 'OriginalText', str(db.OriginalText))
        _write_attribute(root, 'parent_id', str(db.parent_id))
        _write_attribute(root, 'QC_id', str(db.QC_id))
        _write_attribute(root, 'QCType', str(db.QCType))
        _write_attribute(root, 'roi_id', str(db.roi_id))
        _write_attribute(root, 'seq_num', str(db.seq_num))
        _write_attribute(root, 'source_system', str(db.source_system))
        _write_attribute(root, 'UpdatedText', str(db.UpdatedText))
        _write_attribute(root, 'user_id', str(db.user_id))
        ##############################################################
        #
        # End of fields
        #
        ##############################################################
        return root
    except Exception as e:
        logger.error('Failed to write IQVQCUpdateTracking_db to root')


def _writeToXmlFromIQVDocumentProcess_db(db: IQVDocumentProcess_db):
    """
    Get the ET Element IQVDocumentProcess_db with all of its subelements
    """

    try:
        root = ET.Element("IQVDocumentProcess_db")
        ##############################################################
        #
        # Start of fields
        #
        ##############################################################
        _write_attribute(root, 'bProcessRequired', _bool2str(db.bProcessRequired))
        _write_attribute(root, 'doc_id', str(db.doc_id))
        _write_attribute(root, 'group_type', str(db.group_type))
        _write_attribute(root, 'hierarchy', str(db.hierarchy))
        _write_attribute(root, 'id', str(db.id))
        _write_attribute(root, 'iqv_standard_term', str(db.iqv_standard_term))
        _write_attribute(root, 'link_id', str(db.link_id))
        _write_attribute(root, 'link_id_level2', str(db.link_id_level2))
        _write_attribute(root, 'link_id_level3', str(db.link_id_level3))
        _write_attribute(root, 'link_id_level4', str(db.link_id_level4))
        _write_attribute(root, 'link_id_level5', str(db.link_id_level5))
        _write_attribute(root, 'link_id_level6', str(db.link_id_level6))
        _write_attribute(root, 'link_id_subsection1', str(db.link_id_subsection1))
        _write_attribute(root, 'link_id_subsection2', str(db.link_id_subsection2))
        _write_attribute(root, 'link_id_subsection3', str(db.link_id_subsection3))
        _write_attribute(root, 'parent_id', str(db.parent_id))
        _write_attribute(root, 'ProcessEnvironment', str(db.ProcessEnvironment))
        _write_attribute(root, 'ProcessFinishTime', str(db.ProcessFinishTime))
        _write_attribute(root, 'ProcessMachineName', str(db.ProcessMachineName))
        _write_attribute(root, 'ProcessName', str(db.ProcessName))
        _write_attribute(root, 'ProcessStartTime', str(db.ProcessStartTime))
        _write_attribute(root, 'ProcessType', str(db.ProcessType))
        _write_attribute(root, 'ProcessUserID', str(db.ProcessUserID))
        _write_attribute(root, 'ProcessVersion', str(db.ProcessVersion))
        _write_attribute(root, 'ProcessVersionHash', str(db.ProcessVersionHash))
        ##############################################################
        #
        # End of fields
        #
        ##############################################################
        return root
    except Exception as e:
        logger.error('Failed to write IQVDocumentProcess_db to root')


def _writeToXmlFromIQVSubText_db(db: IQVSubText_db):
    """
    Get the ET Element IQVSubText_db with all of its subelements
    """

    try:
        root = ET.Element("IQVSubText_db")
        ##############################################################
        #
        # Start of fields
        #
        ##############################################################
        _write_attribute(root, 'bNoTranslate', _bool2str(db.bNoTranslate))
        _write_attribute(root, 'doc_id', str(db.doc_id))
        _write_attribute(root, 'DocumentSequenceIndex', str(db.DocumentSequenceIndex))
        _write_attribute(root, 'group_type', str(db.group_type))
        _write_attribute(root, 'hierarchy', str(db.hierarchy))
        _write_attribute(root, 'id', str(db.id))
        _write_attribute(root, 'iqv_standard_term', str(db.iqv_standard_term))
        _write_attribute(root, 'link_id', str(db.link_id))
        _write_attribute(root, 'link_id_level2', str(db.link_id_level2))
        _write_attribute(root, 'link_id_level3', str(db.link_id_level3))
        _write_attribute(root, 'link_id_level4', str(db.link_id_level4))
        _write_attribute(root, 'link_id_level5', str(db.link_id_level5))
        _write_attribute(root, 'link_id_level6', str(db.link_id_level6))
        _write_attribute(root, 'link_id_subsection1', str(db.link_id_subsection1))
        _write_attribute(root, 'link_id_subsection2', str(db.link_id_subsection2))
        _write_attribute(root, 'link_id_subsection3', str(db.link_id_subsection3))
        _write_attribute(root, 'OuterXml', str(db.OuterXml))
        _write_attribute(root, 'parent_id', str(db.parent_id))
        _write_attribute(root, 'parent2LocalName', str(db.parent2LocalName))
        _write_attribute(root, 'reservedTypeVal', str(db.reservedTypeVal))
        _write_attribute(root, 'runElementName', str(db.runElementName))
        _write_attribute(root, 'sequence', str(db.sequence))
        _write_attribute(root, 'startCharIndex', str(db.startCharIndex))
        _write_attribute(root, 'strText', str(db.strText))
        _write_attribute(root, 'strTranslatedText', str(db.strTranslatedText))
        _write_attribute(root, 'Value', str(db.Value))
        ##############################################################
        #
        # End of fields
        #
        ##############################################################
        return root
    except Exception as e:
        logger.error('Failed to write IQVSubText_db to root')


def _writeToXmlFromIQVDocumentFeedbackQC_db(db: IQVDocumentFeedbackQC_db):
    """
    Get the ET Element IQVDocumentFeedbackQC_db with all of its subelements
    """

    try:
        root = ET.Element("IQVDocumentFeedbackQC_db")
        ##############################################################
        #
        # Start of fields
        #
        ##############################################################
        _write_attribute(root, 'bIsActive', _bool2str(db.bIsActive))
        _write_attribute(root, 'doc_id', str(db.doc_id))
        _write_attribute(root, 'documentFilePath', str(db.documentFilePath))
        _write_attribute(root, 'fileName', str(db.fileName))
        _write_attribute(root, 'group_type', str(db.group_type))
        _write_attribute(root, 'hierarchy', str(db.hierarchy))
        _write_attribute(root, 'id', str(db.id))
        _write_attribute(root, 'iqv_standard_term', str(db.iqv_standard_term))
        _write_attribute(root, 'link_id', str(db.link_id))
        _write_attribute(root, 'link_id_level2', str(db.link_id_level2))
        _write_attribute(root, 'link_id_level3', str(db.link_id_level3))
        _write_attribute(root, 'link_id_level4', str(db.link_id_level4))
        _write_attribute(root, 'link_id_level5', str(db.link_id_level5))
        _write_attribute(root, 'link_id_level6', str(db.link_id_level6))
        _write_attribute(root, 'link_id_subsection1', str(db.link_id_subsection1))
        _write_attribute(root, 'link_id_subsection2', str(db.link_id_subsection2))
        _write_attribute(root, 'link_id_subsection3', str(db.link_id_subsection3))
        _write_attribute(root, 'parent_id', str(db.parent_id))
        _write_attribute(root, 'source_system', str(db.source_system))
        _write_attribute(root, 'timeCreated', str(db.timeCreated))
        _write_attribute(root, 'timeUpdated', str(db.timeUpdated))
        _write_attribute(root, 'userId', str(db.userId))
        ##############################################################
        #
        # End of fields
        #
        ##############################################################
        return root
    except Exception as e:
        logger.error('Failed to write IQVDocumentFeedbackQC_db to root')


def _writeToXmlFromIQVDocumentFeedbackResults_db(db: IQVDocumentFeedbackResults_db):
    """
    Get the ET Element IQVDocumentFeedbackResults_db with all of its subelements
    """

    try:
        root = ET.Element("IQVDocumentFeedbackResults_db")
        ##############################################################
        #
        # Start of fields
        #
        ##############################################################
        _write_attribute(root, 'alcoac_check_composite_score', str(db.alcoac_check_composite_score))
        _write_attribute(root, 'alcoac_check_composite_score_confidence',
                         str(db.alcoac_check_composite_score_confidence))
        _write_attribute(root, 'amendment_number', str(db.amendment_number))
        _write_attribute(root, 'blinded', _bool2str(db.blinded))
        _write_attribute(root, 'country', str(db.country))
        _write_attribute(root, 'customer', str(db.customer))
        _write_attribute(root, 'date_time_stamp', str(db.date_time_stamp))
        _write_attribute(root, 'doc_id', str(db.doc_id))
        _write_attribute(root, 'document_class', str(db.document_class))
        _write_attribute(root, 'document_composite_confidence', str(db.document_composite_confidence))
        _write_attribute(root, 'document_date', str(db.document_date))
        _write_attribute(root, 'document_date_confidence', str(db.document_date_confidence))
        _write_attribute(root, 'document_date_type', str(db.document_date_type))
        _write_attribute(root, 'document_id', str(db.document_id))
        _write_attribute(root, 'document_rejected', str(db.document_rejected))
        _write_attribute(root, 'document_status', str(db.document_status))
        _write_attribute(root, 'draft_number', str(db.draft_number))
        _write_attribute(root, 'environment', str(db.environment))
        _write_attribute(root, 'expiry_date', str(db.expiry_date))
        _write_attribute(root, 'expiry_date_confidence', str(db.expiry_date_confidence))
        _write_attribute(root, 'feedback_source', str(db.feedback_source))
        _write_attribute(root, 'feedback_source_version', str(db.feedback_source_version))
        _write_attribute(root, 'group_type', str(db.group_type))
        _write_attribute(root, 'hierarchy', str(db.hierarchy))
        _write_attribute(root, 'id', str(db.id))
        _write_attribute(root, 'indication', str(db.indication))
        _write_attribute(root, 'iqv_standard_term', str(db.iqv_standard_term))
        _write_attribute(root, 'iqvdata', str(db.iqvdata))
        _write_attribute(root, 'language', str(db.language))
        _write_attribute(root, 'language_confidence', str(db.language_confidence))
        _write_attribute(root, 'link_id', str(db.link_id))
        _write_attribute(root, 'link_id_level2', str(db.link_id_level2))
        _write_attribute(root, 'link_id_level3', str(db.link_id_level3))
        _write_attribute(root, 'link_id_level4', str(db.link_id_level4))
        _write_attribute(root, 'link_id_level5', str(db.link_id_level5))
        _write_attribute(root, 'link_id_level6', str(db.link_id_level6))
        _write_attribute(root, 'link_id_subsection1', str(db.link_id_subsection1))
        _write_attribute(root, 'link_id_subsection2', str(db.link_id_subsection2))
        _write_attribute(root, 'link_id_subsection3', str(db.link_id_subsection3))
        _write_attribute(root, 'molecule_device', str(db.molecule_device))
        _write_attribute(root, 'name', str(db.name))
        _write_attribute(root, 'name_confidence', str(db.name_confidence))
        _write_attribute(root, 'parent_id', str(db.parent_id))
        _write_attribute(root, 'post_data', str(db.post_data))
        _write_attribute(root, 'priority', str(db.priority))
        _write_attribute(root, 'project_id', str(db.project_id))
        _write_attribute(root, 'protocol', str(db.protocol))
        _write_attribute(root, 'received_date', str(db.received_date))
        _write_attribute(root, 'ref_id', str(db.ref_id))
        _write_attribute(root, 'ref_id_type', str(db.ref_id_type))
        _write_attribute(root, 'site', str(db.site))
        _write_attribute(root, 'source_filename', str(db.source_filename))
        _write_attribute(root, 'source_system', str(db.source_system))
        _write_attribute(root, 'sponsor', str(db.sponsor))
        _write_attribute(root, 'study_status', str(db.study_status))
        _write_attribute(root, 'subject', str(db.subject))
        _write_attribute(root, 'subject_confidence', str(db.subject_confidence))
        _write_attribute(root, 'tmf_environment', str(db.tmf_environment))
        _write_attribute(root, 'tmf_ibr', str(db.tmf_ibr))
        _write_attribute(root, 'user_id', str(db.user_id))
        _write_attribute(root, 'version_number', str(db.version_number))
        ##############################################################
        #
        # End of fields
        #
        ##############################################################
        return root
    except Exception as e:
        logger.error('Failed to write IQVDocumentFeedbackResults_db to root')


def _writeToXmlFromIQVLanguageMapping_db(db: IQVLanguageMapping_db):
    """
    Get the ET Element IQVLanguageMapping_db with all of its subelements
    """

    try:
        root = ET.Element("IQVLanguageMapping_db")
        ##############################################################
        #
        # Start of fields
        #
        ##############################################################
        _write_attribute(root, 'HistoricalCount', str(db.HistoricalCount))
        _write_attribute(root, 'HistoricalCountWeight', str(db.HistoricalCountWeight))
        _write_attribute(root, 'id', str(db.id))
        _write_attribute(root, 'script_list', str(db.script_list))
        ##############################################################
        #
        # End of fields
        #
        ##############################################################
        return root
    except Exception as e:
        logger.error('Failed to write IQVLanguageMapping_db to root')


def _writeToXmlFromLanguageCode_db(db: LanguageCode_db):
    """
    Get the ET Element LanguageCode_db with all of its subelements
    """

    try:
        root = ET.Element("LanguageCode_db")
        ##############################################################
        #
        # Start of fields
        #
        ##############################################################
        _write_attribute(root, 'code', str(db.code))
        _write_attribute(root, 'description', str(db.description))
        _write_attribute(root, 'eTMFCode', str(db.eTMFCode))
        _write_attribute(root, 'fourLetterCode', str(db.fourLetterCode))
        _write_attribute(root, 'id', str(db.id))
        _write_attribute(root, 'ReleaseVersionAvailability', str(db.ReleaseVersionAvailability))
        _write_attribute(root, 'tesseractCode', str(db.tesseractCode))
        ##############################################################
        #
        # End of fields
        #
        ##############################################################
        return root
    except Exception as e:
        logger.error('Failed to write LanguageCode_db to root')


def _writeToXmlFromIQVDocumentMapping_db(db: IQVDocumentMapping_db):
    """
    Get the ET Element IQVDocumentMapping_db with all of its subelements
    """

    try:
        root = ET.Element("IQVDocumentMapping_db")
        ##############################################################
        #
        # Start of fields
        #
        ##############################################################
        _write_attribute(root, 'Additional_instructions', str(db.Additional_instructions))
        _write_attribute(root, 'CONTENT_TYPE', str(db.CONTENT_TYPE))
        _write_attribute(root, 'DateGuidance', str(db.DateGuidance))
        _write_attribute(root, 'DateGuidanceSecondary', str(db.DateGuidanceSecondary))
        _write_attribute(root, 'DIA_KEY', str(db.DIA_KEY))
        _write_attribute(root, 'DOC_ABBREVIATION', str(db.DOC_ABBREVIATION))
        _write_attribute(root, 'DOC_ARTIFACT', str(db.DOC_ARTIFACT))
        _write_attribute(root, 'DOC_CLASS', str(db.DOC_CLASS))
        _write_attribute(root, 'DOC_COUNT', str(db.DOC_COUNT))
        _write_attribute(root, 'DOC_COUNT_CURRENT', str(db.DOC_COUNT_CURRENT))
        _write_attribute(root, 'DOC_SECTION', str(db.DOC_SECTION))
        _write_attribute(root, 'DOC_ZONE', str(db.DOC_ZONE))
        _write_attribute(root, 'Document_Description', str(db.Document_Description))
        _write_attribute(root, 'ExpirationDateExpected', str(db.ExpirationDateExpected))
        _write_attribute(root, 'Full_Classification_Historical', str(db.Full_Classification_Historical))
        _write_attribute(root, 'Full_Classification_Wingspan', str(db.Full_Classification_Wingspan))
        _write_attribute(root, 'id', str(db.id))
        _write_attribute(root, 'MLClassificationGroup', str(db.MLClassificationGroup))
        _write_attribute(root, 'MLClassificationRole', str(db.MLClassificationRole))
        _write_attribute(root, 'MLConfusionCluster', str(db.MLConfusionCluster))
        _write_attribute(root, 'Subject', str(db.Subject))
        _write_attribute(root, 'Subtype', str(db.Subtype))
        _write_attribute(root, 'TargetSystemName', str(db.TargetSystemName))
        _write_attribute(root, 'TargetSystemVersion', str(db.TargetSystemVersion))
        _write_attribute(root, 'Wingspan_DIA', str(db.Wingspan_DIA))
        _write_attribute(root, 'Wingspan_Doc_ID', str(db.Wingspan_Doc_ID))
        _write_attribute(root, 'Wingspan_doc_type', str(db.Wingspan_doc_type))
        ##############################################################
        #
        # End of fields
        #
        ##############################################################
        return root
    except Exception as e:
        logger.error('Failed to write IQVDocumentMapping_db to root')


def _writeToXmlFromConfig_db(db: Config_db):
    """
    Get the ET Element Config_db with all of its subelements
    """

    try:
        root = ET.Element("Config_db")
        ##############################################################
        #
        # Start of fields
        #
        ##############################################################
        _write_attribute(root, 'AIDocQueue_IsAdmin', str(db.AIDocQueue_IsAdmin))
        _write_attribute(root, 'AIDocQueue_IsWorker', str(db.AIDocQueue_IsWorker))
        _write_attribute(root, 'AIDocQueue_NumWorkers', str(db.AIDocQueue_NumWorkers))
        _write_attribute(root, 'API_Endpoint', str(db.API_Endpoint))
        _write_attribute(root, 'API_Key', str(db.API_Key))
        _write_attribute(root, 'bClearWorkingDirectory', str(db.bClearWorkingDirectory))
        _write_attribute(root, 'bCorrectRotation', str(db.bCorrectRotation))
        _write_attribute(root, 'bDeleteAllFilesExceptFinalizerOutputFile',
                         _bool2str(db.bDeleteAllFilesExceptFinalizerOutputFile))
        _write_attribute(root, 'bDeleteInputSourceFile', _bool2str(db.bDeleteInputSourceFile))
        _write_attribute(root, 'bDeleteWorkingTempDirOnSuccessComplete', str(db.bDeleteWorkingTempDirOnSuccessComplete))
        _write_attribute(root, 'bDictionaryBernoulliSingleCounts', str(db.bDictionaryBernoulliSingleCounts))
        _write_attribute(root, 'bDocumentManagerEXE_CloseAfterProcessDocument',
                         str(db.bDocumentManagerEXE_CloseAfterProcessDocument))
        _write_attribute(root, 'bELK_EnableLogging', str(db.bELK_EnableLogging))
        _write_attribute(root, 'bMSG_EnableMessaging', str(db.bMSG_EnableMessaging))
        _write_attribute(root, 'bMSG_EnableMessaging_CompareProcessing', str(db.bMSG_EnableMessaging_CompareProcessing))
        _write_attribute(root, 'bMSG_EnableMessaging_Digitizer2Processing',
                         str(db.bMSG_EnableMessaging_Digitizer2Processing))
        _write_attribute(root, 'bMSG_EnableMessaging_OMOPGenerate', str(db.bMSG_EnableMessaging_OMOPGenerate))
        _write_attribute(root, 'bMSG_EnableMessaging_OMOPProcessing', str(db.bMSG_EnableMessaging_OMOPProcessing))
        _write_attribute(root, 'bMSG_EnableMessaging_QCFeedbackProcessing',
                         str(db.bMSG_EnableMessaging_QCFeedbackProcessing))
        _write_attribute(root, 'bNoiseGenGreyscale', _bool2str(db.bNoiseGenGreyscale))
        _write_attribute(root, 'bNoiseGenLegibility', _bool2str(db.bNoiseGenLegibility))
        _write_attribute(root, 'bNoiseGenPageBlanks', _bool2str(db.bNoiseGenPageBlanks))
        _write_attribute(root, 'bNoiseGenPageOrientation', _bool2str(db.bNoiseGenPageOrientation))
        _write_attribute(root, 'bNoiseGenPageSequence', _bool2str(db.bNoiseGenPageSequence))
        _write_attribute(root, 'bOCRRaiseErrorIfScan', str(db.bOCRRaiseErrorIfScan))
        _write_attribute(root, 'bOutput_OmopPrefixText', str(db.bOutput_OmopPrefixText))
        _write_attribute(root, 'bOutput_PrefixText', str(db.bOutput_PrefixText))
        _write_attribute(root, 'bOutput_QCFeedbackPrefixText', str(db.bOutput_QCFeedbackPrefixText))
        _write_attribute(root, 'bOutput_ToMetricsDir', str(db.bOutput_ToMetricsDir))
        _write_attribute(root, 'bProvideRemoteService', str(db.bProvideRemoteService))
        _write_attribute(root, 'bRunInternalOCRProcesses', str(db.bRunInternalOCRProcesses))
        _write_attribute(root, 'bRunPyIPOCRProcesses', str(db.bRunPyIPOCRProcesses))
        _write_attribute(root, 'bTMFGTOutputConstrained', _bool2str(db.bTMFGTOutputConstrained))
        _write_attribute(root, 'bUseDBConnection', str(db.bUseDBConnection))
        _write_attribute(root, 'bUseMTServer', str(db.bUseMTServer))
        _write_attribute(root, 'bUseSegServer', str(db.bUseSegServer))
        _write_attribute(root, 'bWatchLog_EnableWebserverRequests', str(db.bWatchLog_EnableWebserverRequests))
        _write_attribute(root, 'ConfigFilename', str(db.ConfigFilename))
        _write_attribute(root, 'CorpusLevel', str(db.CorpusLevel))
        _write_attribute(root, 'CorrectRotation_RotationIncrementDegrees',
                         str(db.CorrectRotation_RotationIncrementDegrees))
        _write_attribute(root, 'CorrectRotation_RotationRangeDegrees', str(db.CorrectRotation_RotationRangeDegrees))
        _write_attribute(root, 'CountryMappingFilename', str(db.CountryMappingFilename))
        _write_attribute(root, 'CustomHostName', str(db.CustomHostName))
        _write_attribute(root, 'DataSplit_TestPercent', str(db.DataSplit_TestPercent))
        _write_attribute(root, 'DataSplit_TrainingPercent', str(db.DataSplit_TrainingPercent))
        _write_attribute(root, 'DBConn_Database', str(db.DBConn_Database))
        _write_attribute(root, 'DBConn_Login', str(db.DBConn_Login))
        _write_attribute(root, 'DBConn_Password', str(db.DBConn_Password))
        _write_attribute(root, 'DBConn_Server', str(db.DBConn_Server))
        _write_attribute(root, 'DebugMode', str(db.DebugMode))
        _write_attribute(root, 'DebugType', str(db.DebugType))
        _write_attribute(root, 'DefaultRotation', str(db.DefaultRotation))
        _write_attribute(root, 'DictionarybRemoveCommonTerms', str(db.DictionarybRemoveCommonTerms))
        _write_attribute(root, 'DictionarybRemoveSparseTerms', str(db.DictionarybRemoveSparseTerms))
        _write_attribute(root, 'DictionaryIncludeAdditionalFeatures', str(db.DictionaryIncludeAdditionalFeatures))
        _write_attribute(root, 'DictionaryIncludeBigrams', str(db.DictionaryIncludeBigrams))
        _write_attribute(root, 'DictionaryIncludeLines', str(db.DictionaryIncludeLines))
        _write_attribute(root, 'DictionaryIncludeStopWords', str(db.DictionaryIncludeStopWords))
        _write_attribute(root, 'DictionaryIncludeTrigrams', str(db.DictionaryIncludeTrigrams))
        _write_attribute(root, 'DictionaryRemoveCommonTerms_MaxDocCount',
                         str(db.DictionaryRemoveCommonTerms_MaxDocCount))
        _write_attribute(root, 'DictionaryRemoveSparseTerms_MinDocCount',
                         str(db.DictionaryRemoveSparseTerms_MinDocCount))
        _write_attribute(root, 'Dig1CodePathFilename', str(db.Dig1CodePathFilename))
        _write_attribute(root, 'Dig1DocID', str(db.Dig1DocID))
        _write_attribute(root, 'DisplayLabel', str(db.DisplayLabel))
        _write_attribute(root, 'DOCANALYSIS_TrainedNaiveBayesLibFilename',
                         str(db.DOCANALYSIS_TrainedNaiveBayesLibFilename))
        _write_attribute(root, 'DocID', str(db.DocID))
        _write_attribute(root, 'DocID1', str(db.DocID1))
        _write_attribute(root, 'DocID2', str(db.DocID2))
        _write_attribute(root, 'DocumentManagerEXE', str(db.DocumentManagerEXE))
        _write_attribute(root, 'DocumentManagerVersion', str(db.DocumentManagerVersion))
        _write_attribute(root, 'DropBox1Dir', str(db.DropBox1Dir))
        _write_attribute(root, 'DropBoxWebUI', str(db.DropBoxWebUI))
        _write_attribute(root, 'ELK_HostName', str(db.ELK_HostName))
        _write_attribute(root, 'ELK_Port', str(db.ELK_Port))
        _write_attribute(root, 'ETMFDocumentSource', str(db.ETMFDocumentSource))
        _write_attribute(root, 'ETMFOutputDir', str(db.ETMFOutputDir))
        _write_attribute(root, 'ExcelTemplate_SOA', str(db.ExcelTemplate_SOA))
        _write_attribute(root, 'FileDownloadStartIndex', str(db.FileDownloadStartIndex))
        _write_attribute(root, 'flow_id', str(db.flow_id))
        _write_attribute(root, 'flow_name', str(db.flow_name))
        _write_attribute(root, 'GenerateNoise', str(db.GenerateNoise))
        _write_attribute(root, 'GhostscriptEXEFilename', str(db.GhostscriptEXEFilename))
        _write_attribute(root, 'GroundTruthMasterFilename', str(db.GroundTruthMasterFilename))
        _write_attribute(root, 'GroundTruthOutputDirectory', str(db.GroundTruthOutputDirectory))
        _write_attribute(root, 'id', str(db.id))
        _write_attribute(root, 'ImageProc_BulletImagesDir', str(db.ImageProc_BulletImagesDir))
        _write_attribute(root, 'ImageQC_GreyscaleThreshold', str(db.ImageQC_GreyscaleThreshold))
        _write_attribute(root, 'ImageQC_LegibilityThreshold', str(db.ImageQC_LegibilityThreshold))
        _write_attribute(root, 'ImagesDirectory', str(db.ImagesDirectory))
        _write_attribute(root, 'InputDataDirectory', str(db.InputDataDirectory))
        _write_attribute(root, 'InputImageFilename', str(db.InputImageFilename))
        _write_attribute(root, 'InputRawFilename', str(db.InputRawFilename))
        _write_attribute(root, 'InputSourceMasterFilename', str(db.InputSourceMasterFilename))
        _write_attribute(root, 'InputWorkingMasterFilename', str(db.InputWorkingMasterFilename))
        _write_attribute(root, 'IQVDocumentMappingFilename', str(db.IQVDocumentMappingFilename))
        _write_attribute(root, 'IQVEnvironment', str(db.IQVEnvironment))
        _write_attribute(root, 'IQVXML_DBConn_bUseDBConnection', str(db.IQVXML_DBConn_bUseDBConnection))
        _write_attribute(root, 'IQVXML_DBConn_Database', str(db.IQVXML_DBConn_Database))
        _write_attribute(root, 'IQVXML_DBConn_Login', str(db.IQVXML_DBConn_Login))
        _write_attribute(root, 'IQVXML_DBConn_Password', str(db.IQVXML_DBConn_Password))
        _write_attribute(root, 'IQVXML_DBConn_Port', str(db.IQVXML_DBConn_Port))
        _write_attribute(root, 'IQVXML_DBConn_Server', str(db.IQVXML_DBConn_Server))
        _write_attribute(root, 'IQVXMLInputFilename', str(db.IQVXMLInputFilename))
        _write_attribute(root, 'IQVXMLInputFilename2', str(db.IQVXMLInputFilename2))
        _write_attribute(root, 'LanguageAnalysisLib', str(db.LanguageAnalysisLib))
        _write_attribute(root, 'LocalTopLevelDataDir', str(db.LocalTopLevelDataDir))
        _write_attribute(root, 'LogDirectory', str(db.LogDirectory))
        _write_attribute(root, 'LogFilename', str(db.LogFilename))
        _write_attribute(root, 'MasterFile', str(db.MasterFile))
        _write_attribute(root, 'MasterIQVDocumentListFilename', str(db.MasterIQVDocumentListFilename))
        _write_attribute(root, 'MatrixFile', str(db.MatrixFile))
        _write_attribute(root, 'MaxCellsPerPage', str(db.MaxCellsPerPage))
        _write_attribute(root, 'MaxNumDocsToProcess', str(db.MaxNumDocsToProcess))
        _write_attribute(root, 'MaxPagesCoreProcessing_BackSection', str(db.MaxPagesCoreProcessing_BackSection))
        _write_attribute(root, 'MaxPagesCoreProcessing_FrontSection', str(db.MaxPagesCoreProcessing_FrontSection))
        _write_attribute(root, 'MaxPagesToProcess', str(db.MaxPagesToProcess))
        _write_attribute(root, 'MaxPagesToProcessIQVTM', str(db.MaxPagesToProcessIQVTM))
        _write_attribute(root, 'MaxTimeMinutesPerPage', str(db.MaxTimeMinutesPerPage))
        _write_attribute(root, 'MinPixelHeightForOCR', str(db.MinPixelHeightForOCR))
        _write_attribute(root, 'MinPixelHeightForValidImage', str(db.MinPixelHeightForValidImage))
        _write_attribute(root, 'MinPixelWidthForOCR', str(db.MinPixelWidthForOCR))
        _write_attribute(root, 'MinPixelWidthForValidImage', str(db.MinPixelWidthForValidImage))
        _write_attribute(root, 'MSG_ErrorLevelLowerBound', str(db.MSG_ErrorLevelLowerBound))
        _write_attribute(root, 'MSG_ExchangeIsDurable', str(db.MSG_ExchangeIsDurable))
        _write_attribute(root, 'MSG_HostName', str(db.MSG_HostName))
        _write_attribute(root, 'MSG_MaxCPU', str(db.MSG_MaxCPU))
        _write_attribute(root, 'MSG_MaxRAM', str(db.MSG_MaxRAM))
        _write_attribute(root, 'MSG_Password', str(db.MSG_Password))
        _write_attribute(root, 'MSG_Port', str(db.MSG_Port))
        _write_attribute(root, 'MSG_QueueIsDurable', str(db.MSG_QueueIsDurable))
        _write_attribute(root, 'MSG_User', str(db.MSG_User))
        _write_attribute(root, 'MSG_VirtualHost', str(db.MSG_VirtualHost))
        _write_attribute(root, 'MTServer_Endpoint', str(db.MTServer_Endpoint))
        _write_attribute(root, 'MTServer_LocalPathMapping', str(db.MTServer_LocalPathMapping))
        _write_attribute(root, 'MTServer_MachineName', str(db.MTServer_MachineName))
        _write_attribute(root, 'MTServer_Password', str(db.MTServer_Password))
        _write_attribute(root, 'MTServer_Port', str(db.MTServer_Port))
        _write_attribute(root, 'MTServer_SecureHTTP', str(db.MTServer_SecureHTTP))
        _write_attribute(root, 'MTServer_SharedDir', str(db.MTServer_SharedDir))
        _write_attribute(root, 'MTServer_User', str(db.MTServer_User))
        _write_attribute(root, 'NLP_CharMatrixDirectory', str(db.NLP_CharMatrixDirectory))
        _write_attribute(root, 'NLP_DictionaryDirectory', str(db.NLP_DictionaryDirectory))
        _write_attribute(root, 'NoiseGenMaxRecords', str(db.NoiseGenMaxRecords))
        _write_attribute(root, 'NoiseGenStartIndex', str(db.NoiseGenStartIndex))
        _write_attribute(root, 'NoiseType', str(db.NoiseType))
        _write_attribute(root, 'OCR_bUseSpellCheck', str(db.OCR_bUseSpellCheck))
        _write_attribute(root, 'OCR_SpellCheckDirectory', str(db.OCR_SpellCheckDirectory))
        _write_attribute(root, 'OCR_UserWordsDirectory', str(db.OCR_UserWordsDirectory))
        _write_attribute(root, 'OMOPUpdateFilename', str(db.OMOPUpdateFilename))
        _write_attribute(root, 'Output_OmopPrefixText', str(db.Output_OmopPrefixText))
        _write_attribute(root, 'Output_PrefixText', str(db.Output_PrefixText))
        _write_attribute(root, 'Output_QCFeedbackPrefixText', str(db.Output_QCFeedbackPrefixText))
        _write_attribute(root, 'Output_ToCompareDir', str(db.Output_ToCompareDir))
        _write_attribute(root, 'Output_ToMetricsDir', str(db.Output_ToMetricsDir))
        _write_attribute(root, 'OutputDirectory', str(db.OutputDirectory))
        _write_attribute(root, 'OutputFilename', str(db.OutputFilename))
        _write_attribute(root, 'OutputLevel', str(db.OutputLevel))
        _write_attribute(root, 'PageIndex', str(db.PageIndex))
        _write_attribute(root, 'PerformBatchDocClass', str(db.PerformBatchDocClass))
        _write_attribute(root, 'PerformDocumentDeconstruction', str(db.PerformDocumentDeconstruction))
        _write_attribute(root, 'PerformDocumentReconstruction', str(db.PerformDocumentReconstruction))
        _write_attribute(root, 'PerformDuplicateCheck', str(db.PerformDuplicateCheck))
        _write_attribute(root, 'PerformImageQC', str(db.PerformImageQC))
        _write_attribute(root, 'PerformMetadata', str(db.PerformMetadata))
        _write_attribute(root, 'PerformRotations', str(db.PerformRotations))
        _write_attribute(root, 'PerformXLIFFReceive', str(db.PerformXLIFFReceive))
        _write_attribute(root, 'PerformXLIFFSend', str(db.PerformXLIFFSend))
        _write_attribute(root, 'PerformXLIFFSourceCreation', str(db.PerformXLIFFSourceCreation))
        _write_attribute(root, 'Priority', str(db.Priority))
        _write_attribute(root, 'ProcessSource', str(db.ProcessSource))
        _write_attribute(root, 'PythonEnvironment', str(db.PythonEnvironment))
        _write_attribute(root, 'PythonEXEFilename', str(db.PythonEXEFilename))
        _write_attribute(root, 'QCFeedbackJSONFilename', str(db.QCFeedbackJSONFilename))
        _write_attribute(root, 'QCFeedbackRunId', str(db.QCFeedbackRunId))
        _write_attribute(root, 'Recon_bUseTemplateMatching', str(db.Recon_bUseTemplateMatching))
        _write_attribute(root, 'Recon_TemplateDirectory', str(db.Recon_TemplateDirectory))
        _write_attribute(root, 'Recon_TemplateFilename', str(db.Recon_TemplateFilename))
        _write_attribute(root, 'RedactionProfileID', str(db.RedactionProfileID))
        _write_attribute(root, 'RedactionProfileListingFilename', str(db.RedactionProfileListingFilename))
        _write_attribute(root, 'RedactionReplacementMethod', str(db.RedactionReplacementMethod))
        _write_attribute(root, 'RedactionTextMask', str(db.RedactionTextMask))
        _write_attribute(root, 'RedactionTextPrefix', str(db.RedactionTextPrefix))
        _write_attribute(root, 'RedactionTextSuffix', str(db.RedactionTextSuffix))
        _write_attribute(root, 'RemoteServer_MachineName', str(db.RemoteServer_MachineName))
        _write_attribute(root, 'RemoteServer_Port', str(db.RemoteServer_Port))
        _write_attribute(root, 'RemoteServer_ServerLocalDir', str(db.RemoteServer_ServerLocalDir))
        _write_attribute(root, 'RemoteServer_SharedDir', str(db.RemoteServer_SharedDir))
        _write_attribute(root, 'Rotation', str(db.Rotation))
        _write_attribute(root, 'RunRemote', _bool2str(db.RunRemote))
        _write_attribute(root, 'SegmentationType', str(db.SegmentationType))
        _write_attribute(root, 'SegServer_Endpoint', str(db.SegServer_Endpoint))
        _write_attribute(root, 'SegServer_LocalPathMapping', str(db.SegServer_LocalPathMapping))
        _write_attribute(root, 'SegServer_MachineName', str(db.SegServer_MachineName))
        _write_attribute(root, 'SegServer_Port', str(db.SegServer_Port))
        _write_attribute(root, 'SegServer_SecureHTTP', str(db.SegServer_SecureHTTP))
        _write_attribute(root, 'SegServer_SharedDir', str(db.SegServer_SharedDir))
        _write_attribute(root, 'ShowProgressForm', str(db.ShowProgressForm))
        _write_attribute(root, 'sofficeLocation', str(db.sofficeLocation))
        _write_attribute(root, 'SourceLanguage', str(db.SourceLanguage))
        _write_attribute(root, 'StandardTemplateIQVXML', str(db.StandardTemplateIQVXML))
        _write_attribute(root, 'TargetLanguage', str(db.TargetLanguage))
        _write_attribute(root, 'tessdataDir', str(db.tessdataDir))
        _write_attribute(root, 'TesseractEXEFilename', str(db.TesseractEXEFilename))
        _write_attribute(root, 'TMFGTOutputConstrained_AvgPages', str(db.TMFGTOutputConstrained_AvgPages))
        _write_attribute(root, 'TMFGTOutputConstrained_MinSamples', str(db.TMFGTOutputConstrained_MinSamples))
        _write_attribute(root, 'TMFRawDataSourceDirectory', str(db.TMFRawDataSourceDirectory))
        _write_attribute(root, 'TMSServer_Endpoint', str(db.TMSServer_Endpoint))
        _write_attribute(root, 'TMSServer_Info', str(db.TMSServer_Info))
        _write_attribute(root, 'TMSServer_MachineName', str(db.TMSServer_MachineName))
        _write_attribute(root, 'TMSServer_Port', str(db.TMSServer_Port))
        _write_attribute(root, 'UserEmail', str(db.UserEmail))
        _write_attribute(root, 'UserID', str(db.UserID))
        _write_attribute(root, 'WatchLogCheckIntervalSeconds', str(db.WatchLogCheckIntervalSeconds))
        _write_attribute(root, 'WatchLogFilename', str(db.WatchLogFilename))
        _write_attribute(root, 'WatchLogOutputDir', str(db.WatchLogOutputDir))
        _write_attribute(root, 'WorkingDirectory', str(db.WorkingDirectory))
        _write_attribute(root, 'XLIFFInputFilename', str(db.XLIFFInputFilename))
        _write_attribute(root, 'XLIFFMarkupVersion', str(db.XLIFFMarkupVersion))
        ##############################################################
        #
        # End of fields
        #
        ##############################################################
        return root
    except Exception as e:
        logger.error('Failed to write Config_db to root')


def _writeToXmlFromFontInfo_db(db: FontInfo_db):
    """
    Get the ET Element FontInfo_db with all of its subelements
    """

    try:
        root = ET.Element("FontInfo_db")
        ##############################################################
        #
        # Start of fields
        #
        ##############################################################
        _write_attribute(root, 'Bold', _bool2str(db.Bold))
        _write_attribute(root, 'Caps', _bool2str(db.Caps))
        _write_attribute(root, 'ColorRGB', str(db.ColorRGB))
        _write_attribute(root, 'doc_id', str(db.doc_id))
        _write_attribute(root, 'DStrike', _bool2str(db.DStrike))
        _write_attribute(root, 'Emboss', _bool2str(db.Emboss))
        _write_attribute(root, 'group_type', str(db.group_type))
        _write_attribute(root, 'hierarchy', str(db.hierarchy))
        _write_attribute(root, 'Highlight', str(db.Highlight))
        _write_attribute(root, 'id', str(db.id))
        _write_attribute(root, 'Imprint', _bool2str(db.Imprint))
        _write_attribute(root, 'iqv_standard_term', str(db.iqv_standard_term))
        _write_attribute(root, 'Italics', _bool2str(db.Italics))
        _write_attribute(root, 'link_id', str(db.link_id))
        _write_attribute(root, 'link_id_level2', str(db.link_id_level2))
        _write_attribute(root, 'link_id_level3', str(db.link_id_level3))
        _write_attribute(root, 'link_id_level4', str(db.link_id_level4))
        _write_attribute(root, 'link_id_level5', str(db.link_id_level5))
        _write_attribute(root, 'link_id_level6', str(db.link_id_level6))
        _write_attribute(root, 'link_id_subsection1', str(db.link_id_subsection1))
        _write_attribute(root, 'link_id_subsection2', str(db.link_id_subsection2))
        _write_attribute(root, 'link_id_subsection3', str(db.link_id_subsection3))
        _write_attribute(root, 'Outline', _bool2str(db.Outline))
        _write_attribute(root, 'parent_id', str(db.parent_id))
        _write_attribute(root, 'rFonts', str(db.rFonts))
        _write_attribute(root, 'rStyle', str(db.rStyle))
        _write_attribute(root, 'Shadow', _bool2str(db.Shadow))
        _write_attribute(root, 'Size', str(db.Size))
        _write_attribute(root, 'SmallCaps', _bool2str(db.SmallCaps))
        _write_attribute(root, 'Strike', _bool2str(db.Strike))
        _write_attribute(root, 'Underline', str(db.Underline))
        _write_attribute(root, 'Vanish', _bool2str(db.Vanish))
        _write_attribute(root, 'VertAlign', str(db.VertAlign))
        ##############################################################
        #
        # End of fields
        #
        ##############################################################
        return root
    except Exception as e:
        logger.error('Failed to write FontInfo_db to root')


def _writeToXmlFromIQVAttribute_db(db: IQVAttribute_db):
    """
    Get the ET Element IQVAttribute_db with all of its subelements
    """

    try:
        root = ET.Element("IQVAttribute_db")
        ##############################################################
        #
        # Start of fields
        #
        ##############################################################
        _write_attribute(root, 'doc_id', str(db.doc_id))
        _write_attribute(root, 'group_type', str(db.group_type))
        _write_attribute(root, 'hierarchy', str(db.hierarchy))
        _write_attribute(root, 'id', str(db.id))
        _write_attribute(root, 'iqv_standard_term', str(db.iqv_standard_term))
        _write_attribute(root, 'link_id', str(db.link_id))
        _write_attribute(root, 'link_id_level2', str(db.link_id_level2))
        _write_attribute(root, 'link_id_level3', str(db.link_id_level3))
        _write_attribute(root, 'link_id_level4', str(db.link_id_level4))
        _write_attribute(root, 'link_id_level5', str(db.link_id_level5))
        _write_attribute(root, 'link_id_level6', str(db.link_id_level6))
        _write_attribute(root, 'link_id_subsection1', str(db.link_id_subsection1))
        _write_attribute(root, 'link_id_subsection2', str(db.link_id_subsection2))
        _write_attribute(root, 'link_id_subsection3', str(db.link_id_subsection3))
        _write_attribute(root, 'LocalName', str(db.LocalName))
        _write_attribute(root, 'Name', str(db.Name))
        _write_attribute(root, 'parent_id', str(db.parent_id))
        _write_attribute(root, 'Value', str(db.Value))
        ##############################################################
        #
        # End of fields
        #
        ##############################################################
        return root
    except Exception as e:
        logger.error('Failed to write IQVAttribute_db to root')


def _writeToXmlFromIQVAttributeCandidate_db(db: IQVAttributeCandidate_db):
    """
    Get the ET Element IQVAttributeCandidate_db with all of its subelements
    """

    try:
        root = ET.Element("IQVAttributeCandidate_db")
        ##############################################################
        #
        # Start of fields
        #
        ##############################################################
        _write_attribute(root, 'AttributeKey', str(db.AttributeKey))
        _write_attribute(root, 'AttributeValue', str(db.AttributeValue))
        _write_attribute(root, 'CandidateSelected', str(db.CandidateSelected))
        _write_attribute(root, 'doc_id', str(db.doc_id))
        _write_attribute(root, 'group_type', str(db.group_type))
        _write_attribute(root, 'hierarchy', str(db.hierarchy))
        _write_attribute(root, 'id', str(db.id))
        _write_attribute(root, 'iqv_standard_term', str(db.iqv_standard_term))
        _write_attribute(root, 'link_id', str(db.link_id))
        _write_attribute(root, 'link_id_level2', str(db.link_id_level2))
        _write_attribute(root, 'link_id_level3', str(db.link_id_level3))
        _write_attribute(root, 'link_id_level4', str(db.link_id_level4))
        _write_attribute(root, 'link_id_level5', str(db.link_id_level5))
        _write_attribute(root, 'link_id_level6', str(db.link_id_level6))
        _write_attribute(root, 'link_id_subsection1', str(db.link_id_subsection1))
        _write_attribute(root, 'link_id_subsection2', str(db.link_id_subsection2))
        _write_attribute(root, 'link_id_subsection3', str(db.link_id_subsection3))
        _write_attribute(root, 'parent_id', str(db.parent_id))
        _write_attribute(root, 'RawProbabilitiyScore', str(db.RawProbabilitiyScore))
        _write_attribute(root, 'roi_id', str(db.roi_id))
        ##############################################################
        #
        # End of fields
        #
        ##############################################################
        return root
    except Exception as e:
        logger.error('Failed to write IQVAttributeCandidate_db to root')


def _writeToXmlFromIQVCharacter_db(db: IQVCharacter_db):
    """
    Get the ET Element IQVCharacter_db with all of its subelements
    """

    try:
        root = ET.Element("IQVCharacter_db")
        ##############################################################
        #
        # Start of fields
        #
        ##############################################################
        _write_attribute(root, 'Bottom', str(db.Bottom))
        _write_attribute(root, 'doc_id', str(db.doc_id))
        _write_attribute(root, 'group_type', str(db.group_type))
        _write_attribute(root, 'hierarchy', str(db.hierarchy))
        _write_attribute(root, 'id', str(db.id))
        _write_attribute(root, 'iqv_standard_term', str(db.iqv_standard_term))
        _write_attribute(root, 'Left', str(db.Left))
        _write_attribute(root, 'link_id', str(db.link_id))
        _write_attribute(root, 'link_id_level2', str(db.link_id_level2))
        _write_attribute(root, 'link_id_level3', str(db.link_id_level3))
        _write_attribute(root, 'link_id_level4', str(db.link_id_level4))
        _write_attribute(root, 'link_id_level5', str(db.link_id_level5))
        _write_attribute(root, 'link_id_level6', str(db.link_id_level6))
        _write_attribute(root, 'link_id_subsection1', str(db.link_id_subsection1))
        _write_attribute(root, 'link_id_subsection2', str(db.link_id_subsection2))
        _write_attribute(root, 'link_id_subsection3', str(db.link_id_subsection3))
        _write_attribute(root, 'parent_id', str(db.parent_id))
        _write_attribute(root, 'Right', str(db.Right))
        _write_attribute(root, 'Tag', str(db.Tag))
        _write_attribute(root, 'Top', str(db.Top))
        _write_attribute(root, 'Value', str(db.Value))
        ##############################################################
        #
        # End of fields
        #
        ##############################################################
        return root
    except Exception as e:
        logger.error('Failed to write IQVCharacter_db to root')


def _writeToXmlFromIQVWord_db(db: IQVWord_db):
    """
    Get the ET Element IQVWord_db with all of its subelements
    """

    try:
        root = ET.Element("IQVWord_db")
        ##############################################################
        #
        # Start of fields
        #
        ##############################################################
        _write_attribute(root, 'Blanks', str(db.Blanks))
        _write_attribute(root, 'BlockIndex', str(db.BlockIndex))
        _write_attribute(root, 'Bottom', str(db.Bottom))
        _write_attribute(root, 'Class', str(db.Class))
        _write_attribute(root, 'Confidence', str(db.Confidence))
        _write_attribute(root, 'doc_id', str(db.doc_id))
        _write_attribute(root, 'FontIndex', str(db.FontIndex))
        _write_attribute(root, 'FontName', str(db.FontName))
        _write_attribute(root, 'Formating', str(db.Formating))
        _write_attribute(root, 'group_type', str(db.group_type))
        _write_attribute(root, 'GT_ScoreMatch', str(db.GT_ScoreMatch))
        _write_attribute(root, 'GT_TextMatch', str(db.GT_TextMatch))
        _write_attribute(root, 'hierarchy', str(db.hierarchy))
        _write_attribute(root, 'id', str(db.id))
        _write_attribute(root, 'iqv_standard_term', str(db.iqv_standard_term))
        _write_attribute(root, 'Left', str(db.Left))
        _write_attribute(root, 'LineIndex', str(db.LineIndex))
        _write_attribute(root, 'link_id', str(db.link_id))
        _write_attribute(root, 'link_id_level2', str(db.link_id_level2))
        _write_attribute(root, 'link_id_level3', str(db.link_id_level3))
        _write_attribute(root, 'link_id_level4', str(db.link_id_level4))
        _write_attribute(root, 'link_id_level5', str(db.link_id_level5))
        _write_attribute(root, 'link_id_level6', str(db.link_id_level6))
        _write_attribute(root, 'link_id_subsection1', str(db.link_id_subsection1))
        _write_attribute(root, 'link_id_subsection2', str(db.link_id_subsection2))
        _write_attribute(root, 'link_id_subsection3', str(db.link_id_subsection3))
        _write_attribute(root, 'NLP_ScoreMatch', str(db.NLP_ScoreMatch))
        _write_attribute(root, 'NLP_TextMatch', str(db.NLP_TextMatch))
        _write_attribute(root, 'NLP_TextMatchReconstructed', str(db.NLP_TextMatchReconstructed))
        _write_attribute(root, 'parent_id', str(db.parent_id))
        _write_attribute(root, 'PointSize', str(db.PointSize))
        _write_attribute(root, 'Right', str(db.Right))
        _write_attribute(root, 'Tag', str(db.Tag))
        _write_attribute(root, 'Text', str(db.Text))
        _write_attribute(root, 'textangle', str(db.textangle))
        _write_attribute(root, 'TextDerivedCase', str(db.TextDerivedCase))
        _write_attribute(root, 'TextDerivedDeconstructed', str(db.TextDerivedDeconstructed))
        _write_attribute(root, 'TextDerivedIsNumeric', str(db.TextDerivedIsNumeric))
        _write_attribute(root, 'TextDerivedPrefix', str(db.TextDerivedPrefix))
        _write_attribute(root, 'TextDerivedSuffix', str(db.TextDerivedSuffix))
        _write_attribute(root, 'TextLanguage', str(db.TextLanguage))
        _write_attribute(root, 'Top', str(db.Top))
        _write_attribute(root, 'WordIndex', str(db.WordIndex))
        ##############################################################
        #
        # End of fields
        #
        ##############################################################
        return root
    except Exception as e:
        logger.error('Failed to write IQVWord_db to root')


def _writeToXmlFromIQVClassifierModel_db(db: IQVClassifierModel_db):
    """
    Get the ET Element IQVClassifierModel_db with all of its subelements
    """

    try:
        root = ET.Element("IQVClassifierModel_db")
        ##############################################################
        #
        # Start of fields
        #
        ##############################################################
        _write_attribute(root, 'Base_Model_Version', str(db.Base_Model_Version))
        _write_attribute(root, 'Country', str(db.Country))
        _write_attribute(root, 'Doc_Class', str(db.Doc_Class))

        fieldName = 'Full_Classification_List_list'
        try:
            subelement = ET.SubElement(root, fieldName)
            for xelm in db.Full_Classification_List_list:
                subelement.append(_writeToXmlFromString(xelm))
        except Exception as e:
            logger.info('Failed to export field ' + fieldName)
        _write_attribute(root, 'id', str(db.id))
        _write_attribute(root, 'Language', str(db.Language))
        _write_attribute(root, 'Model_Directory', str(db.Model_Directory))
        _write_attribute(root, 'Model_Index', str(db.Model_Index))
        _write_attribute(root, 'Model_Label', str(db.Model_Label))
        _write_attribute(root, 'Model_Name', str(db.Model_Name))
        _write_attribute(root, 'Model_Sequence', str(db.Model_Sequence))
        ##############################################################
        #
        # End of fields
        #
        ##############################################################
        return root
    except Exception as e:
        logger.error('Failed to write IQVClassifierModel_db to root')


def _writeToXmlFromIQVCountryMapping_db(db: IQVCountryMapping_db):
    """
    Get the ET Element IQVCountryMapping_db with all of its subelements
    """

    try:
        root = ET.Element("IQVCountryMapping_db")
        ##############################################################
        #
        # Start of fields
        #
        ##############################################################
        _write_attribute(root, 'Country', str(db.Country))

        fieldName = 'DateFormats_list'
        try:
            subelement = ET.SubElement(root, fieldName)
            for xelm in db.DateFormats_list:
                subelement.append(_writeToXmlFromString(xelm))
        except Exception as e:
            logger.info('Failed to export field ' + fieldName)
        _write_attribute(root, 'id', str(db.id))
        ##############################################################
        #
        # End of fields
        #
        ##############################################################
        return root
    except Exception as e:
        logger.error('Failed to write IQVCountryMapping_db to root')


def _writeToXmlFromIQVDocumentCompare_db(db: IQVDocumentCompare_db):
    """
    Get the ET Element IQVDocumentCompare_db with all of its subelements
    """

    try:
        root = ET.Element("IQVDocumentCompare_db")
        ##############################################################
        #
        # Start of fields
        #
        ##############################################################
        _write_attribute(root, 'base_doc_id', str(db.base_doc_id))
        _write_attribute(root, 'base_doc_name', str(db.base_doc_name))
        _write_attribute(root, 'compare_doc_id', str(db.compare_doc_id))
        _write_attribute(root, 'compare_doc_name', str(db.compare_doc_name))
        _write_attribute(root, 'id', str(db.id))
        _write_attribute(root, 'redaction_profile_id', str(db.redaction_profile_id))
        ##############################################################
        #
        # End of fields
        #
        ##############################################################
        return root
    except Exception as e:
        logger.error('Failed to write IQVDocumentCompare_db to root')


def _writeToXmlFromIQVDocumentDiff_db(db: IQVDocumentDiff_db):
    """
    Get the ET Element IQVDocumentDiff_db with all of its subelements
    """

    try:
        root = ET.Element("IQVDocumentDiff_db")
        ##############################################################
        #
        # Start of fields
        #
        ##############################################################
        _write_attribute(root, 'compare_roi_id', str(db.compare_roi_id))
        _write_attribute(root, 'confidence', str(db.confidence))
        _write_attribute(root, 'diff_category', str(db.diff_category))
        _write_attribute(root, 'diff_string', str(db.diff_string))
        _write_attribute(root, 'diff_subcategory', str(db.diff_subcategory))
        _write_attribute(root, 'diff_type', str(db.diff_type))
        _write_attribute(root, 'id', str(db.id))
        _write_attribute(root, 'IsPreferredTermComparison', _bool2str(db.IsPreferredTermComparison))
        _write_attribute(root, 'local_roi_id', str(db.local_roi_id))
        ##############################################################
        #
        # End of fields
        #
        ##############################################################
        return root
    except Exception as e:
        logger.error('Failed to write IQVDocumentDiff_db to root')


def _writeToXmlFromIQVExternalLink_db(db: IQVExternalLink_db):
    """
    Get the ET Element IQVExternalLink_db with all of its subelements
    """

    try:
        root = ET.Element("IQVExternalLink_db")
        ##############################################################
        #
        # Start of fields
        #
        ##############################################################
        _write_attribute(root, 'connection_type', str(db.connection_type))
        _write_attribute(root, 'destination_link_id', str(db.destination_link_id))
        _write_attribute(root, 'destination_link_prefix', str(db.destination_link_prefix))
        _write_attribute(root, 'destination_link_text', str(db.destination_link_text))
        _write_attribute(root, 'destination_url', str(db.destination_url))
        _write_attribute(root, 'doc_id', str(db.doc_id))
        _write_attribute(root, 'group_type', str(db.group_type))
        _write_attribute(root, 'hierarchy', str(db.hierarchy))
        _write_attribute(root, 'id', str(db.id))
        _write_attribute(root, 'iqv_standard_term', str(db.iqv_standard_term))
        _write_attribute(root, 'length', str(db.length))
        _write_attribute(root, 'link_id', str(db.link_id))
        _write_attribute(root, 'link_id_level2', str(db.link_id_level2))
        _write_attribute(root, 'link_id_level3', str(db.link_id_level3))
        _write_attribute(root, 'link_id_level4', str(db.link_id_level4))
        _write_attribute(root, 'link_id_level5', str(db.link_id_level5))
        _write_attribute(root, 'link_id_level6', str(db.link_id_level6))
        _write_attribute(root, 'link_id_subsection1', str(db.link_id_subsection1))
        _write_attribute(root, 'link_id_subsection2', str(db.link_id_subsection2))
        _write_attribute(root, 'link_id_subsection3', str(db.link_id_subsection3))
        _write_attribute(root, 'link_text', str(db.link_text))
        _write_attribute(root, 'parent_id', str(db.parent_id))
        _write_attribute(root, 'source_text', str(db.source_text))
        _write_attribute(root, 'startIndex', str(db.startIndex))
        ##############################################################
        #
        # End of fields
        #
        ##############################################################
        return root
    except Exception as e:
        logger.error('Failed to write IQVExternalLink_db to root')


def _writeToXmlFromIQVExternalLinkElement_db(db: IQVExternalLinkElement_db):
    """
    Get the ET Element IQVExternalLinkElement_db with all of its subelements
    """

    try:
        root = ET.Element("IQVExternalLinkElement_db")
        ##############################################################
        #
        # Start of fields
        #
        ##############################################################
        _write_attribute(root, 'doc_id', str(db.doc_id))
        _write_attribute(root, 'group_type', str(db.group_type))
        _write_attribute(root, 'hierarchy', str(db.hierarchy))
        _write_attribute(root, 'id', str(db.id))
        _write_attribute(root, 'iqv_standard_term', str(db.iqv_standard_term))
        _write_attribute(root, 'length', str(db.length))
        _write_attribute(root, 'link_id', str(db.link_id))
        _write_attribute(root, 'link_id_level2', str(db.link_id_level2))
        _write_attribute(root, 'link_id_level3', str(db.link_id_level3))
        _write_attribute(root, 'link_id_level4', str(db.link_id_level4))
        _write_attribute(root, 'link_id_level5', str(db.link_id_level5))
        _write_attribute(root, 'link_id_level6', str(db.link_id_level6))
        _write_attribute(root, 'link_id_subsection1', str(db.link_id_subsection1))
        _write_attribute(root, 'link_id_subsection2', str(db.link_id_subsection2))
        _write_attribute(root, 'link_id_subsection3', str(db.link_id_subsection3))
        _write_attribute(root, 'parent_id', str(db.parent_id))
        _write_attribute(root, 'startIndex', str(db.startIndex))
        _write_attribute(root, 'text', str(db.text))
        ##############################################################
        #
        # End of fields
        #
        ##############################################################
        return root
    except Exception as e:
        logger.error('Failed to write IQVExternalLinkElement_db to root')


def _writeToXmlFromIQVLine_db(db: IQVLine_db):
    """
    Get the ET Element IQVLine_db with all of its subelements
    """

    try:
        root = ET.Element("IQVLine_db")
        ##############################################################
        #
        # Start of fields
        #
        ##############################################################
        _write_attribute(root, 'BackgroundToForeground', _bool2str(db.BackgroundToForeground))
        _write_attribute(root, 'bIncludedInBox', _bool2str(db.bIncludedInBox))
        _write_attribute(root, 'bIsHorizontal', _bool2str(db.bIsHorizontal))
        _write_attribute(root, 'doc_id', str(db.doc_id))
        _write_attribute(root, 'ForegroundToBackground', _bool2str(db.ForegroundToBackground))
        _write_attribute(root, 'group_type', str(db.group_type))
        _write_attribute(root, 'hierarchy', str(db.hierarchy))
        _write_attribute(root, 'id', str(db.id))
        _write_attribute(root, 'iqv_standard_term', str(db.iqv_standard_term))
        _write_attribute(root, 'link_id', str(db.link_id))
        _write_attribute(root, 'link_id_level2', str(db.link_id_level2))
        _write_attribute(root, 'link_id_level3', str(db.link_id_level3))
        _write_attribute(root, 'link_id_level4', str(db.link_id_level4))
        _write_attribute(root, 'link_id_level5', str(db.link_id_level5))
        _write_attribute(root, 'link_id_level6', str(db.link_id_level6))
        _write_attribute(root, 'link_id_subsection1', str(db.link_id_subsection1))
        _write_attribute(root, 'link_id_subsection2', str(db.link_id_subsection2))
        _write_attribute(root, 'link_id_subsection3', str(db.link_id_subsection3))
        _write_attribute(root, 'parent_id', str(db.parent_id))
        _write_attribute(root, 'ParentID', str(db.ParentID))
        _write_attribute(root, 'SequenceID', str(db.SequenceID))
        _write_attribute(root, 'Thickness', str(db.Thickness))
        _write_attribute(root, 'ThicknessUnit', str(db.ThicknessUnit))
        _write_attribute(root, 'TopParentID', str(db.TopParentID))
        _write_attribute(root, 'X1', str(db.X1))
        _write_attribute(root, 'X1Right', str(db.X1Right))
        _write_attribute(root, 'X2', str(db.X2))
        _write_attribute(root, 'X2Right', str(db.X2Right))
        _write_attribute(root, 'Y1', str(db.Y1))
        _write_attribute(root, 'Y1Lower', str(db.Y1Lower))
        _write_attribute(root, 'Y2', str(db.Y2))
        _write_attribute(root, 'Y2Lower', str(db.Y2Lower))
        ##############################################################
        #
        # End of fields
        #
        ##############################################################
        return root
    except Exception as e:
        logger.error('Failed to write IQVLine_db to root')


def _writeToXmlFromIQVNumberingGroup_db(db: IQVNumberingGroup_db):
    """
    Get the ET Element IQVNumberingGroup_db with all of its subelements
    """

    try:
        root = ET.Element("IQVNumberingGroup_db")
        ##############################################################
        #
        # Start of fields
        #
        ##############################################################
        _write_attribute(root, 'abstractNumId', str(db.abstractNumId))
        _write_attribute(root, 'countItems', str(db.countItems))
        _write_attribute(root, 'doc_id', str(db.doc_id))
        _write_attribute(root, 'group_type', str(db.group_type))
        _write_attribute(root, 'hierarchy', str(db.hierarchy))
        _write_attribute(root, 'id', str(db.id))
        _write_attribute(root, 'iqv_standard_term', str(db.iqv_standard_term))
        _write_attribute(root, 'link_id', str(db.link_id))
        _write_attribute(root, 'link_id_level2', str(db.link_id_level2))
        _write_attribute(root, 'link_id_level3', str(db.link_id_level3))
        _write_attribute(root, 'link_id_level4', str(db.link_id_level4))
        _write_attribute(root, 'link_id_level5', str(db.link_id_level5))
        _write_attribute(root, 'link_id_level6', str(db.link_id_level6))
        _write_attribute(root, 'link_id_subsection1', str(db.link_id_subsection1))
        _write_attribute(root, 'link_id_subsection2', str(db.link_id_subsection2))
        _write_attribute(root, 'link_id_subsection3', str(db.link_id_subsection3))
        _write_attribute(root, 'numId', str(db.numId))
        _write_attribute(root, 'paraEndIndex', str(db.paraEndIndex))
        _write_attribute(root, 'paraIds_list', str(db.paraIds_list))
        _write_attribute(root, 'paraStartIndex', str(db.paraStartIndex))
        _write_attribute(root, 'parent_id', str(db.parent_id))
        ##############################################################
        #
        # End of fields
        #
        ##############################################################
        return root
    except Exception as e:
        logger.error('Failed to write IQVNumberingGroup_db to root')


def _writeToXmlFromIQVNumberingLevel_db(db: IQVNumberingLevel_db):
    """
    Get the ET Element IQVNumberingLevel_db with all of its subelements
    """

    try:
        root = ET.Element("IQVNumberingLevel_db")
        ##############################################################
        #
        # Start of fields
        #
        ##############################################################
        _write_attribute(root, 'doc_id', str(db.doc_id))
        _write_attribute(root, 'group_type', str(db.group_type))
        _write_attribute(root, 'hierarchy', str(db.hierarchy))
        _write_attribute(root, 'id', str(db.id))
        _write_attribute(root, 'ilvl', str(db.ilvl))
        _write_attribute(root, 'iqv_standard_term', str(db.iqv_standard_term))
        _write_attribute(root, 'link_id', str(db.link_id))
        _write_attribute(root, 'link_id_level2', str(db.link_id_level2))
        _write_attribute(root, 'link_id_level3', str(db.link_id_level3))
        _write_attribute(root, 'link_id_level4', str(db.link_id_level4))
        _write_attribute(root, 'link_id_level5', str(db.link_id_level5))
        _write_attribute(root, 'link_id_level6', str(db.link_id_level6))
        _write_attribute(root, 'link_id_subsection1', str(db.link_id_subsection1))
        _write_attribute(root, 'link_id_subsection2', str(db.link_id_subsection2))
        _write_attribute(root, 'link_id_subsection3', str(db.link_id_subsection3))
        _write_attribute(root, 'lvlText', str(db.lvlText))
        _write_attribute(root, 'numFmt', str(db.numFmt))
        _write_attribute(root, 'parent_id', str(db.parent_id))
        _write_attribute(root, 'start', str(db.start))
        ##############################################################
        #
        # End of fields
        #
        ##############################################################
        return root
    except Exception as e:
        logger.error('Failed to write IQVNumberingLevel_db to root')


def _writeToXmlFromIQVRedactionProfile_db(db: IQVRedactionProfile_db):
    """
    Get the ET Element IQVRedactionProfile_db with all of its subelements
    """

    try:
        root = ET.Element("IQVRedactionProfile_db")
        ##############################################################
        #
        # Start of fields
        #
        ##############################################################
        _write_attribute(root, 'DefaultIsRedacted', str(db.DefaultIsRedacted))
        _write_attribute(root, 'id', str(db.id))
        ##############################################################
        #
        # End of fields
        #
        ##############################################################
        return root
    except Exception as e:
        logger.error('Failed to write IQVRedactionProfile_db to root')


def _writeToXmlFromIQVRedactionCategory_db(db: IQVRedactionCategory_db):
    """
    Get the ET Element IQVRedactionCategory_db with all of its subelements
    """

    try:
        root = ET.Element("IQVRedactionCategory_db")
        ##############################################################
        #
        # Start of fields
        #
        ##############################################################
        _write_attribute(root, 'Category', str(db.Category))
        _write_attribute(root, 'id', str(db.id))
        _write_attribute(root, 'IsRedacted', str(db.IsRedacted))
        _write_attribute(root, 'Query', str(db.Query))
        ##############################################################
        #
        # End of fields
        #
        ##############################################################
        return root
    except Exception as e:
        logger.error('Failed to write IQVRedactionCategory_db to root')


def _writeToXmlFromNLP_System_Mapping_db(db: NLP_System_Mapping_db):
    """
    Get the ET Element NLP_System_Mapping_db with all of its subelements
    """

    try:
        root = ET.Element("NLP_System_Mapping_db")
        ##############################################################
        #
        # Start of fields
        #
        ##############################################################
        _write_attribute(root, 'DataType', str(db.DataType))
        _write_attribute(root, 'doc_id', str(db.doc_id))
        _write_attribute(root, 'EntityKey', str(db.EntityKey))
        _write_attribute(root, 'FilenameKey', str(db.FilenameKey))
        _write_attribute(root, 'group_type', str(db.group_type))
        _write_attribute(root, 'hierarchy', str(db.hierarchy))
        _write_attribute(root, 'id', str(db.id))
        _write_attribute(root, 'iqv_standard_term', str(db.iqv_standard_term))
        _write_attribute(root, 'link_id', str(db.link_id))
        _write_attribute(root, 'link_id_level2', str(db.link_id_level2))
        _write_attribute(root, 'link_id_level3', str(db.link_id_level3))
        _write_attribute(root, 'link_id_level4', str(db.link_id_level4))
        _write_attribute(root, 'link_id_level5', str(db.link_id_level5))
        _write_attribute(root, 'link_id_level6', str(db.link_id_level6))
        _write_attribute(root, 'link_id_subsection1', str(db.link_id_subsection1))
        _write_attribute(root, 'link_id_subsection2', str(db.link_id_subsection2))
        _write_attribute(root, 'link_id_subsection3', str(db.link_id_subsection3))
        _write_attribute(root, 'NLPSystem', str(db.NLPSystem))
        _write_attribute(root, 'NLPSystemQueryName', str(db.NLPSystemQueryName))
        _write_attribute(root, 'NLPSystemVersion', str(db.NLPSystemVersion))
        _write_attribute(root, 'parent_id', str(db.parent_id))
        _write_attribute(root, 'QCFeedbackUIKey', str(db.QCFeedbackUIKey))
        ##############################################################
        #
        # End of fields
        #
        ##############################################################
        return root
    except Exception as e:
        logger.error('Failed to write NLP_System_Mapping_db to root')


def _writeToXmlFromNLP_Segment_db(db: NLP_Segment_db):
    """
    Get the ET Element NLP_Segment_db with all of its subelements
    """

    try:
        root = ET.Element("NLP_Segment_db")
        ##############################################################
        #
        # Start of fields
        #
        ##############################################################
        _write_attribute(root, 'doc_id', str(db.doc_id))
        _write_attribute(root, 'group_type', str(db.group_type))
        _write_attribute(root, 'hierarchy', str(db.hierarchy))
        _write_attribute(root, 'id', str(db.id))
        _write_attribute(root, 'iqv_standard_term', str(db.iqv_standard_term))
        _write_attribute(root, 'link_id', str(db.link_id))
        _write_attribute(root, 'link_id_level2', str(db.link_id_level2))
        _write_attribute(root, 'link_id_level3', str(db.link_id_level3))
        _write_attribute(root, 'link_id_level4', str(db.link_id_level4))
        _write_attribute(root, 'link_id_level5', str(db.link_id_level5))
        _write_attribute(root, 'link_id_level6', str(db.link_id_level6))
        _write_attribute(root, 'link_id_subsection1', str(db.link_id_subsection1))
        _write_attribute(root, 'link_id_subsection2', str(db.link_id_subsection2))
        _write_attribute(root, 'link_id_subsection3', str(db.link_id_subsection3))
        _write_attribute(root, 'parent_id', str(db.parent_id))
        _write_attribute(root, 'primary_section', str(db.primary_section))
        _write_attribute(root, 'secondary_section', str(db.secondary_section))
        _write_attribute(root, 'segment_type', str(db.segment_type))
        _write_attribute(root, 'text', str(db.text))

        fieldName = 'text_footnotes_list'
        try:
            subelement = ET.SubElement(root, fieldName)
            for xelm in db.text_footnotes_list:
                subelement.append(_writeToXmlFromString(xelm))
        except Exception as e:
            logger.info('Failed to export field ' + fieldName)
        ##############################################################
        #
        # End of fields
        #
        ##############################################################
        return root
    except Exception as e:
        logger.error('Failed to write NLP_Segment_db to root')


def _writeToXmlFromNLP_Relation_db(db: NLP_Relation_db):
    """
    Get the ET Element NLP_Relation_db with all of its subelements
    """

    try:
        root = ET.Element("NLP_Relation_db")
        ##############################################################
        #
        # Start of fields
        #
        ##############################################################
        _write_attribute(root, 'confidence', str(db.confidence))
        _write_attribute(root, 'doc_id', str(db.doc_id))
        _write_attribute(root, 'entities_list', str(db.entities_list))
        _write_attribute(root, 'group_type', str(db.group_type))
        _write_attribute(root, 'hierarchy', str(db.hierarchy))
        _write_attribute(root, 'id', str(db.id))
        _write_attribute(root, 'iqv_standard_term', str(db.iqv_standard_term))
        _write_attribute(root, 'is_bidirectional', str(db.is_bidirectional))
        _write_attribute(root, 'is_hierarchical', str(db.is_hierarchical))
        _write_attribute(root, 'link_id', str(db.link_id))
        _write_attribute(root, 'link_id_level2', str(db.link_id_level2))
        _write_attribute(root, 'link_id_level3', str(db.link_id_level3))
        _write_attribute(root, 'link_id_level4', str(db.link_id_level4))
        _write_attribute(root, 'link_id_level5', str(db.link_id_level5))
        _write_attribute(root, 'link_id_level6', str(db.link_id_level6))
        _write_attribute(root, 'link_id_subsection1', str(db.link_id_subsection1))
        _write_attribute(root, 'link_id_subsection2', str(db.link_id_subsection2))
        _write_attribute(root, 'link_id_subsection3', str(db.link_id_subsection3))
        _write_attribute(root, 'parent_id', str(db.parent_id))
        _write_attribute(root, 'process_source', str(db.process_source))
        _write_attribute(root, 'relation_name', str(db.relation_name))
        _write_attribute(root, 'relation_type', str(db.relation_type))
        ##############################################################
        #
        # End of fields
        #
        ##############################################################
        return root
    except Exception as e:
        logger.error('Failed to write NLP_Relation_db to root')


def _writeToXmlFromIQVTableRow_db(db: IQVTableRow_db):
    """
    Get the ET Element IQVTableRow_db with all of its subelements
    """

    try:
        root = ET.Element("IQVTableRow_db")
        ##############################################################
        #
        # Start of fields
        #
        ##############################################################
        _write_attribute(root, 'doc_id', str(db.doc_id))
        _write_attribute(root, 'group_type', str(db.group_type))
        _write_attribute(root, 'header', str(db.header))
        _write_attribute(root, 'hierarchy', str(db.hierarchy))
        _write_attribute(root, 'id', str(db.id))
        _write_attribute(root, 'iqv_standard_term', str(db.iqv_standard_term))
        _write_attribute(root, 'link_id', str(db.link_id))
        _write_attribute(root, 'link_id_level2', str(db.link_id_level2))
        _write_attribute(root, 'link_id_level3', str(db.link_id_level3))
        _write_attribute(root, 'link_id_level4', str(db.link_id_level4))
        _write_attribute(root, 'link_id_level5', str(db.link_id_level5))
        _write_attribute(root, 'link_id_level6', str(db.link_id_level6))
        _write_attribute(root, 'link_id_subsection1', str(db.link_id_subsection1))
        _write_attribute(root, 'link_id_subsection2', str(db.link_id_subsection2))
        _write_attribute(root, 'link_id_subsection3', str(db.link_id_subsection3))
        _write_attribute(root, 'maxY', str(db.maxY))
        _write_attribute(root, 'minY', str(db.minY))
        _write_attribute(root, 'parent_id', str(db.parent_id))
        _write_attribute(root, 'tableIndex', str(db.tableIndex))
        _write_attribute(root, 'tableRowIndex', str(db.tableRowIndex))
        _write_attribute(root, 'tableRowRef', str(db.tableRowRef))
        ##############################################################
        #
        # End of fields
        #
        ##############################################################
        return root
    except Exception as e:
        logger.error('Failed to write IQVTableRow_db to root')


def _writeToXmlFromIQVTableColumn_db(db: IQVTableColumn_db):
    """
    Get the ET Element IQVTableColumn_db with all of its subelements
    """

    try:
        root = ET.Element("IQVTableColumn_db")
        ##############################################################
        #
        # Start of fields
        #
        ##############################################################
        _write_attribute(root, 'doc_id', str(db.doc_id))
        _write_attribute(root, 'group_type', str(db.group_type))
        _write_attribute(root, 'hierarchy', str(db.hierarchy))
        _write_attribute(root, 'id', str(db.id))
        _write_attribute(root, 'iqv_standard_term', str(db.iqv_standard_term))
        _write_attribute(root, 'link_id', str(db.link_id))
        _write_attribute(root, 'link_id_level2', str(db.link_id_level2))
        _write_attribute(root, 'link_id_level3', str(db.link_id_level3))
        _write_attribute(root, 'link_id_level4', str(db.link_id_level4))
        _write_attribute(root, 'link_id_level5', str(db.link_id_level5))
        _write_attribute(root, 'link_id_level6', str(db.link_id_level6))
        _write_attribute(root, 'link_id_subsection1', str(db.link_id_subsection1))
        _write_attribute(root, 'link_id_subsection2', str(db.link_id_subsection2))
        _write_attribute(root, 'link_id_subsection3', str(db.link_id_subsection3))
        _write_attribute(root, 'maxX', str(db.maxX))
        _write_attribute(root, 'minX', str(db.minX))
        _write_attribute(root, 'parent_id', str(db.parent_id))
        _write_attribute(root, 'table_roi_id', str(db.table_roi_id))
        _write_attribute(root, 'tableColumnIndex', str(db.tableColumnIndex))
        _write_attribute(root, 'tableColumnRef', str(db.tableColumnRef))
        _write_attribute(root, 'tableIndex', str(db.tableIndex))
        ##############################################################
        #
        # End of fields
        #
        ##############################################################
        return root
    except Exception as e:
        logger.error('Failed to write IQVTableColumn_db to root')


def _writeToXmlFromIQVTableColumnHeader_db(db: IQVTableColumnHeader_db):
    """
    Get the ET Element IQVTableColumnHeader_db with all of its subelements
    """

    try:
        root = ET.Element("IQVTableColumnHeader_db")
        ##############################################################
        #
        # Start of fields
        #
        ##############################################################
        _write_attribute(root, 'doc_id', str(db.doc_id))
        _write_attribute(root, 'group_type', str(db.group_type))
        _write_attribute(root, 'hierarchy', str(db.hierarchy))
        _write_attribute(root, 'id', str(db.id))
        _write_attribute(root, 'iqv_standard_term', str(db.iqv_standard_term))
        _write_attribute(root, 'link_id', str(db.link_id))
        _write_attribute(root, 'link_id_level2', str(db.link_id_level2))
        _write_attribute(root, 'link_id_level3', str(db.link_id_level3))
        _write_attribute(root, 'link_id_level4', str(db.link_id_level4))
        _write_attribute(root, 'link_id_level5', str(db.link_id_level5))
        _write_attribute(root, 'link_id_level6', str(db.link_id_level6))
        _write_attribute(root, 'link_id_subsection1', str(db.link_id_subsection1))
        _write_attribute(root, 'link_id_subsection2', str(db.link_id_subsection2))
        _write_attribute(root, 'link_id_subsection3', str(db.link_id_subsection3))
        _write_attribute(root, 'OriginalText', str(db.OriginalText))
        _write_attribute(root, 'parent_id', str(db.parent_id))
        _write_attribute(root, 'roi_id', str(db.roi_id))
        _write_attribute(root, 'rowIndex', str(db.rowIndex))
        _write_attribute(root, 'rowRef', str(db.rowRef))
        ##############################################################
        #
        # End of fields
        #
        ##############################################################
        return root
    except Exception as e:
        logger.error('Failed to write IQVTableColumnHeader_db to root')


def _writeToXmlFromNLP_Entity_db(db: NLP_Entity_db):
    """
    Get the ET Element NLP_Entity_db with all of its subelements
    """

    try:
        root = ET.Element("NLP_Entity_db")
        ##############################################################
        #
        # Start of fields
        #
        ##############################################################
        _write_attribute(root, 'confidence', str(db.confidence))
        _write_attribute(root, 'doc_id', str(db.doc_id))
        _write_attribute(root, 'dts', str(db.dts))
        _write_attribute(root, 'entity_class', str(db.entity_class))
        _write_attribute(root, 'entity_index', str(db.entity_index))
        _write_attribute(root, 'entity_key', str(db.entity_key))
        _write_attribute(root, 'group_type', str(db.group_type))
        _write_attribute(root, 'hierarchy', str(db.hierarchy))
        _write_attribute(root, 'id', str(db.id))
        _write_attribute(root, 'iqv_standard_term', str(db.iqv_standard_term))
        _write_attribute(root, 'link_id', str(db.link_id))
        _write_attribute(root, 'link_id_level2', str(db.link_id_level2))
        _write_attribute(root, 'link_id_level3', str(db.link_id_level3))
        _write_attribute(root, 'link_id_level4', str(db.link_id_level4))
        _write_attribute(root, 'link_id_level5', str(db.link_id_level5))
        _write_attribute(root, 'link_id_level6', str(db.link_id_level6))
        _write_attribute(root, 'link_id_subsection1', str(db.link_id_subsection1))
        _write_attribute(root, 'link_id_subsection2', str(db.link_id_subsection2))
        _write_attribute(root, 'link_id_subsection3', str(db.link_id_subsection3))
        _write_attribute(root, 'negated', str(db.negated))
        _write_attribute(root, 'ontology', str(db.ontology))
        _write_attribute(root, 'ontology_item_code', str(db.ontology_item_code))
        _write_attribute(root, 'ontology_version', str(db.ontology_version))
        _write_attribute(root, 'parent_id', str(db.parent_id))
        _write_attribute(root, 'process_source', str(db.process_source))
        _write_attribute(root, 'standard_entity_name', str(db.standard_entity_name))
        _write_attribute(root, 'start', str(db.start))
        _write_attribute(root, 'text', str(db.text))
        _write_attribute(root, 'text_len', str(db.text_len))
        _write_attribute(root, 'user_id', str(db.user_id))
        ##############################################################
        #
        # End of fields
        #
        ##############################################################
        return root
    except Exception as e:
        logger.error('Failed to write NLP_Entity_db to root')


def _writeToXmlFromIQVConceptTerm_db(db: IQVConceptTerm_db):
    """
    Get the ET Element IQVConceptTerm_db with all of its subelements
    """

    try:
        root = ET.Element("IQVConceptTerm_db")
        ##############################################################
        #
        # Start of fields
        #
        ##############################################################
        _write_attribute(root, 'cui', str(db.cui))
        _write_attribute(root, 'entity_class', str(db.entity_class))
        _write_attribute(root, 'entity_text', str(db.entity_text))
        _write_attribute(root, 'entity_xref', str(db.entity_xref))
        _write_attribute(root, 'id', str(db.id))
        _write_attribute(root, 'info', str(db.info))
        _write_attribute(root, 'ontology', str(db.ontology))
        _write_attribute(root, 'preferred_term', str(db.preferred_term))
        ##############################################################
        #
        # End of fields
        #
        ##############################################################
        return root
    except Exception as e:
        logger.error('Failed to write IQVConceptTerm_db to root')


def _writeToXmlFromIQVConceptRelation_db(db: IQVConceptRelation_db):
    """
    Get the ET Element IQVConceptRelation_db with all of its subelements
    """

    try:
        root = ET.Element("IQVConceptRelation_db")
        ##############################################################
        #
        # Start of fields
        #
        ##############################################################
        _write_attribute(root, 'context_unit', str(db.context_unit))
        _write_attribute(root, 'dts', str(db.dts))
        _write_attribute(root, 'id', str(db.id))
        _write_attribute(root, 'id1', str(db.id1))
        _write_attribute(root, 'id2', str(db.id2))
        _write_attribute(root, 'relation_type', str(db.relation_type))
        _write_attribute(root, 'user_id', str(db.user_id))
        _write_attribute(root, 'weight', str(db.weight))
        ##############################################################
        #
        # End of fields
        #
        ##############################################################
        return root
    except Exception as e:
        logger.error('Failed to write IQVConceptRelation_db to root')


def _writeToXmlFromNLP_Attribute_db(db: NLP_Attribute_db):
    """
    Get the ET Element NLP_Attribute_db with all of its subelements
    """

    try:
        root = ET.Element("NLP_Attribute_db")
        ##############################################################
        #
        # Start of fields
        #
        ##############################################################
        _write_attribute(root, 'attribute_class', str(db.attribute_class))
        _write_attribute(root, 'attribute_index', str(db.attribute_index))
        _write_attribute(root, 'doc_id', str(db.doc_id))
        _write_attribute(root, 'group_type', str(db.group_type))
        _write_attribute(root, 'hierarchy', str(db.hierarchy))
        _write_attribute(root, 'id', str(db.id))
        _write_attribute(root, 'iqv_standard_term', str(db.iqv_standard_term))
        _write_attribute(root, 'link_id', str(db.link_id))
        _write_attribute(root, 'link_id_level2', str(db.link_id_level2))
        _write_attribute(root, 'link_id_level3', str(db.link_id_level3))
        _write_attribute(root, 'link_id_level4', str(db.link_id_level4))
        _write_attribute(root, 'link_id_level5', str(db.link_id_level5))
        _write_attribute(root, 'link_id_level6', str(db.link_id_level6))
        _write_attribute(root, 'link_id_subsection1', str(db.link_id_subsection1))
        _write_attribute(root, 'link_id_subsection2', str(db.link_id_subsection2))
        _write_attribute(root, 'link_id_subsection3', str(db.link_id_subsection3))
        _write_attribute(root, 'parent_id', str(db.parent_id))
        _write_attribute(root, 'process_source', str(db.process_source))
        _write_attribute(root, 'start', str(db.start))
        _write_attribute(root, 'text', str(db.text))
        ##############################################################
        #
        # End of fields
        #
        ##############################################################
        return root
    except Exception as e:
        logger.error('Failed to write NLP_Attribute_db to root')


def _writeToXmlFromIQVAssessmentVisitRecord_db(db: IQVAssessmentVisitRecord_db):
    """
    Get the ET Element IQVAssessmentVisitRecord_db with all of its subelements
    """

    try:
        root = ET.Element("IQVAssessmentVisitRecord_db")
        ##############################################################
        #
        # Start of fields
        #
        ##############################################################
        _write_attribute(root, 'assessment', str(db.assessment))
        _write_attribute(root, 'assessment_text', str(db.assessment_text))
        _write_attribute(root, 'cycle_timepoint', str(db.cycle_timepoint))
        _write_attribute(root, 'day_timepoint', str(db.day_timepoint))
        _write_attribute(root, 'doc_id', str(db.doc_id))
        _write_attribute(root, 'DocumentSequenceIndex', str(db.DocumentSequenceIndex))
        _write_attribute(root, 'dts', str(db.dts))
        _write_attribute(root, 'epoch_timepoint', str(db.epoch_timepoint))
        _write_attribute(root, 'footnote_0', str(db.footnote_0))
        _write_attribute(root, 'footnote_1', str(db.footnote_1))
        _write_attribute(root, 'footnote_2', str(db.footnote_2))
        _write_attribute(root, 'footnote_3', str(db.footnote_3))
        _write_attribute(root, 'footnote_4', str(db.footnote_4))
        _write_attribute(root, 'footnote_5', str(db.footnote_5))
        _write_attribute(root, 'footnote_6', str(db.footnote_6))
        _write_attribute(root, 'footnote_7', str(db.footnote_7))
        _write_attribute(root, 'footnote_8', str(db.footnote_8))
        _write_attribute(root, 'footnote_9', str(db.footnote_9))
        _write_attribute(root, 'id', str(db.id))
        _write_attribute(root, 'indicator_text', str(db.indicator_text))
        _write_attribute(root, 'month_timepoint', str(db.month_timepoint))
        _write_attribute(root, 'pname', str(db.pname))
        _write_attribute(root, 'procedure', str(db.procedure))
        _write_attribute(root, 'procedure_text', str(db.procedure_text))
        _write_attribute(root, 'ProcessMachineName', str(db.ProcessMachineName))
        _write_attribute(root, 'ProcessVersion', str(db.ProcessVersion))
        _write_attribute(root, 'roi_id', str(db.roi_id))
        _write_attribute(root, 'run_id', str(db.run_id))
        _write_attribute(root, 'section', str(db.section))
        _write_attribute(root, 'study_cohort', str(db.study_cohort))
        _write_attribute(root, 'table_link_text', str(db.table_link_text))
        _write_attribute(root, 'table_roi_id', str(db.table_roi_id))
        _write_attribute(root, 'table_sequence_index', str(db.table_sequence_index))
        _write_attribute(root, 'visit_timepoint', str(db.visit_timepoint))
        _write_attribute(root, 'week_timepoint', str(db.week_timepoint))
        _write_attribute(root, 'window_timepoint', str(db.window_timepoint))
        _write_attribute(root, 'year_timepoint', str(db.year_timepoint))
        ##############################################################
        #
        # End of fields
        #
        ##############################################################
        return root
    except Exception as e:
        logger.error('Failed to write IQVAssessmentVisitRecord_db to root')


def _writeToXmlFromIQVAssessmentRecord_db(db: IQVAssessmentRecord_db):
    """
    Get the ET Element IQVAssessmentRecord_db with all of its subelements
    """

    try:
        root = ET.Element("IQVAssessmentRecord_db")
        ##############################################################
        #
        # Start of fields
        #
        ##############################################################
        _write_attribute(root, 'assessment', str(db.assessment))
        _write_attribute(root, 'assessment_text', str(db.assessment_text))
        _write_attribute(root, 'doc_id', str(db.doc_id))
        _write_attribute(root, 'DocumentSequenceIndex', str(db.DocumentSequenceIndex))
        _write_attribute(root, 'dts', str(db.dts))
        _write_attribute(root, 'footnote_0', str(db.footnote_0))
        _write_attribute(root, 'footnote_1', str(db.footnote_1))
        _write_attribute(root, 'footnote_2', str(db.footnote_2))
        _write_attribute(root, 'footnote_3', str(db.footnote_3))
        _write_attribute(root, 'footnote_4', str(db.footnote_4))
        _write_attribute(root, 'footnote_5', str(db.footnote_5))
        _write_attribute(root, 'footnote_6', str(db.footnote_6))
        _write_attribute(root, 'footnote_7', str(db.footnote_7))
        _write_attribute(root, 'footnote_8', str(db.footnote_8))
        _write_attribute(root, 'footnote_9', str(db.footnote_9))
        _write_attribute(root, 'id', str(db.id))
        _write_attribute(root, 'num_visits', str(db.num_visits))
        _write_attribute(root, 'pname', str(db.pname))
        _write_attribute(root, 'procedure', str(db.procedure))
        _write_attribute(root, 'procedure_text', str(db.procedure_text))
        _write_attribute(root, 'ProcessMachineName', str(db.ProcessMachineName))
        _write_attribute(root, 'ProcessVersion', str(db.ProcessVersion))
        _write_attribute(root, 'roi_id', str(db.roi_id))
        _write_attribute(root, 'run_id', str(db.run_id))
        _write_attribute(root, 'section', str(db.section))
        _write_attribute(root, 'study_cohort', str(db.study_cohort))
        _write_attribute(root, 'table_link_text', str(db.table_link_text))
        _write_attribute(root, 'table_roi_id', str(db.table_roi_id))
        _write_attribute(root, 'table_sequence_index', str(db.table_sequence_index))
        ##############################################################
        #
        # End of fields
        #
        ##############################################################
        return root
    except Exception as e:
        logger.error('Failed to write IQVAssessmentRecord_db to root')


def _writeToXmlFromIQVLabParameterRecord_db(db: IQVLabParameterRecord_db):
    """
    Get the ET Element IQVLabParameterRecord_db with all of its subelements
    """

    try:
        root = ET.Element("IQVLabParameterRecord_db")
        ##############################################################
        #
        # Start of fields
        #
        ##############################################################
        _write_attribute(root, 'assessment', str(db.assessment))
        _write_attribute(root, 'doc_id', str(db.doc_id))
        _write_attribute(root, 'dts', str(db.dts))
        _write_attribute(root, 'id', str(db.id))
        _write_attribute(root, 'parameter', str(db.parameter))
        _write_attribute(root, 'parameter_text', str(db.parameter_text))
        _write_attribute(root, 'pname', str(db.pname))
        _write_attribute(root, 'procedure_panel', str(db.procedure_panel))
        _write_attribute(root, 'procedure_panel_text', str(db.procedure_panel_text))
        _write_attribute(root, 'ProcessMachineName', str(db.ProcessMachineName))
        _write_attribute(root, 'ProcessVersion', str(db.ProcessVersion))
        _write_attribute(root, 'roi_id', str(db.roi_id))
        _write_attribute(root, 'run_id', str(db.run_id))
        _write_attribute(root, 'section', str(db.section))
        _write_attribute(root, 'table_link_text', str(db.table_link_text))
        _write_attribute(root, 'table_roi_id', str(db.table_roi_id))
        _write_attribute(root, 'table_sequence_index', str(db.table_sequence_index))
        ##############################################################
        #
        # End of fields
        #
        ##############################################################
        return root
    except Exception as e:
        logger.error('Failed to write IQVLabParameterRecord_db to root')


def _writeToXmlFromIQVVisitRecord_db(db: IQVVisitRecord_db):
    """
    Get the ET Element IQVVisitRecord_db with all of its subelements
    """

    try:
        root = ET.Element("IQVVisitRecord_db")
        ##############################################################
        #
        # Start of fields
        #
        ##############################################################
        _write_attribute(root, 'cycle_timepoint', str(db.cycle_timepoint))
        _write_attribute(root, 'day_timepoint', str(db.day_timepoint))
        _write_attribute(root, 'doc_id', str(db.doc_id))
        _write_attribute(root, 'DocumentSequenceIndex', str(db.DocumentSequenceIndex))
        _write_attribute(root, 'dts', str(db.dts))
        _write_attribute(root, 'epoch_timepoint', str(db.epoch_timepoint))
        _write_attribute(root, 'footnote_0', str(db.footnote_0))
        _write_attribute(root, 'footnote_1', str(db.footnote_1))
        _write_attribute(root, 'footnote_2', str(db.footnote_2))
        _write_attribute(root, 'footnote_3', str(db.footnote_3))
        _write_attribute(root, 'footnote_4', str(db.footnote_4))
        _write_attribute(root, 'footnote_5', str(db.footnote_5))
        _write_attribute(root, 'footnote_6', str(db.footnote_6))
        _write_attribute(root, 'footnote_7', str(db.footnote_7))
        _write_attribute(root, 'footnote_8', str(db.footnote_8))
        _write_attribute(root, 'footnote_9', str(db.footnote_9))
        _write_attribute(root, 'id', str(db.id))
        _write_attribute(root, 'month_timepoint', str(db.month_timepoint))
        _write_attribute(root, 'num_assessments', str(db.num_assessments))
        _write_attribute(root, 'pname', str(db.pname))
        _write_attribute(root, 'ProcessMachineName', str(db.ProcessMachineName))
        _write_attribute(root, 'ProcessVersion', str(db.ProcessVersion))
        _write_attribute(root, 'run_id', str(db.run_id))
        _write_attribute(root, 'study_cohort', str(db.study_cohort))
        _write_attribute(root, 'table_link_text', str(db.table_link_text))
        _write_attribute(root, 'table_roi_id', str(db.table_roi_id))
        _write_attribute(root, 'table_sequence_index', str(db.table_sequence_index))
        _write_attribute(root, 'visit_timepoint', str(db.visit_timepoint))
        _write_attribute(root, 'week_timepoint', str(db.week_timepoint))
        _write_attribute(root, 'window_timepoint', str(db.window_timepoint))
        _write_attribute(root, 'year_timepoint', str(db.year_timepoint))
        ##############################################################
        #
        # End of fields
        #
        ##############################################################
        return root
    except Exception as e:
        logger.error('Failed to write IQVVisitRecord_db to root')


def _writeToXmlFromIQVIECriteriaRecord_db(db: IQVIECriteriaRecord_db):
    """
    Get the ET Element IQVIECriteriaRecord_db with all of its subelements
    """

    try:
        root = ET.Element("IQVIECriteriaRecord_db")
        ##############################################################
        #
        # Start of fields
        #
        ##############################################################
        _write_attribute(root, 'doc_id', str(db.doc_id))
        _write_attribute(root, 'DocumentSequenceIndex', str(db.DocumentSequenceIndex))
        _write_attribute(root, 'dts', str(db.dts))
        _write_attribute(root, 'footnote_0', str(db.footnote_0))
        _write_attribute(root, 'footnote_1', str(db.footnote_1))
        _write_attribute(root, 'footnote_2', str(db.footnote_2))
        _write_attribute(root, 'footnote_3', str(db.footnote_3))
        _write_attribute(root, 'footnote_4', str(db.footnote_4))
        _write_attribute(root, 'footnote_5', str(db.footnote_5))
        _write_attribute(root, 'footnote_6', str(db.footnote_6))
        _write_attribute(root, 'footnote_7', str(db.footnote_7))
        _write_attribute(root, 'footnote_8', str(db.footnote_8))
        _write_attribute(root, 'footnote_9', str(db.footnote_9))
        _write_attribute(root, 'id', str(db.id))
        _write_attribute(root, 'ie_type', str(db.ie_type))
        _write_attribute(root, 'item_text', str(db.item_text))
        _write_attribute(root, 'link_text', str(db.link_text))
        _write_attribute(root, 'pname', str(db.pname))
        _write_attribute(root, 'procedure', str(db.procedure))
        _write_attribute(root, 'ProcessMachineName', str(db.ProcessMachineName))
        _write_attribute(root, 'ProcessVersion', str(db.ProcessVersion))
        _write_attribute(root, 'roi_id', str(db.roi_id))
        _write_attribute(root, 'section', str(db.section))
        _write_attribute(root, 'study_cohort', str(db.study_cohort))
        ##############################################################
        #
        # End of fields
        #
        ##############################################################
        return root
    except Exception as e:
        logger.error('Failed to write IQVIECriteriaRecord_db to root')


def _writeToXmlFromIQVDocumentVariable_db(db: IQVDocumentVariable_db):
    """
    Get the ET Element IQVDocumentVariable_db with all of its subelements
    """

    try:
        root = ET.Element("IQVDocumentVariable_db")
        ##############################################################
        #
        # Start of fields
        #
        ##############################################################
        _write_attribute(root, 'doc_id', str(db.doc_id))
        _write_attribute(root, 'dts', str(db.dts))
        _write_attribute(root, 'id', str(db.id))
        _write_attribute(root, 'run_id', str(db.run_id))
        _write_attribute(root, 'source_filename', str(db.source_filename))
        _write_attribute(root, 'variable_category', str(db.variable_category))
        _write_attribute(root, 'variable_datatype', str(db.variable_datatype))
        _write_attribute(root, 'variable_index', str(db.variable_index))
        _write_attribute(root, 'variable_key', str(db.variable_key))
        _write_attribute(root, 'variable_label', str(db.variable_label))
        _write_attribute(root, 'variable_listing_filename', str(db.variable_listing_filename))
        _write_attribute(root, 'variable_notes', str(db.variable_notes))
        _write_attribute(root, 'variable_score', str(db.variable_score))
        _write_attribute(root, 'variable_source', str(db.variable_source))
        _write_attribute(root, 'variable_value', str(db.variable_value))
        ##############################################################
        #
        # End of fields
        #
        ##############################################################
        return root
    except Exception as e:
        logger.error('Failed to write IQVDocumentVariable_db to root')


def _writeToXmlFromQ_EVENT_LOG_ENTRY_db(db: Q_EVENT_LOG_ENTRY_db):
    """
    Get the ET Element Q_EVENT_LOG_ENTRY_db with all of its subelements
    """

    try:
        root = ET.Element("Q_EVENT_LOG_ENTRY_db")
        ##############################################################
        #
        # Start of fields
        #
        ##############################################################
        _write_attribute(root, 'bHandled', _bool2str(db.bHandled))
        _write_attribute(root, 'ClassMapping', str(db.ClassMapping))
        _write_attribute(root, 'CountReplace', str(db.CountReplace))
        _write_attribute(root, 'DocumentID', str(db.DocumentID))
        _write_attribute(root, 'DocumentName', str(db.DocumentName))
        _write_attribute(root, 'DocumentPage', str(db.DocumentPage))
        _write_attribute(root, 'ErrorLevelVal', str(db.ErrorLevelVal))
        _write_attribute(root, 'EventTypeVal', str(db.EventTypeVal))
        _write_attribute(root, 'FieldMapping', str(db.FieldMapping))
        _write_attribute(root, 'id', str(db.id))
        _write_attribute(root, 'Message', str(db.Message))
        _write_attribute(root, 'StackTrace', str(db.StackTrace))
        _write_attribute(root, 'UserEmail', str(db.UserEmail))
        _write_attribute(root, 'UserID', str(db.UserID))
        _write_attribute(root, 'UserInputMessage', str(db.UserInputMessage))
        _write_attribute(root, 'Value', str(db.Value))
        ##############################################################
        #
        # End of fields
        #
        ##############################################################
        return root
    except Exception as e:
        logger.error('Failed to write Q_EVENT_LOG_ENTRY_db to root')


def _writeToXmlFromIQVTM_PDFDocumentPage(db: IQVTM_PDFDocumentPage):
    """
    Get the ET Element IQVTM_PDFDocumentPage with all of its subelements
    """

    try:
        root = ET.Element("IQVTM_PDFDocumentPage")
        ##############################################################
        #
        # Start of fields
        #
        ##############################################################
        _write_attribute(root, 'FooterText', str(db.FooterText))
        _write_attribute(root, 'HeaderText', str(db.HeaderText))

        fieldName = 'Hyperlinks'
        try:
            subelement = ET.SubElement(root, fieldName)
            for xelm in db.Hyperlinks:
                subelement.append(_writeToXmlFromString(xelm))
        except Exception as e:
            logger.info('Failed to export field ' + fieldName)

        fieldName = 'ImageNames'
        try:
            subelement = ET.SubElement(root, fieldName)
            for xelm in db.ImageNames:
                subelement.append(_writeToXmlFromString(xelm))
        except Exception as e:
            logger.info('Failed to export field ' + fieldName)
        _write_attribute(root, 'OrientationIsPortrait', _bool2str(db.OrientationIsPortrait))

        fieldName = 'PageSizeRectangle'
        try:
            subelement = _writeToXmlFromRectangle(db.PageSizeRectangle)
            subelement.tag = fieldName
            root.append(subelement)
        except Exception as e:
            logger.info('Failed to export field ' + fieldName)

        fieldName = 'PageSizeWithRotationRectangle'
        try:
            subelement = _writeToXmlFromRectangle(db.PageSizeWithRotationRectangle)
            subelement.tag = fieldName
            root.append(subelement)
        except Exception as e:
            logger.info('Failed to export field ' + fieldName)
        _write_attribute(root, 'PDFDocumentPageIndex', str(db.PDFDocumentPageIndex))
        _write_attribute(root, 'PDFDocumentPageText', str(db.PDFDocumentPageText))
        _write_attribute(root, 'PDFDocumentPageTextNumChars', str(db.PDFDocumentPageTextNumChars))
        _write_attribute(root, 'PDFDocumentPageTextNumWords', str(db.PDFDocumentPageTextNumWords))
        _write_attribute(root, 'Rotation', str(db.Rotation))
        _write_attribute(root, 'TitleText', str(db.TitleText))
        ##############################################################
        #
        # End of fields
        #
        ##############################################################
        return root
    except Exception as e:
        logger.error('Failed to write IQVTM_PDFDocumentPage to root')


def _writeToXmlFromIQVDocumentTest(db: IQVDocumentTest):
    """
    Get the ET Element IQVDocumentTest with all of its subelements
    """

    try:
        root = ET.Element("IQVDocumentTest")
        ##############################################################
        #
        # Start of fields
        #
        ##############################################################
        _write_attribute(root, 'ActualClassFromGT', str(db.ActualClassFromGT))
        _write_attribute(root, 'ActualDIACodeFromGT', str(db.ActualDIACodeFromGT))
        _write_attribute(root, 'CodeVersion', str(db.CodeVersion))
        _write_attribute(root, 'Confidence', str(db.Confidence))

        fieldName = 'ConfuserClasses'
        try:
            subelement = ET.SubElement(root, fieldName)
            for xelm in db.ConfuserClasses:
                subelement.append(_writeToXmlFromString(xelm))
        except Exception as e:
            logger.info('Failed to export field ' + fieldName)

        fieldName = 'ConfuserRawLogProbScores'
        try:
            subelement = ET.SubElement(root, fieldName)
            for xelm in db.ConfuserRawLogProbScores:
                subelement.append(_writeToXmlFromDouble(xelm))
        except Exception as e:
            logger.info('Failed to export field ' + fieldName)
        _write_attribute(root, 'MeanLogProbScoreAllClasses', str(db.MeanLogProbScoreAllClasses))
        _write_attribute(root, 'PredictedClass', str(db.PredictedClass))
        _write_attribute(root, 'PredictedDIACode', str(db.PredictedDIACode))
        _write_attribute(root, 'RankingActualClass', str(db.RankingActualClass))
        _write_attribute(root, 'RawLogProbScoreActualClass', str(db.RawLogProbScoreActualClass))
        _write_attribute(root, 'RawLogProbScoreSelectedClass', str(db.RawLogProbScoreSelectedClass))
        _write_attribute(root, 'TestDate', str(db.TestDate))
        _write_attribute(root, 'Variance', str(db.Variance))
        _write_attribute(root, 'ZScore', str(db.ZScore))
        ##############################################################
        #
        # End of fields
        #
        ##############################################################
        return root
    except Exception as e:
        logger.error('Failed to write IQVDocumentTest to root')


def _writeToXmlFromIQVTM_PDFDocument(db: IQVTM_PDFDocument):
    """
    Get the ET Element IQVTM_PDFDocument with all of its subelements
    """

    try:
        root = ET.Element("IQVTM_PDFDocument")
        ##############################################################
        #
        # Start of fields
        #
        ##############################################################
        _write_attribute(root, 'DocumentClass', str(db.DocumentClass))

        fieldName = 'DocumentGroundTruth'
        try:
            subelement = _writeToXmlFromIQVDocumentGroundTruth(db.DocumentGroundTruth)
            subelement.tag = fieldName
            root.append(subelement)
        except Exception as e:
            logger.info('Failed to export field ' + fieldName)
        _write_attribute(root, 'DocumentName', str(db.DocumentName))
        _write_attribute(root, 'id', str(db.id))

        fieldName = 'IQVDocumentTests'
        try:
            subelement = ET.SubElement(root, fieldName)
            for xelm in db.IQVDocumentTests:
                subelement.append(_writeToXmlFromIQVDocumentTest(xelm))
        except Exception as e:
            logger.info('Failed to export field ' + fieldName)
        _write_attribute(root, 'NumberOfPages', str(db.NumberOfPages))

        fieldName = 'PDFDocumentPageList'
        try:
            subelement = ET.SubElement(root, fieldName)
            for xelm in db.PDFDocumentPageList:
                subelement.append(_writeToXmlFromIQVTM_PDFDocumentPage(xelm))
        except Exception as e:
            logger.info('Failed to export field ' + fieldName)
        _write_attribute(root, 'PDFDocumentTextNumChars', str(db.PDFDocumentTextNumChars))
        ##############################################################
        #
        # End of fields
        #
        ##############################################################
        return root
    except Exception as e:
        logger.error('Failed to write IQVTM_PDFDocument to root')


def _writeToXmlFromIQVKeyMapping(db: IQVKeyMapping):
    """
    Get the ET Element IQVKeyMapping with all of its subelements
    """

    try:
        root = ET.Element("IQVKeyMapping")
        ##############################################################
        #
        # Start of fields
        #
        ##############################################################
        _write_attribute(root, 'container', str(db.container))
        _write_attribute(root, 'description', str(db.description))
        _write_attribute(root, 'key', str(db.key))

        fieldName = 'synonyms'
        try:
            subelement = ET.SubElement(root, fieldName)
            for xelm in db.synonyms:
                subelement.append(_writeToXmlFromIQVKeyValueSet(xelm))
        except Exception as e:
            logger.info('Failed to export field ' + fieldName)
        _write_attribute(root, 'value_type', str(db.value_type))
        ##############################################################
        #
        # End of fields
        #
        ##############################################################
        return root
    except Exception as e:
        logger.error('Failed to write IQVKeyMapping to root')


def _writeToXmlFromIQV_KEY_STRING(db: IQV_KEY_STRING):
    """
    Get the ET Element IQV_KEY_STRING with all of its subelements
    """

    try:
        root = ET.Element("IQV_KEY_STRING")
        ##############################################################
        #
        # Start of fields
        #
        ##############################################################
        _write_attribute(root, 'KEY_AlternateContent', str(db.KEY_AlternateContent))
        _write_attribute(root, 'KEY_amendment_number', str(db.KEY_amendment_number))
        _write_attribute(root, 'KEY_approval_date', str(db.KEY_approval_date))
        _write_attribute(root, 'KEY_arm', str(db.KEY_arm))
        _write_attribute(root, 'KEY_blank_header', str(db.KEY_blank_header))
        _write_attribute(root, 'KEY_blinding', str(db.KEY_blinding))
        _write_attribute(root, 'KEY_BlockInsert', str(db.KEY_BlockInsert))
        _write_attribute(root, 'KEY_BlockLineROIExactMatch', str(db.KEY_BlockLineROIExactMatch))
        _write_attribute(root, 'KEY_BlockPrintPage', str(db.KEY_BlockPrintPage))
        _write_attribute(root, 'KEY_BlockROI', str(db.KEY_BlockROI))
        _write_attribute(root, 'KEY_BulletPrefix', str(db.KEY_BulletPrefix))
        _write_attribute(root, 'KEY_color', str(db.KEY_color))
        _write_attribute(root, 'KEY_COMPARE_base_text', str(db.KEY_COMPARE_base_text))
        _write_attribute(root, 'KEY_COMPARE_char_roi_base_location', str(db.KEY_COMPARE_char_roi_base_location))
        _write_attribute(root, 'KEY_COMPARE_char_roi_compare_location', str(db.KEY_COMPARE_char_roi_compare_location))
        _write_attribute(root, 'KEY_COMPARE_char_section_location', str(db.KEY_COMPARE_char_section_location))
        _write_attribute(root, 'KEY_COMPARE_compare_text', str(db.KEY_COMPARE_compare_text))
        _write_attribute(root, 'KEY_compare_document_a', str(db.KEY_compare_document_a))
        _write_attribute(root, 'KEY_compare_document_b', str(db.KEY_compare_document_b))
        _write_attribute(root, 'KEY_COMPARE_summary_num_chars', str(db.KEY_COMPARE_summary_num_chars))
        _write_attribute(root, 'KEY_COMPARE_summary_num_diffs', str(db.KEY_COMPARE_summary_num_diffs))
        _write_attribute(root, 'KEY_compound', str(db.KEY_compound))
        _write_attribute(root, 'KEY_ConjoinedSegments', str(db.KEY_ConjoinedSegments))
        _write_attribute(root, 'KEY_control', str(db.KEY_control))
        _write_attribute(root, 'KEY_CumulativeWordCount', str(db.KEY_CumulativeWordCount))
        _write_attribute(root, 'KEY_CustomXML', str(db.KEY_CustomXML))
        _write_attribute(root, 'KEY_decon_soa_max_x', str(db.KEY_decon_soa_max_x))
        _write_attribute(root, 'KEY_decon_soa_page', str(db.KEY_decon_soa_page))
        _write_attribute(root, 'KEY_design', str(db.KEY_design))
        _write_attribute(root, 'KEY_DiscontinuationofStudyInterventionsandParticipantWithdrawalHeader',
                         str(db.KEY_DiscontinuationofStudyInterventionsandParticipantWithdrawalHeader))
        _write_attribute(root, 'KEY_DiscontinuationofStudyInterventionsandParticipantWithdrawalRefRoiId',
                         str(db.KEY_DiscontinuationofStudyInterventionsandParticipantWithdrawalRefRoiId))
        _write_attribute(root, 'KEY_document_keyword', str(db.KEY_document_keyword))
        _write_attribute(root, 'KEY_document_status', str(db.KEY_document_status))
        _write_attribute(root, 'KEY_document_topic', str(db.KEY_document_topic))
        _write_attribute(root, 'KEY_document_version', str(db.KEY_document_version))
        _write_attribute(root, 'KEY_DocumentPropertyKey', str(db.KEY_DocumentPropertyKey))
        _write_attribute(root, 'KEY_drug', str(db.KEY_drug))
        _write_attribute(root, 'KEY_dts', str(db.KEY_dts))
        _write_attribute(root, 'KEY_endpoints', str(db.KEY_endpoints))
        _write_attribute(root, 'KEY_EndpointsHeader', str(db.KEY_EndpointsHeader))
        _write_attribute(root, 'KEY_EndpointsRefRoiId', str(db.KEY_EndpointsRefRoiId))
        _write_attribute(root, 'KEY_entities_in_assessments', str(db.KEY_entities_in_assessments))
        _write_attribute(root, 'KEY_entity_key', str(db.KEY_entity_key))
        _write_attribute(root, 'KEY_environment', str(db.KEY_environment))
        _write_attribute(root, 'KEY_exclusion_section', str(db.KEY_exclusion_section))
        _write_attribute(root, 'KEY_ExclusionCriteriaHeader', str(db.KEY_ExclusionCriteriaHeader))
        _write_attribute(root, 'KEY_ExclusionCriteriaRefRoiId', str(db.KEY_ExclusionCriteriaRefRoiId))
        _write_attribute(root, 'KEY_font_bold', str(db.KEY_font_bold))
        _write_attribute(root, 'KEY_font_size', str(db.KEY_font_size))
        _write_attribute(root, 'KEY_font_style', str(db.KEY_font_style))
        _write_attribute(root, 'KEY_Footnote_', str(db.KEY_Footnote_))
        _write_attribute(root, 'KEY_FootnoteID_', str(db.KEY_FootnoteID_))
        _write_attribute(root, 'KEY_FootnoteParaROI', str(db.KEY_FootnoteParaROI))
        _write_attribute(root, 'KEY_FootnoteTableROI', str(db.KEY_FootnoteTableROI))
        _write_attribute(root, 'KEY_FootnoteText_', str(db.KEY_FootnoteText_))
        _write_attribute(root, 'KEY_gridspan', str(db.KEY_gridspan))
        _write_attribute(root, 'KEY_HeaderNumericSection', str(db.KEY_HeaderNumericSection))
        _write_attribute(root, 'KEY_HeaderText', str(db.KEY_HeaderText))
        _write_attribute(root, 'KEY_ilvl', str(db.KEY_ilvl))
        _write_attribute(root, 'KEY_inclusion_section', str(db.KEY_inclusion_section))
        _write_attribute(root, 'KEY_InclusionCriteriaHeader', str(db.KEY_InclusionCriteriaHeader))
        _write_attribute(root, 'KEY_InclusionCriteriaRefRoiId', str(db.KEY_InclusionCriteriaRefRoiId))
        _write_attribute(root, 'KEY_indication', str(db.KEY_indication))
        _write_attribute(root, 'KEY_InsertRectifyText', str(db.KEY_InsertRectifyText))
        _write_attribute(root, 'KEY_intervention_form', str(db.KEY_intervention_form))
        _write_attribute(root, 'KEY_intervention_method', str(db.KEY_intervention_method))
        _write_attribute(root, 'KEY_IntroductionHeader', str(db.KEY_IntroductionHeader))
        _write_attribute(root, 'KEY_IntroductionRefRoiId', str(db.KEY_IntroductionRefRoiId))
        _write_attribute(root, 'KEY_investigator', str(db.KEY_investigator))
        _write_attribute(root, 'KEY_iqv_standard_term', str(db.KEY_iqv_standard_term))
        _write_attribute(root, 'KEY_IsAmendment', str(db.KEY_IsAmendment))
        _write_attribute(root, 'KEY_IsAttachment', str(db.KEY_IsAttachment))
        _write_attribute(root, 'KEY_IsColumnHeader', str(db.KEY_IsColumnHeader))
        _write_attribute(root, 'KEY_IsDiscontinuationofStudyInterventionsandParticipantWithdrawalElement',
                         str(db.KEY_IsDiscontinuationofStudyInterventionsandParticipantWithdrawalElement))
        _write_attribute(root, 'KEY_IsDiscontinuationofStudyInterventionsandParticipantWithdrawalHeader',
                         str(db.KEY_IsDiscontinuationofStudyInterventionsandParticipantWithdrawalHeader))
        _write_attribute(root, 'KEY_IsEndpointsElement', str(db.KEY_IsEndpointsElement))
        _write_attribute(root, 'KEY_IsEndpointsHeader', str(db.KEY_IsEndpointsHeader))
        _write_attribute(root, 'KEY_IsEndpointTable', str(db.KEY_IsEndpointTable))
        _write_attribute(root, 'KEY_IsExclusionCriteria', str(db.KEY_IsExclusionCriteria))
        _write_attribute(root, 'KEY_IsExclusionCriteriaElement', str(db.KEY_IsExclusionCriteriaElement))
        _write_attribute(root, 'KEY_IsExclusionCriteriaHeader', str(db.KEY_IsExclusionCriteriaHeader))
        _write_attribute(root, 'KEY_IsFootnote', str(db.KEY_IsFootnote))
        _write_attribute(root, 'KEY_IsFootnote_', str(db.KEY_IsFootnote_))
        _write_attribute(root, 'KEY_IsFootnoteText_', str(db.KEY_IsFootnoteText_))
        _write_attribute(root, 'KEY_IsInclusionCriteria', str(db.KEY_IsInclusionCriteria))
        _write_attribute(root, 'KEY_IsInclusionCriteriaElement', str(db.KEY_IsInclusionCriteriaElement))
        _write_attribute(root, 'KEY_IsInclusionCriteriaHeader', str(db.KEY_IsInclusionCriteriaHeader))
        _write_attribute(root, 'KEY_IsIntroductionElement', str(db.KEY_IsIntroductionElement))
        _write_attribute(root, 'KEY_IsIntroductionHeader', str(db.KEY_IsIntroductionHeader))
        _write_attribute(root, 'KEY_IsObjectivesElement', str(db.KEY_IsObjectivesElement))
        _write_attribute(root, 'KEY_IsObjectivesEndpointsElement', str(db.KEY_IsObjectivesEndpointsElement))
        _write_attribute(root, 'KEY_IsObjectivesEndpointsHeader', str(db.KEY_IsObjectivesEndpointsHeader))
        _write_attribute(root, 'KEY_IsObjectivesHeader', str(db.KEY_IsObjectivesHeader))
        _write_attribute(root, 'KEY_IsReferencesElement', str(db.KEY_IsReferencesElement))
        _write_attribute(root, 'KEY_IsReferencesHeader', str(db.KEY_IsReferencesHeader))
        _write_attribute(root, 'KEY_IsRootElement', str(db.KEY_IsRootElement))
        _write_attribute(root, 'KEY_IsSectionElement', str(db.KEY_IsSectionElement))
        _write_attribute(root, 'KEY_IsSectionElementDiff', str(db.KEY_IsSectionElementDiff))
        _write_attribute(root, 'KEY_IsSectionHeader', str(db.KEY_IsSectionHeader))
        _write_attribute(root, 'KEY_IsSOAAssessment', str(db.KEY_IsSOAAssessment))
        _write_attribute(root, 'KEY_IsSOAAssessmentPreferredTerm', str(db.KEY_IsSOAAssessmentPreferredTerm))
        _write_attribute(root, 'KEY_IsSOAElement', str(db.KEY_IsSOAElement))
        _write_attribute(root, 'KEY_IsSOAEpoch', str(db.KEY_IsSOAEpoch))
        _write_attribute(root, 'KEY_IsSOAHeader', str(db.KEY_IsSOAHeader))
        _write_attribute(root, 'KEY_IsSOALink', str(db.KEY_IsSOALink))
        _write_attribute(root, 'KEY_IsSOATable', str(db.KEY_IsSOATable))
        _write_attribute(root, 'KEY_IsSOATableColumn', str(db.KEY_IsSOATableColumn))
        _write_attribute(root, 'KEY_IsStatisticalConsiderationsElement', str(db.KEY_IsStatisticalConsiderationsElement))
        _write_attribute(root, 'KEY_IsStatisticalConsiderationsHeader', str(db.KEY_IsStatisticalConsiderationsHeader))
        _write_attribute(root, 'KEY_IsStudyAssessmentsandProceduresElement',
                         str(db.KEY_IsStudyAssessmentsandProceduresElement))
        _write_attribute(root, 'KEY_IsStudyAssessmentsandProceduresHeader',
                         str(db.KEY_IsStudyAssessmentsandProceduresHeader))
        _write_attribute(root, 'KEY_IsStudyDesignElement', str(db.KEY_IsStudyDesignElement))
        _write_attribute(root, 'KEY_IsStudyDesignHeader', str(db.KEY_IsStudyDesignHeader))
        _write_attribute(root, 'KEY_IsStudyInterventionsandConcomitantTherapyElement',
                         str(db.KEY_IsStudyInterventionsandConcomitantTherapyElement))
        _write_attribute(root, 'KEY_IsStudyInterventionsandConcomitantTherapyHeader',
                         str(db.KEY_IsStudyInterventionsandConcomitantTherapyHeader))
        _write_attribute(root, 'KEY_IsStudyPopulationElement', str(db.KEY_IsStudyPopulationElement))
        _write_attribute(root, 'KEY_IsStudyPopulationHeader', str(db.KEY_IsStudyPopulationHeader))
        _write_attribute(root, 'KEY_IsSummaryElement', str(db.KEY_IsSummaryElement))
        _write_attribute(root, 'KEY_IsSummaryHeader', str(db.KEY_IsSummaryHeader))
        _write_attribute(root, 'KEY_IsSupportingDocumentationElement', str(db.KEY_IsSupportingDocumentationElement))
        _write_attribute(root, 'KEY_IsSupportingDocumentationHeader', str(db.KEY_IsSupportingDocumentationHeader))
        _write_attribute(root, 'KEY_IsTOAElement', str(db.KEY_IsTOAElement))
        _write_attribute(root, 'KEY_IsTOAHeader', str(db.KEY_IsTOAHeader))
        _write_attribute(root, 'KEY_IsTOCElement', str(db.KEY_IsTOCElement))
        _write_attribute(root, 'KEY_IsTOCHeader', str(db.KEY_IsTOCHeader))
        _write_attribute(root, 'KEY_IsTOCLink', str(db.KEY_IsTOCLink))
        _write_attribute(root, 'KEY_IsTOFElement', str(db.KEY_IsTOFElement))
        _write_attribute(root, 'KEY_IsTOFHeader', str(db.KEY_IsTOFHeader))
        _write_attribute(root, 'KEY_IsTOTElement', str(db.KEY_IsTOTElement))
        _write_attribute(root, 'KEY_IsTOTHeader', str(db.KEY_IsTOTHeader))
        _write_attribute(root, 'KEY_ItemType', str(db.KEY_ItemType))
        _write_attribute(root, 'KEY_ItemType_Endpoint', str(db.KEY_ItemType_Endpoint))
        _write_attribute(root, 'KEY_ItemType_EndpointType', str(db.KEY_ItemType_EndpointType))
        _write_attribute(root, 'KEY_ItemType_Objective', str(db.KEY_ItemType_Objective))
        _write_attribute(root, 'KEY_ItemType_ObjectiveType', str(db.KEY_ItemType_ObjectiveType))
        _write_attribute(root, 'KEY_LinkLevel', str(db.KEY_LinkLevel))
        _write_attribute(root, 'KEY_LinkPage', str(db.KEY_LinkPage))
        _write_attribute(root, 'KEY_LinkPageLHS', str(db.KEY_LinkPageLHS))
        _write_attribute(root, 'KEY_LinkPageRHS', str(db.KEY_LinkPageRHS))
        _write_attribute(root, 'KEY_LinkPrefix', str(db.KEY_LinkPrefix))
        _write_attribute(root, 'KEY_LinkROI', str(db.KEY_LinkROI))
        _write_attribute(root, 'KEY_LinkText', str(db.KEY_LinkText))
        _write_attribute(root, 'KEY_ManualInsert', str(db.KEY_ManualInsert))
        _write_attribute(root, 'KEY_masking', str(db.KEY_masking))
        _write_attribute(root, 'KEY_molecule_device', str(db.KEY_molecule_device))
        _write_attribute(root, 'KEY_next', str(db.KEY_next))
        _write_attribute(root, 'KEY_nid', str(db.KEY_nid))
        _write_attribute(root, 'KEY_NormalizedSOA_CSVFilename', str(db.KEY_NormalizedSOA_CSVFilename))
        _write_attribute(root, 'KEY_NormalizedSOA_JSONFilename', str(db.KEY_NormalizedSOA_JSONFilename))
        _write_attribute(root, 'KEY_num_entities', str(db.KEY_num_entities))
        _write_attribute(root, 'KEY_number_of_subjects', str(db.KEY_number_of_subjects))
        _write_attribute(root, 'KEY_numId', str(db.KEY_numId))
        _write_attribute(root, 'KEY_ObjectiveRefRoiId', str(db.KEY_ObjectiveRefRoiId))
        _write_attribute(root, 'KEY_objectives_section', str(db.KEY_objectives_section))
        _write_attribute(root, 'KEY_ObjectivesEndpointsHeader', str(db.KEY_ObjectivesEndpointsHeader))
        _write_attribute(root, 'KEY_ObjectivesEndpointsRefRoiId', str(db.KEY_ObjectivesEndpointsRefRoiId))
        _write_attribute(root, 'KEY_ObjectivesHeader', str(db.KEY_ObjectivesHeader))
        _write_attribute(root, 'KEY_ObjectivesRefRoiId', str(db.KEY_ObjectivesRefRoiId))
        _write_attribute(root, 'KEY_observation', str(db.KEY_observation))
        _write_attribute(root, 'KEY_ParaIndex', str(db.KEY_ParaIndex))
        _write_attribute(root, 'KEY_ParaPrintPage', str(db.KEY_ParaPrintPage))
        _write_attribute(root, 'KEY_ParaROI', str(db.KEY_ParaROI))
        _write_attribute(root, 'KEY_ParaROIExactMatch', str(db.KEY_ParaROIExactMatch))
        _write_attribute(root, 'KEY_participant_age', str(db.KEY_participant_age))
        _write_attribute(root, 'KEY_participant_sex', str(db.KEY_participant_sex))
        _write_attribute(root, 'KEY_PB_biopsy', str(db.KEY_PB_biopsy))
        _write_attribute(root, 'KEY_PB_blood_draw', str(db.KEY_PB_blood_draw))
        _write_attribute(root, 'KEY_PB_caregiver', str(db.KEY_PB_caregiver))
        _write_attribute(root, 'KEY_PB_colonoscopy', str(db.KEY_PB_colonoscopy))
        _write_attribute(root, 'KEY_PB_diary', str(db.KEY_PB_diary))
        _write_attribute(root, 'KEY_PB_discontinue_treatment', str(db.KEY_PB_discontinue_treatment))
        _write_attribute(root, 'KEY_PB_endoscopy', str(db.KEY_PB_endoscopy))
        _write_attribute(root, 'KEY_PB_freq_pro', str(db.KEY_PB_freq_pro))
        _write_attribute(root, 'KEY_PB_imaging_ct', str(db.KEY_PB_imaging_ct))
        _write_attribute(root, 'KEY_PB_imaging_dexa', str(db.KEY_PB_imaging_dexa))
        _write_attribute(root, 'KEY_PB_imaging_mammogram', str(db.KEY_PB_imaging_mammogram))
        _write_attribute(root, 'KEY_PB_imaging_mri', str(db.KEY_PB_imaging_mri))
        _write_attribute(root, 'KEY_PB_imaging_pet', str(db.KEY_PB_imaging_pet))
        _write_attribute(root, 'KEY_PB_imaging_xray', str(db.KEY_PB_imaging_xray))
        _write_attribute(root, 'KEY_PB_IncludesPRO', str(db.KEY_PB_IncludesPRO))
        _write_attribute(root, 'KEY_PB_injectable', str(db.KEY_PB_injectable))
        _write_attribute(root, 'KEY_PB_injection_gt1_visit', str(db.KEY_PB_injection_gt1_visit))
        _write_attribute(root, 'KEY_PB_inpatient', str(db.KEY_PB_inpatient))
        _write_attribute(root, 'KEY_PB_lumbar_puncture', str(db.KEY_PB_lumbar_puncture))
        _write_attribute(root, 'KEY_PB_median_visit_len', str(db.KEY_PB_median_visit_len))
        _write_attribute(root, 'KEY_PB_novel_drug', str(db.KEY_PB_novel_drug))
        _write_attribute(root, 'KEY_PB_num_visits_per_month', str(db.KEY_PB_num_visits_per_month))
        _write_attribute(root, 'KEY_PB_pb_total_score', str(db.KEY_PB_pb_total_score))
        _write_attribute(root, 'KEY_PB_percent_placebo', str(db.KEY_PB_percent_placebo))
        _write_attribute(root, 'KEY_PB_percent_visit_blood_gte1', str(db.KEY_PB_percent_visit_blood_gte1))
        _write_attribute(root, 'KEY_PB_pro', str(db.KEY_PB_pro))
        _write_attribute(root, 'KEY_PB_total_num_months', str(db.KEY_PB_total_num_months))
        _write_attribute(root, 'KEY_PB_total_num_pro', str(db.KEY_PB_total_num_pro))
        _write_attribute(root, 'KEY_PB_total_num_site_visit', str(db.KEY_PB_total_num_site_visit))
        _write_attribute(root, 'KEY_phase', str(db.KEY_phase))
        _write_attribute(root, 'KEY_PhysicalTableIndex', str(db.KEY_PhysicalTableIndex))
        _write_attribute(root, 'KEY_population', str(db.KEY_population))
        _write_attribute(root, 'KEY_PopulationCountElement', str(db.KEY_PopulationCountElement))
        _write_attribute(root, 'KEY_priority', str(db.KEY_priority))
        _write_attribute(root, 'KEY_prob', str(db.KEY_prob))
        _write_attribute(root, 'KEY_ProcessDateTime', str(db.KEY_ProcessDateTime))
        _write_attribute(root, 'KEY_ProcessMachineName', str(db.KEY_ProcessMachineName))
        _write_attribute(root, 'KEY_ProcessName', str(db.KEY_ProcessName))
        _write_attribute(root, 'KEY_ProcessVersion', str(db.KEY_ProcessVersion))
        _write_attribute(root, 'KEY_project_id', str(db.KEY_project_id))
        _write_attribute(root, 'KEY_ProtocolName', str(db.KEY_ProtocolName))
        _write_attribute(root, 'KEY_ProtocolNumber', str(db.KEY_ProtocolNumber))
        _write_attribute(root, 'KEY_ProtocolNumberElement', str(db.KEY_ProtocolNumberElement))
        _write_attribute(root, 'KEY_ProtocolSponsorElement', str(db.KEY_ProtocolSponsorElement))
        _write_attribute(root, 'KEY_ProtocolTitle', str(db.KEY_ProtocolTitle))
        _write_attribute(root, 'KEY_ProtocolTitleElement', str(db.KEY_ProtocolTitleElement))
        _write_attribute(root, 'KEY_ProtocolVersion', str(db.KEY_ProtocolVersion))
        _write_attribute(root, 'KEY_pt', str(db.KEY_pt))
        _write_attribute(root, 'KEY_qcfeedback_runid', str(db.KEY_qcfeedback_runid))
        _write_attribute(root, 'KEY_redaction_any_address', str(db.KEY_redaction_any_address))
        _write_attribute(root, 'KEY_redaction_any_email', str(db.KEY_redaction_any_email))
        _write_attribute(root, 'KEY_redaction_any_organization', str(db.KEY_redaction_any_organization))
        _write_attribute(root, 'KEY_redaction_any_telephone', str(db.KEY_redaction_any_telephone))
        _write_attribute(root, 'KEY_redaction_category', str(db.KEY_redaction_category))
        _write_attribute(root, 'KEY_redaction_investigator', str(db.KEY_redaction_investigator))
        _write_attribute(root, 'KEY_redaction_molecule_name', str(db.KEY_redaction_molecule_name))
        _write_attribute(root, 'KEY_redaction_other_person_role', str(db.KEY_redaction_other_person_role))
        _write_attribute(root, 'KEY_redaction_primary_investigator', str(db.KEY_redaction_primary_investigator))
        _write_attribute(root, 'KEY_redaction_profile_id', str(db.KEY_redaction_profile_id))
        _write_attribute(root, 'KEY_redaction_qualified_physician', str(db.KEY_redaction_qualified_physician))
        _write_attribute(root, 'KEY_redaction_sponsor_address', str(db.KEY_redaction_sponsor_address))
        _write_attribute(root, 'KEY_redaction_sponsor_monitor', str(db.KEY_redaction_sponsor_monitor))
        _write_attribute(root, 'KEY_redaction_sponsor_name', str(db.KEY_redaction_sponsor_name))
        _write_attribute(root, 'KEY_redaction_sponsor_signatory', str(db.KEY_redaction_sponsor_signatory))
        _write_attribute(root, 'KEY_redaction_sponsors_medical_expert', str(db.KEY_redaction_sponsors_medical_expert))
        _write_attribute(root, 'KEY_redaction_subcategory', str(db.KEY_redaction_subcategory))
        _write_attribute(root, 'KEY_ReferencesHeader', str(db.KEY_ReferencesHeader))
        _write_attribute(root, 'KEY_ReferencesRefRoiId', str(db.KEY_ReferencesRefRoiId))
        _write_attribute(root, 'KEY_roi_id', str(db.KEY_roi_id))
        _write_attribute(root, 'KEY_roi_text', str(db.KEY_roi_text))
        _write_attribute(root, 'KEY_secondary_objectives', str(db.KEY_secondary_objectives))
        _write_attribute(root, 'KEY_SectionHeader', str(db.KEY_SectionHeader))
        _write_attribute(root, 'KEY_SectionHeaderPrintPage', str(db.KEY_SectionHeaderPrintPage))
        _write_attribute(root, 'KEY_SectionHeaderROI', str(db.KEY_SectionHeaderROI))
        _write_attribute(root, 'KEY_SectionHeaderRoiId', str(db.KEY_SectionHeaderRoiId))
        _write_attribute(root, 'KEY_SectionRefRoiId', str(db.KEY_SectionRefRoiId))
        _write_attribute(root, 'KEY_short_title', str(db.KEY_short_title))
        _write_attribute(root, 'KEY_sid', str(db.KEY_sid))
        _write_attribute(root, 'KEY_site', str(db.KEY_site))
        _write_attribute(root, 'KEY_soa_days', str(db.KEY_soa_days))
        _write_attribute(root, 'KEY_soa_epochs', str(db.KEY_soa_epochs))
        _write_attribute(root, 'KEY_soa_footnotes', str(db.KEY_soa_footnotes))
        _write_attribute(root, 'KEY_soa_months', str(db.KEY_soa_months))
        _write_attribute(root, 'KEY_soa_section_links', str(db.KEY_soa_section_links))
        _write_attribute(root, 'KEY_soa_visit', str(db.KEY_soa_visit))
        _write_attribute(root, 'KEY_soa_weeks', str(db.KEY_soa_weeks))
        _write_attribute(root, 'KEY_soa_window', str(db.KEY_soa_window))
        _write_attribute(root, 'KEY_soa_years', str(db.KEY_soa_years))
        _write_attribute(root, 'KEY_SOAHeader', str(db.KEY_SOAHeader))
        _write_attribute(root, 'KEY_SOARefRoiId', str(db.KEY_SOARefRoiId))
        _write_attribute(root, 'KEY_SOATableFeatures', str(db.KEY_SOATableFeatures))
        _write_attribute(root, 'KEY_span', str(db.KEY_span))
        _write_attribute(root, 'KEY_sponsor', str(db.KEY_sponsor))
        _write_attribute(root, 'KEY_sponsor_address', str(db.KEY_sponsor_address))
        _write_attribute(root, 'KEY_standard_template_level', str(db.KEY_standard_template_level))
        _write_attribute(root, 'KEY_standard_template_level_item', str(db.KEY_standard_template_level_item))
        _write_attribute(root, 'KEY_standard_template_placeholder', str(db.KEY_standard_template_placeholder))
        _write_attribute(root, 'KEY_standard_template_placeholder_item', str(db.KEY_standard_template_placeholder_item))
        _write_attribute(root, 'KEY_standard_template_prefix', str(db.KEY_standard_template_prefix))
        _write_attribute(root, 'KEY_standard_template_prefix_item', str(db.KEY_standard_template_prefix_item))
        _write_attribute(root, 'KEY_standard_template_similarity_score', str(db.KEY_standard_template_similarity_score))
        _write_attribute(root, 'KEY_standard_template_text', str(db.KEY_standard_template_text))
        _write_attribute(root, 'KEY_StatisticalConsiderationsHeader', str(db.KEY_StatisticalConsiderationsHeader))
        _write_attribute(root, 'KEY_StatisticalConsiderationsRefRoiId', str(db.KEY_StatisticalConsiderationsRefRoiId))
        _write_attribute(root, 'KEY_study_id', str(db.KEY_study_id))
        _write_attribute(root, 'KEY_study_status', str(db.KEY_study_status))
        _write_attribute(root, 'KEY_StudyAssessmentsandProceduresHeader',
                         str(db.KEY_StudyAssessmentsandProceduresHeader))
        _write_attribute(root, 'KEY_StudyAssessmentsandProceduresRefRoiId',
                         str(db.KEY_StudyAssessmentsandProceduresRefRoiId))
        _write_attribute(root, 'KEY_StudyDesignHeader', str(db.KEY_StudyDesignHeader))
        _write_attribute(root, 'KEY_StudyDesignRefRoiId', str(db.KEY_StudyDesignRefRoiId))
        _write_attribute(root, 'KEY_StudyInterventionsandConcomitantTherapyHeader',
                         str(db.KEY_StudyInterventionsandConcomitantTherapyHeader))
        _write_attribute(root, 'KEY_StudyInterventionsandConcomitantTherapyRefRoiId',
                         str(db.KEY_StudyInterventionsandConcomitantTherapyRefRoiId))
        _write_attribute(root, 'KEY_StudyPopulationHeader', str(db.KEY_StudyPopulationHeader))
        _write_attribute(root, 'KEY_StudyPopulationRefRoiId', str(db.KEY_StudyPopulationRefRoiId))
        _write_attribute(root, 'KEY_SummaryHeader', str(db.KEY_SummaryHeader))
        _write_attribute(root, 'KEY_SummaryRefRoiId', str(db.KEY_SummaryRefRoiId))
        _write_attribute(root, 'KEY_SupportingDocumentationHeader', str(db.KEY_SupportingDocumentationHeader))
        _write_attribute(root, 'KEY_SupportingDocumentationRefRoiId', str(db.KEY_SupportingDocumentationRefRoiId))
        _write_attribute(root, 'KEY_TableColumnIndex', str(db.KEY_TableColumnIndex))
        _write_attribute(root, 'KEY_TableROI', str(db.KEY_TableROI))
        _write_attribute(root, 'KEY_TableRowIndex', str(db.KEY_TableRowIndex))
        _write_attribute(root, 'KEY_this', str(db.KEY_this))
        _write_attribute(root, 'KEY_time_unit', str(db.KEY_time_unit))
        _write_attribute(root, 'KEY_time_unit_day', str(db.KEY_time_unit_day))
        _write_attribute(root, 'KEY_time_unit_epoch', str(db.KEY_time_unit_epoch))
        _write_attribute(root, 'KEY_time_unit_month', str(db.KEY_time_unit_month))
        _write_attribute(root, 'KEY_time_unit_sub_epoch', str(db.KEY_time_unit_sub_epoch))
        _write_attribute(root, 'KEY_time_unit_visit', str(db.KEY_time_unit_visit))
        _write_attribute(root, 'KEY_time_unit_week', str(db.KEY_time_unit_week))
        _write_attribute(root, 'KEY_time_unit_window', str(db.KEY_time_unit_window))
        _write_attribute(root, 'KEY_time_unit_year', str(db.KEY_time_unit_year))
        _write_attribute(root, 'KEY_time_value', str(db.KEY_time_value))
        _write_attribute(root, 'KEY_TOAHeader', str(db.KEY_TOAHeader))
        _write_attribute(root, 'KEY_TOARefRoiId', str(db.KEY_TOARefRoiId))
        _write_attribute(root, 'KEY_TOCHeader', str(db.KEY_TOCHeader))
        _write_attribute(root, 'KEY_TOCRefRoiId', str(db.KEY_TOCRefRoiId))
        _write_attribute(root, 'KEY_TOFHeader', str(db.KEY_TOFHeader))
        _write_attribute(root, 'KEY_TOFRefRoiId', str(db.KEY_TOFRefRoiId))
        _write_attribute(root, 'KEY_TOTHeader', str(db.KEY_TOTHeader))
        _write_attribute(root, 'KEY_TOTRefRoiId', str(db.KEY_TOTRefRoiId))
        _write_attribute(root, 'KEY_trial_type_randomized', str(db.KEY_trial_type_randomized))
        _write_attribute(root, 'KEY_uploadDate', str(db.KEY_uploadDate))
        _write_attribute(root, 'KEY_user_filename', str(db.KEY_user_filename))
        _write_attribute(root, 'KEY_UserBusinessUnit', str(db.KEY_UserBusinessUnit))
        _write_attribute(root, 'KEY_version_date', str(db.KEY_version_date))
        _write_attribute(root, 'KEY_Y', str(db.KEY_Y))
        ##############################################################
        #
        # End of fields
        #
        ##############################################################
        return root
    except Exception as e:
        logger.error('Failed to write IQV_KEY_STRING to root')


def _writeToXmlFromNLP_Entity(db: NLP_Entity):
    """
    Get the ET Element NLP_Entity with all of its subelements
    """

    try:
        root = ET.Element("NLP_Entity")
        ##############################################################
        #
        # Start of fields
        #
        ##############################################################
        _write_attribute(root, 'confidence', str(db.confidence))
        _write_attribute(root, 'doc_id', str(db.doc_id))
        _write_attribute(root, 'dts', str(db.dts))
        _write_attribute(root, 'entity_class', str(db.entity_class))
        _write_attribute(root, 'entity_index', str(db.entity_index))
        _write_attribute(root, 'entity_key', str(db.entity_key))
        _write_attribute(root, 'group_type', str(db.group_type))
        _write_attribute(root, 'hierarchy', str(db.hierarchy))
        _write_attribute(root, 'id', str(db.id))
        _write_attribute(root, 'iqv_standard_term', str(db.iqv_standard_term))
        _write_attribute(root, 'link_id', str(db.link_id))
        _write_attribute(root, 'link_id_level2', str(db.link_id_level2))
        _write_attribute(root, 'link_id_level3', str(db.link_id_level3))
        _write_attribute(root, 'link_id_level4', str(db.link_id_level4))
        _write_attribute(root, 'link_id_level5', str(db.link_id_level5))
        _write_attribute(root, 'link_id_level6', str(db.link_id_level6))
        _write_attribute(root, 'link_id_subsection1', str(db.link_id_subsection1))
        _write_attribute(root, 'link_id_subsection2', str(db.link_id_subsection2))
        _write_attribute(root, 'link_id_subsection3', str(db.link_id_subsection3))
        _write_attribute(root, 'negated', str(db.negated))
        _write_attribute(root, 'ontology', str(db.ontology))
        _write_attribute(root, 'ontology_item_code', str(db.ontology_item_code))
        _write_attribute(root, 'ontology_version', str(db.ontology_version))
        _write_attribute(root, 'parent_id', str(db.parent_id))
        _write_attribute(root, 'process_source', str(db.process_source))

        fieldName = 'Properties'
        try:
            subelement = ET.SubElement(root, fieldName)
            for xelm in db.Properties:
                subelement.append(_writeToXmlFromIQVKeyValueSet(xelm))
        except Exception as e:
            logger.info('Failed to export field ' + fieldName)
        _write_attribute(root, 'standard_entity_name', str(db.standard_entity_name))
        _write_attribute(root, 'start', str(db.start))
        _write_attribute(root, 'text', str(db.text))
        _write_attribute(root, 'text_len', str(db.text_len))
        _write_attribute(root, 'user_id', str(db.user_id))
        ##############################################################
        #
        # End of fields
        #
        ##############################################################
        return root
    except Exception as e:
        logger.error('Failed to write NLP_Entity to root')


def _writeToXmlFromIQVConceptTerm(db: IQVConceptTerm):
    """
    Get the ET Element IQVConceptTerm with all of its subelements
    """

    try:
        root = ET.Element("IQVConceptTerm")
        ##############################################################
        #
        # Start of fields
        #
        ##############################################################
        _write_attribute(root, 'cui', str(db.cui))
        _write_attribute(root, 'entity_class', str(db.entity_class))
        _write_attribute(root, 'entity_text', str(db.entity_text))
        _write_attribute(root, 'entity_xref', str(db.entity_xref))
        _write_attribute(root, 'id', str(db.id))
        _write_attribute(root, 'info', str(db.info))
        _write_attribute(root, 'ontology', str(db.ontology))
        _write_attribute(root, 'preferred_term', str(db.preferred_term))
        ##############################################################
        #
        # End of fields
        #
        ##############################################################
        return root
    except Exception as e:
        logger.error('Failed to write IQVConceptTerm to root')


def _writeToXmlFromIQVConceptRelation(db: IQVConceptRelation):
    """
    Get the ET Element IQVConceptRelation with all of its subelements
    """

    try:
        root = ET.Element("IQVConceptRelation")
        ##############################################################
        #
        # Start of fields
        #
        ##############################################################
        _write_attribute(root, 'context_unit', str(db.context_unit))
        _write_attribute(root, 'dts', str(db.dts))
        _write_attribute(root, 'id', str(db.id))
        _write_attribute(root, 'id1', str(db.id1))
        _write_attribute(root, 'id2', str(db.id2))
        _write_attribute(root, 'relation_type', str(db.relation_type))
        _write_attribute(root, 'user_id', str(db.user_id))
        _write_attribute(root, 'weight', str(db.weight))
        ##############################################################
        #
        # End of fields
        #
        ##############################################################
        return root
    except Exception as e:
        logger.error('Failed to write IQVConceptRelation to root')


def _writeToXmlFromNLP_Attribute(db: NLP_Attribute):
    """
    Get the ET Element NLP_Attribute with all of its subelements
    """

    try:
        root = ET.Element("NLP_Attribute")
        ##############################################################
        #
        # Start of fields
        #
        ##############################################################
        _write_attribute(root, 'attribute_class', str(db.attribute_class))
        _write_attribute(root, 'attribute_index', str(db.attribute_index))
        _write_attribute(root, 'doc_id', str(db.doc_id))
        _write_attribute(root, 'group_type', str(db.group_type))
        _write_attribute(root, 'hierarchy', str(db.hierarchy))
        _write_attribute(root, 'id', str(db.id))
        _write_attribute(root, 'iqv_standard_term', str(db.iqv_standard_term))
        _write_attribute(root, 'link_id', str(db.link_id))
        _write_attribute(root, 'link_id_level2', str(db.link_id_level2))
        _write_attribute(root, 'link_id_level3', str(db.link_id_level3))
        _write_attribute(root, 'link_id_level4', str(db.link_id_level4))
        _write_attribute(root, 'link_id_level5', str(db.link_id_level5))
        _write_attribute(root, 'link_id_level6', str(db.link_id_level6))
        _write_attribute(root, 'link_id_subsection1', str(db.link_id_subsection1))
        _write_attribute(root, 'link_id_subsection2', str(db.link_id_subsection2))
        _write_attribute(root, 'link_id_subsection3', str(db.link_id_subsection3))
        _write_attribute(root, 'parent_id', str(db.parent_id))
        _write_attribute(root, 'process_source', str(db.process_source))
        _write_attribute(root, 'start', str(db.start))
        _write_attribute(root, 'text', str(db.text))
        ##############################################################
        #
        # End of fields
        #
        ##############################################################
        return root
    except Exception as e:
        logger.error('Failed to write NLP_Attribute to root')


def _writeToXmlFromNLP_Relation(db: NLP_Relation):
    """
    Get the ET Element NLP_Relation with all of its subelements
    """

    try:
        root = ET.Element("NLP_Relation")
        ##############################################################
        #
        # Start of fields
        #
        ##############################################################
        _write_attribute(root, 'confidence', str(db.confidence))
        _write_attribute(root, 'doc_id', str(db.doc_id))

        fieldName = 'entities'
        try:
            subelement = ET.SubElement(root, fieldName)
            for xelm in db.entities:
                subelement.append(_writeToXmlFromString(xelm))
        except Exception as e:
            logger.info('Failed to export field ' + fieldName)
        _write_attribute(root, 'entities_list', str(db.entities_list))
        _write_attribute(root, 'group_type', str(db.group_type))
        _write_attribute(root, 'hierarchy', str(db.hierarchy))
        _write_attribute(root, 'id', str(db.id))
        _write_attribute(root, 'iqv_standard_term', str(db.iqv_standard_term))
        _write_attribute(root, 'is_bidirectional', str(db.is_bidirectional))
        _write_attribute(root, 'is_hierarchical', str(db.is_hierarchical))
        _write_attribute(root, 'link_id', str(db.link_id))
        _write_attribute(root, 'link_id_level2', str(db.link_id_level2))
        _write_attribute(root, 'link_id_level3', str(db.link_id_level3))
        _write_attribute(root, 'link_id_level4', str(db.link_id_level4))
        _write_attribute(root, 'link_id_level5', str(db.link_id_level5))
        _write_attribute(root, 'link_id_level6', str(db.link_id_level6))
        _write_attribute(root, 'link_id_subsection1', str(db.link_id_subsection1))
        _write_attribute(root, 'link_id_subsection2', str(db.link_id_subsection2))
        _write_attribute(root, 'link_id_subsection3', str(db.link_id_subsection3))
        _write_attribute(root, 'parent_id', str(db.parent_id))
        _write_attribute(root, 'process_source', str(db.process_source))
        _write_attribute(root, 'relation_name', str(db.relation_name))
        _write_attribute(root, 'relation_type', str(db.relation_type))
        ##############################################################
        #
        # End of fields
        #
        ##############################################################
        return root
    except Exception as e:
        logger.error('Failed to write NLP_Relation to root')


def _writeToXmlFromNLP_Segment(db: NLP_Segment):
    """
    Get the ET Element NLP_Segment with all of its subelements
    """

    try:
        root = ET.Element("NLP_Segment")
        ##############################################################
        #
        # Start of fields
        #
        ##############################################################

        fieldName = 'attributes'
        try:
            subelement = ET.SubElement(root, fieldName)
            for xelm in db.attributes:
                subelement.append(_writeToXmlFromNLP_Attribute(xelm))
        except Exception as e:
            logger.info('Failed to export field ' + fieldName)
        _write_attribute(root, 'doc_id', str(db.doc_id))

        fieldName = 'entities'
        try:
            subelement = ET.SubElement(root, fieldName)
            for xelm in db.entities:
                subelement.append(_writeToXmlFromNLP_Entity(xelm))
        except Exception as e:
            logger.info('Failed to export field ' + fieldName)
        _write_attribute(root, 'group_type', str(db.group_type))
        _write_attribute(root, 'hierarchy', str(db.hierarchy))
        _write_attribute(root, 'id', str(db.id))
        _write_attribute(root, 'iqv_standard_term', str(db.iqv_standard_term))
        _write_attribute(root, 'link_id', str(db.link_id))
        _write_attribute(root, 'link_id_level2', str(db.link_id_level2))
        _write_attribute(root, 'link_id_level3', str(db.link_id_level3))
        _write_attribute(root, 'link_id_level4', str(db.link_id_level4))
        _write_attribute(root, 'link_id_level5', str(db.link_id_level5))
        _write_attribute(root, 'link_id_level6', str(db.link_id_level6))
        _write_attribute(root, 'link_id_subsection1', str(db.link_id_subsection1))
        _write_attribute(root, 'link_id_subsection2', str(db.link_id_subsection2))
        _write_attribute(root, 'link_id_subsection3', str(db.link_id_subsection3))
        _write_attribute(root, 'parent_id', str(db.parent_id))
        _write_attribute(root, 'primary_section', str(db.primary_section))

        fieldName = 'Properties'
        try:
            subelement = ET.SubElement(root, fieldName)
            for xelm in db.Properties:
                subelement.append(_writeToXmlFromIQVKeyValueSet(xelm))
        except Exception as e:
            logger.info('Failed to export field ' + fieldName)
        _write_attribute(root, 'secondary_section', str(db.secondary_section))
        _write_attribute(root, 'segment_type', str(db.segment_type))

        fieldName = 'segments'
        try:
            subelement = ET.SubElement(root, fieldName)
            for xelm in db.segments:
                subelement.append(_writeToXmlFromNLP_Entity(xelm))
        except Exception as e:
            logger.info('Failed to export field ' + fieldName)
        _write_attribute(root, 'text', str(db.text))

        fieldName = 'text_footnotes'
        try:
            subelement = ET.SubElement(root, fieldName)
            for xelm in db.text_footnotes:
                subelement.append(_writeToXmlFromString(xelm))
        except Exception as e:
            logger.info('Failed to export field ' + fieldName)
        ##############################################################
        #
        # End of fields
        #
        ##############################################################
        return root
    except Exception as e:
        logger.error('Failed to write NLP_Segment to root')


def _writeToXmlFromNLP_System_Mapping(db: NLP_System_Mapping):
    """
    Get the ET Element NLP_System_Mapping with all of its subelements
    """

    try:
        root = ET.Element("NLP_System_Mapping")
        ##############################################################
        #
        # Start of fields
        #
        ##############################################################
        _write_attribute(root, 'DataType', str(db.DataType))
        _write_attribute(root, 'doc_id', str(db.doc_id))
        _write_attribute(root, 'EntityKey', str(db.EntityKey))
        _write_attribute(root, 'FilenameKey', str(db.FilenameKey))
        _write_attribute(root, 'group_type', str(db.group_type))
        _write_attribute(root, 'hierarchy', str(db.hierarchy))
        _write_attribute(root, 'id', str(db.id))
        _write_attribute(root, 'iqv_standard_term', str(db.iqv_standard_term))
        _write_attribute(root, 'link_id', str(db.link_id))
        _write_attribute(root, 'link_id_level2', str(db.link_id_level2))
        _write_attribute(root, 'link_id_level3', str(db.link_id_level3))
        _write_attribute(root, 'link_id_level4', str(db.link_id_level4))
        _write_attribute(root, 'link_id_level5', str(db.link_id_level5))
        _write_attribute(root, 'link_id_level6', str(db.link_id_level6))
        _write_attribute(root, 'link_id_subsection1', str(db.link_id_subsection1))
        _write_attribute(root, 'link_id_subsection2', str(db.link_id_subsection2))
        _write_attribute(root, 'link_id_subsection3', str(db.link_id_subsection3))
        _write_attribute(root, 'NLPSystem', str(db.NLPSystem))
        _write_attribute(root, 'NLPSystemQueryName', str(db.NLPSystemQueryName))
        _write_attribute(root, 'NLPSystemVersion', str(db.NLPSystemVersion))
        _write_attribute(root, 'parent_id', str(db.parent_id))
        _write_attribute(root, 'QCFeedbackUIKey', str(db.QCFeedbackUIKey))
        ##############################################################
        #
        # End of fields
        #
        ##############################################################
        return root
    except Exception as e:
        logger.error('Failed to write NLP_System_Mapping to root')


def _writeToXmlFromIQVRedactionCategory(db: IQVRedactionCategory):
    """
    Get the ET Element IQVRedactionCategory with all of its subelements
    """

    try:
        root = ET.Element("IQVRedactionCategory")
        ##############################################################
        #
        # Start of fields
        #
        ##############################################################
        _write_attribute(root, 'Category', str(db.Category))
        _write_attribute(root, 'id', str(db.id))
        _write_attribute(root, 'IsRedacted', str(db.IsRedacted))
        _write_attribute(root, 'Query', str(db.Query))
        ##############################################################
        #
        # End of fields
        #
        ##############################################################
        return root
    except Exception as e:
        logger.error('Failed to write IQVRedactionCategory to root')


def _writeToXmlFromIQVRedactionProfile(db: IQVRedactionProfile):
    """
    Get the ET Element IQVRedactionProfile with all of its subelements
    """

    try:
        root = ET.Element("IQVRedactionProfile")
        ##############################################################
        #
        # Start of fields
        #
        ##############################################################

        fieldName = 'Categories'
        try:
            subelement = ET.SubElement(root, fieldName)
            for xelm in db.Categories:
                subelement.append(_writeToXmlFromIQVKeyValueSet(xelm))
        except Exception as e:
            logger.info('Failed to export field ' + fieldName)
        _write_attribute(root, 'DefaultIsRedacted', str(db.DefaultIsRedacted))
        _write_attribute(root, 'id', str(db.id))
        ##############################################################
        #
        # End of fields
        #
        ##############################################################
        return root
    except Exception as e:
        logger.error('Failed to write IQVRedactionProfile to root')


def _writeToXmlFromIQVDocumentLink(db: IQVDocumentLink):
    """
    Get the ET Element IQVDocumentLink with all of its subelements
    """

    try:
        root = ET.Element("IQVDocumentLink")
        ##############################################################
        #
        # Start of fields
        #
        ##############################################################
        _write_attribute(root, 'doc_id', str(db.doc_id))
        _write_attribute(root, 'group_type', str(db.group_type))
        _write_attribute(root, 'hierarchy', str(db.hierarchy))
        _write_attribute(root, 'id', str(db.id))
        _write_attribute(root, 'iqv_standard_term', str(db.iqv_standard_term))
        _write_attribute(root, 'link_id', str(db.link_id))
        _write_attribute(root, 'link_id_level2', str(db.link_id_level2))
        _write_attribute(root, 'link_id_level3', str(db.link_id_level3))
        _write_attribute(root, 'link_id_level4', str(db.link_id_level4))
        _write_attribute(root, 'link_id_level5', str(db.link_id_level5))
        _write_attribute(root, 'link_id_level6', str(db.link_id_level6))
        _write_attribute(root, 'link_id_subsection1', str(db.link_id_subsection1))
        _write_attribute(root, 'link_id_subsection2', str(db.link_id_subsection2))
        _write_attribute(root, 'link_id_subsection3', str(db.link_id_subsection3))

        fieldName = 'LinkDestinations'
        try:
            subelement = ET.SubElement(root, fieldName)
            for xelm in db.LinkDestinations:
                subelement.append(_writeToXmlFromIQVPageROI(xelm))
        except Exception as e:
            logger.info('Failed to export field ' + fieldName)
        _write_attribute(root, 'LinkLevel', str(db.LinkLevel))
        _write_attribute(root, 'LinkPage', str(db.LinkPage))

        fieldName = 'LinkPointers'
        try:
            subelement = ET.SubElement(root, fieldName)
            for xelm in db.LinkPointers:
                subelement.append(_writeToXmlFromIQVPageROI(xelm))
        except Exception as e:
            logger.info('Failed to export field ' + fieldName)
        _write_attribute(root, 'LinkPrefix', str(db.LinkPrefix))
        _write_attribute(root, 'LinkText', str(db.LinkText))
        _write_attribute(root, 'LinkType', str(db.LinkType))
        _write_attribute(root, 'parent_id', str(db.parent_id))

        fieldName = 'Properties'
        try:
            subelement = ET.SubElement(root, fieldName)
            for xelm in db.Properties:
                subelement.append(_writeToXmlFromIQVKeyValueSet(xelm))
        except Exception as e:
            logger.info('Failed to export field ' + fieldName)
        ##############################################################
        #
        # End of fields
        #
        ##############################################################
        return root
    except Exception as e:
        logger.error('Failed to write IQVDocumentLink to root')


def _writeToXmlFromIQVDocumentVariable(db: IQVDocumentVariable):
    """
    Get the ET Element IQVDocumentVariable with all of its subelements
    """

    try:
        root = ET.Element("IQVDocumentVariable")
        ##############################################################
        #
        # Start of fields
        #
        ##############################################################
        _write_attribute(root, 'doc_id', str(db.doc_id))
        _write_attribute(root, 'dts', str(db.dts))
        _write_attribute(root, 'id', str(db.id))
        _write_attribute(root, 'run_id', str(db.run_id))
        _write_attribute(root, 'source_filename', str(db.source_filename))
        _write_attribute(root, 'variable_category', str(db.variable_category))
        _write_attribute(root, 'variable_datatype', str(db.variable_datatype))
        _write_attribute(root, 'variable_index', str(db.variable_index))
        _write_attribute(root, 'variable_key', str(db.variable_key))
        _write_attribute(root, 'variable_label', str(db.variable_label))
        _write_attribute(root, 'variable_listing_filename', str(db.variable_listing_filename))
        _write_attribute(root, 'variable_notes', str(db.variable_notes))
        _write_attribute(root, 'variable_score', str(db.variable_score))
        _write_attribute(root, 'variable_source', str(db.variable_source))
        _write_attribute(root, 'variable_value', str(db.variable_value))
        ##############################################################
        #
        # End of fields
        #
        ##############################################################
        return root
    except Exception as e:
        logger.error('Failed to write IQVDocumentVariable to root')


def _writeToXmlFromIQVDocumentDiff(db: IQVDocumentDiff):
    """
    Get the ET Element IQVDocumentDiff with all of its subelements
    """

    try:
        root = ET.Element("IQVDocumentDiff")
        ##############################################################
        #
        # Start of fields
        #
        ##############################################################

        fieldName = 'ChildDiffs'
        try:
            subelement = ET.SubElement(root, fieldName)
            for xelm in db.ChildDiffs:
                subelement.append(_writeToXmlFromIQVDocumentDiff(xelm))
        except Exception as e:
            logger.info('Failed to export field ' + fieldName)
        _write_attribute(root, 'compare_roi_id', str(db.compare_roi_id))
        _write_attribute(root, 'confidence', str(db.confidence))
        _write_attribute(root, 'diff_category', str(db.diff_category))
        _write_attribute(root, 'diff_string', str(db.diff_string))
        _write_attribute(root, 'diff_subcategory', str(db.diff_subcategory))
        _write_attribute(root, 'diff_type', str(db.diff_type))
        _write_attribute(root, 'id', str(db.id))
        _write_attribute(root, 'IsPreferredTermComparison', _bool2str(db.IsPreferredTermComparison))
        _write_attribute(root, 'local_roi_id', str(db.local_roi_id))

        fieldName = 'Properties'
        try:
            subelement = ET.SubElement(root, fieldName)
            for xelm in db.Properties:
                subelement.append(_writeToXmlFromIQVKeyValueSet(xelm))
        except Exception as e:
            logger.info('Failed to export field ' + fieldName)

        fieldName = 'PropertiesBase'
        try:
            subelement = ET.SubElement(root, fieldName)
            for xelm in db.PropertiesBase:
                subelement.append(_writeToXmlFromIQVKeyValueSet(xelm))
        except Exception as e:
            logger.info('Failed to export field ' + fieldName)

        fieldName = 'PropertiesCompare'
        try:
            subelement = ET.SubElement(root, fieldName)
            for xelm in db.PropertiesCompare:
                subelement.append(_writeToXmlFromIQVKeyValueSet(xelm))
        except Exception as e:
            logger.info('Failed to export field ' + fieldName)

        fieldName = 'tableColumnLHS'
        try:
            subelement = _writeToXmlFromIQVTableColumn(db.tableColumnLHS)
            subelement.tag = fieldName
            root.append(subelement)
        except Exception as e:
            logger.info('Failed to export field ' + fieldName)

        fieldName = 'tableColumnRHS'
        try:
            subelement = _writeToXmlFromIQVTableColumn(db.tableColumnRHS)
            subelement.tag = fieldName
            root.append(subelement)
        except Exception as e:
            logger.info('Failed to export field ' + fieldName)

        fieldName = 'tableRowHeaderLHS'
        try:
            subelement = _writeToXmlFromIQVPageROI(db.tableRowHeaderLHS)
            subelement.tag = fieldName
            root.append(subelement)
        except Exception as e:
            logger.info('Failed to export field ' + fieldName)

        fieldName = 'tableRowHeaderRHS'
        try:
            subelement = _writeToXmlFromIQVPageROI(db.tableRowHeaderRHS)
            subelement.tag = fieldName
            root.append(subelement)
        except Exception as e:
            logger.info('Failed to export field ' + fieldName)
        ##############################################################
        #
        # End of fields
        #
        ##############################################################
        return root
    except Exception as e:
        logger.error('Failed to write IQVDocumentDiff to root')


def _writeToXmlFromIQVDocumentCompare(db: IQVDocumentCompare):
    """
    Get the ET Element IQVDocumentCompare with all of its subelements
    """

    try:
        root = ET.Element("IQVDocumentCompare")
        ##############################################################
        #
        # Start of fields
        #
        ##############################################################
        _write_attribute(root, 'base_doc_id', str(db.base_doc_id))
        _write_attribute(root, 'base_doc_name', str(db.base_doc_name))

        fieldName = 'BaseDocProperties'
        try:
            subelement = ET.SubElement(root, fieldName)
            for xelm in db.BaseDocProperties:
                subelement.append(_writeToXmlFromIQVKeyValueSet(xelm))
        except Exception as e:
            logger.info('Failed to export field ' + fieldName)
        _write_attribute(root, 'compare_doc_id', str(db.compare_doc_id))
        _write_attribute(root, 'compare_doc_name', str(db.compare_doc_name))

        fieldName = 'CompareDocProperties'
        try:
            subelement = ET.SubElement(root, fieldName)
            for xelm in db.CompareDocProperties:
                subelement.append(_writeToXmlFromIQVKeyValueSet(xelm))
        except Exception as e:
            logger.info('Failed to export field ' + fieldName)

        fieldName = 'DocumentDiffs'
        try:
            subelement = ET.SubElement(root, fieldName)
            for xelm in db.DocumentDiffs:
                subelement.append(_writeToXmlFromIQVDocumentDiff(xelm))
        except Exception as e:
            logger.info('Failed to export field ' + fieldName)
        _write_attribute(root, 'id', str(db.id))

        fieldName = 'Properties'
        try:
            subelement = ET.SubElement(root, fieldName)
            for xelm in db.Properties:
                subelement.append(_writeToXmlFromIQVKeyValueSet(xelm))
        except Exception as e:
            logger.info('Failed to export field ' + fieldName)
        _write_attribute(root, 'redaction_profile_id', str(db.redaction_profile_id))

        fieldName = 'RedactionProfile'
        try:
            subelement = _writeToXmlFromIQVRedactionProfile(db.RedactionProfile)
            subelement.tag = fieldName
            root.append(subelement)
        except Exception as e:
            logger.info('Failed to export field ' + fieldName)
        ##############################################################
        #
        # End of fields
        #
        ##############################################################
        return root
    except Exception as e:
        logger.error('Failed to write IQVDocumentCompare to root')


def _writeToXmlFromIQVDiffRecord(db: IQVDiffRecord):
    """
    Get the ET Element IQVDiffRecord with all of its subelements
    """

    try:
        root = ET.Element("IQVDiffRecord")
        ##############################################################
        #
        # Start of fields
        #
        ##############################################################
        _write_attribute(root, 'category', str(db.category))
        _write_attribute(root, 'diff_string', str(db.diff_string))
        _write_attribute(root, 'diff_type', str(db.diff_type))
        _write_attribute(root, 'doc_id_a', str(db.doc_id_a))
        _write_attribute(root, 'doc_id_b', str(db.doc_id_b))
        _write_attribute(root, 'dts', str(db.dts))
        _write_attribute(root, 'id', str(db.id))
        _write_attribute(root, 'pname_a', str(db.pname_a))
        _write_attribute(root, 'pname_b', str(db.pname_b))
        _write_attribute(root, 'ProcessMachineName', str(db.ProcessMachineName))
        _write_attribute(root, 'ProcessVersion', str(db.ProcessVersion))
        _write_attribute(root, 'ptdiff_string', str(db.ptdiff_string))
        _write_attribute(root, 'ptdiff_type', str(db.ptdiff_type))
        _write_attribute(root, 'pttext_a', str(db.pttext_a))
        _write_attribute(root, 'pttext_b', str(db.pttext_b))
        _write_attribute(root, 'roi_id_a', str(db.roi_id_a))
        _write_attribute(root, 'roi_id_b', str(db.roi_id_b))
        _write_attribute(root, 'section', str(db.section))
        _write_attribute(root, 'start_index', str(db.start_index))
        _write_attribute(root, 'subcategory', str(db.subcategory))
        _write_attribute(root, 'table_column', str(db.table_column))
        _write_attribute(root, 'table_row', str(db.table_row))
        _write_attribute(root, 'text_a', str(db.text_a))
        _write_attribute(root, 'text_b', str(db.text_b))
        _write_attribute(root, 'text_length', str(db.text_length))
        ##############################################################
        #
        # End of fields
        #
        ##############################################################
        return root
    except Exception as e:
        logger.error('Failed to write IQVDiffRecord to root')


def _writeToXmlFromIQVDiffRecordSOA(db: IQVDiffRecordSOA):
    """
    Get the ET Element IQVDiffRecordSOA with all of its subelements
    """

    try:
        root = ET.Element("IQVDiffRecordSOA")
        ##############################################################
        #
        # Start of fields
        #
        ##############################################################
        _write_attribute(root, 'assessment', str(db.assessment))
        _write_attribute(root, 'category', str(db.category))
        _write_attribute(root, 'cycle', str(db.cycle))
        _write_attribute(root, 'day', str(db.day))
        _write_attribute(root, 'diff_string', str(db.diff_string))
        _write_attribute(root, 'diff_type', str(db.diff_type))
        _write_attribute(root, 'doc_id_a', str(db.doc_id_a))
        _write_attribute(root, 'doc_id_b', str(db.doc_id_b))
        _write_attribute(root, 'dts', str(db.dts))
        _write_attribute(root, 'epoch', str(db.epoch))
        _write_attribute(root, 'id', str(db.id))
        _write_attribute(root, 'month', str(db.month))
        _write_attribute(root, 'pname_a', str(db.pname_a))
        _write_attribute(root, 'pname_b', str(db.pname_b))
        _write_attribute(root, 'procedure', str(db.procedure))
        _write_attribute(root, 'ProcessMachineName', str(db.ProcessMachineName))
        _write_attribute(root, 'ProcessVersion', str(db.ProcessVersion))
        _write_attribute(root, 'roi_id_a', str(db.roi_id_a))
        _write_attribute(root, 'roi_id_b', str(db.roi_id_b))
        _write_attribute(root, 'section', str(db.section))
        _write_attribute(root, 'start_index', str(db.start_index))
        _write_attribute(root, 'subcategory', str(db.subcategory))
        _write_attribute(root, 'table_column', str(db.table_column))
        _write_attribute(root, 'table_row', str(db.table_row))
        _write_attribute(root, 'text_a', str(db.text_a))
        _write_attribute(root, 'text_b', str(db.text_b))
        _write_attribute(root, 'text_length', str(db.text_length))
        _write_attribute(root, 'visit', str(db.visit))
        _write_attribute(root, 'week', str(db.week))
        _write_attribute(root, 'window', str(db.window))
        _write_attribute(root, 'year', str(db.year))
        ##############################################################
        #
        # End of fields
        #
        ##############################################################
        return root
    except Exception as e:
        logger.error('Failed to write IQVDiffRecordSOA to root')


def _writeToXmlFromIQVAssessmentVisitRecord(db: IQVAssessmentVisitRecord):
    """
    Get the ET Element IQVAssessmentVisitRecord with all of its subelements
    """

    try:
        root = ET.Element("IQVAssessmentVisitRecord")
        ##############################################################
        #
        # Start of fields
        #
        ##############################################################
        _write_attribute(root, 'assessment', str(db.assessment))
        _write_attribute(root, 'assessment_text', str(db.assessment_text))
        _write_attribute(root, 'cycle_timepoint', str(db.cycle_timepoint))
        _write_attribute(root, 'day_timepoint', str(db.day_timepoint))
        _write_attribute(root, 'doc_id', str(db.doc_id))
        _write_attribute(root, 'DocumentSequenceIndex', str(db.DocumentSequenceIndex))
        _write_attribute(root, 'dts', str(db.dts))
        _write_attribute(root, 'epoch_timepoint', str(db.epoch_timepoint))

        fieldName = 'footnotes'
        try:
            subelement = ET.SubElement(root, fieldName)
            for xelm in db.footnotes:
                subelement.append(_writeToXmlFromString(xelm))
        except Exception as e:
            logger.info('Failed to export field ' + fieldName)
        _write_attribute(root, 'id', str(db.id))
        _write_attribute(root, 'indicator_text', str(db.indicator_text))
        _write_attribute(root, 'month_timepoint', str(db.month_timepoint))
        _write_attribute(root, 'pname', str(db.pname))
        _write_attribute(root, 'procedure', str(db.procedure))
        _write_attribute(root, 'procedure_text', str(db.procedure_text))
        _write_attribute(root, 'ProcessMachineName', str(db.ProcessMachineName))
        _write_attribute(root, 'ProcessVersion', str(db.ProcessVersion))
        _write_attribute(root, 'roi_id', str(db.roi_id))
        _write_attribute(root, 'run_id', str(db.run_id))
        _write_attribute(root, 'section', str(db.section))
        _write_attribute(root, 'study_cohort', str(db.study_cohort))
        _write_attribute(root, 'table_column_id', str(db.table_column_id))
        _write_attribute(root, 'table_link_text', str(db.table_link_text))
        _write_attribute(root, 'table_roi_id', str(db.table_roi_id))
        _write_attribute(root, 'table_sequence_index', str(db.table_sequence_index))
        _write_attribute(root, 'visit_timepoint', str(db.visit_timepoint))
        _write_attribute(root, 'week_timepoint', str(db.week_timepoint))
        _write_attribute(root, 'window_timepoint', str(db.window_timepoint))
        _write_attribute(root, 'year_timepoint', str(db.year_timepoint))
        ##############################################################
        #
        # End of fields
        #
        ##############################################################
        return root
    except Exception as e:
        logger.error('Failed to write IQVAssessmentVisitRecord to root')


def _writeToXmlFromIQVAssessmentRecord(db: IQVAssessmentRecord):
    """
    Get the ET Element IQVAssessmentRecord with all of its subelements
    """

    try:
        root = ET.Element("IQVAssessmentRecord")
        ##############################################################
        #
        # Start of fields
        #
        ##############################################################
        _write_attribute(root, 'assessment', str(db.assessment))
        _write_attribute(root, 'assessment_text', str(db.assessment_text))
        _write_attribute(root, 'doc_id', str(db.doc_id))
        _write_attribute(root, 'DocumentSequenceIndex', str(db.DocumentSequenceIndex))
        _write_attribute(root, 'dts', str(db.dts))

        fieldName = 'footnotes'
        try:
            subelement = ET.SubElement(root, fieldName)
            for xelm in db.footnotes:
                subelement.append(_writeToXmlFromString(xelm))
        except Exception as e:
            logger.info('Failed to export field ' + fieldName)
        _write_attribute(root, 'id', str(db.id))
        _write_attribute(root, 'num_visits', str(db.num_visits))
        _write_attribute(root, 'pname', str(db.pname))
        _write_attribute(root, 'procedure', str(db.procedure))
        _write_attribute(root, 'procedure_text', str(db.procedure_text))
        _write_attribute(root, 'ProcessMachineName', str(db.ProcessMachineName))
        _write_attribute(root, 'ProcessVersion', str(db.ProcessVersion))
        _write_attribute(root, 'roi_id', str(db.roi_id))
        _write_attribute(root, 'run_id', str(db.run_id))
        _write_attribute(root, 'section', str(db.section))
        _write_attribute(root, 'study_cohort', str(db.study_cohort))
        _write_attribute(root, 'table_column_id', str(db.table_column_id))
        _write_attribute(root, 'table_link_text', str(db.table_link_text))
        _write_attribute(root, 'table_roi_id', str(db.table_roi_id))
        _write_attribute(root, 'table_sequence_index', str(db.table_sequence_index))
        ##############################################################
        #
        # End of fields
        #
        ##############################################################
        return root
    except Exception as e:
        logger.error('Failed to write IQVAssessmentRecord to root')


def _writeToXmlFromIQVLabParameterRecord(db: IQVLabParameterRecord):
    """
    Get the ET Element IQVLabParameterRecord with all of its subelements
    """

    try:
        root = ET.Element("IQVLabParameterRecord")
        ##############################################################
        #
        # Start of fields
        #
        ##############################################################
        _write_attribute(root, 'assessment', str(db.assessment))
        _write_attribute(root, 'doc_id', str(db.doc_id))
        _write_attribute(root, 'dts', str(db.dts))
        _write_attribute(root, 'id', str(db.id))
        _write_attribute(root, 'parameter', str(db.parameter))
        _write_attribute(root, 'parameter_text', str(db.parameter_text))
        _write_attribute(root, 'pname', str(db.pname))
        _write_attribute(root, 'procedure_panel', str(db.procedure_panel))
        _write_attribute(root, 'procedure_panel_text', str(db.procedure_panel_text))
        _write_attribute(root, 'ProcessMachineName', str(db.ProcessMachineName))
        _write_attribute(root, 'ProcessVersion', str(db.ProcessVersion))
        _write_attribute(root, 'roi_id', str(db.roi_id))
        _write_attribute(root, 'run_id', str(db.run_id))
        _write_attribute(root, 'section', str(db.section))
        _write_attribute(root, 'table_link_text', str(db.table_link_text))
        _write_attribute(root, 'table_roi_id', str(db.table_roi_id))
        _write_attribute(root, 'table_sequence_index', str(db.table_sequence_index))
        ##############################################################
        #
        # End of fields
        #
        ##############################################################
        return root
    except Exception as e:
        logger.error('Failed to write IQVLabParameterRecord to root')


def _writeToXmlFromIQVVisitRecord(db: IQVVisitRecord):
    """
    Get the ET Element IQVVisitRecord with all of its subelements
    """

    try:
        root = ET.Element("IQVVisitRecord")
        ##############################################################
        #
        # Start of fields
        #
        ##############################################################
        _write_attribute(root, 'cycle_timepoint', str(db.cycle_timepoint))
        _write_attribute(root, 'day_timepoint', str(db.day_timepoint))
        _write_attribute(root, 'doc_id', str(db.doc_id))
        _write_attribute(root, 'DocumentSequenceIndex', str(db.DocumentSequenceIndex))
        _write_attribute(root, 'dts', str(db.dts))
        _write_attribute(root, 'epoch_timepoint', str(db.epoch_timepoint))

        fieldName = 'footnotes'
        try:
            subelement = ET.SubElement(root, fieldName)
            for xelm in db.footnotes:
                subelement.append(_writeToXmlFromString(xelm))
        except Exception as e:
            logger.info('Failed to export field ' + fieldName)
        _write_attribute(root, 'id', str(db.id))
        _write_attribute(root, 'month_timepoint', str(db.month_timepoint))
        _write_attribute(root, 'num_assessments', str(db.num_assessments))
        _write_attribute(root, 'pname', str(db.pname))
        _write_attribute(root, 'ProcessMachineName', str(db.ProcessMachineName))
        _write_attribute(root, 'ProcessVersion', str(db.ProcessVersion))
        _write_attribute(root, 'run_id', str(db.run_id))
        _write_attribute(root, 'study_cohort', str(db.study_cohort))
        _write_attribute(root, 'table_column_id', str(db.table_column_id))
        _write_attribute(root, 'table_link_text', str(db.table_link_text))
        _write_attribute(root, 'table_roi_id', str(db.table_roi_id))
        _write_attribute(root, 'table_sequence_index', str(db.table_sequence_index))
        _write_attribute(root, 'visit_timepoint', str(db.visit_timepoint))
        _write_attribute(root, 'week_timepoint', str(db.week_timepoint))
        _write_attribute(root, 'window_timepoint', str(db.window_timepoint))
        _write_attribute(root, 'year_timepoint', str(db.year_timepoint))
        ##############################################################
        #
        # End of fields
        #
        ##############################################################
        return root
    except Exception as e:
        logger.error('Failed to write IQVVisitRecord to root')


def _writeToXmlFromIQVIECriteriaRecord(db: IQVIECriteriaRecord):
    """
    Get the ET Element IQVIECriteriaRecord with all of its subelements
    """

    try:
        root = ET.Element("IQVIECriteriaRecord")
        ##############################################################
        #
        # Start of fields
        #
        ##############################################################
        _write_attribute(root, 'doc_id', str(db.doc_id))
        _write_attribute(root, 'DocumentSequenceIndex', str(db.DocumentSequenceIndex))
        _write_attribute(root, 'dts', str(db.dts))

        fieldName = 'footnotes'
        try:
            subelement = ET.SubElement(root, fieldName)
            for xelm in db.footnotes:
                subelement.append(_writeToXmlFromString(xelm))
        except Exception as e:
            logger.info('Failed to export field ' + fieldName)
        _write_attribute(root, 'id', str(db.id))
        _write_attribute(root, 'ie_type', str(db.ie_type))
        _write_attribute(root, 'item_text', str(db.item_text))
        _write_attribute(root, 'link_text', str(db.link_text))
        _write_attribute(root, 'pname', str(db.pname))
        _write_attribute(root, 'procedure', str(db.procedure))
        _write_attribute(root, 'procedure_text', str(db.procedure_text))
        _write_attribute(root, 'ProcessMachineName', str(db.ProcessMachineName))
        _write_attribute(root, 'ProcessVersion', str(db.ProcessVersion))
        _write_attribute(root, 'roi_id', str(db.roi_id))
        _write_attribute(root, 'section', str(db.section))
        _write_attribute(root, 'study_cohort', str(db.study_cohort))
        ##############################################################
        #
        # End of fields
        #
        ##############################################################
        return root
    except Exception as e:
        logger.error('Failed to write IQVIECriteriaRecord to root')


def _writeToXmlFromIQVGxPElement(db: IQVGxPElement):
    """
    Get the ET Element IQVGxPElement with all of its subelements
    """

    try:
        root = ET.Element("IQVGxPElement")
        ##############################################################
        #
        # Start of fields
        #
        ##############################################################
        _write_attribute(root, 'code_source', str(db.code_source))
        _write_attribute(root, 'code_source_repo', str(db.code_source_repo))
        _write_attribute(root, 'creator', str(db.creator))
        _write_attribute(root, 'creator_organization', str(db.creator_organization))
        _write_attribute(root, 'date_time_stamp', str(db.date_time_stamp))
        _write_attribute(root, 'description', str(db.description))
        _write_attribute(root, 'element_namespace', str(db.element_namespace))
        _write_attribute(root, 'element_type', str(db.element_type))
        _write_attribute(root, 'element_version', str(db.element_version))

        fieldName = 'elements'
        try:
            subelement = ET.SubElement(root, fieldName)
            for xelm in db.elements:
                subelement.append(_writeToXmlFromIQVGxPElement(xelm))
        except Exception as e:
            logger.info('Failed to export field ' + fieldName)
        _write_attribute(root, 'environment', str(db.environment))
        _write_attribute(root, 'id', str(db.id))

        fieldName = 'item_ids'
        try:
            subelement = ET.SubElement(root, fieldName)
            for xelm in db.item_ids:
                subelement.append(_writeToXmlFromString(xelm))
        except Exception as e:
            logger.info('Failed to export field ' + fieldName)
        _write_attribute(root, 'item_ids_location', str(db.item_ids_location))
        _write_attribute(root, 'label', str(db.label))
        _write_attribute(root, 'project_id', str(db.project_id))

        fieldName = 'Properties'
        try:
            subelement = ET.SubElement(root, fieldName)
            for xelm in db.Properties:
                subelement.append(_writeToXmlFromIQVKeyValueSet(xelm))
        except Exception as e:
            logger.info('Failed to export field ' + fieldName)
        _write_attribute(root, 'source_repo_id', str(db.source_repo_id))
        _write_attribute(root, 'source_system', str(db.source_system))

        fieldName = 'technical_notes'
        try:
            subelement = ET.SubElement(root, fieldName)
            for xelm in db.technical_notes:
                subelement.append(_writeToXmlFromString(xelm))
        except Exception as e:
            logger.info('Failed to export field ' + fieldName)
        _write_attribute(root, 'user_id', str(db.user_id))
        ##############################################################
        #
        # End of fields
        #
        ##############################################################
        return root
    except Exception as e:
        logger.error('Failed to write IQVGxPElement to root')


def _writeToXmlFromIQVDocumentDiffGenericDisplayCellItem(db: IQVDocumentDiffGenericDisplayCellItem):
    """
    Get the ET Element IQVDocumentDiffGenericDisplayCellItem with all of its subelements
    """

    try:
        root = ET.Element("IQVDocumentDiffGenericDisplayCellItem")
        ##############################################################
        #
        # Start of fields
        #
        ##############################################################

        fieldName = 'ChildItems'
        try:
            subelement = ET.SubElement(root, fieldName)
            for xelm in db.ChildItems:
                subelement.append(_writeToXmlFromIQVDocumentDiffGenericDisplayCellItem(xelm))
        except Exception as e:
            logger.info('Failed to export field ' + fieldName)

        fieldName = 'diff_types'
        try:
            subelement = ET.SubElement(root, fieldName)
            for xelm in db.diff_types:
                subelement.append(_writeToXmlFromString(xelm))
        except Exception as e:
            logger.info('Failed to export field ' + fieldName)
        _write_attribute(root, 'id', str(db.id))
        _write_attribute(root, 'indent', str(db.indent))
        _write_attribute(root, 'item_type', str(db.item_type))
        _write_attribute(root, 'sequence', str(db.sequence))

        fieldName = 'strs'
        try:
            subelement = ET.SubElement(root, fieldName)
            for xelm in db.strs:
                subelement.append(_writeToXmlFromString(xelm))
        except Exception as e:
            logger.info('Failed to export field ' + fieldName)
        ##############################################################
        #
        # End of fields
        #
        ##############################################################
        return root
    except Exception as e:
        logger.error('Failed to write IQVDocumentDiffGenericDisplayCellItem to root')


def _writeToXmlFromIQVDocumentDiffGenericDisplayCell(db: IQVDocumentDiffGenericDisplayCell):
    """
    Get the ET Element IQVDocumentDiffGenericDisplayCell with all of its subelements
    """

    try:
        root = ET.Element("IQVDocumentDiffGenericDisplayCell")
        ##############################################################
        #
        # Start of fields
        #
        ##############################################################

        fieldName = 'cellItems'
        try:
            subelement = ET.SubElement(root, fieldName)
            for xelm in db.cellItems:
                subelement.append(_writeToXmlFromIQVDocumentDiffGenericDisplayCellItem(xelm))
        except Exception as e:
            logger.info('Failed to export field ' + fieldName)
        _write_attribute(root, 'colIndex', str(db.colIndex))

        fieldName = 'diff_types'
        try:
            subelement = ET.SubElement(root, fieldName)
            for xelm in db.diff_types:
                subelement.append(_writeToXmlFromIQVDocumentDiffType(xelm))
        except Exception as e:
            logger.info('Failed to export field ' + fieldName)
        _write_attribute(root, 'id', str(db.id))
        _write_attribute(root, 'rowIndex', str(db.rowIndex))
        ##############################################################
        #
        # End of fields
        #
        ##############################################################
        return root
    except Exception as e:
        logger.error('Failed to write IQVDocumentDiffGenericDisplayCell to root')


def _writeToXmlFromIQVDocumentDiffGenericDisplayRow(db: IQVDocumentDiffGenericDisplayRow):
    """
    Get the ET Element IQVDocumentDiffGenericDisplayRow with all of its subelements
    """

    try:
        root = ET.Element("IQVDocumentDiffGenericDisplayRow")
        ##############################################################
        #
        # Start of fields
        #
        ##############################################################

        fieldName = 'cells'
        try:
            subelement = ET.SubElement(root, fieldName)
            for xelm in db.cells:
                subelement.append(_writeToXmlFromIQVDocumentDiffGenericDisplayCell(xelm))
        except Exception as e:
            logger.info('Failed to export field ' + fieldName)

        fieldName = 'ChildRows'
        try:
            subelement = ET.SubElement(root, fieldName)
            for xelm in db.ChildRows:
                subelement.append(_writeToXmlFromIQVDocumentDiffGenericDisplayRow(xelm))
        except Exception as e:
            logger.info('Failed to export field ' + fieldName)
        _write_attribute(root, 'headerType', str(db.headerType))
        _write_attribute(root, 'id', str(db.id))
        _write_attribute(root, 'rowIndex', str(db.rowIndex))
        ##############################################################
        #
        # End of fields
        #
        ##############################################################
        return root
    except Exception as e:
        logger.error('Failed to write IQVDocumentDiffGenericDisplayRow to root')


def _writeToXmlFromIQVDocumentDiffGenericDisplayTable(db: IQVDocumentDiffGenericDisplayTable):
    """
    Get the ET Element IQVDocumentDiffGenericDisplayTable with all of its subelements
    """

    try:
        root = ET.Element("IQVDocumentDiffGenericDisplayTable")
        ##############################################################
        #
        # Start of fields
        #
        ##############################################################
        _write_attribute(root, 'id', str(db.id))

        fieldName = 'rowGroups'
        try:
            subelement = ET.SubElement(root, fieldName)
            for xelm in db.rowGroups:
                subelement.append(_writeToXmlFromIQVDocumentDiffGenericDisplayRow(xelm))
        except Exception as e:
            logger.info('Failed to export field ' + fieldName)

        fieldName = 'rows'
        try:
            subelement = ET.SubElement(root, fieldName)
            for xelm in db.rows:
                subelement.append(_writeToXmlFromIQVDocumentDiffGenericDisplayRow(xelm))
        except Exception as e:
            logger.info('Failed to export field ' + fieldName)
        _write_attribute(root, 'tableType', str(db.tableType))
        ##############################################################
        #
        # End of fields
        #
        ##############################################################
        return root
    except Exception as e:
        logger.error('Failed to write IQVDocumentDiffGenericDisplayTable to root')


def _writeToXmlFromIQVDocumentDiffGenericDisplayDocument(db: IQVDocumentDiffGenericDisplayDocument):
    """
    Get the ET Element IQVDocumentDiffGenericDisplayDocument with all of its subelements
    """

    try:
        root = ET.Element("IQVDocumentDiffGenericDisplayDocument")
        ##############################################################
        #
        # Start of fields
        #
        ##############################################################

        fieldName = 'diff_table_other'
        try:
            subelement = _writeToXmlFromIQVDocumentDiffGenericDisplayTable(db.diff_table_other)
            subelement.tag = fieldName
            root.append(subelement)
        except Exception as e:
            logger.info('Failed to export field ' + fieldName)

        fieldName = 'diff_table_soa'
        try:
            subelement = _writeToXmlFromIQVDocumentDiffGenericDisplayTable(db.diff_table_soa)
            subelement.tag = fieldName
            root.append(subelement)
        except Exception as e:
            logger.info('Failed to export field ' + fieldName)

        fieldName = 'diff_table_toc'
        try:
            subelement = _writeToXmlFromIQVDocumentDiffGenericDisplayTable(db.diff_table_toc)
            subelement.tag = fieldName
            root.append(subelement)
        except Exception as e:
            logger.info('Failed to export field ' + fieldName)
        _write_attribute(root, 'id', str(db.id))

        fieldName = 'Properties'
        try:
            subelement = ET.SubElement(root, fieldName)
            for xelm in db.Properties:
                subelement.append(_writeToXmlFromIQVKeyValueSet(xelm))
        except Exception as e:
            logger.info('Failed to export field ' + fieldName)
        ##############################################################
        #
        # End of fields
        #
        ##############################################################
        return root
    except Exception as e:
        logger.error('Failed to write IQVDocumentDiffGenericDisplayDocument to root')


def _writeToXmlFromIQVDocumentDataItemQC(db: IQVDocumentDataItemQC):
    """
    Get the ET Element IQVDocumentDataItemQC with all of its subelements
    """

    try:
        root = ET.Element("IQVDocumentDataItemQC")
        ##############################################################
        #
        # Start of fields
        #
        ##############################################################
        _write_attribute(root, 'bIsTableCell', _bool2str(db.bIsTableCell))
        _write_attribute(root, 'childbox_id', str(db.childbox_id))
        _write_attribute(root, 'column_roi_id', str(db.column_roi_id))
        _write_attribute(root, 'content', str(db.content))
        _write_attribute(root, 'CPT_section', str(db.CPT_section))
        _write_attribute(root, 'datacell_roi_id', str(db.datacell_roi_id))
        _write_attribute(root, 'dataType', str(db.dataType))

        fieldName = 'entities'
        try:
            subelement = ET.SubElement(root, fieldName)
            for xelm in db.entities:
                subelement.append(_writeToXmlFromNLP_Entity(xelm))
        except Exception as e:
            logger.info('Failed to export field ' + fieldName)
        _write_attribute(root, 'file_section', str(db.file_section))
        _write_attribute(root, 'file_section_level', str(db.file_section_level))
        _write_attribute(root, 'file_section_num', str(db.file_section_num))

        fieldName = 'fontInfo'
        try:
            subelement = _writeToXmlFromFontInfo(db.fontInfo)
            subelement.tag = fieldName
            root.append(subelement)
        except Exception as e:
            logger.info('Failed to export field ' + fieldName)
        _write_attribute(root, 'level_1_CPT_section', str(db.level_1_CPT_section))
        _write_attribute(root, 'para_id', str(db.para_id))
        _write_attribute(root, 'qc_change_type', str(db.qc_change_type))
        _write_attribute(root, 'roi_id', str(db.roi_id))
        _write_attribute(root, 'row_roi_id', str(db.row_roi_id))
        _write_attribute(root, 'section_level', str(db.section_level))
        _write_attribute(root, 'seq_num', str(db.seq_num))
        _write_attribute(root, 'subtext_id', str(db.subtext_id))
        _write_attribute(root, 'table_roi_id', str(db.table_roi_id))
        ##############################################################
        #
        # End of fields
        #
        ##############################################################
        return root
    except Exception as e:
        logger.error('Failed to write IQVDocumentDataItemQC to root')


def _writeToXmlFromIQVDocumentDataFeedbackQC(db: IQVDocumentDataFeedbackQC):
    """
    Get the ET Element IQVDocumentDataFeedbackQC with all of its subelements
    """

    try:
        root = ET.Element("IQVDocumentDataFeedbackQC")
        ##############################################################
        #
        # Start of fields
        #
        ##############################################################

        fieldName = 'columns'
        try:
            subelement = ET.SubElement(root, fieldName)
            for xelm in db.columns:
                subelement.append(_writeToXmlFromString(xelm))
        except Exception as e:
            logger.info('Failed to export field ' + fieldName)

        fieldName = 'data'
        try:
            subelement = ET.SubElement(root, fieldName)
            for xelm in db.data:
                subelement.append(_writeToXmlFromIQVDocumentDataItemQC(xelm))
        except Exception as e:
            logger.info('Failed to export field ' + fieldName)

        fieldName = 'index'
        try:
            subelement = ET.SubElement(root, fieldName)
            for xelm in db.index:
                subelement.append(_writeToXmlFromint(xelm))
        except Exception as e:
            logger.info('Failed to export field ' + fieldName)

        fieldName = 'metadata'
        try:
            subelement = ET.SubElement(root, fieldName)
            for xelm in db.metadata:
                subelement.append(_writeToXmlFromIQVKeyValueSet(xelm))
        except Exception as e:
            logger.info('Failed to export field ' + fieldName)
        ##############################################################
        #
        # End of fields
        #
        ##############################################################
        return root
    except Exception as e:
        logger.error('Failed to write IQVDocumentDataFeedbackQC to root')


def _writeToXmlFromIQVDocumentFeedbackQC(db: IQVDocumentFeedbackQC):
    """
    Get the ET Element IQVDocumentFeedbackQC with all of its subelements
    """

    try:
        root = ET.Element("IQVDocumentFeedbackQC")
        ##############################################################
        #
        # Start of fields
        #
        ##############################################################
        _write_attribute(root, 'bIsActive', _bool2str(db.bIsActive))
        _write_attribute(root, 'doc_id', str(db.doc_id))
        _write_attribute(root, 'documentFilePath', str(db.documentFilePath))
        _write_attribute(root, 'fileName', str(db.fileName))
        _write_attribute(root, 'group_type', str(db.group_type))
        _write_attribute(root, 'hierarchy', str(db.hierarchy))
        _write_attribute(root, 'id', str(db.id))
        _write_attribute(root, 'iqv_standard_term', str(db.iqv_standard_term))

        fieldName = 'iqvdata'
        try:
            subelement = _writeToXmlFromIQVDocumentDataFeedbackQC(db.iqvdata)
            subelement.tag = fieldName
            root.append(subelement)
        except Exception as e:
            logger.info('Failed to export field ' + fieldName)

        fieldName = 'iqvdataSoa'
        try:
            subelement = _writeToXmlFromIQVDocumentDataFeedbackQC(db.iqvdataSoa)
            subelement.tag = fieldName
            root.append(subelement)
        except Exception as e:
            logger.info('Failed to export field ' + fieldName)

        fieldName = 'iqvdataSoaStd'
        try:
            subelement = _writeToXmlFromIQVDocumentDataFeedbackQC(db.iqvdataSoaStd)
            subelement.tag = fieldName
            root.append(subelement)
        except Exception as e:
            logger.info('Failed to export field ' + fieldName)

        fieldName = 'iqvdataSummary'
        try:
            subelement = _writeToXmlFromIQVDocumentDataFeedbackQC(db.iqvdataSummary)
            subelement.tag = fieldName
            root.append(subelement)
        except Exception as e:
            logger.info('Failed to export field ' + fieldName)

        fieldName = 'iqvdataToc'
        try:
            subelement = _writeToXmlFromIQVDocumentDataFeedbackQC(db.iqvdataToc)
            subelement.tag = fieldName
            root.append(subelement)
        except Exception as e:
            logger.info('Failed to export field ' + fieldName)
        _write_attribute(root, 'link_id', str(db.link_id))
        _write_attribute(root, 'link_id_level2', str(db.link_id_level2))
        _write_attribute(root, 'link_id_level3', str(db.link_id_level3))
        _write_attribute(root, 'link_id_level4', str(db.link_id_level4))
        _write_attribute(root, 'link_id_level5', str(db.link_id_level5))
        _write_attribute(root, 'link_id_level6', str(db.link_id_level6))
        _write_attribute(root, 'link_id_subsection1', str(db.link_id_subsection1))
        _write_attribute(root, 'link_id_subsection2', str(db.link_id_subsection2))
        _write_attribute(root, 'link_id_subsection3', str(db.link_id_subsection3))
        _write_attribute(root, 'parent_id', str(db.parent_id))
        _write_attribute(root, 'source_system', str(db.source_system))
        _write_attribute(root, 'timeCreated', str(db.timeCreated))
        _write_attribute(root, 'timeUpdated', str(db.timeUpdated))
        _write_attribute(root, 'userId', str(db.userId))
        ##############################################################
        #
        # End of fields
        #
        ##############################################################
        return root
    except Exception as e:
        logger.error('Failed to write IQVDocumentFeedbackQC to root')


def _writeToXmlFromIQVClassifierModel(db: IQVClassifierModel):
    """
    Get the ET Element IQVClassifierModel with all of its subelements
    """

    try:
        root = ET.Element("IQVClassifierModel")
        ##############################################################
        #
        # Start of fields
        #
        ##############################################################
        _write_attribute(root, 'Base_Model_Version', str(db.Base_Model_Version))
        _write_attribute(root, 'Country', str(db.Country))
        _write_attribute(root, 'Doc_Class', str(db.Doc_Class))

        fieldName = 'Full_Classification_List'
        try:
            subelement = ET.SubElement(root, fieldName)
            for xelm in db.Full_Classification_List:
                subelement.append(_writeToXmlFromString(xelm))
        except Exception as e:
            logger.info('Failed to export field ' + fieldName)
        _write_attribute(root, 'id', str(db.id))
        _write_attribute(root, 'Language', str(db.Language))
        _write_attribute(root, 'Model_Directory', str(db.Model_Directory))
        _write_attribute(root, 'Model_Index', str(db.Model_Index))
        _write_attribute(root, 'Model_Label', str(db.Model_Label))
        _write_attribute(root, 'Model_Name', str(db.Model_Name))
        _write_attribute(root, 'Model_Sequence', str(db.Model_Sequence))
        ##############################################################
        #
        # End of fields
        #
        ##############################################################
        return root
    except Exception as e:
        logger.error('Failed to write IQVClassifierModel to root')


def _writeToXmlFromIQVFormularyItem(db: IQVFormularyItem):
    """
    Get the ET Element IQVFormularyItem with all of its subelements
    """

    try:
        root = ET.Element("IQVFormularyItem")
        ##############################################################
        #
        # Start of fields
        #
        ##############################################################
        _write_attribute(root, 'Client', str(db.Client))
        _write_attribute(root, 'DrugName', str(db.DrugName))
        _write_attribute(root, 'DrugSpecialCode', str(db.DrugSpecialCode))
        _write_attribute(root, 'DrugTier', str(db.DrugTier))
        _write_attribute(root, 'id', str(db.id))
        _write_attribute(root, 'PBM', str(db.PBM))

        fieldName = 'Properties'
        try:
            subelement = ET.SubElement(root, fieldName)
            for xelm in db.Properties:
                subelement.append(_writeToXmlFromIQVKeyValueSet(xelm))
        except Exception as e:
            logger.info('Failed to export field ' + fieldName)
        _write_attribute(root, 'Source', str(db.Source))
        _write_attribute(root, 'source_system', str(db.source_system))
        _write_attribute(root, 'SourceDate', str(db.SourceDate))
        ##############################################################
        #
        # End of fields
        #
        ##############################################################
        return root
    except Exception as e:
        logger.error('Failed to write IQVFormularyItem to root')
