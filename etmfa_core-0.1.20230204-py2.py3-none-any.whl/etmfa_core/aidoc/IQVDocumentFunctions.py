import logging
import re
from typing import List

from etmfa_core.aidoc.models.IQVDocument import (IQV_STRING,
                                                 IQVAttributeCandidate,
                                                 IQVDocument,
                                                 IQVDocumentProcess,
                                                 IQVKeyValueSet, IQVPageROI)
from etmfa_core.aidoc.models.IQVUtilities import Constants

logger = logging.getLogger('etmfa_core.aidoc')


def GeneratePageSkewError(iqvDocument: IQVDocument,
                          pageIndex: int,
                          errorScore: float = 0.0,
                          confidence: float = 95.0):
    """
    Raise page skew error for a specific document, at the document-level
    AttributeKey = ‘alcoac_check_error’
    AttributeValue = 
    Features = list of IQVKeyValueSet

    Feature0: IQVKeyValueSet
    key = ‘alcoac_error_score’
    value = int value 0 (bad) to 100 (good)
    # worse greyscale, closer to zero

    Feature1: IQVKeyValueSet
    key = ‘alcoac_error_message’
    value = ‘3,5’ # string
    # string, comma-separated list of int

    API Representation
    KEY=alcoac_check_error
    VALUE=[[alcoac_error_type=greyscale_error, alcoac_error_score=0, alcoac_error_message=[3,5]],
    [alcoac_error_type=blank_pages_error, alcoac_error_score=0, alcoac_error_message=[2]]]

    :param iqvDocument:the document resource
    :param pageIndex:ZERO-based page sequence index, should match PageSequenceIndex
    :param errorScore:0-100 0=(severe error) 100=(not an error), default severe error=0
    :param confidence:0-100 0=(not confident) 100=(very confident), default very confident=95
    """
    IQV_STRING_OBJECT = IQV_STRING()

    alcoac_error = IQVAttributeCandidate()
    alcoac_error.AttributeKey = IQV_STRING_OBJECT.ALCOAC_ERROR
    alcoac_error.AttributeValue = IQV_STRING_OBJECT.ALCOAC_ERROR_TYPE_PAGE_SKEW_ERROR

    scoreFeature = IQVKeyValueSet()
    scoreFeature.key = IQV_STRING_OBJECT.ALCOAC_SCORE_FEATURE
    scoreFeature.value = str(errorScore)
    alcoac_error.Features.append(scoreFeature)

    messageFeature = IQVKeyValueSet()
    messageFeature.key = IQV_STRING_OBJECT.ALCOAC_MESSAGE_FEATURE
    messageFeature.value = str(pageIndex)
    alcoac_error.Features.append(messageFeature)

    confidenceFeature = IQVKeyValueSet()
    confidenceFeature.key = IQV_STRING_OBJECT.ALCOAC_CONFIDENCE_FEATURE
    confidenceFeature.value = str(confidence)
    alcoac_error.Features.append(confidenceFeature)

    iqvDocument.alcoac_check_error.append(alcoac_error)


def GenerateGreyscaleError(iqvDocument: IQVDocument,
                           pageIndex: int,
                           errorScore: float = 0.0,
                           confidence: float = 95.0):
    """
    Raise greyscale error for a specific document, at the document-level
    Greyscale error is for a background that is very dark/noisy,
    thus making the document hard to read
    AttributeKey = ‘alcoac_check_error’
    AttributeValue = ‘greyscale_error’
    Features = list of IQVKeyValueSet

    Feature0: IQVKeyValueSet
    key = ‘alcoac_error_score’
    value = int value 0 (bad) to 100 (good)
    # worse greyscale, closer to zero

    Feature1: IQVKeyValueSet
    key = ‘alcoac_error_message’
    value = ‘3,5’ # string
    # string, comma-separated list of int

    API Representation
    KEY=alcoac_check_error
    VALUE=[[alcoac_error_type=greyscale_error, alcoac_error_score=0, alcoac_error_message=[3,5]],
    [alcoac_error_type=blank_pages_error, alcoac_error_score=0, alcoac_error_message=[2]]]

    :param iqvDocument:the document resource
    :param pageIndex:ZERO-based page sequence index, should match PageSequenceIndex
    :param errorScore:0-100 0=(severe error) 100=(not an error), default severe error=0
    :param confidence:0-100 0=(not confident) 100=(very confident), default very confident=95
    """
    IQV_STRING_OBJECT = IQV_STRING()
    alcoac_error = IQVAttributeCandidate()
    alcoac_error.AttributeKey = IQV_STRING_OBJECT.ALCOAC_ERROR
    alcoac_error.AttributeValue = IQV_STRING_OBJECT.ALCOAC_ERROR_TYPE_GREYSCALE_ERROR

    scoreFeature = IQVKeyValueSet()
    scoreFeature.key = IQV_STRING_OBJECT.ALCOAC_SCORE_FEATURE
    scoreFeature.value = str(errorScore)
    alcoac_error.Features.append(scoreFeature)

    messageFeature = IQVKeyValueSet()
    messageFeature.key = IQV_STRING_OBJECT.ALCOAC_MESSAGE_FEATURE
    messageFeature.value = str(pageIndex)
    alcoac_error.Features.append(messageFeature)

    confidenceFeature = IQVKeyValueSet()
    confidenceFeature.key = IQV_STRING_OBJECT.ALCOAC_CONFIDENCE_FEATURE
    confidenceFeature.value = str(confidence)
    alcoac_error.Features.append(confidenceFeature)

    iqvDocument.alcoac_check_error.append(alcoac_error)


def GenerateFiletypeError(iqvDocument: IQVDocument,
                          filetype: str = "",
                          errorScore: float = 0.0,
                          confidence: float = 95.0):
    """
    Raise filetype error for a specific document, at the document-level.
    Filetype error is when AI does not have the appropriate handler for
    the filetype. For example, an XLS file is processed but there is no
    Excel file handler available.

    AttributeKey = ‘alcoac_check_error’
    AttributeValue = ‘filetype_error’
    Features = list of IQVKeyValueSet

    Feature0: IQVKeyValueSet
    key = ‘alcoac_error_score’
    value = int value 0 (bad) to 100 (good)
    # worse greyscale, closer to zero

    Feature1: IQVKeyValueSet
    key = ‘alcoac_error_message’
    value = ‘3,5’ # string
    # string, comma-separated list of int

    API Representation
    KEY=alcoac_check_error
    VALUE=[[alcoac_error_type=greyscale_error, alcoac_error_score=0, alcoac_error_message=[3,5]],
    [alcoac_error_type=blank_pages_error, alcoac_error_score=0, alcoac_error_message=[2]]]

    :param iqvDocument:the document resource
    :param filetype:string to represent filetype, file extension (often 3-character), such as 'xls', 'png', 'sasbdat'
    :param errorScore:0-100 0=(severe error) 100=(not an error), default severe error=0
    :param confidence:0-100 0=(not confident) 100=(very confident), default very confident=95
    """
    IQV_STRING_OBJECT = IQV_STRING()
    alcoac_error = IQVAttributeCandidate()
    alcoac_error.AttributeKey = IQV_STRING_OBJECT.ALCOAC_ERROR
    alcoac_error.AttributeValue = IQV_STRING_OBJECT.ALCOAC_ERROR_TYPE_FILETYPE_ERROR

    scoreFeature = IQVKeyValueSet()
    scoreFeature.key = IQV_STRING_OBJECT.ALCOAC_SCORE_FEATURE
    scoreFeature.value = str(errorScore)
    alcoac_error.Features.append(scoreFeature)

    messageFeature = IQVKeyValueSet()
    messageFeature.key = IQV_STRING_OBJECT.ALCOAC_MESSAGE_FEATURE
    messageFeature.value = filetype
    alcoac_error.Features.append(messageFeature)

    confidenceFeature = IQVKeyValueSet()
    confidenceFeature.key = IQV_STRING_OBJECT.ALCOAC_CONFIDENCE_FEATURE
    confidenceFeature.value = str(confidence)
    alcoac_error.Features.append(confidenceFeature)

    iqvDocument.alcoac_check_error.append(alcoac_error)


def GenerateLegibilityError(iqvDocument: IQVDocument,
                            pageIndex: int,
                            errorScore: float = 0.0,
                            confidence: float = 95.0):
    """
    Raise legibility error for a specific document, at the document-level
    AttributeKey = ‘alcoac_check_error’
    AttributeValue = 
    Features = list of IQVKeyValueSet

    Feature0: IQVKeyValueSet
    key = ‘alcoac_error_score’
    value = int value 0 (bad) to 100 (good)
    # worse greyscale, closer to zero

    Feature1: IQVKeyValueSet
    key = ‘alcoac_error_message’
    value = ‘3,5’ # string
    # string, comma-separated list of int

    API Representation
    KEY=alcoac_check_error
    VALUE=[[alcoac_error_type=greyscale_error, alcoac_error_score=0, alcoac_error_message=[3,5]],
    [alcoac_error_type=blank_pages_error, alcoac_error_score=0, alcoac_error_message=[2]]]

    :param iqvDocument:the document resource
    :param pageIndex:ZERO-based page sequence index, should match PageSequenceIndex
    :param errorScore:0-100 0=(severe error) 100=(not an error), default severe error=0
    :param confidence:0-100 0=(not confident) 100=(very confident), default very confident=95
    """
    IQV_STRING_OBJECT = IQV_STRING()
    alcoac_error = IQVAttributeCandidate()
    alcoac_error.AttributeKey = IQV_STRING_OBJECT.ALCOAC_ERROR
    alcoac_error.AttributeValue = IQV_STRING_OBJECT.ALCOAC_ERROR_TYPE_LEGIBILITY_ERROR

    scoreFeature = IQVKeyValueSet()
    scoreFeature.key = IQV_STRING_OBJECT.ALCOAC_SCORE_FEATURE
    scoreFeature.value = str(errorScore)
    alcoac_error.Features.append(scoreFeature)

    messageFeature = IQVKeyValueSet()
    messageFeature.key = IQV_STRING_OBJECT.ALCOAC_MESSAGE_FEATURE
    messageFeature.value = str(pageIndex)
    alcoac_error.Features.append(messageFeature)

    confidenceFeature = IQVKeyValueSet()
    confidenceFeature.key = IQV_STRING_OBJECT.ALCOAC_CONFIDENCE_FEATURE
    confidenceFeature.value = str(confidence)
    alcoac_error.Features.append(confidenceFeature)

    iqvDocument.alcoac_check_error.append(alcoac_error)


def GenerateDuplicateDocumentError(iqvDocument: IQVDocument,
                                   document_id: str = "",
                                   errorScore: float = 0.0,
                                   confidence: float = 95.0):
    """
    Raise legibility error for a specific document, at the document-level
    AttributeKey = ‘alcoac_check_error’
    AttributeValue = 
    Features = list of IQVKeyValueSet

    Feature0: IQVKeyValueSet
    key = ‘alcoac_error_score’
    value = int value 0 (bad) to 100 (good)
    # worse greyscale, closer to zero

    Feature1: IQVKeyValueSet
    key = ‘alcoac_error_message’
    value = ‘3,5’ # string
    # string, comma-separated list of int

    API Representation
    KEY=alcoac_check_error
    VALUE=[[alcoac_error_type=greyscale_error, alcoac_error_score=0, alcoac_error_message=[3,5]],
    [alcoac_error_type=blank_pages_error, alcoac_error_score=0, alcoac_error_message=[2]]]

    :param iqvDocument:the document resource
    :param document_id:ZERO-based page sequence index, should match PageSequenceIndex
    :param errorScore:0-100 0=(severe error) 100=(not an error), default severe error=0
    :param confidence:0-100 0=(not confident) 100=(very confident), default very confident=95
    """
    IQV_STRING_OBJECT = IQV_STRING()
    alcoac_error = IQVAttributeCandidate()
    alcoac_error.AttributeKey = IQV_STRING_OBJECT.ALCOAC_ERROR
    alcoac_error.AttributeValue = IQV_STRING_OBJECT.ALCOAC_ERROR_TYPE_DUPLICATE_DOCUMENT_ERROR

    scoreFeature = IQVKeyValueSet()
    scoreFeature.key = IQV_STRING_OBJECT.ALCOAC_SCORE_FEATURE
    scoreFeature.value = str(errorScore)
    alcoac_error.Features.append(scoreFeature)

    messageFeature = IQVKeyValueSet()
    messageFeature.key = IQV_STRING_OBJECT.ALCOAC_MESSAGE_FEATURE
    messageFeature.value = document_id
    alcoac_error.Features.append(messageFeature)

    confidenceFeature = IQVKeyValueSet()
    confidenceFeature.key = IQV_STRING_OBJECT.ALCOAC_CONFIDENCE_FEATURE
    confidenceFeature.value = str(confidence)
    alcoac_error.Features.append(confidenceFeature)

    iqvDocument.alcoac_check_error.append(alcoac_error)


def GeneratePageSequenceOrderError(iqvDocument: IQVDocument,
                                   pageIndex: int,
                                   errorScore: float = 0.0,
                                   confidence: float = 95.0):
    """
    Raise legibility error for a specific document, at the document-level
    AttributeKey = ‘alcoac_check_error’
    AttributeValue = 
    Features = list of IQVKeyValueSet

    Feature0: IQVKeyValueSet
    key = ‘alcoac_error_score’
    value = int value 0 (bad) to 100 (good)
    # worse greyscale, closer to zero

    Feature1: IQVKeyValueSet
    key = ‘alcoac_error_message’
    value = ‘3,5’ # string
    # string, comma-separated list of int

    API Representation
    KEY=alcoac_check_error
    VALUE=[[alcoac_error_type=greyscale_error, alcoac_error_score=0, alcoac_error_message=[3,5]],
    [alcoac_error_type=blank_pages_error, alcoac_error_score=0, alcoac_error_message=[2]]]

    :param iqvDocument:the document resource
    :param pageIndex:ZERO-based page sequence index, should match PageSequenceIndex
    :param errorScore:0-100 0=(severe error) 100=(not an error), default severe error=0
    :param confidence:0-100 0=(not confident) 100=(very confident), default very confident=95
    """
    IQV_STRING_OBJECT = IQV_STRING()
    alcoac_error = IQVAttributeCandidate()
    alcoac_error.AttributeKey = IQV_STRING_OBJECT.ALCOAC_ERROR
    alcoac_error.AttributeValue = IQV_STRING_OBJECT.ALCOAC_ERROR_TYPE_ORDER_PAGES_ERROR

    scoreFeature = IQVKeyValueSet()
    scoreFeature.key = IQV_STRING_OBJECT.ALCOAC_SCORE_FEATURE
    scoreFeature.value = str(errorScore)
    alcoac_error.Features.append(scoreFeature)

    messageFeature = IQVKeyValueSet()
    messageFeature.key = IQV_STRING_OBJECT.ALCOAC_MESSAGE_FEATURE
    messageFeature.value = str(pageIndex)
    alcoac_error.Features.append(messageFeature)

    confidenceFeature = IQVKeyValueSet()
    confidenceFeature.key = IQV_STRING_OBJECT.ALCOAC_CONFIDENCE_FEATURE
    confidenceFeature.value = str(confidence)
    alcoac_error.Features.append(confidenceFeature)

    iqvDocument.alcoac_check_error.append(alcoac_error)


def GenerateBlankPageError(iqvDocument: IQVDocument,
                           pageIndex: int,
                           errorScore: float = 0.0,
                           confidence: float = 95.0):
    """
    Raise legibility error for a specific document, at the document-level
    AttributeKey = ‘alcoac_check_error’
    AttributeValue = 
    Features = list of IQVKeyValueSet

    Feature0: IQVKeyValueSet
    key = ‘alcoac_error_score’
    value = int value 0 (bad) to 100 (good)
    # worse greyscale, closer to zero

    Feature1: IQVKeyValueSet
    key = ‘alcoac_error_message’
    value = ‘3,5’ # string
    # string, comma-separated list of int

    API Representation
    KEY=alcoac_check_error
    VALUE=[[alcoac_error_type=greyscale_error, alcoac_error_score=0, alcoac_error_message=[3,5]],
    [alcoac_error_type=blank_pages_error, alcoac_error_score=0, alcoac_error_message=[2]]]

    :param iqvDocument:the document resource
    :param pageIndex:ZERO-based page sequence index, should match PageSequenceIndex
    :param errorScore:0-100 0=(severe error) 100=(not an error), default severe error=0
    :param confidence:0-100 0=(not confident) 100=(very confident), default very confident=95
    """
    IQV_STRING_OBJECT = IQV_STRING()
    alcoac_error = IQVAttributeCandidate()
    alcoac_error.AttributeKey = IQV_STRING_OBJECT.ALCOAC_ERROR
    alcoac_error.AttributeValue = IQV_STRING_OBJECT.ALCOAC_ERROR_TYPE_BLANK_PAGES_ERROR

    scoreFeature = IQVKeyValueSet()
    scoreFeature.key = IQV_STRING_OBJECT.ALCOAC_SCORE_FEATURE
    scoreFeature.value = str(errorScore)
    alcoac_error.Features.append(scoreFeature)

    messageFeature = IQVKeyValueSet()
    messageFeature.key = IQV_STRING_OBJECT.ALCOAC_MESSAGE_FEATURE
    messageFeature.value = str(pageIndex)
    alcoac_error.Features.append(messageFeature)

    confidenceFeature = IQVKeyValueSet()
    confidenceFeature.key = IQV_STRING_OBJECT.ALCOAC_CONFIDENCE_FEATURE
    confidenceFeature.value = str(confidence)
    alcoac_error.Features.append(confidenceFeature)

    iqvDocument.alcoac_check_error.append(alcoac_error)


def GenerateMissingPageError(iqvDocument: IQVDocument,
                             pageIndex: int,
                             errorScore: float = 0.0,
                             confidence: float = 95.0):
    """
    Raise legibility error for a specific document, at the document-level
    AttributeKey = ‘alcoac_check_error’
    AttributeValue = 
    Features = list of IQVKeyValueSet

    Feature0: IQVKeyValueSet
    key = ‘alcoac_error_score’
    value = int value 0 (bad) to 100 (good)
    # worse greyscale, closer to zero

    Feature1: IQVKeyValueSet
    key = ‘alcoac_error_message’
    value = ‘3,5’ # string
    # string, comma-separated list of int

    API Representation
    KEY=alcoac_check_error
    VALUE=[[alcoac_error_type=greyscale_error, alcoac_error_score=0, alcoac_error_message=[3,5]],
    [alcoac_error_type=blank_pages_error, alcoac_error_score=0, alcoac_error_message=[2]]]

    :param iqvDocument:the document resource
    :param pageIndex:ZERO-based page sequence index, should match PageSequenceIndex
    :param errorScore:0-100 0=(severe error) 100=(not an error), default severe error=0
    :param confidence:0-100 0=(not confident) 100=(very confident), default very confident=95
    """
    IQV_STRING_OBJECT = IQV_STRING()
    alcoac_error = IQVAttributeCandidate()
    alcoac_error.AttributeKey = IQV_STRING_OBJECT.ALCOAC_ERROR
    alcoac_error.AttributeValue = IQV_STRING_OBJECT.ALCOAC_ERROR_TYPE_MISSING_PAGES_ERROR

    scoreFeature = IQVKeyValueSet()
    scoreFeature.key = IQV_STRING_OBJECT.ALCOAC_SCORE_FEATURE
    scoreFeature.value = str(errorScore)
    alcoac_error.Features.append(scoreFeature)

    messageFeature = IQVKeyValueSet()
    messageFeature.key = IQV_STRING_OBJECT.ALCOAC_MESSAGE_FEATURE
    messageFeature.value = str(pageIndex)
    alcoac_error.Features.append(messageFeature)

    confidenceFeature = IQVKeyValueSet()
    confidenceFeature.key = IQV_STRING_OBJECT.ALCOAC_CONFIDENCE_FEATURE
    confidenceFeature.value = str(confidence)
    alcoac_error.Features.append(confidenceFeature)

    iqvDocument.alcoac_check_error.append(alcoac_error)


def SetWorkflowSubProcess(iqvDocument: IQVDocument = None,
                          subprocess: str = "",
                          required: bool = None,
                          startTime: str = None,
                          finishTime: str = None,
                          machineName: str = None,
                          version: str = None):
    """
    Utility function for creating/modifying the IQVDocumentProcess.
    There should be just a singleton for each unique subprocess 
    :param iqvDocument: required
    :param subprocess:name of subprocess {triage,digitizer,classifier,extractor,finalizer}
    :param required:is this process required part of the workflow?
    :param startTime:start datetimestamp
    :param finishTime:end datetimestamp
    :param machineName:machine name process runs on
    :param version:code version

    Usage:
    # Beginning of processing
    SetWorkflowSubProcess(
        iqvDocument, 
        subprocess = "triage", 
        required = True,
        startTime = GetDateTimeString(),
        machineName = socket.gethostname(),
        version = "1.0" )
    # End of processing
    SetWorkflowSubProcess(
        iqvDocument, 
        subprocess = "triage", 
        finishTime = GetDateTimeString())
    """
    try:
        bFound = False
        if iqvDocument is None:
            logger.exception("Error setting workflow subprocess for subprocess. IQVDocument is None.")
            return False
        if len(subprocess) == 0:
            logger.exception("Error setting workflow subprocess for subprocess = " + subprocess)
            return False
        #
        # If exists, use the existing entry for this subprocess
        #
        for subproc in iqvDocument.IQVDocumentProcesses:
            if subproc.ProcessName == subprocess:
                if required is not None:
                    subproc.bProcessRequired = required
                if startTime is not None:
                    subproc.ProcessStartTime = startTime
                if finishTime is not None:
                    subproc.ProcessFinishTime = finishTime
                if machineName is not None:
                    subproc.ProcessMachineName = machineName
                if version is not None:
                    subproc.ProcessVersion = version
                bFound = True
                break
        #
        # If does not exist, create a new entry for this subprocess
        #
        if not bFound:
            subproc = IQVDocumentProcess()
            subproc.ProcessName = subprocess
            if required is not None:
                subproc.bProcessRequired = required
            if startTime is not None:
                subproc.ProcessStartTime = startTime
            if finishTime is not None:
                subproc.ProcessFinishTime = finishTime
            if machineName is not None:
                subproc.ProcessMachineName = machineName
            if version is not None:
                subproc.ProcessVersion = version
            iqvDocument.IQVDocumentProcesses.append(subproc)
    except Exception as e:
        logger.exception("Error setting workflow subprocess for subprocess = " + subprocess)
        return False
    return True


def GetDocumentClassFromInput(iqvDocument: IQVDocument):
    """
    It is EXPECTED to receive the document class from input.
    Get document class/level (study/core, country, or site).
    Use the Ground Truth if it exists.
    Use the IQVDocumentFeedbackResults if this is production.
    Default is blank string
    """
    docClass = ""

    #
    # Use ground truth if this is historical document
    #
    if iqvDocument.DocumentGroundTruth is not None:
        gt = iqvDocument.DocumentGroundTruth
        if gt.Document_Class is not None:
            docClass = gt.Document_Class
    #
    # Use IQVDocumentFeedbackResults if this is production
    #
    if len(docClass) == 0:
        for iqvResults in iqvDocument.IQVDocumentFeedbackResultsList:
            if iqvResults.feedback_source.lower() == 'post':
                if iqvResults.document_class is not None:
                    docClass = iqvResults.document_class
    return docClass


def GetROIFromIQVPageROIByID(roi: IQVPageROI, id: str):
    """
    Get the ROI matching the id provided
    """
    if roi.id == id:
        return roi

    for cbox in roi.ChildBoxes:
        tmpLeaf = GetROIFromIQVPageROIByID(cbox, id)
        if tmpLeaf is not None:
            return tmpLeaf

    return None


def GetROIFromIQVDocumentByID(iqvDocument: IQVDocument, id: str):
    """
    Get the ROI matching the id provided
    """
    leaves = []
    for pageROI in iqvDocument.DocumentImages:
        tmpLeaf = GetROIFromIQVPageROIByID(pageROI, id)
        if tmpLeaf is not None:
            return tmpLeaf
        # leaves = leaves + tmpLeaves

    return leaves


def get_leaves_from_roi(roi: IQVPageROI, include_all=False):
    """
    Get descendants of the roi that are terminal leaves
    include_all ->
            Get all roi triage and digitizer
        otherwise ROIS will be filtered according to these conditions:
            If digitized (bScannedOCR == False), include digitized AND scanned
            If OCR, only include OCR
            If OCR certain language, only include same language

    """
    leaves = []
    if len(roi.ChildBoxes) == 0:
        return [roi]

    for child_box in roi.ChildBoxes:
        if include_all:
            tmp_leaves = get_leaves_from_roi(child_box, include_all)
            leaves.extend(tmp_leaves)
        else:
            #
            # If digitized (bScannedOCR == False), include digitized AND scanned
            # If OCR, only include OCR
            # If OCR certain language, only include same language
            #
            if not roi.bScannedOCR or (
                    child_box.bScannedOCR == roi.bScannedOCR
                    and (
                            child_box.scannedOCRCode == roi.scannedOCRCode
                            or (child_box.scannedOCRCode == 'eng' and roi.scannedOCRCode == '')
                            or (child_box.scannedOCRCode == '' and roi.scannedOCRCode == 'eng'))):
                tmp_leaves = get_leaves_from_roi(child_box, include_all)
                leaves.extend(tmp_leaves)

    return leaves


def GetDocumentNumPages(iqv: IQVDocument):
    """
    Use ground truth for historical data. Use
    IQVDocumentFeedbackResultsList (source="post") for
    production data.

    :returns int
    """
    num_pages = len(iqv.DocumentImages)
    if iqv.NumPDFPages > num_pages:
        num_pages = iqv.NumPDFPages
    if iqv.DocumentGroundTruth is not None:
        if iqv.DocumentGroundTruth.DocumentNumPages > num_pages:
            num_pages = iqv.DocumentGroundTruth.DocumentNumPages
    return num_pages


def GetDocumentDocClass(iqv: IQVDocument):
    """
    Use ground truth for historical data. Use
    IQVDocumentFeedbackResultsList (source="post") for
    production data.
    Cast this as proper case / title.
    Study --> Core (using "Core" in historical data)
    Country
    Site

    default is Site, but this should NEVER be blank!

    :returns proper case (title) of the document class,
        such as "Core", "Country", "Site"
    """
    docClass = ""
    if iqv.DocumentGroundTruth is not None:
        docClass = iqv.DocumentGroundTruth.Document_Class
    if len(docClass) == 0:
        for results in iqv.IQVDocumentFeedbackResultsList:
            if results.feedback_source.lower() == "post":
                docClass = results.document_class
    docClass = docClass.title()
    if docClass == "Study":
        docClass = "Core"
    #
    # default if unknown
    #
    if len(docClass) == 0:
        docClass = "Site"
    return docClass


def _get_page_roi(iqv_document: IQVDocument, pages: List[int] = None) -> IQVPageROI:
    """Get page rois from input document with generator."""
    if not pages:
        pages = [1, 2, 3]

    for page_roi in iqv_document.DocumentImages:

        if page_roi.PageSequenceIndex not in pages:
            continue

        yield page_roi


def get_document_header_text(iqv_document: IQVDocument, pages: List[int] = None) -> str:
    """
    Use spatial information to filter only header
    """
    # Ratio based on on letter settings 1.5 inches / 11 inches
    relative_header_area = Constants.RELATIVE_AREA_HEADER

    pages_text = []

    for page_roi in _get_page_roi(iqv_document, pages):
        max_y_inches = relative_header_area * page_roi.OriginalROIHeightInches
        pages_text.append(get_page_text_by_location(page_roi, max_y_inches=max_y_inches))

    return ' '.join(pages_text)


def get_document_footer_text(iqv_document: IQVDocument, relative_footer_area: float = None,
                             pages: List[int] = None, clean_non_letter_chars=True) -> str:
    """
    Fetch text from the footer area of document.

    Default relative footer area is based on letter format ~ 9.5 inches / 11 inches.
    """
    pages_text = []

    if not relative_footer_area:
        relative_footer_area = 1 - Constants.RELATIVE_AREA_HEADER

    for page_roi in _get_page_roi(iqv_document, pages):
        min_y_inches = relative_footer_area * page_roi.OriginalROIHeightInches
        pages_text.append(get_page_text_by_location(page_roi, min_y_inches=min_y_inches,
                                                    clean_non_letter_chars=clean_non_letter_chars))

    return ' '.join(pages_text)


def get_document_title_text(iqv_document: IQVDocument) -> str:
    """
    Use spatial information to filter only title text.
    """
    page_roi = next(_get_page_roi(iqv_document, [1]), None)

    if not page_roi:
        return ''

    title_min_y_area_inches = Constants.RELATIVE_AREA_HEADER * page_roi.OriginalROIHeightInches

    # Ratio based on letter format settings 5 inches / 11 inches
    title_max_y_area_relative = 0.45
    title_max_y_area_inches = title_max_y_area_relative * page_roi.OriginalROIHeightInches

    return get_page_text_by_location(page_roi, min_y_inches=title_min_y_area_inches,
                                     max_y_inches=title_max_y_area_inches)


def get_page_text_by_location(page_roi: IQVPageROI, min_y_inches: float = 0.0, max_y_inches: float = None,
                              min_x_inches: float = 0.0, max_x_inches: float = None,
                              clean_non_letter_chars: bool = True) -> str:
    """
    Use spatial coordinates to filter and fetch text rois from input page.
    """
    if max_y_inches is None:
        max_y_inches = page_roi.OriginalROIHeightInches

    if max_x_inches is None:
        max_x_inches = page_roi.OriginalROIWidthInches

    max_x = Constants.PPI_RESOLUTION * max_x_inches
    min_x = Constants.PPI_RESOLUTION * min_x_inches
    max_y = Constants.PPI_RESOLUTION * max_y_inches
    min_y = Constants.PPI_RESOLUTION * min_y_inches

    roi_list = get_leaves_from_roi(page_roi)
    matching_roi_texts = []

    for roi in roi_list:
        rect = roi.rectangleGlobalLocationOnPage
        roi_text = roi.GetFullText().strip()

        if (rect.X >= min_x and rect.X <= max_x and
                rect.Y >= min_y and rect.Y <= max_y and
                len(roi_text) > 0):
            text = re.sub(r'[^A-Za-z ]+', '', roi_text).strip() if clean_non_letter_chars else roi_text

            if len(text) > 1:
                matching_roi_texts.append(text)

    return ' '.join(matching_roi_texts)


def get_leaves_from_iqv_document(iqv_document: IQVDocument, include_all=False):
    """
    Get descendants of the roi that are terminal leaves
    filter_regions -> Get all roi or return only filter regions
    """
    leaves = []
    for page_roi in iqv_document.DocumentImages:
        tmp_leaves = get_leaves_from_roi(page_roi, include_all)
        leaves.extend(tmp_leaves)

    return leaves


def GetIQVAttributeCandidatesSorted(iqvDocument: IQVDocument,
                                    attributeKey: str = "",
                                    bSortDescending: bool = True):
    """
    Get list of all of the IQVAttributeCandidate objects
    in this IQVDocument, sorted by RawProbabilityScore
    :param iqvDocument: input document object IQVDocument
    :param attributeKey: filter by this key (return all candidates if blank)
    :param bSortDescending: sort by field RawProbabilityScore ASC if False, DESC if True (default)
    :return sorted list of IQVAttributeCandidate objects
    """

    try:
        list = []
        if len(attributeKey) > 0:
            list = [x for x in iqvDocument.IQVAttributeCandidates if x.AttributeKey == attributeKey]
        else:
            list = [x for x in iqvDocument.IQVAttributeCandidates]

        list.sort(key=lambda x: x.RawProbabilitiyScore, reverse=bSortDescending)
        return list

    except Exception as e:
        logger.exception("Error getting sorted candidates")
        return None
